* ENCODING=ISO-8859-1
NAME          K5050W11.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  IC30              
 L  IC31              
 L  IC32              
 L  IC33              
 L  IC34              
 L  IC35              
 L  IC36              
 L  IC37              
 L  IC38              
 L  IC39              
 L  IC40              
 L  IC41              
 L  IC42              
 L  IC43              
 L  IC44              
 L  IC45              
 L  IC46              
 L  IC47              
 L  IC48              
 L  IC49              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  550
    C0000000            R0000000                                 66
    C0000000            IC0                                       1
    C0000001            OBJROW                                  211
    C0000001            R0000000                                953
    C0000001            IC1                                       1
    C0000002            OBJROW                                  415
    C0000002            R0000000                                200
    C0000002            IC2                                       1
    C0000003            OBJROW                                  235
    C0000003            R0000000                                 75
    C0000003            IC3                                       1
    C0000004            OBJROW                                  543
    C0000004            R0000000                                230
    C0000004            IC4                                       1
    C0000005            OBJROW                                  796
    C0000005            R0000000                                957
    C0000005            IC5                                       1
    C0000006            OBJROW                                  895
    C0000006            R0000000                                942
    C0000006            IC6                                       1
    C0000007            OBJROW                                  466
    C0000007            R0000000                                101
    C0000007            IC7                                       1
    C0000008            OBJROW                                  432
    C0000008            R0000000                                406
    C0000008            IC8                                       1
    C0000009            OBJROW                                  842
    C0000009            R0000000                                821
    C0000009            IC9                                       1
    C0000010            OBJROW                                  705
    C0000010            R0000000                                 38
    C0000010            IC10                                      1
    C0000011            OBJROW                                  682
    C0000011            R0000000                                851
    C0000011            IC11                                      1
    C0000012            OBJROW                                  183
    C0000012            R0000000                                984
    C0000012            IC12                                      1
    C0000013            OBJROW                                  316
    C0000013            R0000000                                  3
    C0000013            IC13                                      1
    C0000014            OBJROW                                  375
    C0000014            R0000000                                536
    C0000014            IC14                                      1
    C0000015            OBJROW                                    4
    C0000015            R0000000                                 51
    C0000015            IC15                                      1
    C0000016            OBJROW                                  439
    C0000016            R0000000                                830
    C0000016            IC16                                      1
    C0000017            OBJROW                                  388
    C0000017            R0000000                                428
    C0000017            IC17                                      1
    C0000018            OBJROW                                  159
    C0000018            R0000000                                351
    C0000018            IC18                                      1
    C0000019            OBJROW                                   66
    C0000019            R0000000                                866
    C0000019            IC19                                      1
    C0000020            OBJROW                                  121
    C0000020            R0000000                                768
    C0000020            IC20                                      1
    C0000021            OBJROW                                  824
    C0000021            R0000000                                107
    C0000021            IC21                                      1
    C0000022            OBJROW                                   18
    C0000022            R0000000                                864
    C0000022            IC22                                      1
    C0000023            OBJROW                                  560
    C0000023            R0000000                                755
    C0000023            IC23                                      1
    C0000024            OBJROW                                  426
    C0000024            R0000000                                726
    C0000024            IC24                                      1
    C0000025            OBJROW                                  416
    C0000025            R0000000                                325
    C0000025            IC25                                      1
    C0000026            OBJROW                                  211
    C0000026            R0000000                                876
    C0000026            IC26                                      1
    C0000027            OBJROW                                   62
    C0000027            R0000000                                198
    C0000027            IC27                                      1
    C0000028            OBJROW                                  317
    C0000028            R0000000                                485
    C0000028            IC28                                      1
    C0000029            OBJROW                                  164
    C0000029            R0000000                                836
    C0000029            IC29                                      1
    C0000030            OBJROW                                  791
    C0000030            R0000000                                119
    C0000030            IC30                                      1
    C0000031            OBJROW                                  162
    C0000031            R0000000                                 60
    C0000031            IC31                                      1
    C0000032            OBJROW                                  865
    C0000032            R0000000                                357
    C0000032            IC32                                      1
    C0000033            OBJROW                                  810
    C0000033            R0000000                                469
    C0000033            IC33                                      1
    C0000034            OBJROW                                  889
    C0000034            R0000000                                238
    C0000034            IC34                                      1
    C0000035            OBJROW                                  976
    C0000035            R0000000                                173
    C0000035            IC35                                      1
    C0000036            OBJROW                                  594
    C0000036            R0000000                                958
    C0000036            IC36                                      1
    C0000037            OBJROW                                  952
    C0000037            R0000000                                901
    C0000037            IC37                                      1
    C0000038            OBJROW                                  562
    C0000038            R0000000                                126
    C0000038            IC38                                      1
    C0000039            OBJROW                                  417
    C0000039            R0000000                                507
    C0000039            IC39                                      1
    C0000040            OBJROW                                    2
    C0000040            R0000000                                656
    C0000040            IC40                                      1
    C0000041            OBJROW                                  817
    C0000041            R0000000                                217
    C0000041            IC41                                      1
    C0000042            OBJROW                                  554
    C0000042            R0000000                                994
    C0000042            IC42                                      1
    C0000043            OBJROW                                    9
    C0000043            R0000000                                457
    C0000043            IC43                                      1
    C0000044            OBJROW                                  128
    C0000044            R0000000                                162
    C0000044            IC44                                      1
    C0000045            OBJROW                                  619
    C0000045            R0000000                                727
    C0000045            IC45                                      1
    C0000046            OBJROW                                  934
    C0000046            R0000000                                 27
    C0000046            IC46                                      1
    C0000047            OBJROW                                  805
    C0000047            R0000000                                879
    C0000047            IC47                                      1
    C0000048            OBJROW                                  100
    C0000048            R0000000                                843
    C0000048            IC48                                      1
    C0000049            OBJROW                                  334
    C0000049            R0000000                                688
    C0000049            IC49                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      444
    x1                  IC1                                       1
    x1                  interdictionBudget                      207
    x2                  IC2                                       1
    x2                  interdictionBudget                      628
    x3                  IC3                                       1
    x3                  interdictionBudget                      437
    x4                  IC4                                       1
    x4                  interdictionBudget                      709
    x5                  IC5                                       1
    x5                  interdictionBudget                      477
    x6                  IC6                                       1
    x6                  interdictionBudget                      637
    x7                  IC7                                       1
    x7                  interdictionBudget                      869
    x8                  IC8                                       1
    x8                  interdictionBudget                      758
    x9                  IC9                                       1
    x9                  interdictionBudget                      571
    x10                 IC10                                      1
    x10                 interdictionBudget                      607
    x11                 IC11                                      1
    x11                 interdictionBudget                       84
    x12                 IC12                                      1
    x12                 interdictionBudget                      477
    x13                 IC13                                      1
    x13                 interdictionBudget                      485
    x14                 IC14                                      1
    x14                 interdictionBudget                      933
    x15                 IC15                                      1
    x15                 interdictionBudget                      917
    x16                 IC16                                      1
    x16                 interdictionBudget                      173
    x17                 IC17                                      1
    x17                 interdictionBudget                      141
    x18                 IC18                                      1
    x18                 interdictionBudget                      470
    x19                 IC19                                      1
    x19                 interdictionBudget                      933
    x20                 IC20                                      1
    x20                 interdictionBudget                      790
    x21                 IC21                                      1
    x21                 interdictionBudget                      291
    x22                 IC22                                      1
    x22                 interdictionBudget                      432
    x23                 IC23                                      1
    x23                 interdictionBudget                      793
    x24                 IC24                                      1
    x24                 interdictionBudget                      306
    x25                 IC25                                      1
    x25                 interdictionBudget                       47
    x26                 IC26                                      1
    x26                 interdictionBudget                      467
    x27                 IC27                                      1
    x27                 interdictionBudget                      520
    x28                 IC28                                      1
    x28                 interdictionBudget                      201
    x29                 IC29                                      1
    x29                 interdictionBudget                      905
    x30                 IC30                                      1
    x30                 interdictionBudget                      921
    x31                 IC31                                      1
    x31                 interdictionBudget                      850
    x32                 IC32                                      1
    x32                 interdictionBudget                      905
    x33                 IC33                                      1
    x33                 interdictionBudget                      850
    x34                 IC34                                      1
    x34                 interdictionBudget                      767
    x35                 IC35                                      1
    x35                 interdictionBudget                      163
    x36                 IC36                                      1
    x36                 interdictionBudget                      895
    x37                 IC37                                      1
    x37                 interdictionBudget                      579
    x38                 IC38                                      1
    x38                 interdictionBudget                       64
    x39                 IC39                                      1
    x39                 interdictionBudget                       17
    x40                 IC40                                      1
    x40                 interdictionBudget                      738
    x41                 IC41                                      1
    x41                 interdictionBudget                      281
    x42                 IC42                                      1
    x42                 interdictionBudget                       98
    x43                 IC43                                      1
    x43                 interdictionBudget                      567
    x44                 IC44                                      1
    x44                 interdictionBudget                      132
    x45                 IC45                                      1
    x45                 interdictionBudget                      191
    x46                 IC46                                      1
    x46                 interdictionBudget                      626
    x47                 IC47                                      1
    x47                 interdictionBudget                      576
    x48                 IC48                                      1
    x48                 interdictionBudget                      250
    x49                 IC49                                      1
    x49                 interdictionBudget                      384
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                              12593
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 IC30                                      1
    rhs                 IC31                                      1
    rhs                 IC32                                      1
    rhs                 IC33                                      1
    rhs                 IC34                                      1
    rhs                 IC35                                      1
    rhs                 IC36                                      1
    rhs                 IC37                                      1
    rhs                 IC38                                      1
    rhs                 IC39                                      1
    rhs                 IC40                                      1
    rhs                 IC41                                      1
    rhs                 IC42                                      1
    rhs                 IC43                                      1
    rhs                 IC44                                      1
    rhs                 IC45                                      1
    rhs                 IC46                                      1
    rhs                 IC47                                      1
    rhs                 IC48                                      1
    rhs                 IC49                                      1
    rhs                 interdictionBudget                    12782
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 C0000030          
 BV bnd                 C0000031          
 BV bnd                 C0000032          
 BV bnd                 C0000033          
 BV bnd                 C0000034          
 BV bnd                 C0000035          
 BV bnd                 C0000036          
 BV bnd                 C0000037          
 BV bnd                 C0000038          
 BV bnd                 C0000039          
 BV bnd                 C0000040          
 BV bnd                 C0000041          
 BV bnd                 C0000042          
 BV bnd                 C0000043          
 BV bnd                 C0000044          
 BV bnd                 C0000045          
 BV bnd                 C0000046          
 BV bnd                 C0000047          
 BV bnd                 C0000048          
 BV bnd                 C0000049          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
 BV bnd                 x30               
 BV bnd                 x31               
 BV bnd                 x32               
 BV bnd                 x33               
 BV bnd                 x34               
 BV bnd                 x35               
 BV bnd                 x36               
 BV bnd                 x37               
 BV bnd                 x38               
 BV bnd                 x39               
 BV bnd                 x40               
 BV bnd                 x41               
 BV bnd                 x42               
 BV bnd                 x43               
 BV bnd                 x44               
 BV bnd                 x45               
 BV bnd                 x46               
 BV bnd                 x47               
 BV bnd                 x48               
 BV bnd                 x49               
ENDATA
