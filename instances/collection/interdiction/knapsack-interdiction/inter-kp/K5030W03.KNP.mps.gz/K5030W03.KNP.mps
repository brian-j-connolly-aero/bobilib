* ENCODING=ISO-8859-1
NAME          K5030W03.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  356
    C0000000            R0000000                                872
    C0000000            IC0                                       1
    C0000001            OBJROW                                  662
    C0000001            R0000000                                403
    C0000001            IC1                                       1
    C0000002            OBJROW                                  149
    C0000002            R0000000                                128
    C0000002            IC2                                       1
    C0000003            OBJROW                                  780
    C0000003            R0000000                                449
    C0000003            IC3                                       1
    C0000004            OBJROW                                  134
    C0000004            R0000000                                601
    C0000004            IC4                                       1
    C0000005            OBJROW                                   36
    C0000005            R0000000                                450
    C0000005            IC5                                       1
    C0000006            OBJROW                                  479
    C0000006            R0000000                                359
    C0000006            IC6                                       1
    C0000007            OBJROW                                  420
    C0000007            R0000000                                251
    C0000007            IC7                                       1
    C0000008            OBJROW                                  735
    C0000008            R0000000                                311
    C0000008            IC8                                       1
    C0000009            OBJROW                                  258
    C0000009            R0000000                                 76
    C0000009            IC9                                       1
    C0000010            OBJROW                                  680
    C0000010            R0000000                                269
    C0000010            IC10                                      1
    C0000011            OBJROW                                  539
    C0000011            R0000000                                 29
    C0000011            IC11                                      1
    C0000012            OBJROW                                  894
    C0000012            R0000000                                846
    C0000012            IC12                                      1
    C0000013            OBJROW                                  901
    C0000013            R0000000                                181
    C0000013            IC13                                      1
    C0000014            OBJROW                                  956
    C0000014            R0000000                                236
    C0000014            IC14                                      1
    C0000015            OBJROW                                  159
    C0000015            R0000000                                294
    C0000015            IC15                                      1
    C0000016            OBJROW                                    2
    C0000016            R0000000                                197
    C0000016            IC16                                      1
    C0000017            OBJROW                                  777
    C0000017            R0000000                                382
    C0000017            IC17                                      1
    C0000018            OBJROW                                  200
    C0000018            R0000000                                435
    C0000018            IC18                                      1
    C0000019            OBJROW                                  259
    C0000019            R0000000                                647
    C0000019            IC19                                      1
    C0000020            OBJROW                                  606
    C0000020            R0000000                                 36
    C0000020            IC20                                      1
    C0000021            OBJROW                                  221
    C0000021            R0000000                                117
    C0000021            IC21                                      1
    C0000022            OBJROW                                  590
    C0000022            R0000000                                310
    C0000022            IC22                                      1
    C0000023            OBJROW                                   43
    C0000023            R0000000                                821
    C0000023            IC23                                      1
    C0000024            OBJROW                                  559
    C0000024            R0000000                                932
    C0000024            IC24                                      1
    C0000025            OBJROW                                  531
    C0000025            R0000000                                958
    C0000025            IC25                                      1
    C0000026            OBJROW                                  735
    C0000026            R0000000                                148
    C0000026            IC26                                      1
    C0000027            OBJROW                                  491
    C0000027            R0000000                                 39
    C0000027            IC27                                      1
    C0000028            OBJROW                                  455
    C0000028            R0000000                                828
    C0000028            IC28                                      1
    C0000029            OBJROW                                  195
    C0000029            R0000000                                421
    C0000029            IC29                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      494
    x1                  IC1                                       1
    x1                  interdictionBudget                      349
    x2                  IC2                                       1
    x2                  interdictionBudget                       22
    x3                  IC3                                       1
    x3                  interdictionBudget                      171
    x4                  IC4                                       1
    x4                  interdictionBudget                      296
    x5                  IC5                                       1
    x5                  interdictionBudget                      713
    x6                  IC6                                       1
    x6                  interdictionBudget                      226
    x7                  IC7                                       1
    x7                  interdictionBudget                       47
    x8                  IC8                                       1
    x8                  interdictionBudget                      403
    x9                  IC9                                       1
    x9                  interdictionBudget                      176
    x10                 IC10                                      1
    x10                 interdictionBudget                      931
    x11                 IC11                                      1
    x11                 interdictionBudget                      870
    x12                 IC12                                      1
    x12                 interdictionBudget                      532
    x13                 IC13                                      1
    x13                 interdictionBudget                      574
    x14                 IC14                                      1
    x14                 interdictionBudget                      484
    x15                 IC15                                      1
    x15                 interdictionBudget                      159
    x16                 IC16                                      1
    x16                 interdictionBudget                      914
    x17                 IC17                                      1
    x17                 interdictionBudget                      296
    x18                 IC18                                      1
    x18                 interdictionBudget                       66
    x19                 IC19                                      1
    x19                 interdictionBudget                       33
    x20                 IC20                                      1
    x20                 interdictionBudget                      232
    x21                 IC21                                      1
    x21                 interdictionBudget                      690
    x22                 IC22                                      1
    x22                 interdictionBudget                      969
    x23                 IC23                                      1
    x23                 interdictionBudget                      162
    x24                 IC24                                      1
    x24                 interdictionBudget                      841
    x25                 IC25                                      1
    x25                 interdictionBudget                      576
    x26                 IC26                                      1
    x26                 interdictionBudget                      323
    x27                 IC27                                      1
    x27                 interdictionBudget                      920
    x28                 IC28                                      1
    x28                 interdictionBudget                      761
    x29                 IC29                                      1
    x29                 interdictionBudget                      642
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               6013
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 interdictionBudget                     6936
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
ENDATA
