* ENCODING=ISO-8859-1
NAME          K5050W01.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  IC30              
 L  IC31              
 L  IC32              
 L  IC33              
 L  IC34              
 L  IC35              
 L  IC36              
 L  IC37              
 L  IC38              
 L  IC39              
 L  IC40              
 L  IC41              
 L  IC42              
 L  IC43              
 L  IC44              
 L  IC45              
 L  IC46              
 L  IC47              
 L  IC48              
 L  IC49              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  786
    C0000000            R0000000                                412
    C0000000            IC0                                       1
    C0000001            OBJROW                                  529
    C0000001            R0000000                                414
    C0000001            IC1                                       1
    C0000002            OBJROW                                  432
    C0000002            R0000000                                156
    C0000002            IC2                                       1
    C0000003            OBJROW                                  730
    C0000003            R0000000                                375
    C0000003            IC3                                       1
    C0000004            OBJROW                                  865
    C0000004            R0000000                                 82
    C0000004            IC4                                       1
    C0000005            OBJROW                                  760
    C0000005            R0000000                                921
    C0000005            IC5                                       1
    C0000006            OBJROW                                  683
    C0000006            R0000000                                544
    C0000006            IC6                                       1
    C0000007            OBJROW                                  238
    C0000007            R0000000                                594
    C0000007            IC7                                       1
    C0000008            OBJROW                                  236
    C0000008            R0000000                                792
    C0000008            IC8                                       1
    C0000009            OBJROW                                  495
    C0000009            R0000000                                323
    C0000009            IC9                                       1
    C0000010            OBJROW                                  178
    C0000010            R0000000                                774
    C0000010            IC10                                      1
    C0000011            OBJROW                                  905
    C0000011            R0000000                                661
    C0000011            IC11                                      1
    C0000012            OBJROW                                   58
    C0000012            R0000000                                 46
    C0000012            IC12                                      1
    C0000013            OBJROW                                  745
    C0000013            R0000000                                379
    C0000013            IC13                                      1
    C0000014            OBJROW                                  744
    C0000014            R0000000                                904
    C0000014            IC14                                      1
    C0000015            OBJROW                                   99
    C0000015            R0000000                                979
    C0000015            IC15                                      1
    C0000016            OBJROW                                  688
    C0000016            R0000000                                334
    C0000016            IC16                                      1
    C0000017            OBJROW                                  849
    C0000017            R0000000                                389
    C0000017            IC17                                      1
    C0000018            OBJROW                                  985
    C0000018            R0000000                                 86
    C0000018            IC18                                      1
    C0000019            OBJROW                                  114
    C0000019            R0000000                                541
    C0000019            IC19                                      1
    C0000020            OBJROW                                  239
    C0000020            R0000000                                878
    C0000020            IC20                                      1
    C0000021            OBJROW                                  164
    C0000021            R0000000                                859
    C0000021            IC21                                      1
    C0000022            OBJROW                                  629
    C0000022            R0000000                                512
    C0000022            IC22                                      1
    C0000023            OBJROW                                  485
    C0000023            R0000000                                923
    C0000023            IC23                                      1
    C0000024            OBJROW                                  118
    C0000024            R0000000                                512
    C0000024            IC24                                      1
    C0000025            OBJROW                                  939
    C0000025            R0000000                                849
    C0000025            IC25                                      1
    C0000026            OBJROW                                  287
    C0000026            R0000000                                 58
    C0000026            IC26                                      1
    C0000027            OBJROW                                  515
    C0000027            R0000000                                407
    C0000027            IC27                                      1
    C0000028            OBJROW                                  744
    C0000028            R0000000                                868
    C0000028            IC28                                      1
    C0000029            OBJROW                                  641
    C0000029            R0000000                                397
    C0000029            IC29                                      1
    C0000030            OBJROW                                  441
    C0000030            R0000000                                341
    C0000030            IC30                                      1
    C0000031            OBJROW                                  193
    C0000031            R0000000                                589
    C0000031            IC31                                      1
    C0000032            OBJROW                                  673
    C0000032            R0000000                                229
    C0000032            IC32                                      1
    C0000033            OBJROW                                  217
    C0000033            R0000000                                 70
    C0000033            IC33                                      1
    C0000034            OBJROW                                  817
    C0000034            R0000000                                563
    C0000034            IC34                                      1
    C0000035            OBJROW                                  481
    C0000035            R0000000                                264
    C0000035            IC35                                      1
    C0000036            OBJROW                                  458
    C0000036            R0000000                                297
    C0000036            IC36                                      1
    C0000037            OBJROW                                  913
    C0000037            R0000000                                162
    C0000037            IC37                                      1
    C0000038            OBJROW                                  128
    C0000038            R0000000                                 49
    C0000038            IC38                                      1
    C0000039            OBJROW                                  403
    C0000039            R0000000                                200
    C0000039            IC39                                      1
    C0000040            OBJROW                                    8
    C0000040            R0000000                                291
    C0000040            IC40                                      1
    C0000041            OBJROW                                  307
    C0000041            R0000000                                400
    C0000041            IC41                                      1
    C0000042            OBJROW                                   38
    C0000042            R0000000                                257
    C0000042            IC42                                      1
    C0000043            OBJROW                                  285
    C0000043            R0000000                                857
    C0000043            IC43                                      1
    C0000044            OBJROW                                  740
    C0000044            R0000000                                602
    C0000044            IC44                                      1
    C0000045            OBJROW                                  182
    C0000045            R0000000                                175
    C0000045            IC45                                      1
    C0000046            OBJROW                                  396
    C0000046            R0000000                                 60
    C0000046            IC46                                      1
    C0000047            OBJROW                                  543
    C0000047            R0000000                                423
    C0000047            IC47                                      1
    C0000048            OBJROW                                  692
    C0000048            R0000000                                620
    C0000048            IC48                                      1
    C0000049            OBJROW                                  615
    C0000049            R0000000                                989
    C0000049            IC49                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      680
    x1                  IC1                                       1
    x1                  interdictionBudget                      635
    x2                  IC2                                       1
    x2                  interdictionBudget                      678
    x3                  IC3                                       1
    x3                  interdictionBudget                      837
    x4                  IC4                                       1
    x4                  interdictionBudget                       14
    x5                  IC5                                       1
    x5                  interdictionBudget                      755
    x6                  IC6                                       1
    x6                  interdictionBudget                      216
    x7                  IC7                                       1
    x7                  interdictionBudget                      769
    x8                  IC8                                       1
    x8                  interdictionBudget                      961
    x9                  IC9                                       1
    x9                  interdictionBudget                      802
    x10                 IC10                                      1
    x10                 interdictionBudget                      545
    x11                 IC11                                      1
    x11                 interdictionBudget                      432
    x12                 IC12                                      1
    x12                 interdictionBudget                      882
    x13                 IC13                                      1
    x13                 interdictionBudget                      801
    x14                 IC14                                      1
    x14                 interdictionBudget                      602
    x15                 IC15                                      1
    x15                 interdictionBudget                      353
    x16                 IC16                                      1
    x16                 interdictionBudget                      600
    x17                 IC17                                      1
    x17                 interdictionBudget                      442
    x18                 IC18                                      1
    x18                 interdictionBudget                      289
    x19                 IC19                                      1
    x19                 interdictionBudget                      578
    x20                 IC20                                      1
    x20                 interdictionBudget                      991
    x21                 IC21                                      1
    x21                 interdictionBudget                      700
    x22                 IC22                                      1
    x22                 interdictionBudget                      215
    x23                 IC23                                      1
    x23                 interdictionBudget                       68
    x24                 IC24                                      1
    x24                 interdictionBudget                      765
    x25                 IC25                                      1
    x25                 interdictionBudget                      357
    x26                 IC26                                      1
    x26                 interdictionBudget                      574
    x27                 IC27                                      1
    x27                 interdictionBudget                      325
    x28                 IC28                                      1
    x28                 interdictionBudget                      838
    x29                 IC29                                      1
    x29                 interdictionBudget                      811
    x30                 IC30                                      1
    x30                 interdictionBudget                       88
    x31                 IC31                                      1
    x31                 interdictionBudget                      515
    x32                 IC32                                      1
    x32                 interdictionBudget                      726
    x33                 IC33                                      1
    x33                 interdictionBudget                      244
    x34                 IC34                                      1
    x34                 interdictionBudget                      927
    x35                 IC35                                      1
    x35                 interdictionBudget                      204
    x36                 IC36                                      1
    x36                 interdictionBudget                      669
    x37                 IC37                                      1
    x37                 interdictionBudget                      606
    x38                 IC38                                      1
    x38                 interdictionBudget                      189
    x39                 IC39                                      1
    x39                 interdictionBudget                       54
    x40                 IC40                                      1
    x40                 interdictionBudget                      947
    x41                 IC41                                      1
    x41                 interdictionBudget                      920
    x42                 IC42                                      1
    x42                 interdictionBudget                      521
    x43                 IC43                                      1
    x43                 interdictionBudget                      225
    x44                 IC44                                      1
    x44                 interdictionBudget                      177
    x45                 IC45                                      1
    x45                 interdictionBudget                      762
    x46                 IC46                                      1
    x46                 interdictionBudget                      303
    x47                 IC47                                      1
    x47                 interdictionBudget                      523
    x48                 IC48                                      1
    x48                 interdictionBudget                      199
    x49                 IC49                                      1
    x49                 interdictionBudget                      268
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                              11703
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 IC30                                      1
    rhs                 IC31                                      1
    rhs                 IC32                                      1
    rhs                 IC33                                      1
    rhs                 IC34                                      1
    rhs                 IC35                                      1
    rhs                 IC36                                      1
    rhs                 IC37                                      1
    rhs                 IC38                                      1
    rhs                 IC39                                      1
    rhs                 IC40                                      1
    rhs                 IC41                                      1
    rhs                 IC42                                      1
    rhs                 IC43                                      1
    rhs                 IC44                                      1
    rhs                 IC45                                      1
    rhs                 IC46                                      1
    rhs                 IC47                                      1
    rhs                 IC48                                      1
    rhs                 IC49                                      1
    rhs                 interdictionBudget                    13291
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 C0000030          
 BV bnd                 C0000031          
 BV bnd                 C0000032          
 BV bnd                 C0000033          
 BV bnd                 C0000034          
 BV bnd                 C0000035          
 BV bnd                 C0000036          
 BV bnd                 C0000037          
 BV bnd                 C0000038          
 BV bnd                 C0000039          
 BV bnd                 C0000040          
 BV bnd                 C0000041          
 BV bnd                 C0000042          
 BV bnd                 C0000043          
 BV bnd                 C0000044          
 BV bnd                 C0000045          
 BV bnd                 C0000046          
 BV bnd                 C0000047          
 BV bnd                 C0000048          
 BV bnd                 C0000049          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
 BV bnd                 x30               
 BV bnd                 x31               
 BV bnd                 x32               
 BV bnd                 x33               
 BV bnd                 x34               
 BV bnd                 x35               
 BV bnd                 x36               
 BV bnd                 x37               
 BV bnd                 x38               
 BV bnd                 x39               
 BV bnd                 x40               
 BV bnd                 x41               
 BV bnd                 x42               
 BV bnd                 x43               
 BV bnd                 x44               
 BV bnd                 x45               
 BV bnd                 x46               
 BV bnd                 x47               
 BV bnd                 x48               
 BV bnd                 x49               
ENDATA
