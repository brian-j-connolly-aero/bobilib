* ENCODING=ISO-8859-1
NAME          K5050W17.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  IC30              
 L  IC31              
 L  IC32              
 L  IC33              
 L  IC34              
 L  IC35              
 L  IC36              
 L  IC37              
 L  IC38              
 L  IC39              
 L  IC40              
 L  IC41              
 L  IC42              
 L  IC43              
 L  IC44              
 L  IC45              
 L  IC46              
 L  IC47              
 L  IC48              
 L  IC49              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  930
    C0000000            R0000000                                556
    C0000000            IC0                                       1
    C0000001            OBJROW                                  937
    C0000001            R0000000                                822
    C0000001            IC1                                       1
    C0000002            OBJROW                                  464
    C0000002            R0000000                                188
    C0000002            IC2                                       1
    C0000003            OBJROW                                  699
    C0000003            R0000000                                102
    C0000003            IC3                                       1
    C0000004            OBJROW                                  168
    C0000004            R0000000                                308
    C0000004            IC4                                       1
    C0000005            OBJROW                                  451
    C0000005            R0000000                                998
    C0000005            IC5                                       1
    C0000006            OBJROW                                  446
    C0000006            R0000000                                213
    C0000006            IC6                                       1
    C0000007            OBJROW                                  964
    C0000007            R0000000                                 68
    C0000007            IC7                                       1
    C0000008            OBJROW                                  550
    C0000008            R0000000                                959
    C0000008            IC8                                       1
    C0000009            OBJROW                                  285
    C0000009            R0000000                                828
    C0000009            IC9                                       1
    C0000010            OBJROW                                  854
    C0000010            R0000000                                357
    C0000010            IC10                                      1
    C0000011            OBJROW                                  621
    C0000011            R0000000                                462
    C0000011            IC11                                      1
    C0000012            OBJROW                                  918
    C0000012            R0000000                                595
    C0000012            IC12                                      1
    C0000013            OBJROW                                  909
    C0000013            R0000000                                839
    C0000013            IC13                                      1
    C0000014            OBJROW                                  500
    C0000014            R0000000                                940
    C0000014            IC14                                      1
    C0000015            OBJROW                                   38
    C0000015            R0000000                                447
    C0000015            IC15                                      1
    C0000016            OBJROW                                  277
    C0000016            R0000000                                778
    C0000016            IC16                                      1
    C0000017            OBJROW                                  438
    C0000017            R0000000                                392
    C0000017            IC17                                      1
    C0000018            OBJROW                                  541
    C0000018            R0000000                                 59
    C0000018            IC18                                      1
    C0000019            OBJROW                                  974
    C0000019            R0000000                                496
    C0000019            IC19                                      1
    C0000020            OBJROW                                  643
    C0000020            R0000000                                 35
    C0000020            IC20                                      1
    C0000021            OBJROW                                  448
    C0000021            R0000000                                200
    C0000021            IC21                                      1
    C0000022            OBJROW                                  737
    C0000022            R0000000                                945
    C0000022            IC22                                      1
    C0000023            OBJROW                                  417
    C0000023            R0000000                                993
    C0000023            IC23                                      1
    C0000024            OBJROW                                  161
    C0000024            R0000000                                522
    C0000024            IC24                                      1
    C0000025            OBJROW                                  138
    C0000025            R0000000                                127
    C0000025            IC25                                      1
    C0000026            OBJROW                                  657
    C0000026            R0000000                                500
    C0000026            IC26                                      1
    C0000027            OBJROW                                  216
    C0000027            R0000000                                781
    C0000027            IC27                                      1
    C0000028            OBJROW                                  115
    C0000028            R0000000                                254
    C0000028            IC28                                      1
    C0000029            OBJROW                                  368
    C0000029            R0000000                                835
    C0000029            IC29                                      1
    C0000030            OBJROW                                  537
    C0000030            R0000000                                991
    C0000030            IC30                                      1
    C0000031            OBJROW                                  274
    C0000031            R0000000                                604
    C0000031            IC31                                      1
    C0000032            OBJROW                                  617
    C0000032            R0000000                                 77
    C0000032            IC32                                      1
    C0000033            OBJROW                                  154
    C0000033            R0000000                                165
    C0000033            IC33                                      1
    C0000034            OBJROW                                  199
    C0000034            R0000000                                613
    C0000034            IC34                                      1
    C0000035            OBJROW                                  107
    C0000035            R0000000                                550
    C0000035            IC35                                      1
    C0000036            OBJROW                                  903
    C0000036            R0000000                                 67
    C0000036            IC36                                      1
    C0000037            OBJROW                                   44
    C0000037            R0000000                                 24
    C0000037            IC37                                      1
    C0000038            OBJROW                                  543
    C0000038            R0000000                                 51
    C0000038            IC38                                      1
    C0000039            OBJROW                                  610
    C0000039            R0000000                                 70
    C0000039            IC39                                      1
    C0000040            OBJROW                                  969
    C0000040            R0000000                                845
    C0000040            IC40                                      1
    C0000041            OBJROW                                  208
    C0000041            R0000000                                 84
    C0000041            IC41                                      1
    C0000042            OBJROW                                  530
    C0000042            R0000000                                767
    C0000042            IC42                                      1
    C0000043            OBJROW                                  857
    C0000043            R0000000                                204
    C0000043            IC43                                      1
    C0000044            OBJROW                                  304
    C0000044            R0000000                                895
    C0000044            IC44                                      1
    C0000045            OBJROW                                  507
    C0000045            R0000000                                642
    C0000045            IC45                                      1
    C0000046            OBJROW                                  374
    C0000046            R0000000                                505
    C0000046            IC46                                      1
    C0000047            OBJROW                                  397
    C0000047            R0000000                                304
    C0000047            IC47                                      1
    C0000048            OBJROW                                  414
    C0000048            R0000000                                411
    C0000048            IC48                                      1
    C0000049            OBJROW                                  139
    C0000049            R0000000                                480
    C0000049            IC49                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      824
    x1                  IC1                                       1
    x1                  interdictionBudget                       43
    x2                  IC2                                       1
    x2                  interdictionBudget                      710
    x3                  IC3                                       1
    x3                  interdictionBudget                      453
    x4                  IC4                                       1
    x4                  interdictionBudget                      156
    x5                  IC5                                       1
    x5                  interdictionBudget                      390
    x6                  IC6                                       1
    x6                  interdictionBudget                       28
    x7                  IC7                                       1
    x7                  interdictionBudget                      814
    x8                  IC8                                       1
    x8                  interdictionBudget                      620
    x9                  IC9                                       1
    x9                  interdictionBudget                      975
    x10                 IC10                                      1
    x10                 interdictionBudget                      572
    x11                 IC11                                      1
    x11                 interdictionBudget                      389
    x12                 IC12                                      1
    x12                 interdictionBudget                      133
    x13                 IC13                                      1
    x13                 interdictionBudget                      133
    x14                 IC14                                      1
    x14                 interdictionBudget                      142
    x15                 IC15                                      1
    x15                 interdictionBudget                       91
    x16                 IC16                                      1
    x16                 interdictionBudget                       96
    x17                 IC17                                      1
    x17                 interdictionBudget                      681
    x18                 IC18                                      1
    x18                 interdictionBudget                      633
    x19                 IC19                                      1
    x19                 interdictionBudget                      250
    x20                 IC20                                      1
    x20                 interdictionBudget                      231
    x21                 IC21                                      1
    x21                 interdictionBudget                      763
    x22                 IC22                                      1
    x22                 interdictionBudget                      495
    x23                 IC23                                      1
    x23                 interdictionBudget                      323
    x24                 IC24                                      1
    x24                 interdictionBudget                       88
    x25                 IC25                                      1
    x25                 interdictionBudget                      275
    x26                 IC26                                      1
    x26                 interdictionBudget                      552
    x27                 IC27                                      1
    x27                 interdictionBudget                       41
    x28                 IC28                                      1
    x28                 interdictionBudget                      873
    x29                 IC29                                      1
    x29                 interdictionBudget                      353
    x30                 IC30                                      1
    x30                 interdictionBudget                      850
    x31                 IC31                                      1
    x31                 interdictionBudget                      711
    x32                 IC32                                      1
    x32                 interdictionBudget                      364
    x33                 IC33                                      1
    x33                 interdictionBudget                       39
    x34                 IC34                                      1
    x34                 interdictionBudget                      940
    x35                 IC35                                      1
    x35                 interdictionBudget                      151
    x36                 IC36                                      1
    x36                 interdictionBudget                      562
    x37                 IC37                                      1
    x37                 interdictionBudget                      449
    x38                 IC38                                      1
    x38                 interdictionBudget                      552
    x39                 IC39                                      1
    x39                 interdictionBudget                       51
    x40                 IC40                                      1
    x40                 interdictionBudget                      968
    x41                 IC41                                      1
    x41                 interdictionBudget                      115
    x42                 IC42                                      1
    x42                 interdictionBudget                      224
    x43                 IC43                                      1
    x43                 interdictionBudget                      147
    x44                 IC44                                      1
    x44                 interdictionBudget                        8
    x45                 IC45                                      1
    x45                 interdictionBudget                      427
    x46                 IC46                                      1
    x46                 interdictionBudget                      424
    x47                 IC47                                      1
    x47                 interdictionBudget                      539
    x48                 IC48                                      1
    x48                 interdictionBudget                      918
    x49                 IC49                                      1
    x49                 interdictionBudget                      149
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                              11974
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 IC30                                      1
    rhs                 IC31                                      1
    rhs                 IC32                                      1
    rhs                 IC33                                      1
    rhs                 IC34                                      1
    rhs                 IC35                                      1
    rhs                 IC36                                      1
    rhs                 IC37                                      1
    rhs                 IC38                                      1
    rhs                 IC39                                      1
    rhs                 IC40                                      1
    rhs                 IC41                                      1
    rhs                 IC42                                      1
    rhs                 IC43                                      1
    rhs                 IC44                                      1
    rhs                 IC45                                      1
    rhs                 IC46                                      1
    rhs                 IC47                                      1
    rhs                 IC48                                      1
    rhs                 IC49                                      1
    rhs                 interdictionBudget                    10358
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 C0000030          
 BV bnd                 C0000031          
 BV bnd                 C0000032          
 BV bnd                 C0000033          
 BV bnd                 C0000034          
 BV bnd                 C0000035          
 BV bnd                 C0000036          
 BV bnd                 C0000037          
 BV bnd                 C0000038          
 BV bnd                 C0000039          
 BV bnd                 C0000040          
 BV bnd                 C0000041          
 BV bnd                 C0000042          
 BV bnd                 C0000043          
 BV bnd                 C0000044          
 BV bnd                 C0000045          
 BV bnd                 C0000046          
 BV bnd                 C0000047          
 BV bnd                 C0000048          
 BV bnd                 C0000049          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
 BV bnd                 x30               
 BV bnd                 x31               
 BV bnd                 x32               
 BV bnd                 x33               
 BV bnd                 x34               
 BV bnd                 x35               
 BV bnd                 x36               
 BV bnd                 x37               
 BV bnd                 x38               
 BV bnd                 x39               
 BV bnd                 x40               
 BV bnd                 x41               
 BV bnd                 x42               
 BV bnd                 x43               
 BV bnd                 x44               
 BV bnd                 x45               
 BV bnd                 x46               
 BV bnd                 x47               
 BV bnd                 x48               
 BV bnd                 x49               
ENDATA
