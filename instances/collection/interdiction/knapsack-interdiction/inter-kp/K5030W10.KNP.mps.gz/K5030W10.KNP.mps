* ENCODING=ISO-8859-1
NAME          K5030W10.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  198
    C0000000            R0000000                                714
    C0000000            IC0                                       1
    C0000001            OBJROW                                  316
    C0000001            R0000000                                 57
    C0000001            IC1                                       1
    C0000002            OBJROW                                  406
    C0000002            R0000000                                384
    C0000002            IC2                                       1
    C0000003            OBJROW                                  748
    C0000003            R0000000                                499
    C0000003            IC3                                       1
    C0000004            OBJROW                                  598
    C0000004            R0000000                                782
    C0000004            IC4                                       1
    C0000005            OBJROW                                  829
    C0000005            R0000000                                133
    C0000005            IC5                                       1
    C0000006            OBJROW                                  404
    C0000006            R0000000                                924
    C0000006            IC6                                       1
    C0000007            OBJROW                                   79
    C0000007            R0000000                                615
    C0000007            IC7                                       1
    C0000008            OBJROW                                  914
    C0000008            R0000000                                250
    C0000008            IC8                                       1
    C0000009            OBJROW                                  232
    C0000009            R0000000                                288
    C0000009            IC9                                       1
    C0000010            OBJROW                                  722
    C0000010            R0000000                                707
    C0000010            IC10                                      1
    C0000011            OBJROW                                  520
    C0000011            R0000000                                544
    C0000011            IC11                                      1
    C0000012            OBJROW                                  667
    C0000012            R0000000                                545
    C0000012            IC12                                      1
    C0000013            OBJROW                                  454
    C0000013            R0000000                                746
    C0000013            IC13                                      1
    C0000014            OBJROW                                  461
    C0000014            R0000000                                495
    C0000014            IC14                                      1
    C0000015            OBJROW                                  822
    C0000015            R0000000                                147
    C0000015            IC15                                      1
    C0000016            OBJROW                                  997
    C0000016            R0000000                                 15
    C0000016            IC16                                      1
    C0000017            OBJROW                                  876
    C0000017            R0000000                                923
    C0000017            IC17                                      1
    C0000018            OBJROW                                   86
    C0000018            R0000000                                768
    C0000018            IC18                                      1
    C0000019            OBJROW                                  645
    C0000019            R0000000                                955
    C0000019            IC19                                      1
    C0000020            OBJROW                                  158
    C0000020            R0000000                                942
    C0000020            IC20                                      1
    C0000021            OBJROW                                   67
    C0000021            R0000000                                 52
    C0000021            IC21                                      1
    C0000022            OBJROW                                 1000
    C0000022            R0000000                                103
    C0000022            IC22                                      1
    C0000023            OBJROW                                  803
    C0000023            R0000000                                 66
    C0000023            IC23                                      1
    C0000024            OBJROW                                  366
    C0000024            R0000000                                 41
    C0000024            IC24                                      1
    C0000025            OBJROW                                   13
    C0000025            R0000000                                778
    C0000025            IC25                                      1
    C0000026            OBJROW                                  884
    C0000026            R0000000                                265
    C0000026            IC26                                      1
    C0000027            OBJROW                                  430
    C0000027            R0000000                                178
    C0000027            IC27                                      1
    C0000028            OBJROW                                  189
    C0000028            R0000000                                705
    C0000028            IC28                                      1
    C0000029            OBJROW                                  870
    C0000029            R0000000                                640
    C0000029            IC29                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      982
    x1                  IC1                                       1
    x1                  interdictionBudget                       36
    x2                  IC2                                       1
    x2                  interdictionBudget                      183
    x3                  IC3                                       1
    x3                  interdictionBudget                      204
    x4                  IC4                                       1
    x4                  interdictionBudget                      549
    x5                  IC5                                       1
    x5                  interdictionBudget                      221
    x6                  IC6                                       1
    x6                  interdictionBudget                      742
    x7                  IC7                                       1
    x7                  interdictionBudget                      965
    x8                  IC8                                       1
    x8                  interdictionBudget                      372
    x9                  IC9                                       1
    x9                  interdictionBudget                      430
    x10                 IC10                                      1
    x10                 interdictionBudget                       76
    x11                 IC11                                      1
    x11                 interdictionBudget                      238
    x12                 IC12                                      1
    x12                 interdictionBudget                      381
    x13                 IC13                                      1
    x13                 interdictionBudget                      678
    x14                 IC14                                      1
    x14                 interdictionBudget                      653
    x15                 IC15                                      1
    x15                 interdictionBudget                      542
    x16                 IC16                                      1
    x16                 interdictionBudget                      707
    x17                 IC17                                      1
    x17                 interdictionBudget                      632
    x18                 IC18                                      1
    x18                 interdictionBudget                      123
    x19                 IC19                                      1
    x19                 interdictionBudget                      936
    x20                 IC20                                      1
    x20                 interdictionBudget                      553
    x21                 IC21                                      1
    x21                 interdictionBudget                      170
    x22                 IC22                                      1
    x22                 interdictionBudget                      231
    x23                 IC23                                      1
    x23                 interdictionBudget                      699
    x24                 IC24                                      1
    x24                 interdictionBudget                      151
    x25                 IC25                                      1
    x25                 interdictionBudget                      699
    x26                 IC26                                      1
    x26                 interdictionBudget                       87
    x27                 IC27                                      1
    x27                 interdictionBudget                      355
    x28                 IC28                                      1
    x28                 interdictionBudget                      463
    x29                 IC29                                      1
    x29                 interdictionBudget                      596
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               7130
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 interdictionBudget                     6827
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
ENDATA
