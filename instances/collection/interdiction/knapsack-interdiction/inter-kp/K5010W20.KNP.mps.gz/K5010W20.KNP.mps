* ENCODING=ISO-8859-1
NAME          K5010W20.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  852
    C0000000            R0000000                                368
    C0000000            IC0                                       1
    C0000001            OBJROW                                  855
    C0000001            R0000000                                707
    C0000001            IC1                                       1
    C0000002            OBJROW                                  450
    C0000002            R0000000                                622
    C0000002            IC2                                       1
    C0000003            OBJROW                                  448
    C0000003            R0000000                                 28
    C0000003            IC3                                       1
    C0000004            OBJROW                                  746
    C0000004            R0000000                                 63
    C0000004            IC4                                       1
    C0000005            OBJROW                                  865
    C0000005            R0000000                                340
    C0000005            IC5                                       1
    C0000006            OBJROW                                  802
    C0000006            R0000000                                791
    C0000006            IC6                                       1
    C0000007            OBJROW                                  343
    C0000007            R0000000                                346
    C0000007            IC7                                       1
    C0000008            OBJROW                                  644
    C0000008            R0000000                                352
    C0000008            IC8                                       1
    C0000009            OBJROW                                  159
    C0000009            R0000000                                914
    C0000009            IC9                                       1
    x0                  IC0                                       1
    x0                  interdictionBudget                      746
    x1                  IC1                                       1
    x1                  interdictionBudget                      608
    x2                  IC2                                       1
    x2                  interdictionBudget                      890
    x3                  IC3                                       1
    x3                  interdictionBudget                      273
    x4                  IC4                                       1
    x4                  interdictionBudget                      834
    x5                  IC5                                       1
    x5                  interdictionBudget                      313
    x6                  IC6                                       1
    x6                  interdictionBudget                      754
    x7                  IC7                                       1
    x7                  interdictionBudget                       49
    x8                  IC8                                       1
    x8                  interdictionBudget                       24
    x9                  IC9                                       1
    x9                  interdictionBudget                      107
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               2265
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 interdictionBudget                     2299
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
ENDATA
