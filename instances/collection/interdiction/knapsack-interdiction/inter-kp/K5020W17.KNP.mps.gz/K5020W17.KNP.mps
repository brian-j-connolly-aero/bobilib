* ENCODING=ISO-8859-1
NAME          K5020W17.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  930
    C0000000            R0000000                                556
    C0000000            IC0                                       1
    C0000001            OBJROW                                  937
    C0000001            R0000000                                822
    C0000001            IC1                                       1
    C0000002            OBJROW                                  464
    C0000002            R0000000                                188
    C0000002            IC2                                       1
    C0000003            OBJROW                                  699
    C0000003            R0000000                                102
    C0000003            IC3                                       1
    C0000004            OBJROW                                  168
    C0000004            R0000000                                308
    C0000004            IC4                                       1
    C0000005            OBJROW                                  451
    C0000005            R0000000                                998
    C0000005            IC5                                       1
    C0000006            OBJROW                                  446
    C0000006            R0000000                                213
    C0000006            IC6                                       1
    C0000007            OBJROW                                  964
    C0000007            R0000000                                 68
    C0000007            IC7                                       1
    C0000008            OBJROW                                  550
    C0000008            R0000000                                959
    C0000008            IC8                                       1
    C0000009            OBJROW                                  285
    C0000009            R0000000                                828
    C0000009            IC9                                       1
    C0000010            OBJROW                                  854
    C0000010            R0000000                                357
    C0000010            IC10                                      1
    C0000011            OBJROW                                  621
    C0000011            R0000000                                462
    C0000011            IC11                                      1
    C0000012            OBJROW                                  918
    C0000012            R0000000                                595
    C0000012            IC12                                      1
    C0000013            OBJROW                                  909
    C0000013            R0000000                                839
    C0000013            IC13                                      1
    C0000014            OBJROW                                  500
    C0000014            R0000000                                940
    C0000014            IC14                                      1
    C0000015            OBJROW                                   38
    C0000015            R0000000                                447
    C0000015            IC15                                      1
    C0000016            OBJROW                                  277
    C0000016            R0000000                                778
    C0000016            IC16                                      1
    C0000017            OBJROW                                  438
    C0000017            R0000000                                392
    C0000017            IC17                                      1
    C0000018            OBJROW                                  541
    C0000018            R0000000                                 59
    C0000018            IC18                                      1
    C0000019            OBJROW                                  974
    C0000019            R0000000                                496
    C0000019            IC19                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      824
    x1                  IC1                                       1
    x1                  interdictionBudget                       43
    x2                  IC2                                       1
    x2                  interdictionBudget                      710
    x3                  IC3                                       1
    x3                  interdictionBudget                      453
    x4                  IC4                                       1
    x4                  interdictionBudget                      156
    x5                  IC5                                       1
    x5                  interdictionBudget                      390
    x6                  IC6                                       1
    x6                  interdictionBudget                       28
    x7                  IC7                                       1
    x7                  interdictionBudget                      814
    x8                  IC8                                       1
    x8                  interdictionBudget                      620
    x9                  IC9                                       1
    x9                  interdictionBudget                      975
    x10                 IC10                                      1
    x10                 interdictionBudget                      572
    x11                 IC11                                      1
    x11                 interdictionBudget                      389
    x12                 IC12                                      1
    x12                 interdictionBudget                      133
    x13                 IC13                                      1
    x13                 interdictionBudget                      133
    x14                 IC14                                      1
    x14                 interdictionBudget                      142
    x15                 IC15                                      1
    x15                 interdictionBudget                       91
    x16                 IC16                                      1
    x16                 interdictionBudget                       96
    x17                 IC17                                      1
    x17                 interdictionBudget                      681
    x18                 IC18                                      1
    x18                 interdictionBudget                      633
    x19                 IC19                                      1
    x19                 interdictionBudget                      250
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               6244
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 interdictionBudget                     4067
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
ENDATA
