* ENCODING=ISO-8859-1
NAME          K5010W14.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  118
    C0000000            R0000000                                634
    C0000000            IC0                                       1
    C0000001            OBJROW                                   52
    C0000001            R0000000                                904
    C0000001            IC1                                       1
    C0000002            OBJROW                                   30
    C0000002            R0000000                                 91
    C0000002            IC2                                       1
    C0000003            OBJROW                                  773
    C0000003            R0000000                                160
    C0000003            IC3                                       1
    C0000004            OBJROW                                  412
    C0000004            R0000000                                929
    C0000004            IC4                                       1
    C0000005            OBJROW                                  302
    C0000005            R0000000                                  9
    C0000005            IC5                                       1
    C0000006            OBJROW                                  669
    C0000006            R0000000                                 73
    C0000006            IC6                                       1
    C0000007            OBJROW                                  260
    C0000007            R0000000                                481
    C0000007            IC7                                       1
    C0000008            OBJROW                                  671
    C0000008            R0000000                                338
    C0000008            IC8                                       1
    C0000009            OBJROW                                  236
    C0000009            R0000000                                881
    C0000009            IC9                                       1
    x0                  IC0                                       1
    x0                  interdictionBudget                      256
    x1                  IC1                                       1
    x1                  interdictionBudget                      849
    x2                  IC2                                       1
    x2                  interdictionBudget                      178
    x3                  IC3                                       1
    x3                  interdictionBudget                      793
    x4                  IC4                                       1
    x4                  interdictionBudget                      232
    x5                  IC5                                       1
    x5                  interdictionBudget                      851
    x6                  IC6                                       1
    x6                  interdictionBudget                      854
    x7                  IC7                                       1
    x7                  interdictionBudget                      765
    x8                  IC8                                       1
    x8                  interdictionBudget                      294
    x9                  IC9                                       1
    x9                  interdictionBudget                      147
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               2250
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 interdictionBudget                     2610
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
ENDATA
