* ENCODING=ISO-8859-1
NAME          K5040W13.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  IC30              
 L  IC31              
 L  IC32              
 L  IC33              
 L  IC34              
 L  IC35              
 L  IC36              
 L  IC37              
 L  IC38              
 L  IC39              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                   10
    C0000000            R0000000                                526
    C0000000            IC0                                       1
    C0000001            OBJROW                                  201
    C0000001            R0000000                                699
    C0000001            IC1                                       1
    C0000002            OBJROW                                  840
    C0000002            R0000000                                288
    C0000002            IC2                                       1
    C0000003            OBJROW                                  674
    C0000003            R0000000                                579
    C0000003            IC3                                       1
    C0000004            OBJROW                                 1000
    C0000004            R0000000                                870
    C0000004            IC4                                       1
    C0000005            OBJROW                                   11
    C0000005            R0000000                                436
    C0000005            IC5                                       1
    C0000006            OBJROW                                  976
    C0000006            R0000000                                679
    C0000006            IC6                                       1
    C0000007            OBJROW                                  489
    C0000007            R0000000                                708
    C0000007            IC7                                       1
    C0000008            OBJROW                                  754
    C0000008            R0000000                                461
    C0000008            IC8                                       1
    C0000009            OBJROW                                  961
    C0000009            R0000000                                910
    C0000009            IC9                                       1
    C0000010            OBJROW                                  786
    C0000010            R0000000                                331
    C0000010            IC10                                      1
    C0000011            OBJROW                                  857
    C0000011            R0000000                                375
    C0000011            IC11                                      1
    C0000012            OBJROW                                  442
    C0000012            R0000000                                131
    C0000012            IC12                                      1
    C0000013            OBJROW                                  951
    C0000013            R0000000                                320
    C0000013            IC13                                      1
    C0000014            OBJROW                                  363
    C0000014            R0000000                                179
    C0000014            IC14                                      1
    C0000015            OBJROW                                  975
    C0000015            R0000000                                664
    C0000015            IC15                                      1
    C0000016            OBJROW                                  924
    C0000016            R0000000                                665
    C0000016            IC16                                      1
    C0000017            OBJROW                                  389
    C0000017            R0000000                                625
    C0000017            IC17                                      1
    C0000018            OBJROW                                  118
    C0000018            R0000000                                553
    C0000018            IC18                                      1
    C0000019            OBJROW                                   77
    C0000019            R0000000                                881
    C0000019            IC19                                      1
    C0000020            OBJROW                                   84
    C0000020            R0000000                                658
    C0000020            IC20                                      1
    C0000021            OBJROW                                  774
    C0000021            R0000000                                201
    C0000021            IC21                                      1
    C0000022            OBJROW                                  604
    C0000022            R0000000                                 98
    C0000022            IC22                                      1
    C0000023            OBJROW                                  102
    C0000023            R0000000                                503
    C0000023            IC23                                      1
    C0000024            OBJROW                                  316
    C0000024            R0000000                                788
    C0000024            IC24                                      1
    C0000025            OBJROW                                  543
    C0000025            R0000000                                567
    C0000025            IC25                                      1
    C0000026            OBJROW                                  628
    C0000026            R0000000                                868
    C0000026            IC26                                      1
    C0000027            OBJROW                                  381
    C0000027            R0000000                                429
    C0000027            IC27                                      1
    C0000028            OBJROW                                  910
    C0000028            R0000000                                134
    C0000028            IC28                                      1
    C0000029            OBJROW                                  621
    C0000029            R0000000                                707
    C0000029            IC29                                      1
    C0000030            OBJROW                                  998
    C0000030            R0000000                                567
    C0000030            IC30                                      1
    C0000031            OBJROW                                  955
    C0000031            R0000000                                132
    C0000031            IC31                                      1
    C0000032            OBJROW                                  143
    C0000032            R0000000                                191
    C0000032            IC32                                      1
    C0000033            OBJROW                                  276
    C0000033            R0000000                                626
    C0000033            IC33                                      1
    C0000034            OBJROW                                  253
    C0000034            R0000000                                576
    C0000034            IC34                                      1
    C0000035            OBJROW                                  237
    C0000035            R0000000                                250
    C0000035            IC35                                      1
    C0000036            OBJROW                                  429
    C0000036            R0000000                                384
    C0000036            IC36                                      1
    C0000037            OBJROW                                   53
    C0000037            R0000000                                491
    C0000037            IC37                                      1
    C0000038            OBJROW                                  869
    C0000038            R0000000                                480
    C0000038            IC38                                      1
    C0000039            OBJROW                                  766
    C0000039            R0000000                                249
    C0000039            IC39                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      904
    x1                  IC1                                       1
    x1                  interdictionBudget                      954
    x2                  IC2                                       1
    x2                  interdictionBudget                      280
    x3                  IC3                                       1
    x3                  interdictionBudget                      146
    x4                  IC4                                       1
    x4                  interdictionBudget                      281
    x5                  IC5                                       1
    x5                  interdictionBudget                       16
    x6                  IC6                                       1
    x6                  interdictionBudget                      811
    x7                  IC7                                       1
    x7                  interdictionBudget                      806
    x8                  IC8                                       1
    x8                  interdictionBudget                      341
    x9                  IC9                                       1
    x9                  interdictionBudget                      532
    x10                 IC10                                      1
    x10                 interdictionBudget                      638
    x11                 IC11                                      1
    x11                 interdictionBudget                      828
    x12                 IC12                                      1
    x12                 interdictionBudget                      783
    x13                 IC13                                      1
    x13                 interdictionBudget                      916
    x14                 IC14                                      1
    x14                 interdictionBudget                       23
    x15                 IC15                                      1
    x15                 interdictionBudget                      244
    x16                 IC16                                      1
    x16                 interdictionBudget                      871
    x17                 IC17                                      1
    x17                 interdictionBudget                      420
    x18                 IC18                                      1
    x18                 interdictionBudget                      759
    x19                 IC19                                      1
    x19                 interdictionBudget                      506
    x20                 IC20                                      1
    x20                 interdictionBudget                      384
    x21                 IC21                                      1
    x21                 interdictionBudget                      482
    x22                 IC22                                      1
    x22                 interdictionBudget                      288
    x23                 IC23                                      1
    x23                 interdictionBudget                      714
    x24                 IC24                                      1
    x24                 interdictionBudget                      297
    x25                 IC25                                      1
    x25                 interdictionBudget                      912
    x26                 IC26                                      1
    x26                 interdictionBudget                      426
    x27                 IC27                                      1
    x27                 interdictionBudget                      401
    x28                 IC28                                      1
    x28                 interdictionBudget                      266
    x29                 IC29                                      1
    x29                 interdictionBudget                       87
    x30                 IC30                                      1
    x30                 interdictionBudget                      524
    x31                 IC31                                      1
    x31                 interdictionBudget                      893
    x32                 IC32                                      1
    x32                 interdictionBudget                      725
    x33                 IC33                                      1
    x33                 interdictionBudget                      358
    x34                 IC34                                      1
    x34                 interdictionBudget                      195
    x35                 IC35                                      1
    x35                 interdictionBudget                      488
    x36                 IC36                                      1
    x36                 interdictionBudget                      729
    x37                 IC37                                      1
    x37                 interdictionBudget                       42
    x38                 IC38                                      1
    x38                 interdictionBudget                      713
    x39                 IC39                                      1
    x39                 interdictionBudget                       42
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               9889
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 IC30                                      1
    rhs                 IC31                                      1
    rhs                 IC32                                      1
    rhs                 IC33                                      1
    rhs                 IC34                                      1
    rhs                 IC35                                      1
    rhs                 IC36                                      1
    rhs                 IC37                                      1
    rhs                 IC38                                      1
    rhs                 IC39                                      1
    rhs                 interdictionBudget                    10013
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 C0000030          
 BV bnd                 C0000031          
 BV bnd                 C0000032          
 BV bnd                 C0000033          
 BV bnd                 C0000034          
 BV bnd                 C0000035          
 BV bnd                 C0000036          
 BV bnd                 C0000037          
 BV bnd                 C0000038          
 BV bnd                 C0000039          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
 BV bnd                 x30               
 BV bnd                 x31               
 BV bnd                 x32               
 BV bnd                 x33               
 BV bnd                 x34               
 BV bnd                 x35               
 BV bnd                 x36               
 BV bnd                 x37               
 BV bnd                 x38               
 BV bnd                 x39               
ENDATA
