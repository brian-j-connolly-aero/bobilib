* ENCODING=ISO-8859-1
NAME          K5020W06.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  168
    C0000000            R0000000                                684
    C0000000            IC0                                       1
    C0000001            OBJROW                                  547
    C0000001            R0000000                                 45
    C0000001            IC1                                       1
    C0000002            OBJROW                                  584
    C0000002            R0000000                                678
    C0000002            IC2                                       1
    C0000003            OBJROW                                  513
    C0000003            R0000000                                805
    C0000003            IC3                                       1
    C0000004            OBJROW                                  978
    C0000004            R0000000                                478
    C0000004            IC4                                       1
    C0000005            OBJROW                                  417
    C0000005            R0000000                                549
    C0000005            IC5                                       1
    C0000006            OBJROW                                  914
    C0000006            R0000000                                302
    C0000006            IC6                                       1
    C0000007            OBJROW                                  225
    C0000007            R0000000                                485
    C0000007            IC7                                       1
    C0000008            OBJROW                                  226
    C0000008            R0000000                                788
    C0000008            IC8                                       1
    C0000009            OBJROW                                   65
    C0000009            R0000000                                623
    C0000009            IC9                                       1
    C0000010            OBJROW                                   58
    C0000010            R0000000                                652
    C0000010            IC10                                      1
    C0000011            OBJROW                                  519
    C0000011            R0000000                                583
    C0000011            IC11                                      1
    C0000012            OBJROW                                  708
    C0000012            R0000000                                682
    C0000012            IC12                                      1
    C0000013            OBJROW                                  429
    C0000013            R0000000                                641
    C0000013            IC13                                      1
    C0000014            OBJROW                                  117
    C0000014            R0000000                                320
    C0000014            IC14                                      1
    C0000015            OBJROW                                  213
    C0000015            R0000000                                258
    C0000015            IC15                                      1
    C0000016            OBJROW                                   37
    C0000016            R0000000                                 49
    C0000016            IC16                                      1
    C0000017            OBJROW                                   69
    C0000017            R0000000                                402
    C0000017            IC17                                      1
    C0000018            OBJROW                                  693
    C0000018            R0000000                                 79
    C0000018            IC18                                      1
    C0000019            OBJROW                                  734
    C0000019            R0000000                                123
    C0000019            IC19                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                       62
    x1                  IC1                                       1
    x1                  interdictionBudget                      300
    x2                  IC2                                       1
    x2                  interdictionBudget                      670
    x3                  IC3                                       1
    x3                  interdictionBudget                      372
    x4                  IC4                                       1
    x4                  interdictionBudget                      535
    x5                  IC5                                       1
    x5                  interdictionBudget                      162
    x6                  IC6                                       1
    x6                  interdictionBudget                      985
    x7                  IC7                                       1
    x7                  interdictionBudget                      952
    x8                  IC8                                       1
    x8                  interdictionBudget                      562
    x9                  IC9                                       1
    x9                  interdictionBudget                      417
    x10                 IC10                                      1
    x10                 interdictionBudget                        2
    x11                 IC11                                      1
    x11                 interdictionBudget                      817
    x12                 IC12                                      1
    x12                 interdictionBudget                      554
    x13                 IC13                                      1
    x13                 interdictionBudget                        9
    x14                 IC14                                      1
    x14                 interdictionBudget                      128
    x15                 IC15                                      1
    x15                 interdictionBudget                      619
    x16                 IC16                                      1
    x16                 interdictionBudget                      934
    x17                 IC17                                      1
    x17                 interdictionBudget                      805
    x18                 IC18                                      1
    x18                 interdictionBudget                      100
    x19                 IC19                                      1
    x19                 interdictionBudget                      334
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               4613
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 interdictionBudget                     4660
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
ENDATA
