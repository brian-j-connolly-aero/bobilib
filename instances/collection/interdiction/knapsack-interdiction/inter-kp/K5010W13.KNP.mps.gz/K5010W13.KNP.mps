* ENCODING=ISO-8859-1
NAME          K5010W13.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                   10
    C0000000            R0000000                                526
    C0000000            IC0                                       1
    C0000001            OBJROW                                  201
    C0000001            R0000000                                699
    C0000001            IC1                                       1
    C0000002            OBJROW                                  840
    C0000002            R0000000                                288
    C0000002            IC2                                       1
    C0000003            OBJROW                                  674
    C0000003            R0000000                                579
    C0000003            IC3                                       1
    C0000004            OBJROW                                 1000
    C0000004            R0000000                                870
    C0000004            IC4                                       1
    C0000005            OBJROW                                   11
    C0000005            R0000000                                436
    C0000005            IC5                                       1
    C0000006            OBJROW                                  976
    C0000006            R0000000                                679
    C0000006            IC6                                       1
    C0000007            OBJROW                                  489
    C0000007            R0000000                                708
    C0000007            IC7                                       1
    C0000008            OBJROW                                  754
    C0000008            R0000000                                461
    C0000008            IC8                                       1
    C0000009            OBJROW                                  961
    C0000009            R0000000                                910
    C0000009            IC9                                       1
    x0                  IC0                                       1
    x0                  interdictionBudget                      904
    x1                  IC1                                       1
    x1                  interdictionBudget                      954
    x2                  IC2                                       1
    x2                  interdictionBudget                      280
    x3                  IC3                                       1
    x3                  interdictionBudget                      146
    x4                  IC4                                       1
    x4                  interdictionBudget                      281
    x5                  IC5                                       1
    x5                  interdictionBudget                       16
    x6                  IC6                                       1
    x6                  interdictionBudget                      811
    x7                  IC7                                       1
    x7                  interdictionBudget                      806
    x8                  IC8                                       1
    x8                  interdictionBudget                      341
    x9                  IC9                                       1
    x9                  interdictionBudget                      532
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               3078
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 interdictionBudget                     2536
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
ENDATA
