* ENCODING=ISO-8859-1
NAME          K5020W12.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  658
    C0000000            R0000000                                174
    C0000000            IC0                                       1
    C0000001            OBJROW                                  305
    C0000001            R0000000                                157
    C0000001            IC1                                       1
    C0000002            OBJROW                                  378
    C0000002            R0000000                                196
    C0000002            IC2                                       1
    C0000003            OBJROW                                   65
    C0000003            R0000000                                567
    C0000003            IC3                                       1
    C0000004            OBJROW                                 1000
    C0000004            R0000000                                786
    C0000004            IC4                                       1
    C0000005            OBJROW                                   11
    C0000005            R0000000                                673
    C0000005            IC5                                       1
    C0000006            OBJROW                                  976
    C0000006            R0000000                                808
    C0000006            IC6                                       1
    C0000007            OBJROW                                  489
    C0000007            R0000000                                211
    C0000007            IC7                                       1
    C0000008            OBJROW                                  754
    C0000008            R0000000                                 86
    C0000008            IC8                                       1
    C0000009            OBJROW                                  961
    C0000009            R0000000                                565
    C0000009            IC9                                       1
    C0000010            OBJROW                                  786
    C0000010            R0000000                                868
    C0000010            IC10                                      1
    C0000011            OBJROW                                  857
    C0000011            R0000000                                623
    C0000011            IC11                                      1
    C0000012            OBJROW                                  442
    C0000012            R0000000                                716
    C0000012            IC12                                      1
    C0000013            OBJROW                                  951
    C0000013            R0000000                                927
    C0000013            IC13                                      1
    C0000014            OBJROW                                  363
    C0000014            R0000000                                196
    C0000014            IC14                                      1
    C0000015            OBJROW                                  975
    C0000015            R0000000                                367
    C0000015            IC15                                      1
    C0000016            OBJROW                                  924
    C0000016            R0000000                                722
    C0000016            IC16                                      1
    C0000017            OBJROW                                  389
    C0000017            R0000000                                529
    C0000017            IC17                                      1
    C0000018            OBJROW                                  118
    C0000018            R0000000                                616
    C0000018            IC18                                      1
    C0000019            OBJROW                                   77
    C0000019            R0000000                                459
    C0000019            IC19                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      796
    x1                  IC1                                       1
    x1                  interdictionBudget                      103
    x2                  IC2                                       1
    x2                  interdictionBudget                       90
    x3                  IC3                                       1
    x3                  interdictionBudget                      289
    x4                  IC4                                       1
    x4                  interdictionBudget                      482
    x5                  IC5                                       1
    x5                  interdictionBudget                       97
    x6                  IC6                                       1
    x6                  interdictionBudget                      488
    x7                  IC7                                       1
    x7                  interdictionBudget                      722
    x8                  IC8                                       1
    x8                  interdictionBudget                      400
    x9                  IC9                                       1
    x9                  interdictionBudget                      282
    x10                 IC10                                      1
    x10                 interdictionBudget                        8
    x11                 IC11                                      1
    x11                 interdictionBudget                      290
    x12                 IC12                                      1
    x12                 interdictionBudget                      529
    x13                 IC13                                      1
    x13                 interdictionBudget                      810
    x14                 IC14                                      1
    x14                 interdictionBudget                      945
    x15                 IC15                                      1
    x15                 interdictionBudget                       18
    x16                 IC16                                      1
    x16                 interdictionBudget                      577
    x17                 IC17                                      1
    x17                 interdictionBudget                      178
    x18                 IC18                                      1
    x18                 interdictionBudget                      665
    x19                 IC19                                      1
    x19                 interdictionBudget                      544
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               5123
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 interdictionBudget                     4157
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
ENDATA
