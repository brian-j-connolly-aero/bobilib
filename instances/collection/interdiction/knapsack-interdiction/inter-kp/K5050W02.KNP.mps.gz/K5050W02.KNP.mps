* ENCODING=ISO-8859-1
NAME          K5050W02.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  IC30              
 L  IC31              
 L  IC32              
 L  IC33              
 L  IC34              
 L  IC35              
 L  IC36              
 L  IC37              
 L  IC38              
 L  IC39              
 L  IC40              
 L  IC41              
 L  IC42              
 L  IC43              
 L  IC44              
 L  IC45              
 L  IC46              
 L  IC47              
 L  IC48              
 L  IC49              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  248
    C0000000            R0000000                                764
    C0000000            IC0                                       1
    C0000001            OBJROW                                  457
    C0000001            R0000000                                309
    C0000001            IC1                                       1
    C0000002            OBJROW                                  993
    C0000002            R0000000                                165
    C0000002            IC2                                       1
    C0000003            OBJROW                                  393
    C0000003            R0000000                                862
    C0000003            IC3                                       1
    C0000004            OBJROW                                  793
    C0000004            R0000000                                 27
    C0000004            IC4                                       1
    C0000005            OBJROW                                  402
    C0000005            R0000000                                999
    C0000005            IC5                                       1
    C0000006            OBJROW                                  185
    C0000006            R0000000                                228
    C0000006            IC6                                       1
    C0000007            OBJROW                                   16
    C0000007            R0000000                                135
    C0000007            IC7                                       1
    C0000008            OBJROW                                  706
    C0000008            R0000000                                 44
    C0000008            IC8                                       1
    C0000009            OBJROW                                  720
    C0000009            R0000000                                807
    C0000009            IC9                                       1
    C0000010            OBJROW                                  594
    C0000010            R0000000                                276
    C0000010            IC10                                      1
    C0000011            OBJROW                                  961
    C0000011            R0000000                                567
    C0000011            IC11                                      1
    C0000012            OBJROW                                  754
    C0000012            R0000000                                754
    C0000012            IC12                                      1
    C0000013            OBJROW                                   63
    C0000013            R0000000                                233
    C0000013            IC13                                      1
    C0000014            OBJROW                                  163
    C0000014            R0000000                                496
    C0000014            IC14                                      1
    C0000015            OBJROW                                  800
    C0000015            R0000000                                155
    C0000015            IC15                                      1
    C0000016            OBJROW                                  587
    C0000016            R0000000                                328
    C0000016            IC16                                      1
    C0000017            OBJROW                                  286
    C0000017            R0000000                                369
    C0000017            IC17                                      1
    C0000018            OBJROW                                  869
    C0000018            R0000000                                465
    C0000018            IC18                                      1
    C0000019            OBJROW                                  540
    C0000019            R0000000                                409
    C0000019            IC19                                      1
    C0000020            OBJROW                                   95
    C0000020            R0000000                                473
    C0000020            IC20                                      1
    C0000021            OBJROW                                  650
    C0000021            R0000000                                737
    C0000021            IC21                                      1
    C0000022            OBJROW                                  608
    C0000022            R0000000                                314
    C0000022            IC22                                      1
    C0000023            OBJROW                                   27
    C0000023            R0000000                                513
    C0000023            IC23                                      1
    C0000024            OBJROW                                  910
    C0000024            R0000000                                752
    C0000024            IC24                                      1
    C0000025            OBJROW                                  733
    C0000025            R0000000                                395
    C0000025            IC25                                      1
    C0000026            OBJROW                                  580
    C0000026            R0000000                                736
    C0000026            IC26                                      1
    C0000027            OBJROW                                   47
    C0000027            R0000000                                507
    C0000027            IC27                                      1
    C0000028            OBJROW                                  290
    C0000028            R0000000                                328
    C0000028            IC28                                      1
    C0000029            OBJROW                                  544
    C0000029            R0000000                                465
    C0000029            IC29                                      1
    C0000030            OBJROW                                  755
    C0000030            R0000000                                602
    C0000030            IC30                                      1
    C0000031            OBJROW                                  920
    C0000031            R0000000                                151
    C0000031            IC31                                      1
    C0000032            OBJROW                                  811
    C0000032            R0000000                                812
    C0000032            IC32                                      1
    C0000033            OBJROW                                  848
    C0000033            R0000000                                719
    C0000033            IC33                                      1
    C0000034            OBJROW                                    1
    C0000034            R0000000                                434
    C0000034            IC34                                      1
    C0000035            OBJROW                                  938
    C0000035            R0000000                                712
    C0000035            IC35                                      1
    C0000036            OBJROW                                  561
    C0000036            R0000000                                259
    C0000036            IC36                                      1
    C0000037            OBJROW                                  522
    C0000037            R0000000                                720
    C0000037            IC37                                      1
    C0000038            OBJROW                                  225
    C0000038            R0000000                                417
    C0000038            IC38                                      1
    C0000039            OBJROW                                  202
    C0000039            R0000000                                985
    C0000039            IC39                                      1
    C0000040            OBJROW                                  927
    C0000040            R0000000                                 65
    C0000040            IC40                                      1
    C0000041            OBJROW                                  387
    C0000041            R0000000                                194
    C0000041            IC41                                      1
    C0000042            OBJROW                                  239
    C0000042            R0000000                                593
    C0000042            IC42                                      1
    C0000043            OBJROW                                  220
    C0000043            R0000000                                952
    C0000043            IC43                                      1
    C0000044            OBJROW                                  317
    C0000044            R0000000                                538
    C0000044            IC44                                      1
    C0000045            OBJROW                                  390
    C0000045            R0000000                                169
    C0000045            IC45                                      1
    C0000046            OBJROW                                  923
    C0000046            R0000000                                298
    C0000046            IC46                                      1
    C0000047            OBJROW                                  727
    C0000047            R0000000                                631
    C0000047            IC47                                      1
    C0000048            OBJROW                                  212
    C0000048            R0000000                                276
    C0000048            IC48                                      1
    C0000049            OBJROW                                  255
    C0000049            R0000000                                383
    C0000049            IC49                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                       32
    x1                  IC1                                       1
    x1                  interdictionBudget                      531
    x2                  IC2                                       1
    x2                  interdictionBudget                      494
    x3                  IC3                                       1
    x3                  interdictionBudget                      413
    x4                  IC4                                       1
    x4                  interdictionBudget                      108
    x5                  IC5                                       1
    x5                  interdictionBudget                      855
    x6                  IC6                                       1
    x6                  interdictionBudget                      426
    x7                  IC7                                       1
    x7                  interdictionBudget                      553
    x8                  IC8                                       1
    x8                  interdictionBudget                      848
    x9                  IC9                                       1
    x9                  interdictionBudget                      315
    x10                 IC10                                      1
    x10                 interdictionBudget                      552
    x11                 IC11                                      1
    x11                 interdictionBudget                       67
    x12                 IC12                                      1
    x12                 interdictionBudget                      830
    x13                 IC13                                      1
    x13                 interdictionBudget                      469
    x14                 IC14                                      1
    x14                 interdictionBudget                       94
    x15                 IC15                                      1
    x15                 interdictionBudget                      797
    x16                 IC16                                      1
    x16                 interdictionBudget                      830
    x17                 IC17                                      1
    x17                 interdictionBudget                      243
    x18                 IC18                                      1
    x18                 interdictionBudget                      719
    x19                 IC19                                      1
    x19                 interdictionBudget                      812
    x20                 IC20                                      1
    x20                 interdictionBudget                      669
    x21                 IC21                                      1
    x21                 interdictionBudget                      229
    x22                 IC22                                      1
    x22                 interdictionBudget                      781
    x23                 IC23                                      1
    x23                 interdictionBudget                      101
    x24                 IC24                                      1
    x24                 interdictionBudget                      606
    x25                 IC25                                      1
    x25                 interdictionBudget                      995
    x26                 IC26                                      1
    x26                 interdictionBudget                      215
    x27                 IC27                                      1
    x27                 interdictionBudget                      948
    x28                 IC28                                      1
    x28                 interdictionBudget                      719
    x29                 IC29                                      1
    x29                 interdictionBudget                      578
    x30                 IC30                                      1
    x30                 interdictionBudget                      992
    x31                 IC31                                      1
    x31                 interdictionBudget                      603
    x32                 IC32                                      1
    x32                 interdictionBudget                      198
    x33                 IC33                                      1
    x33                 interdictionBudget                      429
    x34                 IC34                                      1
    x34                 interdictionBudget                      148
    x35                 IC35                                      1
    x35                 interdictionBudget                      103
    x36                 IC36                                      1
    x36                 interdictionBudget                      172
    x37                 IC37                                      1
    x37                 interdictionBudget                       45
    x38                 IC38                                      1
    x38                 interdictionBudget                      565
    x39                 IC39                                      1
    x39                 interdictionBudget                       62
    x40                 IC40                                      1
    x40                 interdictionBudget                      205
    x41                 IC41                                      1
    x41                 interdictionBudget                      582
    x42                 IC42                                      1
    x42                 interdictionBudget                      699
    x43                 IC43                                      1
    x43                 interdictionBudget                      368
    x44                 IC44                                      1
    x44                 interdictionBudget                      625
    x45                 IC45                                      1
    x45                 interdictionBudget                      866
    x46                 IC46                                      1
    x46                 interdictionBudget                      945
    x47                 IC47                                      1
    x47                 interdictionBudget                       98
    x48                 IC48                                      1
    x48                 interdictionBudget                      623
    x49                 IC49                                      1
    x49                 interdictionBudget                      931
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                              11761
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 IC30                                      1
    rhs                 IC31                                      1
    rhs                 IC32                                      1
    rhs                 IC33                                      1
    rhs                 IC34                                      1
    rhs                 IC35                                      1
    rhs                 IC36                                      1
    rhs                 IC37                                      1
    rhs                 IC38                                      1
    rhs                 IC39                                      1
    rhs                 IC40                                      1
    rhs                 IC41                                      1
    rhs                 IC42                                      1
    rhs                 IC43                                      1
    rhs                 IC44                                      1
    rhs                 IC45                                      1
    rhs                 IC46                                      1
    rhs                 IC47                                      1
    rhs                 IC48                                      1
    rhs                 IC49                                      1
    rhs                 interdictionBudget                    12544
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 C0000030          
 BV bnd                 C0000031          
 BV bnd                 C0000032          
 BV bnd                 C0000033          
 BV bnd                 C0000034          
 BV bnd                 C0000035          
 BV bnd                 C0000036          
 BV bnd                 C0000037          
 BV bnd                 C0000038          
 BV bnd                 C0000039          
 BV bnd                 C0000040          
 BV bnd                 C0000041          
 BV bnd                 C0000042          
 BV bnd                 C0000043          
 BV bnd                 C0000044          
 BV bnd                 C0000045          
 BV bnd                 C0000046          
 BV bnd                 C0000047          
 BV bnd                 C0000048          
 BV bnd                 C0000049          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
 BV bnd                 x30               
 BV bnd                 x31               
 BV bnd                 x32               
 BV bnd                 x33               
 BV bnd                 x34               
 BV bnd                 x35               
 BV bnd                 x36               
 BV bnd                 x37               
 BV bnd                 x38               
 BV bnd                 x39               
 BV bnd                 x40               
 BV bnd                 x41               
 BV bnd                 x42               
 BV bnd                 x43               
 BV bnd                 x44               
 BV bnd                 x45               
 BV bnd                 x46               
 BV bnd                 x47               
 BV bnd                 x48               
 BV bnd                 x49               
ENDATA
