* ENCODING=ISO-8859-1
NAME          K5040W06.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  IC30              
 L  IC31              
 L  IC32              
 L  IC33              
 L  IC34              
 L  IC35              
 L  IC36              
 L  IC37              
 L  IC38              
 L  IC39              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  168
    C0000000            R0000000                                684
    C0000000            IC0                                       1
    C0000001            OBJROW                                  547
    C0000001            R0000000                                 45
    C0000001            IC1                                       1
    C0000002            OBJROW                                  584
    C0000002            R0000000                                678
    C0000002            IC2                                       1
    C0000003            OBJROW                                  513
    C0000003            R0000000                                805
    C0000003            IC3                                       1
    C0000004            OBJROW                                  978
    C0000004            R0000000                                478
    C0000004            IC4                                       1
    C0000005            OBJROW                                  417
    C0000005            R0000000                                549
    C0000005            IC5                                       1
    C0000006            OBJROW                                  914
    C0000006            R0000000                                302
    C0000006            IC6                                       1
    C0000007            OBJROW                                  225
    C0000007            R0000000                                485
    C0000007            IC7                                       1
    C0000008            OBJROW                                  226
    C0000008            R0000000                                788
    C0000008            IC8                                       1
    C0000009            OBJROW                                   65
    C0000009            R0000000                                623
    C0000009            IC9                                       1
    C0000010            OBJROW                                   58
    C0000010            R0000000                                652
    C0000010            IC10                                      1
    C0000011            OBJROW                                  519
    C0000011            R0000000                                583
    C0000011            IC11                                      1
    C0000012            OBJROW                                  708
    C0000012            R0000000                                682
    C0000012            IC12                                      1
    C0000013            OBJROW                                  429
    C0000013            R0000000                                641
    C0000013            IC13                                      1
    C0000014            OBJROW                                  117
    C0000014            R0000000                                320
    C0000014            IC14                                      1
    C0000015            OBJROW                                  213
    C0000015            R0000000                                258
    C0000015            IC15                                      1
    C0000016            OBJROW                                   37
    C0000016            R0000000                                 49
    C0000016            IC16                                      1
    C0000017            OBJROW                                   69
    C0000017            R0000000                                402
    C0000017            IC17                                      1
    C0000018            OBJROW                                  693
    C0000018            R0000000                                 79
    C0000018            IC18                                      1
    C0000019            OBJROW                                  734
    C0000019            R0000000                                123
    C0000019            IC19                                      1
    C0000020            OBJROW                                  507
    C0000020            R0000000                                759
    C0000020            IC20                                      1
    C0000021            OBJROW                                  279
    C0000021            R0000000                                563
    C0000021            IC21                                      1
    C0000022            OBJROW                                  163
    C0000022            R0000000                                328
    C0000022            IC22                                      1
    C0000023            OBJROW                                    8
    C0000023            R0000000                                531
    C0000023            IC23                                      1
    C0000024            OBJROW                                  321
    C0000024            R0000000                                400
    C0000024            IC24                                      1
    C0000025            OBJROW                                  177
    C0000025            R0000000                                985
    C0000025            IC25                                      1
    C0000026            OBJROW                                  978
    C0000026            R0000000                                889
    C0000026            IC26                                      1
    C0000027            OBJROW                                  473
    C0000027            R0000000                                121
    C0000027            IC27                                      1
    C0000028            OBJROW                                  712
    C0000028            R0000000                                130
    C0000028            IC28                                      1
    C0000029            OBJROW                                  274
    C0000029            R0000000                                329
    C0000029            IC29                                      1
    C0000030            OBJROW                                  665
    C0000030            R0000000                                618
    C0000030            IC30                                      1
    C0000031            OBJROW                                  392
    C0000031            R0000000                                113
    C0000031            IC31                                      1
    C0000032            OBJROW                                  778
    C0000032            R0000000                                224
    C0000032            IC32                                      1
    C0000033            OBJROW                                  336
    C0000033            R0000000                                451
    C0000033            IC33                                      1
    C0000034            OBJROW                                   18
    C0000034            R0000000                                512
    C0000034            IC34                                      1
    C0000035            OBJROW                                  673
    C0000035            R0000000                                761
    C0000035            IC35                                      1
    C0000036            OBJROW                                   58
    C0000036            R0000000                                577
    C0000036            IC36                                      1
    C0000037            OBJROW                                  495
    C0000037            R0000000                                273
    C0000037            IC37                                      1
    C0000038            OBJROW                                  460
    C0000038            R0000000                                753
    C0000038            IC38                                      1
    C0000039            OBJROW                                  725
    C0000039            R0000000                                217
    C0000039            IC39                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                       62
    x1                  IC1                                       1
    x1                  interdictionBudget                      300
    x2                  IC2                                       1
    x2                  interdictionBudget                      670
    x3                  IC3                                       1
    x3                  interdictionBudget                      372
    x4                  IC4                                       1
    x4                  interdictionBudget                      535
    x5                  IC5                                       1
    x5                  interdictionBudget                      162
    x6                  IC6                                       1
    x6                  interdictionBudget                      985
    x7                  IC7                                       1
    x7                  interdictionBudget                      952
    x8                  IC8                                       1
    x8                  interdictionBudget                      562
    x9                  IC9                                       1
    x9                  interdictionBudget                      417
    x10                 IC10                                      1
    x10                 interdictionBudget                        2
    x11                 IC11                                      1
    x11                 interdictionBudget                      817
    x12                 IC12                                      1
    x12                 interdictionBudget                      554
    x13                 IC13                                      1
    x13                 interdictionBudget                        9
    x14                 IC14                                      1
    x14                 interdictionBudget                      128
    x15                 IC15                                      1
    x15                 interdictionBudget                      619
    x16                 IC16                                      1
    x16                 interdictionBudget                      934
    x17                 IC17                                      1
    x17                 interdictionBudget                      805
    x18                 IC18                                      1
    x18                 interdictionBudget                      100
    x19                 IC19                                      1
    x19                 interdictionBudget                      334
    x20                 IC20                                      1
    x20                 interdictionBudget                      149
    x21                 IC21                                      1
    x21                 interdictionBudget                      668
    x22                 IC22                                      1
    x22                 interdictionBudget                      647
    x23                 IC23                                      1
    x23                 interdictionBudget                      164
    x24                 IC24                                      1
    x24                 interdictionBudget                      709
    x25                 IC25                                      1
    x25                 interdictionBudget                      421
    x26                 IC26                                      1
    x26                 interdictionBudget                      838
    x27                 IC27                                      1
    x27                 interdictionBudget                      659
    x28                 IC28                                      1
    x28                 interdictionBudget                      152
    x29                 IC29                                      1
    x29                 interdictionBudget                      563
    x30                 IC30                                      1
    x30                 interdictionBudget                      134
    x31                 IC31                                      1
    x31                 interdictionBudget                       60
    x32                 IC32                                      1
    x32                 interdictionBudget                      374
    x33                 IC33                                      1
    x33                 interdictionBudget                      317
    x34                 IC34                                      1
    x34                 interdictionBudget                      478
    x35                 IC35                                      1
    x35                 interdictionBudget                      419
    x36                 IC36                                      1
    x36                 interdictionBudget                      807
    x37                 IC37                                      1
    x37                 interdictionBudget                      220
    x38                 IC38                                      1
    x38                 interdictionBudget                      511
    x39                 IC39                                      1
    x39                 interdictionBudget                      986
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                               9380
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 IC30                                      1
    rhs                 IC31                                      1
    rhs                 IC32                                      1
    rhs                 IC33                                      1
    rhs                 IC34                                      1
    rhs                 IC35                                      1
    rhs                 IC36                                      1
    rhs                 IC37                                      1
    rhs                 IC38                                      1
    rhs                 IC39                                      1
    rhs                 interdictionBudget                     9298
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 C0000030          
 BV bnd                 C0000031          
 BV bnd                 C0000032          
 BV bnd                 C0000033          
 BV bnd                 C0000034          
 BV bnd                 C0000035          
 BV bnd                 C0000036          
 BV bnd                 C0000037          
 BV bnd                 C0000038          
 BV bnd                 C0000039          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
 BV bnd                 x30               
 BV bnd                 x31               
 BV bnd                 x32               
 BV bnd                 x33               
 BV bnd                 x34               
 BV bnd                 x35               
 BV bnd                 x36               
 BV bnd                 x37               
 BV bnd                 x38               
 BV bnd                 x39               
ENDATA
