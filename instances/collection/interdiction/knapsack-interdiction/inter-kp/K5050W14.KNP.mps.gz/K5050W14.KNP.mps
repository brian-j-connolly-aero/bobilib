* ENCODING=ISO-8859-1
NAME          K5050W14.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  IC30              
 L  IC31              
 L  IC32              
 L  IC33              
 L  IC34              
 L  IC35              
 L  IC36              
 L  IC37              
 L  IC38              
 L  IC39              
 L  IC40              
 L  IC41              
 L  IC42              
 L  IC43              
 L  IC44              
 L  IC45              
 L  IC46              
 L  IC47              
 L  IC48              
 L  IC49              
 L  interdictionBudget
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C0000000            OBJROW                                  118
    C0000000            R0000000                                634
    C0000000            IC0                                       1
    C0000001            OBJROW                                   52
    C0000001            R0000000                                904
    C0000001            IC1                                       1
    C0000002            OBJROW                                   30
    C0000002            R0000000                                 91
    C0000002            IC2                                       1
    C0000003            OBJROW                                  773
    C0000003            R0000000                                160
    C0000003            IC3                                       1
    C0000004            OBJROW                                  412
    C0000004            R0000000                                929
    C0000004            IC4                                       1
    C0000005            OBJROW                                  302
    C0000005            R0000000                                  9
    C0000005            IC5                                       1
    C0000006            OBJROW                                  669
    C0000006            R0000000                                 73
    C0000006            IC6                                       1
    C0000007            OBJROW                                  260
    C0000007            R0000000                                481
    C0000007            IC7                                       1
    C0000008            OBJROW                                  671
    C0000008            R0000000                                338
    C0000008            IC8                                       1
    C0000009            OBJROW                                  236
    C0000009            R0000000                                881
    C0000009            IC9                                       1
    C0000010            OBJROW                                  229
    C0000010            R0000000                                842
    C0000010            IC10                                      1
    C0000011            OBJROW                                  950
    C0000011            R0000000                                591
    C0000011            IC11                                      1
    C0000012            OBJROW                                  531
    C0000012            R0000000                                147
    C0000012            IC12                                      1
    C0000013            OBJROW                                  735
    C0000013            R0000000                                120
    C0000013            IC13                                      1
    C0000014            OBJROW                                  491
    C0000014            R0000000                                  9
    C0000014            IC14                                      1
    C0000015            OBJROW                                  455
    C0000015            R0000000                                273
    C0000015            IC15                                      1
    C0000016            OBJROW                                  195
    C0000016            R0000000                                802
    C0000016            IC16                                      1
    C0000017            OBJROW                                  375
    C0000017            R0000000                                505
    C0000017            IC17                                      1
    C0000018            OBJROW                                  987
    C0000018            R0000000                                336
    C0000018            IC18                                      1
    C0000019            OBJROW                                  687
    C0000019            R0000000                                962
    C0000019            IC19                                      1
    C0000020            OBJROW                                   28
    C0000020            R0000000                                632
    C0000020            IC20                                      1
    C0000021            OBJROW                                  743
    C0000021            R0000000                                235
    C0000021            IC21                                      1
    C0000022            OBJROW                                  780
    C0000022            R0000000                                408
    C0000022            IC22                                      1
    C0000023            OBJROW                                    7
    C0000023            R0000000                                723
    C0000023            IC23                                      1
    C0000024            OBJROW                                  154
    C0000024            R0000000                                496
    C0000024            IC24                                      1
    C0000025            OBJROW                                  528
    C0000025            R0000000                                 91
    C0000025            IC25                                      1
    C0000026            OBJROW                                   19
    C0000026            R0000000                                998
    C0000026            IC26                                      1
    C0000027            OBJROW                                  544
    C0000027            R0000000                                237
    C0000027            IC27                                      1
    C0000028            OBJROW                                  505
    C0000028            R0000000                                316
    C0000028            IC28                                      1
    C0000029            OBJROW                                  650
    C0000029            R0000000                                663
    C0000029            IC29                                      1
    C0000030            OBJROW                                  575
    C0000030            R0000000                                770
    C0000030            IC30                                      1
    C0000031            OBJROW                                  331
    C0000031            R0000000                                944
    C0000031            IC31                                      1
    C0000032            OBJROW                                  455
    C0000032            R0000000                                 75
    C0000032            IC32                                      1
    C0000033            OBJROW                                  420
    C0000033            R0000000                                240
    C0000033            IC33                                      1
    C0000034            OBJROW                                  847
    C0000034            R0000000                                 67
    C0000034            IC34                                      1
    C0000035            OBJROW                                   98
    C0000035            R0000000                                870
    C0000035            IC35                                      1
    C0000036            OBJROW                                  712
    C0000036            R0000000                                565
    C0000036            IC36                                      1
    C0000037            OBJROW                                  315
    C0000037            R0000000                                 14
    C0000037            IC37                                      1
    C0000038            OBJROW                                  518
    C0000038            R0000000                                723
    C0000038            IC38                                      1
    C0000039            OBJROW                                  709
    C0000039            R0000000                                423
    C0000039            IC39                                      1
    C0000040            OBJROW                                  308
    C0000040            R0000000                                651
    C0000040            IC40                                      1
    C0000041            OBJROW                                  206
    C0000041            R0000000                                623
    C0000041            IC41                                      1
    C0000042            OBJROW                                  837
    C0000042            R0000000                                740
    C0000042            IC42                                      1
    C0000043            OBJROW                                  926
    C0000043            R0000000                                917
    C0000043            IC43                                      1
    C0000044            OBJROW                                  163
    C0000044            R0000000                                 70
    C0000044            IC44                                      1
    C0000045            OBJROW                                  888
    C0000045            R0000000                                603
    C0000045            IC45                                      1
    C0000046            OBJROW                                  179
    C0000046            R0000000                                360
    C0000046            IC46                                      1
    C0000047            OBJROW                                  614
    C0000047            R0000000                                107
    C0000047            IC47                                      1
    C0000048            OBJROW                                  460
    C0000048            R0000000                                702
    C0000048            IC48                                      1
    C0000049            OBJROW                                  694
    C0000049            R0000000                                820
    C0000049            IC49                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      256
    x1                  IC1                                       1
    x1                  interdictionBudget                      849
    x2                  IC2                                       1
    x2                  interdictionBudget                      178
    x3                  IC3                                       1
    x3                  interdictionBudget                      793
    x4                  IC4                                       1
    x4                  interdictionBudget                      232
    x5                  IC5                                       1
    x5                  interdictionBudget                      851
    x6                  IC6                                       1
    x6                  interdictionBudget                      854
    x7                  IC7                                       1
    x7                  interdictionBudget                      765
    x8                  IC8                                       1
    x8                  interdictionBudget                      294
    x9                  IC9                                       1
    x9                  interdictionBudget                      147
    x10                 IC10                                      1
    x10                 interdictionBudget                       80
    x11                 IC11                                      1
    x11                 interdictionBudget                      803
    x12                 IC12                                      1
    x12                 interdictionBudget                      320
    x13                 IC13                                      1
    x13                 interdictionBudget                       81
    x14                 IC14                                      1
    x14                 interdictionBudget                      962
    x15                 IC15                                      1
    x15                 interdictionBudget                      519
    x16                 IC16                                      1
    x16                 interdictionBudget                      492
    x17                 IC17                                      1
    x17                 interdictionBudget                      503
    x18                 IC18                                      1
    x18                 interdictionBudget                      618
    x19                 IC19                                      1
    x19                 interdictionBudget                      233
    x20                 IC20                                      1
    x20                 interdictionBudget                      706
    x21                 IC21                                      1
    x21                 interdictionBudget                      599
    x22                 IC22                                      1
    x22                 interdictionBudget                      659
    x23                 IC23                                      1
    x23                 interdictionBudget                       95
    x24                 IC24                                      1
    x24                 interdictionBudget                      972
    x25                 IC25                                      1
    x25                 interdictionBudget                      877
    x26                 IC26                                      1
    x26                 interdictionBudget                      981
    x27                 IC27                                      1
    x27                 interdictionBudget                      326
    x28                 IC28                                      1
    x28                 interdictionBudget                      635
    x29                 IC29                                      1
    x29                 interdictionBudget                      144
    x30                 IC30                                      1
    x30                 interdictionBudget                      387
    x31                 IC31                                      1
    x31                 interdictionBudget                      118
    x32                 IC32                                      1
    x32                 interdictionBudget                      285
    x33                 IC33                                      1
    x33                 interdictionBudget                      804
    x34                 IC34                                      1
    x34                 interdictionBudget                      526
    x35                 IC35                                      1
    x35                 interdictionBudget                       20
    x36                 IC36                                      1
    x36                 interdictionBudget                      302
    x37                 IC37                                      1
    x37                 interdictionBudget                      645
    x38                 IC38                                      1
    x38                 interdictionBudget                       12
    x39                 IC39                                      1
    x39                 interdictionBudget                      967
    x40                 IC40                                      1
    x40                 interdictionBudget                       50
    x41                 IC41                                      1
    x41                 interdictionBudget                      305
    x42                 IC42                                      1
    x42                 interdictionBudget                      402
    x43                 IC43                                      1
    x43                 interdictionBudget                      959
    x44                 IC44                                      1
    x44                 interdictionBudget                      980
    x45                 IC45                                      1
    x45                 interdictionBudget                      279
    x46                 IC46                                      1
    x46                 interdictionBudget                      276
    x47                 IC47                                      1
    x47                 interdictionBudget                      301
    x48                 IC48                                      1
    x48                 interdictionBudget                      622
    x49                 IC49                                      1
    x49                 interdictionBudget                      643
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs                 R0000000                              12085
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 IC30                                      1
    rhs                 IC31                                      1
    rhs                 IC32                                      1
    rhs                 IC33                                      1
    rhs                 IC34                                      1
    rhs                 IC35                                      1
    rhs                 IC36                                      1
    rhs                 IC37                                      1
    rhs                 IC38                                      1
    rhs                 IC39                                      1
    rhs                 IC40                                      1
    rhs                 IC41                                      1
    rhs                 IC42                                      1
    rhs                 IC43                                      1
    rhs                 IC44                                      1
    rhs                 IC45                                      1
    rhs                 IC46                                      1
    rhs                 IC47                                      1
    rhs                 IC48                                      1
    rhs                 IC49                                      1
    rhs                 interdictionBudget                    12354
BOUNDS
 BV bnd                 C0000000          
 BV bnd                 C0000001          
 BV bnd                 C0000002          
 BV bnd                 C0000003          
 BV bnd                 C0000004          
 BV bnd                 C0000005          
 BV bnd                 C0000006          
 BV bnd                 C0000007          
 BV bnd                 C0000008          
 BV bnd                 C0000009          
 BV bnd                 C0000010          
 BV bnd                 C0000011          
 BV bnd                 C0000012          
 BV bnd                 C0000013          
 BV bnd                 C0000014          
 BV bnd                 C0000015          
 BV bnd                 C0000016          
 BV bnd                 C0000017          
 BV bnd                 C0000018          
 BV bnd                 C0000019          
 BV bnd                 C0000020          
 BV bnd                 C0000021          
 BV bnd                 C0000022          
 BV bnd                 C0000023          
 BV bnd                 C0000024          
 BV bnd                 C0000025          
 BV bnd                 C0000026          
 BV bnd                 C0000027          
 BV bnd                 C0000028          
 BV bnd                 C0000029          
 BV bnd                 C0000030          
 BV bnd                 C0000031          
 BV bnd                 C0000032          
 BV bnd                 C0000033          
 BV bnd                 C0000034          
 BV bnd                 C0000035          
 BV bnd                 C0000036          
 BV bnd                 C0000037          
 BV bnd                 C0000038          
 BV bnd                 C0000039          
 BV bnd                 C0000040          
 BV bnd                 C0000041          
 BV bnd                 C0000042          
 BV bnd                 C0000043          
 BV bnd                 C0000044          
 BV bnd                 C0000045          
 BV bnd                 C0000046          
 BV bnd                 C0000047          
 BV bnd                 C0000048          
 BV bnd                 C0000049          
 BV bnd                 x0                
 BV bnd                 x1                
 BV bnd                 x2                
 BV bnd                 x3                
 BV bnd                 x4                
 BV bnd                 x5                
 BV bnd                 x6                
 BV bnd                 x7                
 BV bnd                 x8                
 BV bnd                 x9                
 BV bnd                 x10               
 BV bnd                 x11               
 BV bnd                 x12               
 BV bnd                 x13               
 BV bnd                 x14               
 BV bnd                 x15               
 BV bnd                 x16               
 BV bnd                 x17               
 BV bnd                 x18               
 BV bnd                 x19               
 BV bnd                 x20               
 BV bnd                 x21               
 BV bnd                 x22               
 BV bnd                 x23               
 BV bnd                 x24               
 BV bnd                 x25               
 BV bnd                 x26               
 BV bnd                 x27               
 BV bnd                 x28               
 BV bnd                 x29               
 BV bnd                 x30               
 BV bnd                 x31               
 BV bnd                 x32               
 BV bnd                 x33               
 BV bnd                 x34               
 BV bnd                 x35               
 BV bnd                 x36               
 BV bnd                 x37               
 BV bnd                 x38               
 BV bnd                 x39               
 BV bnd                 x40               
 BV bnd                 x41               
 BV bnd                 x42               
 BV bnd                 x43               
 BV bnd                 x44               
 BV bnd                 x45               
 BV bnd                 x46               
 BV bnd                 x47               
 BV bnd                 x48               
 BV bnd                 x49               
ENDATA
