* ENCODING=ISO-8859-1
NAME          interKP-300-100-5-5
ROWS
 N  COST        
 L  leaderCons  
 L  followerCons
 L  inter0      
 L  inter1      
 L  inter2      
 L  inter3      
 L  inter4      
 L  inter5      
 L  inter6      
 L  inter7      
 L  inter8      
 L  inter9      
 L  inter10     
 L  inter11     
 L  inter12     
 L  inter13     
 L  inter14     
 L  inter15     
 L  inter16     
 L  inter17     
 L  inter18     
 L  inter19     
 L  inter20     
 L  inter21     
 L  inter22     
 L  inter23     
 L  inter24     
 L  inter25     
 L  inter26     
 L  inter27     
 L  inter28     
 L  inter29     
 L  inter30     
 L  inter31     
 L  inter32     
 L  inter33     
 L  inter34     
 L  inter35     
 L  inter36     
 L  inter37     
 L  inter38     
 L  inter39     
 L  inter40     
 L  inter41     
 L  inter42     
 L  inter43     
 L  inter44     
 L  inter45     
 L  inter46     
 L  inter47     
 L  inter48     
 L  inter49     
 L  inter50     
 L  inter51     
 L  inter52     
 L  inter53     
 L  inter54     
 L  inter55     
 L  inter56     
 L  inter57     
 L  inter58     
 L  inter59     
 L  inter60     
 L  inter61     
 L  inter62     
 L  inter63     
 L  inter64     
 L  inter65     
 L  inter66     
 L  inter67     
 L  inter68     
 L  inter69     
 L  inter70     
 L  inter71     
 L  inter72     
 L  inter73     
 L  inter74     
 L  inter75     
 L  inter76     
 L  inter77     
 L  inter78     
 L  inter79     
 L  inter80     
 L  inter81     
 L  inter82     
 L  inter83     
 L  inter84     
 L  inter85     
 L  inter86     
 L  inter87     
 L  inter88     
 L  inter89     
 L  inter90     
 L  inter91     
 L  inter92     
 L  inter93     
 L  inter94     
 L  inter95     
 L  inter96     
 L  inter97     
 L  inter98     
 L  inter99     
 L  inter100    
 L  inter101    
 L  inter102    
 L  inter103    
 L  inter104    
 L  inter105    
 L  inter106    
 L  inter107    
 L  inter108    
 L  inter109    
 L  inter110    
 L  inter111    
 L  inter112    
 L  inter113    
 L  inter114    
 L  inter115    
 L  inter116    
 L  inter117    
 L  inter118    
 L  inter119    
 L  inter120    
 L  inter121    
 L  inter122    
 L  inter123    
 L  inter124    
 L  inter125    
 L  inter126    
 L  inter127    
 L  inter128    
 L  inter129    
 L  inter130    
 L  inter131    
 L  inter132    
 L  inter133    
 L  inter134    
 L  inter135    
 L  inter136    
 L  inter137    
 L  inter138    
 L  inter139    
 L  inter140    
 L  inter141    
 L  inter142    
 L  inter143    
 L  inter144    
 L  inter145    
 L  inter146    
 L  inter147    
 L  inter148    
 L  inter149    
 L  inter150    
 L  inter151    
 L  inter152    
 L  inter153    
 L  inter154    
 L  inter155    
 L  inter156    
 L  inter157    
 L  inter158    
 L  inter159    
 L  inter160    
 L  inter161    
 L  inter162    
 L  inter163    
 L  inter164    
 L  inter165    
 L  inter166    
 L  inter167    
 L  inter168    
 L  inter169    
 L  inter170    
 L  inter171    
 L  inter172    
 L  inter173    
 L  inter174    
 L  inter175    
 L  inter176    
 L  inter177    
 L  inter178    
 L  inter179    
 L  inter180    
 L  inter181    
 L  inter182    
 L  inter183    
 L  inter184    
 L  inter185    
 L  inter186    
 L  inter187    
 L  inter188    
 L  inter189    
 L  inter190    
 L  inter191    
 L  inter192    
 L  inter193    
 L  inter194    
 L  inter195    
 L  inter196    
 L  inter197    
 L  inter198    
 L  inter199    
 L  inter200    
 L  inter201    
 L  inter202    
 L  inter203    
 L  inter204    
 L  inter205    
 L  inter206    
 L  inter207    
 L  inter208    
 L  inter209    
 L  inter210    
 L  inter211    
 L  inter212    
 L  inter213    
 L  inter214    
 L  inter215    
 L  inter216    
 L  inter217    
 L  inter218    
 L  inter219    
 L  inter220    
 L  inter221    
 L  inter222    
 L  inter223    
 L  inter224    
 L  inter225    
 L  inter226    
 L  inter227    
 L  inter228    
 L  inter229    
 L  inter230    
 L  inter231    
 L  inter232    
 L  inter233    
 L  inter234    
 L  inter235    
 L  inter236    
 L  inter237    
 L  inter238    
 L  inter239    
 L  inter240    
 L  inter241    
 L  inter242    
 L  inter243    
 L  inter244    
 L  inter245    
 L  inter246    
 L  inter247    
 L  inter248    
 L  inter249    
 L  inter250    
 L  inter251    
 L  inter252    
 L  inter253    
 L  inter254    
 L  inter255    
 L  inter256    
 L  inter257    
 L  inter258    
 L  inter259    
 L  inter260    
 L  inter261    
 L  inter262    
 L  inter263    
 L  inter264    
 L  inter265    
 L  inter266    
 L  inter267    
 L  inter268    
 L  inter269    
 L  inter270    
 L  inter271    
 L  inter272    
 L  inter273    
 L  inter274    
 L  inter275    
 L  inter276    
 L  inter277    
 L  inter278    
 L  inter279    
 L  inter280    
 L  inter281    
 L  inter282    
 L  inter283    
 L  inter284    
 L  inter285    
 L  inter286    
 L  inter287    
 L  inter288    
 L  inter289    
 L  inter290    
 L  inter291    
 L  inter292    
 L  inter293    
 L  inter294    
 L  inter295    
 L  inter296    
 L  inter297    
 L  inter298    
 L  inter299    
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0            inter0                              1
    x1            leaderCons                         18
    x1            inter1                              1
    x2            leaderCons                         51
    x2            inter2                              1
    x3            leaderCons                         38
    x3            inter3                              1
    x4            leaderCons                         62
    x4            inter4                              1
    x5            leaderCons                          4
    x5            inter5                              1
    x6            leaderCons                         85
    x6            inter6                              1
    x7            leaderCons                         69
    x7            inter7                              1
    x8            leaderCons                         56
    x8            inter8                              1
    x9            leaderCons                         18
    x9            inter9                              1
    x10           leaderCons                          1
    x10           inter10                             1
    x11           leaderCons                         13
    x11           inter11                             1
    x12           leaderCons                         81
    x12           inter12                             1
    x13           leaderCons                         89
    x13           inter13                             1
    x14           leaderCons                         37
    x14           inter14                             1
    x15           leaderCons                         32
    x15           inter15                             1
    x16           leaderCons                         30
    x16           inter16                             1
    x17           leaderCons                         79
    x17           inter17                             1
    x18           leaderCons                         62
    x18           inter18                             1
    x19           leaderCons                         97
    x19           inter19                             1
    x20           leaderCons                          4
    x20           inter20                             1
    x21           leaderCons                         10
    x21           inter21                             1
    x22           leaderCons                         24
    x22           inter22                             1
    x23           leaderCons                          9
    x23           inter23                             1
    x24           leaderCons                         27
    x24           inter24                             1
    x25           leaderCons                         54
    x25           inter25                             1
    x26           leaderCons                         95
    x26           inter26                             1
    x27           leaderCons                         87
    x27           inter27                             1
    x28           leaderCons                         38
    x28           inter28                             1
    x29           leaderCons                         14
    x29           inter29                             1
    x30           leaderCons                         55
    x30           inter30                             1
    x31           leaderCons                         48
    x31           inter31                             1
    x32           leaderCons                         40
    x32           inter32                             1
    x33           leaderCons                         85
    x33           inter33                             1
    x34           leaderCons                         14
    x34           inter34                             1
    x35           leaderCons                         62
    x35           inter35                             1
    x36           leaderCons                         72
    x36           inter36                             1
    x37           leaderCons                         62
    x37           inter37                             1
    x38           leaderCons                         98
    x38           inter38                             1
    x39           leaderCons                         18
    x39           inter39                             1
    x40           leaderCons                         22
    x40           inter40                             1
    x41           leaderCons                         93
    x41           inter41                             1
    x42           leaderCons                         74
    x42           inter42                             1
    x43           leaderCons                         81
    x43           inter43                             1
    x44           leaderCons                         67
    x44           inter44                             1
    x45           leaderCons                         57
    x45           inter45                             1
    x46           leaderCons                         58
    x46           inter46                             1
    x47           leaderCons                         44
    x47           inter47                             1
    x48           leaderCons                          7
    x48           inter48                             1
    x49           leaderCons                         94
    x49           inter49                             1
    x50           leaderCons                          3
    x50           inter50                             1
    x51           leaderCons                         60
    x51           inter51                             1
    x52           leaderCons                         94
    x52           inter52                             1
    x53           leaderCons                         96
    x53           inter53                             1
    x54           leaderCons                         24
    x54           inter54                             1
    x55           leaderCons                         53
    x55           inter55                             1
    x56           leaderCons                         12
    x56           inter56                             1
    x57           leaderCons                         42
    x57           inter57                             1
    x58           leaderCons                         84
    x58           inter58                             1
    x59           leaderCons                         92
    x59           inter59                             1
    x60           leaderCons                         42
    x60           inter60                             1
    x61           leaderCons                         50
    x61           inter61                             1
    x62           leaderCons                         89
    x62           inter62                             1
    x63           inter63                             1
    x64           leaderCons                          3
    x64           inter64                             1
    x65           leaderCons                         22
    x65           inter65                             1
    x66           leaderCons                         15
    x66           inter66                             1
    x67           leaderCons                         33
    x67           inter67                             1
    x68           leaderCons                         63
    x68           inter68                             1
    x69           leaderCons                         52
    x69           inter69                             1
    x70           leaderCons                         46
    x70           inter70                             1
    x71           leaderCons                         67
    x71           inter71                             1
    x72           leaderCons                         44
    x72           inter72                             1
    x73           leaderCons                         27
    x73           inter73                             1
    x74           leaderCons                         56
    x74           inter74                             1
    x75           leaderCons                         78
    x75           inter75                             1
    x76           leaderCons                         86
    x76           inter76                             1
    x77           leaderCons                         57
    x77           inter77                             1
    x78           leaderCons                         67
    x78           inter78                             1
    x79           leaderCons                         52
    x79           inter79                             1
    x80           leaderCons                         81
    x80           inter80                             1
    x81           leaderCons                         73
    x81           inter81                             1
    x82           leaderCons                         48
    x82           inter82                             1
    x83           leaderCons                          5
    x83           inter83                             1
    x84           leaderCons                         43
    x84           inter84                             1
    x85           leaderCons                         54
    x85           inter85                             1
    x86           leaderCons                         13
    x86           inter86                             1
    x87           leaderCons                         48
    x87           inter87                             1
    x88           leaderCons                         39
    x88           inter88                             1
    x89           leaderCons                         11
    x89           inter89                             1
    x90           leaderCons                         41
    x90           inter90                             1
    x91           leaderCons                         70
    x91           inter91                             1
    x92           leaderCons                         62
    x92           inter92                             1
    x93           leaderCons                         71
    x93           inter93                             1
    x94           leaderCons                         50
    x94           inter94                             1
    x95           leaderCons                         86
    x95           inter95                             1
    x96           leaderCons                         96
    x96           inter96                             1
    x97           leaderCons                         21
    x97           inter97                             1
    x98           leaderCons                         72
    x98           inter98                             1
    x99           leaderCons                         36
    x99           inter99                             1
    x100          leaderCons                         27
    x100          inter100                            1
    x101          leaderCons                         36
    x101          inter101                            1
    x102          leaderCons                         45
    x102          inter102                            1
    x103          leaderCons                         24
    x103          inter103                            1
    x104          leaderCons                         13
    x104          inter104                            1
    x105          leaderCons                         16
    x105          inter105                            1
    x106          leaderCons                         61
    x106          inter106                            1
    x107          leaderCons                         44
    x107          inter107                            1
    x108          leaderCons                         12
    x108          inter108                            1
    x109          leaderCons                         80
    x109          inter109                            1
    x110          leaderCons                         16
    x110          inter110                            1
    x111          leaderCons                         66
    x111          inter111                            1
    x112          leaderCons                         27
    x112          inter112                            1
    x113          leaderCons                         21
    x113          inter113                            1
    x114          leaderCons                         26
    x114          inter114                            1
    x115          leaderCons                         83
    x115          inter115                            1
    x116          leaderCons                         91
    x116          inter116                            1
    x117          leaderCons                         97
    x117          inter117                            1
    x118          leaderCons                         12
    x118          inter118                            1
    x119          leaderCons                         44
    x119          inter119                            1
    x120          leaderCons                         27
    x120          inter120                            1
    x121          leaderCons                         34
    x121          inter121                            1
    x122          leaderCons                         26
    x122          inter122                            1
    x123          leaderCons                         48
    x123          inter123                            1
    x124          leaderCons                         50
    x124          inter124                            1
    x125          leaderCons                         57
    x125          inter125                            1
    x126          leaderCons                         33
    x126          inter126                            1
    x127          leaderCons                         60
    x127          inter127                            1
    x128          leaderCons                          8
    x128          inter128                            1
    x129          leaderCons                         86
    x129          inter129                            1
    x130          leaderCons                         82
    x130          inter130                            1
    x131          leaderCons                         83
    x131          inter131                            1
    x132          leaderCons                         64
    x132          inter132                            1
    x133          leaderCons                         55
    x133          inter133                            1
    x134          leaderCons                         52
    x134          inter134                            1
    x135          leaderCons                          1
    x135          inter135                            1
    x136          leaderCons                         33
    x136          inter136                            1
    x137          leaderCons                         69
    x137          inter137                            1
    x138          leaderCons                         31
    x138          inter138                            1
    x139          leaderCons                         46
    x139          inter139                            1
    x140          leaderCons                         23
    x140          inter140                            1
    x141          leaderCons                         11
    x141          inter141                            1
    x142          leaderCons                         18
    x142          inter142                            1
    x143          leaderCons                         93
    x143          inter143                            1
    x144          leaderCons                         37
    x144          inter144                            1
    x145          leaderCons                         61
    x145          inter145                            1
    x146          leaderCons                         24
    x146          inter146                            1
    x147          leaderCons                         71
    x147          inter147                            1
    x148          leaderCons                         58
    x148          inter148                            1
    x149          leaderCons                         93
    x149          inter149                            1
    x150          leaderCons                         71
    x150          inter150                            1
    x151          leaderCons                          7
    x151          inter151                            1
    x152          leaderCons                         57
    x152          inter152                            1
    x153          leaderCons                         73
    x153          inter153                            1
    x154          leaderCons                         34
    x154          inter154                            1
    x155          leaderCons                         27
    x155          inter155                            1
    x156          leaderCons                         98
    x156          inter156                            1
    x157          leaderCons                         30
    x157          inter157                            1
    x158          leaderCons                         34
    x158          inter158                            1
    x159          leaderCons                         21
    x159          inter159                            1
    x160          leaderCons                         94
    x160          inter160                            1
    x161          leaderCons                         86
    x161          inter161                            1
    x162          inter162                            1
    x163          leaderCons                         57
    x163          inter163                            1
    x164          leaderCons                         66
    x164          inter164                            1
    x165          leaderCons                          4
    x165          inter165                            1
    x166          leaderCons                         61
    x166          inter166                            1
    x167          leaderCons                          6
    x167          inter167                            1
    x168          leaderCons                         49
    x168          inter168                            1
    x169          leaderCons                         60
    x169          inter169                            1
    x170          leaderCons                         94
    x170          inter170                            1
    x171          leaderCons                         89
    x171          inter171                            1
    x172          leaderCons                         28
    x172          inter172                            1
    x173          leaderCons                         34
    x173          inter173                            1
    x174          leaderCons                         47
    x174          inter174                            1
    x175          leaderCons                         12
    x175          inter175                            1
    x176          leaderCons                         36
    x176          inter176                            1
    x177          leaderCons                         81
    x177          inter177                            1
    x178          leaderCons                         40
    x178          inter178                            1
    x179          leaderCons                         41
    x179          inter179                            1
    x180          leaderCons                          4
    x180          inter180                            1
    x181          leaderCons                         17
    x181          inter181                            1
    x182          leaderCons                         80
    x182          inter182                            1
    x183          leaderCons                         55
    x183          inter183                            1
    x184          inter184                            1
    x185          leaderCons                          2
    x185          inter185                            1
    x186          leaderCons                         34
    x186          inter186                            1
    x187          leaderCons                         30
    x187          inter187                            1
    x188          leaderCons                         25
    x188          inter188                            1
    x189          leaderCons                         93
    x189          inter189                            1
    x190          leaderCons                         57
    x190          inter190                            1
    x191          leaderCons                         68
    x191          inter191                            1
    x192          leaderCons                         39
    x192          inter192                            1
    x193          leaderCons                         24
    x193          inter193                            1
    x194          leaderCons                         51
    x194          inter194                            1
    x195          leaderCons                         59
    x195          inter195                            1
    x196          leaderCons                         49
    x196          inter196                            1
    x197          leaderCons                         49
    x197          inter197                            1
    x198          leaderCons                         30
    x198          inter198                            1
    x199          leaderCons                         19
    x199          inter199                            1
    x200          leaderCons                          8
    x200          inter200                            1
    x201          leaderCons                         40
    x201          inter201                            1
    x202          leaderCons                         92
    x202          inter202                            1
    x203          leaderCons                         80
    x203          inter203                            1
    x204          leaderCons                         23
    x204          inter204                            1
    x205          leaderCons                         73
    x205          inter205                            1
    x206          leaderCons                         13
    x206          inter206                            1
    x207          leaderCons                         21
    x207          inter207                            1
    x208          leaderCons                         20
    x208          inter208                            1
    x209          leaderCons                         50
    x209          inter209                            1
    x210          leaderCons                         79
    x210          inter210                            1
    x211          leaderCons                         16
    x211          inter211                            1
    x212          leaderCons                         76
    x212          inter212                            1
    x213          leaderCons                         23
    x213          inter213                            1
    x214          leaderCons                         10
    x214          inter214                            1
    x215          leaderCons                         18
    x215          inter215                            1
    x216          leaderCons                         80
    x216          inter216                            1
    x217          leaderCons                         37
    x217          inter217                            1
    x218          leaderCons                         42
    x218          inter218                            1
    x219          leaderCons                         35
    x219          inter219                            1
    x220          leaderCons                         49
    x220          inter220                            1
    x221          leaderCons                         57
    x221          inter221                            1
    x222          leaderCons                         30
    x222          inter222                            1
    x223          leaderCons                         15
    x223          inter223                            1
    x224          leaderCons                         26
    x224          inter224                            1
    x225          leaderCons                         24
    x225          inter225                            1
    x226          leaderCons                         87
    x226          inter226                            1
    x227          leaderCons                         60
    x227          inter227                            1
    x228          leaderCons                         12
    x228          inter228                            1
    x229          leaderCons                         92
    x229          inter229                            1
    x230          leaderCons                         98
    x230          inter230                            1
    x231          leaderCons                         68
    x231          inter231                            1
    x232          leaderCons                         51
    x232          inter232                            1
    x233          leaderCons                         42
    x233          inter233                            1
    x234          leaderCons                         63
    x234          inter234                            1
    x235          leaderCons                         23
    x235          inter235                            1
    x236          leaderCons                         16
    x236          inter236                            1
    x237          leaderCons                         56
    x237          inter237                            1
    x238          leaderCons                         19
    x238          inter238                            1
    x239          leaderCons                         31
    x239          inter239                            1
    x240          leaderCons                         75
    x240          inter240                            1
    x241          leaderCons                         11
    x241          inter241                            1
    x242          leaderCons                         53
    x242          inter242                            1
    x243          leaderCons                         96
    x243          inter243                            1
    x244          leaderCons                         24
    x244          inter244                            1
    x245          leaderCons                         93
    x245          inter245                            1
    x246          leaderCons                         45
    x246          inter246                            1
    x247          leaderCons                          7
    x247          inter247                            1
    x248          leaderCons                          2
    x248          inter248                            1
    x249          leaderCons                         88
    x249          inter249                            1
    x250          leaderCons                         57
    x250          inter250                            1
    x251          leaderCons                         54
    x251          inter251                            1
    x252          leaderCons                         36
    x252          inter252                            1
    x253          leaderCons                         79
    x253          inter253                            1
    x254          leaderCons                         50
    x254          inter254                            1
    x255          leaderCons                         93
    x255          inter255                            1
    x256          leaderCons                         27
    x256          inter256                            1
    x257          leaderCons                         14
    x257          inter257                            1
    x258          leaderCons                         15
    x258          inter258                            1
    x259          leaderCons                         13
    x259          inter259                            1
    x260          leaderCons                         65
    x260          inter260                            1
    x261          leaderCons                         78
    x261          inter261                            1
    x262          leaderCons                         73
    x262          inter262                            1
    x263          leaderCons                         85
    x263          inter263                            1
    x264          leaderCons                         69
    x264          inter264                            1
    x265          leaderCons                         28
    x265          inter265                            1
    x266          leaderCons                         39
    x266          inter266                            1
    x267          leaderCons                         68
    x267          inter267                            1
    x268          leaderCons                          3
    x268          inter268                            1
    x269          leaderCons                         78
    x269          inter269                            1
    x270          leaderCons                         65
    x270          inter270                            1
    x271          leaderCons                         26
    x271          inter271                            1
    x272          leaderCons                         35
    x272          inter272                            1
    x273          leaderCons                         76
    x273          inter273                            1
    x274          leaderCons                         73
    x274          inter274                            1
    x275          leaderCons                         86
    x275          inter275                            1
    x276          leaderCons                         74
    x276          inter276                            1
    x277          leaderCons                         28
    x277          inter277                            1
    x278          leaderCons                          1
    x278          inter278                            1
    x279          leaderCons                         73
    x279          inter279                            1
    x280          leaderCons                         58
    x280          inter280                            1
    x281          leaderCons                         29
    x281          inter281                            1
    x282          leaderCons                          8
    x282          inter282                            1
    x283          leaderCons                         64
    x283          inter283                            1
    x284          leaderCons                          4
    x284          inter284                            1
    x285          leaderCons                         66
    x285          inter285                            1
    x286          leaderCons                         59
    x286          inter286                            1
    x287          leaderCons                         62
    x287          inter287                            1
    x288          leaderCons                         27
    x288          inter288                            1
    x289          leaderCons                         99
    x289          inter289                            1
    x290          leaderCons                         20
    x290          inter290                            1
    x291          leaderCons                         77
    x291          inter291                            1
    x292          leaderCons                         98
    x292          inter292                            1
    x293          leaderCons                         83
    x293          inter293                            1
    x294          leaderCons                         27
    x294          inter294                            1
    x295          leaderCons                         63
    x295          inter295                            1
    x296          leaderCons                         47
    x296          inter296                            1
    x297          leaderCons                         45
    x297          inter297                            1
    x298          leaderCons                         26
    x298          inter298                            1
    x299          leaderCons                         36
    x299          inter299                            1
    y0            COST                               75
    y0            followerCons                       65
    y0            inter0                              1
    y1            COST                               92
    y1            followerCons                       82
    y1            inter1                              1
    y2            COST                               20
    y2            followerCons                       10
    y2            inter2                              1
    y3            COST                               32
    y3            followerCons                       22
    y3            inter3                              1
    y4            COST                               59
    y4            followerCons                       49
    y4            inter4                              1
    y5            COST                               57
    y5            followerCons                       47
    y5            inter5                              1
    y6            COST                               70
    y6            followerCons                       60
    y6            inter6                              1
    y7            COST                               24
    y7            followerCons                       14
    y7            inter7                              1
    y8            COST                               91
    y8            followerCons                       81
    y8            inter8                              1
    y9            COST                              105
    y9            followerCons                       95
    y9            inter9                              1
    y10           COST                               21
    y10           followerCons                       11
    y10           inter10                             1
    y11           COST                               88
    y11           followerCons                       78
    y11           inter11                             1
    y12           COST                               13
    y12           followerCons                        3
    y12           inter12                             1
    y13           COST                               35
    y13           followerCons                       25
    y13           inter13                             1
    y14           COST                               28
    y14           followerCons                       18
    y14           inter14                             1
    y15           COST                               49
    y15           followerCons                       39
    y15           inter15                             1
    y16           COST                               53
    y16           followerCons                       43
    y16           inter16                             1
    y17           COST                               77
    y17           followerCons                       67
    y17           inter17                             1
    y18           COST                               98
    y18           followerCons                       88
    y18           inter18                             1
    y19           COST                               65
    y19           followerCons                       55
    y19           inter19                             1
    y20           COST                               15
    y20           followerCons                        5
    y20           inter20                             1
    y21           COST                               28
    y21           followerCons                       18
    y21           inter21                             1
    y22           COST                               65
    y22           followerCons                       55
    y22           inter22                             1
    y23           COST                               87
    y23           followerCons                       77
    y23           inter23                             1
    y24           COST                               30
    y24           followerCons                       20
    y24           inter24                             1
    y25           COST                               83
    y25           followerCons                       73
    y25           inter25                             1
    y26           COST                              103
    y26           followerCons                       93
    y26           inter26                             1
    y27           COST                               99
    y27           followerCons                       89
    y27           inter27                             1
    y28           COST                               96
    y28           followerCons                       86
    y28           inter28                             1
    y29           COST                               92
    y29           followerCons                       82
    y29           inter29                             1
    y30           COST                               59
    y30           followerCons                       49
    y30           inter30                             1
    y31           COST                              102
    y31           followerCons                       92
    y31           inter31                             1
    y32           COST                               51
    y32           followerCons                       41
    y32           inter32                             1
    y33           COST                               75
    y33           followerCons                       65
    y33           inter33                             1
    y34           COST                               24
    y34           followerCons                       14
    y34           inter34                             1
    y35           COST                              100
    y35           followerCons                       90
    y35           inter35                             1
    y36           COST                               24
    y36           followerCons                       14
    y36           inter36                             1
    y37           COST                               16
    y37           followerCons                        6
    y37           inter37                             1
    y38           COST                               46
    y38           followerCons                       36
    y38           inter38                             1
    y39           COST                               24
    y39           followerCons                       14
    y39           inter39                             1
    y40           COST                               99
    y40           followerCons                       89
    y40           inter40                             1
    y41           COST                               81
    y41           followerCons                       71
    y41           inter41                             1
    y42           COST                               90
    y42           followerCons                       80
    y42           inter42                             1
    y43           COST                               58
    y43           followerCons                       48
    y43           inter43                             1
    y44           COST                               21
    y44           followerCons                       11
    y44           inter44                             1
    y45           COST                              101
    y45           followerCons                       91
    y45           inter45                             1
    y46           COST                               50
    y46           followerCons                       40
    y46           inter46                             1
    y47           COST                               37
    y47           followerCons                       27
    y47           inter47                             1
    y48           COST                               56
    y48           followerCons                       46
    y48           inter48                             1
    y49           COST                               22
    y49           followerCons                       12
    y49           inter49                             1
    y50           COST                              106
    y50           followerCons                       96
    y50           inter50                             1
    y51           COST                               84
    y51           followerCons                       74
    y51           inter51                             1
    y52           COST                               62
    y52           followerCons                       52
    y52           inter52                             1
    y53           COST                               67
    y53           followerCons                       57
    y53           inter53                             1
    y54           COST                              104
    y54           followerCons                       94
    y54           inter54                             1
    y55           COST                               96
    y55           followerCons                       86
    y55           inter55                             1
    y56           COST                               46
    y56           followerCons                       36
    y56           inter56                             1
    y57           COST                               30
    y57           followerCons                       20
    y57           inter57                             1
    y58           COST                               48
    y58           followerCons                       38
    y58           inter58                             1
    y59           COST                               84
    y59           followerCons                       74
    y59           inter59                             1
    y60           COST                               89
    y60           followerCons                       79
    y60           inter60                             1
    y61           COST                               63
    y61           followerCons                       53
    y61           inter61                             1
    y62           COST                               76
    y62           followerCons                       66
    y62           inter62                             1
    y63           COST                               64
    y63           followerCons                       54
    y63           inter63                             1
    y64           COST                               78
    y64           followerCons                       68
    y64           inter64                             1
    y65           COST                               94
    y65           followerCons                       84
    y65           inter65                             1
    y66           COST                               73
    y66           followerCons                       63
    y66           inter66                             1
    y67           COST                               74
    y67           followerCons                       64
    y67           inter67                             1
    y68           COST                               25
    y68           followerCons                       15
    y68           inter68                             1
    y69           COST                               12
    y69           followerCons                        2
    y69           inter69                             1
    y70           COST                               59
    y70           followerCons                       49
    y70           inter70                             1
    y71           COST                               43
    y71           followerCons                       33
    y71           inter71                             1
    y72           COST                               51
    y72           followerCons                       41
    y72           inter72                             1
    y73           COST                               38
    y73           followerCons                       28
    y73           inter73                             1
    y74           COST                               72
    y74           followerCons                       62
    y74           inter74                             1
    y75           COST                               74
    y75           followerCons                       64
    y75           inter75                             1
    y76           COST                               80
    y76           followerCons                       70
    y76           inter76                             1
    y77           COST                               52
    y77           followerCons                       42
    y77           inter77                             1
    y78           COST                              106
    y78           followerCons                       96
    y78           inter78                             1
    y79           COST                               91
    y79           followerCons                       81
    y79           inter79                             1
    y80           COST                               95
    y80           followerCons                       85
    y80           inter80                             1
    y81           COST                               99
    y81           followerCons                       89
    y81           inter81                             1
    y82           COST                               79
    y82           followerCons                       69
    y82           inter82                             1
    y83           COST                               73
    y83           followerCons                       63
    y83           inter83                             1
    y84           COST                               53
    y84           followerCons                       43
    y84           inter84                             1
    y85           COST                               55
    y85           followerCons                       45
    y85           inter85                             1
    y86           COST                              104
    y86           followerCons                       94
    y86           inter86                             1
    y87           COST                               72
    y87           followerCons                       62
    y87           inter87                             1
    y88           COST                               33
    y88           followerCons                       23
    y88           inter88                             1
    y89           COST                               21
    y89           followerCons                       11
    y89           inter89                             1
    y90           COST                               19
    y90           followerCons                        9
    y90           inter90                             1
    y91           COST                               35
    y91           followerCons                       25
    y91           inter91                             1
    y92           COST                              105
    y92           followerCons                       95
    y92           inter92                             1
    y93           COST                               29
    y93           followerCons                       19
    y93           inter93                             1
    y94           COST                              110
    y94           followerCons                      100
    y94           inter94                             1
    y95           COST                               63
    y95           followerCons                       53
    y95           inter95                             1
    y96           COST                               40
    y96           followerCons                       30
    y96           inter96                             1
    y97           COST                              101
    y97           followerCons                       91
    y97           inter97                             1
    y98           COST                               14
    y98           followerCons                        4
    y98           inter98                             1
    y99           COST                               38
    y99           followerCons                       28
    y99           inter99                             1
    y100          COST                               97
    y100          followerCons                       87
    y100          inter100                            1
    y101          COST                               40
    y101          followerCons                       30
    y101          inter101                            1
    y102          COST                               17
    y102          followerCons                        7
    y102          inter102                            1
    y103          COST                               36
    y103          followerCons                       26
    y103          inter103                            1
    y104          COST                               22
    y104          followerCons                       12
    y104          inter104                            1
    y105          COST                               23
    y105          followerCons                       13
    y105          inter105                            1
    y106          COST                               51
    y106          followerCons                       41
    y106          inter106                            1
    y107          COST                              104
    y107          followerCons                       94
    y107          inter107                            1
    y108          COST                               98
    y108          followerCons                       88
    y108          inter108                            1
    y109          COST                               83
    y109          followerCons                       73
    y109          inter109                            1
    y110          COST                               74
    y110          followerCons                       64
    y110          inter110                            1
    y111          COST                               19
    y111          followerCons                        9
    y111          inter111                            1
    y112          COST                               96
    y112          followerCons                       86
    y112          inter112                            1
    y113          COST                               36
    y113          followerCons                       26
    y113          inter113                            1
    y114          COST                               42
    y114          followerCons                       32
    y114          inter114                            1
    y115          COST                               24
    y115          followerCons                       14
    y115          inter115                            1
    y116          COST                               62
    y116          followerCons                       52
    y116          inter116                            1
    y117          COST                               19
    y117          followerCons                        9
    y117          inter117                            1
    y118          COST                               33
    y118          followerCons                       23
    y118          inter118                            1
    y119          COST                              102
    y119          followerCons                       92
    y119          inter119                            1
    y120          COST                               96
    y120          followerCons                       86
    y120          inter120                            1
    y121          COST                               68
    y121          followerCons                       58
    y121          inter121                            1
    y122          COST                               66
    y122          followerCons                       56
    y122          inter122                            1
    y123          COST                               93
    y123          followerCons                       83
    y123          inter123                            1
    y124          COST                               29
    y124          followerCons                       19
    y124          inter124                            1
    y125          COST                               12
    y125          followerCons                        2
    y125          inter125                            1
    y126          COST                               69
    y126          followerCons                       59
    y126          inter126                            1
    y127          COST                               40
    y127          followerCons                       30
    y127          inter127                            1
    y128          COST                               85
    y128          followerCons                       75
    y128          inter128                            1
    y129          COST                               36
    y129          followerCons                       26
    y129          inter129                            1
    y130          COST                               93
    y130          followerCons                       83
    y130          inter130                            1
    y131          COST                               23
    y131          followerCons                       13
    y131          inter131                            1
    y132          COST                               36
    y132          followerCons                       26
    y132          inter132                            1
    y133          COST                               48
    y133          followerCons                       38
    y133          inter133                            1
    y134          COST                               25
    y134          followerCons                       15
    y134          inter134                            1
    y135          COST                               99
    y135          followerCons                       89
    y135          inter135                            1
    y136          COST                               55
    y136          followerCons                       45
    y136          inter136                            1
    y137          COST                               16
    y137          followerCons                        6
    y137          inter137                            1
    y138          COST                               16
    y138          followerCons                        6
    y138          inter138                            1
    y139          COST                               25
    y139          followerCons                       15
    y139          inter139                            1
    y140          COST                               78
    y140          followerCons                       68
    y140          inter140                            1
    y141          COST                               54
    y141          followerCons                       44
    y141          inter141                            1
    y142          COST                               80
    y142          followerCons                       70
    y142          inter142                            1
    y143          COST                               26
    y143          followerCons                       16
    y143          inter143                            1
    y144          COST                               73
    y144          followerCons                       63
    y144          inter144                            1
    y145          COST                               45
    y145          followerCons                       35
    y145          inter145                            1
    y146          COST                              101
    y146          followerCons                       91
    y146          inter146                            1
    y147          COST                               29
    y147          followerCons                       19
    y147          inter147                            1
    y148          COST                               87
    y148          followerCons                       77
    y148          inter148                            1
    y149          COST                               91
    y149          followerCons                       81
    y149          inter149                            1
    y150          COST                               58
    y150          followerCons                       48
    y150          inter150                            1
    y151          COST                               78
    y151          followerCons                       68
    y151          inter151                            1
    y152          COST                               97
    y152          followerCons                       87
    y152          inter152                            1
    y153          COST                               95
    y153          followerCons                       85
    y153          inter153                            1
    y154          COST                              107
    y154          followerCons                       97
    y154          inter154                            1
    y155          COST                              108
    y155          followerCons                       98
    y155          inter155                            1
    y156          COST                               99
    y156          followerCons                       89
    y156          inter156                            1
    y157          COST                               11
    y157          followerCons                        1
    y157          inter157                            1
    y158          COST                               66
    y158          followerCons                       56
    y158          inter158                            1
    y159          COST                               56
    y159          followerCons                       46
    y159          inter159                            1
    y160          COST                               97
    y160          followerCons                       87
    y160          inter160                            1
    y161          COST                               79
    y161          followerCons                       69
    y161          inter161                            1
    y162          COST                               46
    y162          followerCons                       36
    y162          inter162                            1
    y163          COST                               64
    y163          followerCons                       54
    y163          inter163                            1
    y164          COST                               59
    y164          followerCons                       49
    y164          inter164                            1
    y165          COST                               16
    y165          followerCons                        6
    y165          inter165                            1
    y166          COST                               61
    y166          followerCons                       51
    y166          inter166                            1
    y167          COST                               36
    y167          followerCons                       26
    y167          inter167                            1
    y168          COST                               60
    y168          followerCons                       50
    y168          inter168                            1
    y169          COST                               62
    y169          followerCons                       52
    y169          inter169                            1
    y170          COST                               37
    y170          followerCons                       27
    y170          inter170                            1
    y171          COST                               43
    y171          followerCons                       33
    y171          inter171                            1
    y172          COST                               82
    y172          followerCons                       72
    y172          inter172                            1
    y173          COST                              101
    y173          followerCons                       91
    y173          inter173                            1
    y174          COST                               47
    y174          followerCons                       37
    y174          inter174                            1
    y175          COST                               70
    y175          followerCons                       60
    y175          inter175                            1
    y176          COST                               80
    y176          followerCons                       70
    y176          inter176                            1
    y177          COST                               43
    y177          followerCons                       33
    y177          inter177                            1
    y178          COST                              102
    y178          followerCons                       92
    y178          inter178                            1
    y179          COST                               88
    y179          followerCons                       78
    y179          inter179                            1
    y180          COST                               51
    y180          followerCons                       41
    y180          inter180                            1
    y181          COST                               83
    y181          followerCons                       73
    y181          inter181                            1
    y182          COST                               26
    y182          followerCons                       16
    y182          inter182                            1
    y183          COST                               60
    y183          followerCons                       50
    y183          inter183                            1
    y184          COST                               21
    y184          followerCons                       11
    y184          inter184                            1
    y185          COST                               43
    y185          followerCons                       33
    y185          inter185                            1
    y186          COST                               89
    y186          followerCons                       79
    y186          inter186                            1
    y187          COST                               50
    y187          followerCons                       40
    y187          inter187                            1
    y188          COST                              101
    y188          followerCons                       91
    y188          inter188                            1
    y189          COST                               46
    y189          followerCons                       36
    y189          inter189                            1
    y190          COST                               19
    y190          followerCons                        9
    y190          inter190                            1
    y191          COST                               46
    y191          followerCons                       36
    y191          inter191                            1
    y192          COST                               52
    y192          followerCons                       42
    y192          inter192                            1
    y193          COST                               95
    y193          followerCons                       85
    y193          inter193                            1
    y194          COST                               27
    y194          followerCons                       17
    y194          inter194                            1
    y195          COST                              102
    y195          followerCons                       92
    y195          inter195                            1
    y196          COST                               28
    y196          followerCons                       18
    y196          inter196                            1
    y197          COST                               24
    y197          followerCons                       14
    y197          inter197                            1
    y198          COST                               31
    y198          followerCons                       21
    y198          inter198                            1
    y199          COST                               23
    y199          followerCons                       13
    y199          inter199                            1
    y200          COST                               64
    y200          followerCons                       54
    y200          inter200                            1
    y201          COST                               91
    y201          followerCons                       81
    y201          inter201                            1
    y202          COST                               40
    y202          followerCons                       30
    y202          inter202                            1
    y203          COST                               64
    y203          followerCons                       54
    y203          inter203                            1
    y204          COST                               98
    y204          followerCons                       88
    y204          inter204                            1
    y205          COST                              100
    y205          followerCons                       90
    y205          inter205                            1
    y206          COST                               47
    y206          followerCons                       37
    y206          inter206                            1
    y207          COST                               89
    y207          followerCons                       79
    y207          inter207                            1
    y208          COST                               79
    y208          followerCons                       69
    y208          inter208                            1
    y209          COST                              100
    y209          followerCons                       90
    y209          inter209                            1
    y210          COST                               60
    y210          followerCons                       50
    y210          inter210                            1
    y211          COST                               85
    y211          followerCons                       75
    y211          inter211                            1
    y212          COST                               98
    y212          followerCons                       88
    y212          inter212                            1
    y213          COST                               67
    y213          followerCons                       57
    y213          inter213                            1
    y214          COST                               42
    y214          followerCons                       32
    y214          inter214                            1
    y215          COST                               68
    y215          followerCons                       58
    y215          inter215                            1
    y216          COST                               65
    y216          followerCons                       55
    y216          inter216                            1
    y217          COST                               54
    y217          followerCons                       44
    y217          inter217                            1
    y218          COST                               84
    y218          followerCons                       74
    y218          inter218                            1
    y219          COST                               78
    y219          followerCons                       68
    y219          inter219                            1
    y220          COST                               85
    y220          followerCons                       75
    y220          inter220                            1
    y221          COST                               50
    y221          followerCons                       40
    y221          inter221                            1
    y222          COST                               33
    y222          followerCons                       23
    y222          inter222                            1
    y223          COST                               29
    y223          followerCons                       19
    y223          inter223                            1
    y224          COST                               62
    y224          followerCons                       52
    y224          inter224                            1
    y225          COST                               86
    y225          followerCons                       76
    y225          inter225                            1
    y226          COST                               81
    y226          followerCons                       71
    y226          inter226                            1
    y227          COST                               14
    y227          followerCons                        4
    y227          inter227                            1
    y228          COST                              101
    y228          followerCons                       91
    y228          inter228                            1
    y229          COST                              108
    y229          followerCons                       98
    y229          inter229                            1
    y230          COST                               22
    y230          followerCons                       12
    y230          inter230                            1
    y231          COST                              104
    y231          followerCons                       94
    y231          inter231                            1
    y232          COST                               39
    y232          followerCons                       29
    y232          inter232                            1
    y233          COST                               73
    y233          followerCons                       63
    y233          inter233                            1
    y234          COST                               67
    y234          followerCons                       57
    y234          inter234                            1
    y235          COST                               15
    y235          followerCons                        5
    y235          inter235                            1
    y236          COST                               60
    y236          followerCons                       50
    y236          inter236                            1
    y237          COST                               43
    y237          followerCons                       33
    y237          inter237                            1
    y238          COST                               64
    y238          followerCons                       54
    y238          inter238                            1
    y239          COST                               74
    y239          followerCons                       64
    y239          inter239                            1
    y240          COST                               77
    y240          followerCons                       67
    y240          inter240                            1
    y241          COST                               66
    y241          followerCons                       56
    y241          inter241                            1
    y242          COST                               43
    y242          followerCons                       33
    y242          inter242                            1
    y243          COST                              100
    y243          followerCons                       90
    y243          inter243                            1
    y244          COST                               48
    y244          followerCons                       38
    y244          inter244                            1
    y245          COST                               31
    y245          followerCons                       21
    y245          inter245                            1
    y246          COST                              107
    y246          followerCons                       97
    y246          inter246                            1
    y247          COST                               35
    y247          followerCons                       25
    y247          inter247                            1
    y248          COST                               80
    y248          followerCons                       70
    y248          inter248                            1
    y249          COST                               58
    y249          followerCons                       48
    y249          inter249                            1
    y250          COST                               37
    y250          followerCons                       27
    y250          inter250                            1
    y251          COST                               40
    y251          followerCons                       30
    y251          inter251                            1
    y252          COST                               21
    y252          followerCons                       11
    y252          inter252                            1
    y253          COST                               37
    y253          followerCons                       27
    y253          inter253                            1
    y254          COST                               17
    y254          followerCons                        7
    y254          inter254                            1
    y255          COST                               35
    y255          followerCons                       25
    y255          inter255                            1
    y256          COST                               40
    y256          followerCons                       30
    y256          inter256                            1
    y257          COST                               98
    y257          followerCons                       88
    y257          inter257                            1
    y258          COST                              101
    y258          followerCons                       91
    y258          inter258                            1
    y259          COST                              104
    y259          followerCons                       94
    y259          inter259                            1
    y260          COST                               40
    y260          followerCons                       30
    y260          inter260                            1
    y261          COST                               85
    y261          followerCons                       75
    y261          inter261                            1
    y262          COST                               74
    y262          followerCons                       64
    y262          inter262                            1
    y263          COST                               96
    y263          followerCons                       86
    y263          inter263                            1
    y264          COST                               74
    y264          followerCons                       64
    y264          inter264                            1
    y265          COST                               42
    y265          followerCons                       32
    y265          inter265                            1
    y266          COST                               24
    y266          followerCons                       14
    y266          inter266                            1
    y267          COST                               40
    y267          followerCons                       30
    y267          inter267                            1
    y268          COST                               61
    y268          followerCons                       51
    y268          inter268                            1
    y269          COST                               59
    y269          followerCons                       49
    y269          inter269                            1
    y270          COST                              110
    y270          followerCons                      100
    y270          inter270                            1
    y271          COST                               13
    y271          followerCons                        3
    y271          inter271                            1
    y272          COST                               78
    y272          followerCons                       68
    y272          inter272                            1
    y273          COST                               99
    y273          followerCons                       89
    y273          inter273                            1
    y274          COST                               67
    y274          followerCons                       57
    y274          inter274                            1
    y275          COST                               18
    y275          followerCons                        8
    y275          inter275                            1
    y276          COST                               49
    y276          followerCons                       39
    y276          inter276                            1
    y277          COST                               20
    y277          followerCons                       10
    y277          inter277                            1
    y278          COST                               34
    y278          followerCons                       24
    y278          inter278                            1
    y279          COST                               55
    y279          followerCons                       45
    y279          inter279                            1
    y280          COST                               18
    y280          followerCons                        8
    y280          inter280                            1
    y281          COST                               94
    y281          followerCons                       84
    y281          inter281                            1
    y282          COST                               18
    y282          followerCons                        8
    y282          inter282                            1
    y283          COST                               12
    y283          followerCons                        2
    y283          inter283                            1
    y284          COST                               56
    y284          followerCons                       46
    y284          inter284                            1
    y285          COST                               16
    y285          followerCons                        6
    y285          inter285                            1
    y286          COST                               18
    y286          followerCons                        8
    y286          inter286                            1
    y287          COST                               43
    y287          followerCons                       33
    y287          inter287                            1
    y288          COST                               64
    y288          followerCons                       54
    y288          inter288                            1
    y289          COST                               98
    y289          followerCons                       88
    y289          inter289                            1
    y290          COST                               29
    y290          followerCons                       19
    y290          inter290                            1
    y291          COST                               69
    y291          followerCons                       59
    y291          inter291                            1
    y292          COST                              107
    y292          followerCons                       97
    y292          inter292                            1
    y293          COST                               57
    y293          followerCons                       47
    y293          inter293                            1
    y294          COST                               31
    y294          followerCons                       21
    y294          inter294                            1
    y295          COST                               81
    y295          followerCons                       71
    y295          inter295                            1
    y296          COST                               67
    y296          followerCons                       57
    y296          inter296                            1
    y297          COST                               20
    y297          followerCons                       10
    y297          inter297                            1
    y298          COST                               82
    y298          followerCons                       72
    y298          inter298                            1
    y299          COST                               75
    y299          followerCons                       65
    y299          inter299                            1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs           leaderCons                       6884
    rhs           followerCons                     6887
    rhs           inter0                              1
    rhs           inter1                              1
    rhs           inter2                              1
    rhs           inter3                              1
    rhs           inter4                              1
    rhs           inter5                              1
    rhs           inter6                              1
    rhs           inter7                              1
    rhs           inter8                              1
    rhs           inter9                              1
    rhs           inter10                             1
    rhs           inter11                             1
    rhs           inter12                             1
    rhs           inter13                             1
    rhs           inter14                             1
    rhs           inter15                             1
    rhs           inter16                             1
    rhs           inter17                             1
    rhs           inter18                             1
    rhs           inter19                             1
    rhs           inter20                             1
    rhs           inter21                             1
    rhs           inter22                             1
    rhs           inter23                             1
    rhs           inter24                             1
    rhs           inter25                             1
    rhs           inter26                             1
    rhs           inter27                             1
    rhs           inter28                             1
    rhs           inter29                             1
    rhs           inter30                             1
    rhs           inter31                             1
    rhs           inter32                             1
    rhs           inter33                             1
    rhs           inter34                             1
    rhs           inter35                             1
    rhs           inter36                             1
    rhs           inter37                             1
    rhs           inter38                             1
    rhs           inter39                             1
    rhs           inter40                             1
    rhs           inter41                             1
    rhs           inter42                             1
    rhs           inter43                             1
    rhs           inter44                             1
    rhs           inter45                             1
    rhs           inter46                             1
    rhs           inter47                             1
    rhs           inter48                             1
    rhs           inter49                             1
    rhs           inter50                             1
    rhs           inter51                             1
    rhs           inter52                             1
    rhs           inter53                             1
    rhs           inter54                             1
    rhs           inter55                             1
    rhs           inter56                             1
    rhs           inter57                             1
    rhs           inter58                             1
    rhs           inter59                             1
    rhs           inter60                             1
    rhs           inter61                             1
    rhs           inter62                             1
    rhs           inter63                             1
    rhs           inter64                             1
    rhs           inter65                             1
    rhs           inter66                             1
    rhs           inter67                             1
    rhs           inter68                             1
    rhs           inter69                             1
    rhs           inter70                             1
    rhs           inter71                             1
    rhs           inter72                             1
    rhs           inter73                             1
    rhs           inter74                             1
    rhs           inter75                             1
    rhs           inter76                             1
    rhs           inter77                             1
    rhs           inter78                             1
    rhs           inter79                             1
    rhs           inter80                             1
    rhs           inter81                             1
    rhs           inter82                             1
    rhs           inter83                             1
    rhs           inter84                             1
    rhs           inter85                             1
    rhs           inter86                             1
    rhs           inter87                             1
    rhs           inter88                             1
    rhs           inter89                             1
    rhs           inter90                             1
    rhs           inter91                             1
    rhs           inter92                             1
    rhs           inter93                             1
    rhs           inter94                             1
    rhs           inter95                             1
    rhs           inter96                             1
    rhs           inter97                             1
    rhs           inter98                             1
    rhs           inter99                             1
    rhs           inter100                            1
    rhs           inter101                            1
    rhs           inter102                            1
    rhs           inter103                            1
    rhs           inter104                            1
    rhs           inter105                            1
    rhs           inter106                            1
    rhs           inter107                            1
    rhs           inter108                            1
    rhs           inter109                            1
    rhs           inter110                            1
    rhs           inter111                            1
    rhs           inter112                            1
    rhs           inter113                            1
    rhs           inter114                            1
    rhs           inter115                            1
    rhs           inter116                            1
    rhs           inter117                            1
    rhs           inter118                            1
    rhs           inter119                            1
    rhs           inter120                            1
    rhs           inter121                            1
    rhs           inter122                            1
    rhs           inter123                            1
    rhs           inter124                            1
    rhs           inter125                            1
    rhs           inter126                            1
    rhs           inter127                            1
    rhs           inter128                            1
    rhs           inter129                            1
    rhs           inter130                            1
    rhs           inter131                            1
    rhs           inter132                            1
    rhs           inter133                            1
    rhs           inter134                            1
    rhs           inter135                            1
    rhs           inter136                            1
    rhs           inter137                            1
    rhs           inter138                            1
    rhs           inter139                            1
    rhs           inter140                            1
    rhs           inter141                            1
    rhs           inter142                            1
    rhs           inter143                            1
    rhs           inter144                            1
    rhs           inter145                            1
    rhs           inter146                            1
    rhs           inter147                            1
    rhs           inter148                            1
    rhs           inter149                            1
    rhs           inter150                            1
    rhs           inter151                            1
    rhs           inter152                            1
    rhs           inter153                            1
    rhs           inter154                            1
    rhs           inter155                            1
    rhs           inter156                            1
    rhs           inter157                            1
    rhs           inter158                            1
    rhs           inter159                            1
    rhs           inter160                            1
    rhs           inter161                            1
    rhs           inter162                            1
    rhs           inter163                            1
    rhs           inter164                            1
    rhs           inter165                            1
    rhs           inter166                            1
    rhs           inter167                            1
    rhs           inter168                            1
    rhs           inter169                            1
    rhs           inter170                            1
    rhs           inter171                            1
    rhs           inter172                            1
    rhs           inter173                            1
    rhs           inter174                            1
    rhs           inter175                            1
    rhs           inter176                            1
    rhs           inter177                            1
    rhs           inter178                            1
    rhs           inter179                            1
    rhs           inter180                            1
    rhs           inter181                            1
    rhs           inter182                            1
    rhs           inter183                            1
    rhs           inter184                            1
    rhs           inter185                            1
    rhs           inter186                            1
    rhs           inter187                            1
    rhs           inter188                            1
    rhs           inter189                            1
    rhs           inter190                            1
    rhs           inter191                            1
    rhs           inter192                            1
    rhs           inter193                            1
    rhs           inter194                            1
    rhs           inter195                            1
    rhs           inter196                            1
    rhs           inter197                            1
    rhs           inter198                            1
    rhs           inter199                            1
    rhs           inter200                            1
    rhs           inter201                            1
    rhs           inter202                            1
    rhs           inter203                            1
    rhs           inter204                            1
    rhs           inter205                            1
    rhs           inter206                            1
    rhs           inter207                            1
    rhs           inter208                            1
    rhs           inter209                            1
    rhs           inter210                            1
    rhs           inter211                            1
    rhs           inter212                            1
    rhs           inter213                            1
    rhs           inter214                            1
    rhs           inter215                            1
    rhs           inter216                            1
    rhs           inter217                            1
    rhs           inter218                            1
    rhs           inter219                            1
    rhs           inter220                            1
    rhs           inter221                            1
    rhs           inter222                            1
    rhs           inter223                            1
    rhs           inter224                            1
    rhs           inter225                            1
    rhs           inter226                            1
    rhs           inter227                            1
    rhs           inter228                            1
    rhs           inter229                            1
    rhs           inter230                            1
    rhs           inter231                            1
    rhs           inter232                            1
    rhs           inter233                            1
    rhs           inter234                            1
    rhs           inter235                            1
    rhs           inter236                            1
    rhs           inter237                            1
    rhs           inter238                            1
    rhs           inter239                            1
    rhs           inter240                            1
    rhs           inter241                            1
    rhs           inter242                            1
    rhs           inter243                            1
    rhs           inter244                            1
    rhs           inter245                            1
    rhs           inter246                            1
    rhs           inter247                            1
    rhs           inter248                            1
    rhs           inter249                            1
    rhs           inter250                            1
    rhs           inter251                            1
    rhs           inter252                            1
    rhs           inter253                            1
    rhs           inter254                            1
    rhs           inter255                            1
    rhs           inter256                            1
    rhs           inter257                            1
    rhs           inter258                            1
    rhs           inter259                            1
    rhs           inter260                            1
    rhs           inter261                            1
    rhs           inter262                            1
    rhs           inter263                            1
    rhs           inter264                            1
    rhs           inter265                            1
    rhs           inter266                            1
    rhs           inter267                            1
    rhs           inter268                            1
    rhs           inter269                            1
    rhs           inter270                            1
    rhs           inter271                            1
    rhs           inter272                            1
    rhs           inter273                            1
    rhs           inter274                            1
    rhs           inter275                            1
    rhs           inter276                            1
    rhs           inter277                            1
    rhs           inter278                            1
    rhs           inter279                            1
    rhs           inter280                            1
    rhs           inter281                            1
    rhs           inter282                            1
    rhs           inter283                            1
    rhs           inter284                            1
    rhs           inter285                            1
    rhs           inter286                            1
    rhs           inter287                            1
    rhs           inter288                            1
    rhs           inter289                            1
    rhs           inter290                            1
    rhs           inter291                            1
    rhs           inter292                            1
    rhs           inter293                            1
    rhs           inter294                            1
    rhs           inter295                            1
    rhs           inter296                            1
    rhs           inter297                            1
    rhs           inter298                            1
    rhs           inter299                            1
BOUNDS
 BV bnd           x0          
 BV bnd           x1          
 BV bnd           x2          
 BV bnd           x3          
 BV bnd           x4          
 BV bnd           x5          
 BV bnd           x6          
 BV bnd           x7          
 BV bnd           x8          
 BV bnd           x9          
 BV bnd           x10         
 BV bnd           x11         
 BV bnd           x12         
 BV bnd           x13         
 BV bnd           x14         
 BV bnd           x15         
 BV bnd           x16         
 BV bnd           x17         
 BV bnd           x18         
 BV bnd           x19         
 BV bnd           x20         
 BV bnd           x21         
 BV bnd           x22         
 BV bnd           x23         
 BV bnd           x24         
 BV bnd           x25         
 BV bnd           x26         
 BV bnd           x27         
 BV bnd           x28         
 BV bnd           x29         
 BV bnd           x30         
 BV bnd           x31         
 BV bnd           x32         
 BV bnd           x33         
 BV bnd           x34         
 BV bnd           x35         
 BV bnd           x36         
 BV bnd           x37         
 BV bnd           x38         
 BV bnd           x39         
 BV bnd           x40         
 BV bnd           x41         
 BV bnd           x42         
 BV bnd           x43         
 BV bnd           x44         
 BV bnd           x45         
 BV bnd           x46         
 BV bnd           x47         
 BV bnd           x48         
 BV bnd           x49         
 BV bnd           x50         
 BV bnd           x51         
 BV bnd           x52         
 BV bnd           x53         
 BV bnd           x54         
 BV bnd           x55         
 BV bnd           x56         
 BV bnd           x57         
 BV bnd           x58         
 BV bnd           x59         
 BV bnd           x60         
 BV bnd           x61         
 BV bnd           x62         
 BV bnd           x63         
 BV bnd           x64         
 BV bnd           x65         
 BV bnd           x66         
 BV bnd           x67         
 BV bnd           x68         
 BV bnd           x69         
 BV bnd           x70         
 BV bnd           x71         
 BV bnd           x72         
 BV bnd           x73         
 BV bnd           x74         
 BV bnd           x75         
 BV bnd           x76         
 BV bnd           x77         
 BV bnd           x78         
 BV bnd           x79         
 BV bnd           x80         
 BV bnd           x81         
 BV bnd           x82         
 BV bnd           x83         
 BV bnd           x84         
 BV bnd           x85         
 BV bnd           x86         
 BV bnd           x87         
 BV bnd           x88         
 BV bnd           x89         
 BV bnd           x90         
 BV bnd           x91         
 BV bnd           x92         
 BV bnd           x93         
 BV bnd           x94         
 BV bnd           x95         
 BV bnd           x96         
 BV bnd           x97         
 BV bnd           x98         
 BV bnd           x99         
 BV bnd           x100        
 BV bnd           x101        
 BV bnd           x102        
 BV bnd           x103        
 BV bnd           x104        
 BV bnd           x105        
 BV bnd           x106        
 BV bnd           x107        
 BV bnd           x108        
 BV bnd           x109        
 BV bnd           x110        
 BV bnd           x111        
 BV bnd           x112        
 BV bnd           x113        
 BV bnd           x114        
 BV bnd           x115        
 BV bnd           x116        
 BV bnd           x117        
 BV bnd           x118        
 BV bnd           x119        
 BV bnd           x120        
 BV bnd           x121        
 BV bnd           x122        
 BV bnd           x123        
 BV bnd           x124        
 BV bnd           x125        
 BV bnd           x126        
 BV bnd           x127        
 BV bnd           x128        
 BV bnd           x129        
 BV bnd           x130        
 BV bnd           x131        
 BV bnd           x132        
 BV bnd           x133        
 BV bnd           x134        
 BV bnd           x135        
 BV bnd           x136        
 BV bnd           x137        
 BV bnd           x138        
 BV bnd           x139        
 BV bnd           x140        
 BV bnd           x141        
 BV bnd           x142        
 BV bnd           x143        
 BV bnd           x144        
 BV bnd           x145        
 BV bnd           x146        
 BV bnd           x147        
 BV bnd           x148        
 BV bnd           x149        
 BV bnd           x150        
 BV bnd           x151        
 BV bnd           x152        
 BV bnd           x153        
 BV bnd           x154        
 BV bnd           x155        
 BV bnd           x156        
 BV bnd           x157        
 BV bnd           x158        
 BV bnd           x159        
 BV bnd           x160        
 BV bnd           x161        
 BV bnd           x162        
 BV bnd           x163        
 BV bnd           x164        
 BV bnd           x165        
 BV bnd           x166        
 BV bnd           x167        
 BV bnd           x168        
 BV bnd           x169        
 BV bnd           x170        
 BV bnd           x171        
 BV bnd           x172        
 BV bnd           x173        
 BV bnd           x174        
 BV bnd           x175        
 BV bnd           x176        
 BV bnd           x177        
 BV bnd           x178        
 BV bnd           x179        
 BV bnd           x180        
 BV bnd           x181        
 BV bnd           x182        
 BV bnd           x183        
 BV bnd           x184        
 BV bnd           x185        
 BV bnd           x186        
 BV bnd           x187        
 BV bnd           x188        
 BV bnd           x189        
 BV bnd           x190        
 BV bnd           x191        
 BV bnd           x192        
 BV bnd           x193        
 BV bnd           x194        
 BV bnd           x195        
 BV bnd           x196        
 BV bnd           x197        
 BV bnd           x198        
 BV bnd           x199        
 BV bnd           x200        
 BV bnd           x201        
 BV bnd           x202        
 BV bnd           x203        
 BV bnd           x204        
 BV bnd           x205        
 BV bnd           x206        
 BV bnd           x207        
 BV bnd           x208        
 BV bnd           x209        
 BV bnd           x210        
 BV bnd           x211        
 BV bnd           x212        
 BV bnd           x213        
 BV bnd           x214        
 BV bnd           x215        
 BV bnd           x216        
 BV bnd           x217        
 BV bnd           x218        
 BV bnd           x219        
 BV bnd           x220        
 BV bnd           x221        
 BV bnd           x222        
 BV bnd           x223        
 BV bnd           x224        
 BV bnd           x225        
 BV bnd           x226        
 BV bnd           x227        
 BV bnd           x228        
 BV bnd           x229        
 BV bnd           x230        
 BV bnd           x231        
 BV bnd           x232        
 BV bnd           x233        
 BV bnd           x234        
 BV bnd           x235        
 BV bnd           x236        
 BV bnd           x237        
 BV bnd           x238        
 BV bnd           x239        
 BV bnd           x240        
 BV bnd           x241        
 BV bnd           x242        
 BV bnd           x243        
 BV bnd           x244        
 BV bnd           x245        
 BV bnd           x246        
 BV bnd           x247        
 BV bnd           x248        
 BV bnd           x249        
 BV bnd           x250        
 BV bnd           x251        
 BV bnd           x252        
 BV bnd           x253        
 BV bnd           x254        
 BV bnd           x255        
 BV bnd           x256        
 BV bnd           x257        
 BV bnd           x258        
 BV bnd           x259        
 BV bnd           x260        
 BV bnd           x261        
 BV bnd           x262        
 BV bnd           x263        
 BV bnd           x264        
 BV bnd           x265        
 BV bnd           x266        
 BV bnd           x267        
 BV bnd           x268        
 BV bnd           x269        
 BV bnd           x270        
 BV bnd           x271        
 BV bnd           x272        
 BV bnd           x273        
 BV bnd           x274        
 BV bnd           x275        
 BV bnd           x276        
 BV bnd           x277        
 BV bnd           x278        
 BV bnd           x279        
 BV bnd           x280        
 BV bnd           x281        
 BV bnd           x282        
 BV bnd           x283        
 BV bnd           x284        
 BV bnd           x285        
 BV bnd           x286        
 BV bnd           x287        
 BV bnd           x288        
 BV bnd           x289        
 BV bnd           x290        
 BV bnd           x291        
 BV bnd           x292        
 BV bnd           x293        
 BV bnd           x294        
 BV bnd           x295        
 BV bnd           x296        
 BV bnd           x297        
 BV bnd           x298        
 BV bnd           x299        
 LI bnd           y0            0
 LI bnd           y1            0
 LI bnd           y2            0
 LI bnd           y3            0
 LI bnd           y4            0
 LI bnd           y5            0
 LI bnd           y6            0
 LI bnd           y7            0
 LI bnd           y8            0
 LI bnd           y9            0
 LI bnd           y10           0
 LI bnd           y11           0
 LI bnd           y12           0
 LI bnd           y13           0
 LI bnd           y14           0
 LI bnd           y15           0
 LI bnd           y16           0
 LI bnd           y17           0
 LI bnd           y18           0
 LI bnd           y19           0
 LI bnd           y20           0
 LI bnd           y21           0
 LI bnd           y22           0
 LI bnd           y23           0
 LI bnd           y24           0
 LI bnd           y25           0
 LI bnd           y26           0
 LI bnd           y27           0
 LI bnd           y28           0
 LI bnd           y29           0
 LI bnd           y30           0
 LI bnd           y31           0
 LI bnd           y32           0
 LI bnd           y33           0
 LI bnd           y34           0
 LI bnd           y35           0
 LI bnd           y36           0
 LI bnd           y37           0
 LI bnd           y38           0
 LI bnd           y39           0
 LI bnd           y40           0
 LI bnd           y41           0
 LI bnd           y42           0
 LI bnd           y43           0
 LI bnd           y44           0
 LI bnd           y45           0
 LI bnd           y46           0
 LI bnd           y47           0
 LI bnd           y48           0
 LI bnd           y49           0
 LI bnd           y50           0
 LI bnd           y51           0
 LI bnd           y52           0
 LI bnd           y53           0
 LI bnd           y54           0
 LI bnd           y55           0
 LI bnd           y56           0
 LI bnd           y57           0
 LI bnd           y58           0
 LI bnd           y59           0
 LI bnd           y60           0
 LI bnd           y61           0
 LI bnd           y62           0
 LI bnd           y63           0
 LI bnd           y64           0
 LI bnd           y65           0
 LI bnd           y66           0
 LI bnd           y67           0
 LI bnd           y68           0
 LI bnd           y69           0
 LI bnd           y70           0
 LI bnd           y71           0
 LI bnd           y72           0
 LI bnd           y73           0
 LI bnd           y74           0
 LI bnd           y75           0
 LI bnd           y76           0
 LI bnd           y77           0
 LI bnd           y78           0
 LI bnd           y79           0
 LI bnd           y80           0
 LI bnd           y81           0
 LI bnd           y82           0
 LI bnd           y83           0
 LI bnd           y84           0
 LI bnd           y85           0
 LI bnd           y86           0
 LI bnd           y87           0
 LI bnd           y88           0
 LI bnd           y89           0
 LI bnd           y90           0
 LI bnd           y91           0
 LI bnd           y92           0
 LI bnd           y93           0
 LI bnd           y94           0
 LI bnd           y95           0
 LI bnd           y96           0
 LI bnd           y97           0
 LI bnd           y98           0
 LI bnd           y99           0
 LI bnd           y100          0
 LI bnd           y101          0
 LI bnd           y102          0
 LI bnd           y103          0
 LI bnd           y104          0
 LI bnd           y105          0
 LI bnd           y106          0
 LI bnd           y107          0
 LI bnd           y108          0
 LI bnd           y109          0
 LI bnd           y110          0
 LI bnd           y111          0
 LI bnd           y112          0
 LI bnd           y113          0
 LI bnd           y114          0
 LI bnd           y115          0
 LI bnd           y116          0
 LI bnd           y117          0
 LI bnd           y118          0
 LI bnd           y119          0
 LI bnd           y120          0
 LI bnd           y121          0
 LI bnd           y122          0
 LI bnd           y123          0
 LI bnd           y124          0
 LI bnd           y125          0
 LI bnd           y126          0
 LI bnd           y127          0
 LI bnd           y128          0
 LI bnd           y129          0
 LI bnd           y130          0
 LI bnd           y131          0
 LI bnd           y132          0
 LI bnd           y133          0
 LI bnd           y134          0
 LI bnd           y135          0
 LI bnd           y136          0
 LI bnd           y137          0
 LI bnd           y138          0
 LI bnd           y139          0
 LI bnd           y140          0
 LI bnd           y141          0
 LI bnd           y142          0
 LI bnd           y143          0
 LI bnd           y144          0
 LI bnd           y145          0
 LI bnd           y146          0
 LI bnd           y147          0
 LI bnd           y148          0
 LI bnd           y149          0
 LI bnd           y150          0
 LI bnd           y151          0
 LI bnd           y152          0
 LI bnd           y153          0
 LI bnd           y154          0
 LI bnd           y155          0
 LI bnd           y156          0
 LI bnd           y157          0
 LI bnd           y158          0
 LI bnd           y159          0
 LI bnd           y160          0
 LI bnd           y161          0
 LI bnd           y162          0
 LI bnd           y163          0
 LI bnd           y164          0
 LI bnd           y165          0
 LI bnd           y166          0
 LI bnd           y167          0
 LI bnd           y168          0
 LI bnd           y169          0
 LI bnd           y170          0
 LI bnd           y171          0
 LI bnd           y172          0
 LI bnd           y173          0
 LI bnd           y174          0
 LI bnd           y175          0
 LI bnd           y176          0
 LI bnd           y177          0
 LI bnd           y178          0
 LI bnd           y179          0
 LI bnd           y180          0
 LI bnd           y181          0
 LI bnd           y182          0
 LI bnd           y183          0
 LI bnd           y184          0
 LI bnd           y185          0
 LI bnd           y186          0
 LI bnd           y187          0
 LI bnd           y188          0
 LI bnd           y189          0
 LI bnd           y190          0
 LI bnd           y191          0
 LI bnd           y192          0
 LI bnd           y193          0
 LI bnd           y194          0
 LI bnd           y195          0
 LI bnd           y196          0
 LI bnd           y197          0
 LI bnd           y198          0
 LI bnd           y199          0
 LI bnd           y200          0
 LI bnd           y201          0
 LI bnd           y202          0
 LI bnd           y203          0
 LI bnd           y204          0
 LI bnd           y205          0
 LI bnd           y206          0
 LI bnd           y207          0
 LI bnd           y208          0
 LI bnd           y209          0
 LI bnd           y210          0
 LI bnd           y211          0
 LI bnd           y212          0
 LI bnd           y213          0
 LI bnd           y214          0
 LI bnd           y215          0
 LI bnd           y216          0
 LI bnd           y217          0
 LI bnd           y218          0
 LI bnd           y219          0
 LI bnd           y220          0
 LI bnd           y221          0
 LI bnd           y222          0
 LI bnd           y223          0
 LI bnd           y224          0
 LI bnd           y225          0
 LI bnd           y226          0
 LI bnd           y227          0
 LI bnd           y228          0
 LI bnd           y229          0
 LI bnd           y230          0
 LI bnd           y231          0
 LI bnd           y232          0
 LI bnd           y233          0
 LI bnd           y234          0
 LI bnd           y235          0
 LI bnd           y236          0
 LI bnd           y237          0
 LI bnd           y238          0
 LI bnd           y239          0
 LI bnd           y240          0
 LI bnd           y241          0
 LI bnd           y242          0
 LI bnd           y243          0
 LI bnd           y244          0
 LI bnd           y245          0
 LI bnd           y246          0
 LI bnd           y247          0
 LI bnd           y248          0
 LI bnd           y249          0
 LI bnd           y250          0
 LI bnd           y251          0
 LI bnd           y252          0
 LI bnd           y253          0
 LI bnd           y254          0
 LI bnd           y255          0
 LI bnd           y256          0
 LI bnd           y257          0
 LI bnd           y258          0
 LI bnd           y259          0
 LI bnd           y260          0
 LI bnd           y261          0
 LI bnd           y262          0
 LI bnd           y263          0
 LI bnd           y264          0
 LI bnd           y265          0
 LI bnd           y266          0
 LI bnd           y267          0
 LI bnd           y268          0
 LI bnd           y269          0
 LI bnd           y270          0
 LI bnd           y271          0
 LI bnd           y272          0
 LI bnd           y273          0
 LI bnd           y274          0
 LI bnd           y275          0
 LI bnd           y276          0
 LI bnd           y277          0
 LI bnd           y278          0
 LI bnd           y279          0
 LI bnd           y280          0
 LI bnd           y281          0
 LI bnd           y282          0
 LI bnd           y283          0
 LI bnd           y284          0
 LI bnd           y285          0
 LI bnd           y286          0
 LI bnd           y287          0
 LI bnd           y288          0
 LI bnd           y289          0
 LI bnd           y290          0
 LI bnd           y291          0
 LI bnd           y292          0
 LI bnd           y293          0
 LI bnd           y294          0
 LI bnd           y295          0
 LI bnd           y296          0
 LI bnd           y297          0
 LI bnd           y298          0
 LI bnd           y299          0
ENDATA
