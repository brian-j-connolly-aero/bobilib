* ENCODING=ISO-8859-1
NAME          interKP-200-100-1-7
ROWS
 N  COST        
 L  leaderCons  
 L  followerCons
 L  inter0      
 L  inter1      
 L  inter2      
 L  inter3      
 L  inter4      
 L  inter5      
 L  inter6      
 L  inter7      
 L  inter8      
 L  inter9      
 L  inter10     
 L  inter11     
 L  inter12     
 L  inter13     
 L  inter14     
 L  inter15     
 L  inter16     
 L  inter17     
 L  inter18     
 L  inter19     
 L  inter20     
 L  inter21     
 L  inter22     
 L  inter23     
 L  inter24     
 L  inter25     
 L  inter26     
 L  inter27     
 L  inter28     
 L  inter29     
 L  inter30     
 L  inter31     
 L  inter32     
 L  inter33     
 L  inter34     
 L  inter35     
 L  inter36     
 L  inter37     
 L  inter38     
 L  inter39     
 L  inter40     
 L  inter41     
 L  inter42     
 L  inter43     
 L  inter44     
 L  inter45     
 L  inter46     
 L  inter47     
 L  inter48     
 L  inter49     
 L  inter50     
 L  inter51     
 L  inter52     
 L  inter53     
 L  inter54     
 L  inter55     
 L  inter56     
 L  inter57     
 L  inter58     
 L  inter59     
 L  inter60     
 L  inter61     
 L  inter62     
 L  inter63     
 L  inter64     
 L  inter65     
 L  inter66     
 L  inter67     
 L  inter68     
 L  inter69     
 L  inter70     
 L  inter71     
 L  inter72     
 L  inter73     
 L  inter74     
 L  inter75     
 L  inter76     
 L  inter77     
 L  inter78     
 L  inter79     
 L  inter80     
 L  inter81     
 L  inter82     
 L  inter83     
 L  inter84     
 L  inter85     
 L  inter86     
 L  inter87     
 L  inter88     
 L  inter89     
 L  inter90     
 L  inter91     
 L  inter92     
 L  inter93     
 L  inter94     
 L  inter95     
 L  inter96     
 L  inter97     
 L  inter98     
 L  inter99     
 L  inter100    
 L  inter101    
 L  inter102    
 L  inter103    
 L  inter104    
 L  inter105    
 L  inter106    
 L  inter107    
 L  inter108    
 L  inter109    
 L  inter110    
 L  inter111    
 L  inter112    
 L  inter113    
 L  inter114    
 L  inter115    
 L  inter116    
 L  inter117    
 L  inter118    
 L  inter119    
 L  inter120    
 L  inter121    
 L  inter122    
 L  inter123    
 L  inter124    
 L  inter125    
 L  inter126    
 L  inter127    
 L  inter128    
 L  inter129    
 L  inter130    
 L  inter131    
 L  inter132    
 L  inter133    
 L  inter134    
 L  inter135    
 L  inter136    
 L  inter137    
 L  inter138    
 L  inter139    
 L  inter140    
 L  inter141    
 L  inter142    
 L  inter143    
 L  inter144    
 L  inter145    
 L  inter146    
 L  inter147    
 L  inter148    
 L  inter149    
 L  inter150    
 L  inter151    
 L  inter152    
 L  inter153    
 L  inter154    
 L  inter155    
 L  inter156    
 L  inter157    
 L  inter158    
 L  inter159    
 L  inter160    
 L  inter161    
 L  inter162    
 L  inter163    
 L  inter164    
 L  inter165    
 L  inter166    
 L  inter167    
 L  inter168    
 L  inter169    
 L  inter170    
 L  inter171    
 L  inter172    
 L  inter173    
 L  inter174    
 L  inter175    
 L  inter176    
 L  inter177    
 L  inter178    
 L  inter179    
 L  inter180    
 L  inter181    
 L  inter182    
 L  inter183    
 L  inter184    
 L  inter185    
 L  inter186    
 L  inter187    
 L  inter188    
 L  inter189    
 L  inter190    
 L  inter191    
 L  inter192    
 L  inter193    
 L  inter194    
 L  inter195    
 L  inter196    
 L  inter197    
 L  inter198    
 L  inter199    
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0            inter0                              1
    x1            leaderCons                         18
    x1            inter1                              1
    x2            leaderCons                         51
    x2            inter2                              1
    x3            leaderCons                         38
    x3            inter3                              1
    x4            leaderCons                         62
    x4            inter4                              1
    x5            leaderCons                          4
    x5            inter5                              1
    x6            leaderCons                         85
    x6            inter6                              1
    x7            leaderCons                         69
    x7            inter7                              1
    x8            leaderCons                         56
    x8            inter8                              1
    x9            leaderCons                         18
    x9            inter9                              1
    x10           leaderCons                          1
    x10           inter10                             1
    x11           leaderCons                         13
    x11           inter11                             1
    x12           leaderCons                         81
    x12           inter12                             1
    x13           leaderCons                         89
    x13           inter13                             1
    x14           leaderCons                         37
    x14           inter14                             1
    x15           leaderCons                         32
    x15           inter15                             1
    x16           leaderCons                         30
    x16           inter16                             1
    x17           leaderCons                         79
    x17           inter17                             1
    x18           leaderCons                         62
    x18           inter18                             1
    x19           leaderCons                         97
    x19           inter19                             1
    x20           leaderCons                          4
    x20           inter20                             1
    x21           leaderCons                         10
    x21           inter21                             1
    x22           leaderCons                         24
    x22           inter22                             1
    x23           leaderCons                          9
    x23           inter23                             1
    x24           leaderCons                         27
    x24           inter24                             1
    x25           leaderCons                         54
    x25           inter25                             1
    x26           leaderCons                         95
    x26           inter26                             1
    x27           leaderCons                         87
    x27           inter27                             1
    x28           leaderCons                         38
    x28           inter28                             1
    x29           leaderCons                         14
    x29           inter29                             1
    x30           leaderCons                         55
    x30           inter30                             1
    x31           leaderCons                         48
    x31           inter31                             1
    x32           leaderCons                         40
    x32           inter32                             1
    x33           leaderCons                         85
    x33           inter33                             1
    x34           leaderCons                         14
    x34           inter34                             1
    x35           leaderCons                         62
    x35           inter35                             1
    x36           leaderCons                         72
    x36           inter36                             1
    x37           leaderCons                         62
    x37           inter37                             1
    x38           leaderCons                         98
    x38           inter38                             1
    x39           leaderCons                         18
    x39           inter39                             1
    x40           leaderCons                         22
    x40           inter40                             1
    x41           leaderCons                         93
    x41           inter41                             1
    x42           leaderCons                         74
    x42           inter42                             1
    x43           leaderCons                         81
    x43           inter43                             1
    x44           leaderCons                         67
    x44           inter44                             1
    x45           leaderCons                         57
    x45           inter45                             1
    x46           leaderCons                         58
    x46           inter46                             1
    x47           leaderCons                         44
    x47           inter47                             1
    x48           leaderCons                          7
    x48           inter48                             1
    x49           leaderCons                         94
    x49           inter49                             1
    x50           leaderCons                          3
    x50           inter50                             1
    x51           leaderCons                         60
    x51           inter51                             1
    x52           leaderCons                         94
    x52           inter52                             1
    x53           leaderCons                         96
    x53           inter53                             1
    x54           leaderCons                         24
    x54           inter54                             1
    x55           leaderCons                         53
    x55           inter55                             1
    x56           leaderCons                         12
    x56           inter56                             1
    x57           leaderCons                         42
    x57           inter57                             1
    x58           leaderCons                         84
    x58           inter58                             1
    x59           leaderCons                         92
    x59           inter59                             1
    x60           leaderCons                         42
    x60           inter60                             1
    x61           leaderCons                         50
    x61           inter61                             1
    x62           leaderCons                         89
    x62           inter62                             1
    x63           inter63                             1
    x64           leaderCons                          3
    x64           inter64                             1
    x65           leaderCons                         22
    x65           inter65                             1
    x66           leaderCons                         15
    x66           inter66                             1
    x67           leaderCons                         33
    x67           inter67                             1
    x68           leaderCons                         63
    x68           inter68                             1
    x69           leaderCons                         52
    x69           inter69                             1
    x70           leaderCons                         46
    x70           inter70                             1
    x71           leaderCons                         67
    x71           inter71                             1
    x72           leaderCons                         44
    x72           inter72                             1
    x73           leaderCons                         27
    x73           inter73                             1
    x74           leaderCons                         56
    x74           inter74                             1
    x75           leaderCons                         78
    x75           inter75                             1
    x76           leaderCons                         86
    x76           inter76                             1
    x77           leaderCons                         57
    x77           inter77                             1
    x78           leaderCons                         67
    x78           inter78                             1
    x79           leaderCons                         52
    x79           inter79                             1
    x80           leaderCons                         81
    x80           inter80                             1
    x81           leaderCons                         73
    x81           inter81                             1
    x82           leaderCons                         48
    x82           inter82                             1
    x83           leaderCons                          5
    x83           inter83                             1
    x84           leaderCons                         43
    x84           inter84                             1
    x85           leaderCons                         54
    x85           inter85                             1
    x86           leaderCons                         13
    x86           inter86                             1
    x87           leaderCons                         48
    x87           inter87                             1
    x88           leaderCons                         39
    x88           inter88                             1
    x89           leaderCons                         11
    x89           inter89                             1
    x90           leaderCons                         41
    x90           inter90                             1
    x91           leaderCons                         70
    x91           inter91                             1
    x92           leaderCons                         62
    x92           inter92                             1
    x93           leaderCons                         71
    x93           inter93                             1
    x94           leaderCons                         50
    x94           inter94                             1
    x95           leaderCons                         86
    x95           inter95                             1
    x96           leaderCons                         96
    x96           inter96                             1
    x97           leaderCons                         21
    x97           inter97                             1
    x98           leaderCons                         72
    x98           inter98                             1
    x99           leaderCons                         36
    x99           inter99                             1
    x100          leaderCons                         27
    x100          inter100                            1
    x101          leaderCons                         36
    x101          inter101                            1
    x102          leaderCons                         45
    x102          inter102                            1
    x103          leaderCons                         24
    x103          inter103                            1
    x104          leaderCons                         13
    x104          inter104                            1
    x105          leaderCons                         16
    x105          inter105                            1
    x106          leaderCons                         61
    x106          inter106                            1
    x107          leaderCons                         44
    x107          inter107                            1
    x108          leaderCons                         12
    x108          inter108                            1
    x109          leaderCons                         80
    x109          inter109                            1
    x110          leaderCons                         16
    x110          inter110                            1
    x111          leaderCons                         66
    x111          inter111                            1
    x112          leaderCons                         27
    x112          inter112                            1
    x113          leaderCons                         21
    x113          inter113                            1
    x114          leaderCons                         26
    x114          inter114                            1
    x115          leaderCons                         83
    x115          inter115                            1
    x116          leaderCons                         91
    x116          inter116                            1
    x117          leaderCons                         97
    x117          inter117                            1
    x118          leaderCons                         12
    x118          inter118                            1
    x119          leaderCons                         44
    x119          inter119                            1
    x120          leaderCons                         27
    x120          inter120                            1
    x121          leaderCons                         34
    x121          inter121                            1
    x122          leaderCons                         26
    x122          inter122                            1
    x123          leaderCons                         48
    x123          inter123                            1
    x124          leaderCons                         50
    x124          inter124                            1
    x125          leaderCons                         57
    x125          inter125                            1
    x126          leaderCons                         33
    x126          inter126                            1
    x127          leaderCons                         60
    x127          inter127                            1
    x128          leaderCons                          8
    x128          inter128                            1
    x129          leaderCons                         86
    x129          inter129                            1
    x130          leaderCons                         82
    x130          inter130                            1
    x131          leaderCons                         83
    x131          inter131                            1
    x132          leaderCons                         64
    x132          inter132                            1
    x133          leaderCons                         55
    x133          inter133                            1
    x134          leaderCons                         52
    x134          inter134                            1
    x135          leaderCons                          1
    x135          inter135                            1
    x136          leaderCons                         33
    x136          inter136                            1
    x137          leaderCons                         69
    x137          inter137                            1
    x138          leaderCons                         31
    x138          inter138                            1
    x139          leaderCons                         46
    x139          inter139                            1
    x140          leaderCons                         23
    x140          inter140                            1
    x141          leaderCons                         11
    x141          inter141                            1
    x142          leaderCons                         18
    x142          inter142                            1
    x143          leaderCons                         93
    x143          inter143                            1
    x144          leaderCons                         37
    x144          inter144                            1
    x145          leaderCons                         61
    x145          inter145                            1
    x146          leaderCons                         24
    x146          inter146                            1
    x147          leaderCons                         71
    x147          inter147                            1
    x148          leaderCons                         58
    x148          inter148                            1
    x149          leaderCons                         93
    x149          inter149                            1
    x150          leaderCons                         71
    x150          inter150                            1
    x151          leaderCons                          7
    x151          inter151                            1
    x152          leaderCons                         57
    x152          inter152                            1
    x153          leaderCons                         73
    x153          inter153                            1
    x154          leaderCons                         34
    x154          inter154                            1
    x155          leaderCons                         27
    x155          inter155                            1
    x156          leaderCons                         98
    x156          inter156                            1
    x157          leaderCons                         30
    x157          inter157                            1
    x158          leaderCons                         34
    x158          inter158                            1
    x159          leaderCons                         21
    x159          inter159                            1
    x160          leaderCons                         94
    x160          inter160                            1
    x161          leaderCons                         86
    x161          inter161                            1
    x162          inter162                            1
    x163          leaderCons                         57
    x163          inter163                            1
    x164          leaderCons                         66
    x164          inter164                            1
    x165          leaderCons                          4
    x165          inter165                            1
    x166          leaderCons                         61
    x166          inter166                            1
    x167          leaderCons                          6
    x167          inter167                            1
    x168          leaderCons                         49
    x168          inter168                            1
    x169          leaderCons                         60
    x169          inter169                            1
    x170          leaderCons                         94
    x170          inter170                            1
    x171          leaderCons                         89
    x171          inter171                            1
    x172          leaderCons                         28
    x172          inter172                            1
    x173          leaderCons                         34
    x173          inter173                            1
    x174          leaderCons                         47
    x174          inter174                            1
    x175          leaderCons                         12
    x175          inter175                            1
    x176          leaderCons                         36
    x176          inter176                            1
    x177          leaderCons                         81
    x177          inter177                            1
    x178          leaderCons                         40
    x178          inter178                            1
    x179          leaderCons                         41
    x179          inter179                            1
    x180          leaderCons                          4
    x180          inter180                            1
    x181          leaderCons                         17
    x181          inter181                            1
    x182          leaderCons                         80
    x182          inter182                            1
    x183          leaderCons                         55
    x183          inter183                            1
    x184          inter184                            1
    x185          leaderCons                          2
    x185          inter185                            1
    x186          leaderCons                         34
    x186          inter186                            1
    x187          leaderCons                         30
    x187          inter187                            1
    x188          leaderCons                         25
    x188          inter188                            1
    x189          leaderCons                         93
    x189          inter189                            1
    x190          leaderCons                         57
    x190          inter190                            1
    x191          leaderCons                         68
    x191          inter191                            1
    x192          leaderCons                         39
    x192          inter192                            1
    x193          leaderCons                         24
    x193          inter193                            1
    x194          leaderCons                         51
    x194          inter194                            1
    x195          leaderCons                         59
    x195          inter195                            1
    x196          leaderCons                         49
    x196          inter196                            1
    x197          leaderCons                         49
    x197          inter197                            1
    x198          leaderCons                         30
    x198          inter198                            1
    x199          leaderCons                         19
    x199          inter199                            1
    y0            COST                               93
    y0            followerCons                       41
    y0            inter0                              1
    y1            COST                               24
    y1            followerCons                       81
    y1            inter1                              1
    y2            COST                               14
    y2            followerCons                       74
    y2            inter2                              1
    y3            COST                               21
    y3            followerCons                       22
    y3            inter3                              1
    y4            COST                               80
    y4            followerCons                       51
    y4            inter4                              1
    y5            COST                               77
    y5            followerCons                       17
    y5            inter5                              1
    y6            COST                               11
    y6            followerCons                       24
    y6            inter6                              1
    y7            COST                               81
    y7            followerCons                       19
    y7            inter7                              1
    y8            COST                               43
    y8            followerCons                       38
    y8            inter8                              1
    y9            COST                               50
    y9            followerCons                       36
    y9            inter9                              1
    y10           COST                               31
    y10           followerCons                       58
    y10           inter10                             1
    y11           COST                               27
    y11           followerCons                       16
    y11           inter11                             1
    y12           COST                               88
    y12           followerCons                       25
    y12           inter12                             1
    y13           COST                               13
    y13           followerCons                       61
    y13           inter13                             1
    y14           COST                               99
    y14           followerCons                       93
    y14           inter14                             1
    y15           COST                               52
    y15           followerCons                       69
    y15           inter15                             1
    y16           COST                               64
    y16           followerCons                       43
    y16           inter16                             1
    y17           COST                               17
    y17           followerCons                       24
    y17           inter17                             1
    y18           COST                               20
    y18           followerCons                       57
    y18           inter18                             1
    y19           COST                               76
    y19           followerCons                       32
    y19           inter19                             1
    y20           COST                               54
    y20           followerCons                       12
    y20           inter20                             1
    y21           COST                               25
    y21           followerCons                       97
    y21           inter21                             1
    y22           COST                               46
    y22           followerCons                       94
    y22           inter22                             1
    y23           COST                                3
    y23           followerCons                        8
    y23           inter23                             1
    y24           COST                               58
    y24           followerCons                       89
    y24           inter24                             1
    y25           COST                               37
    y25           followerCons                       55
    y25           inter25                             1
    y26           COST                               51
    y26           followerCons                       80
    y26           inter26                             1
    y27           COST                               28
    y27           followerCons                       94
    y27           inter27                             1
    y28           COST                               16
    y28           followerCons                       15
    y28           inter28                             1
    y29           COST                               66
    y29           followerCons                       14
    y29           inter29                             1
    y30           COST                               74
    y30           followerCons                       79
    y30           inter30                             1
    y31           COST                               70
    y31           followerCons                       86
    y31           inter31                             1
    y32           COST                               40
    y32           followerCons                       29
    y32           inter32                             1
    y33           COST                                4
    y33           followerCons                       69
    y33           inter33                             1
    y34           COST                               66
    y34           followerCons                       79
    y34           inter34                             1
    y35           COST                               36
    y35           followerCons                       27
    y35           inter35                             1
    y36           COST                               74
    y36           followerCons                       77
    y36           inter36                             1
    y37           COST                               75
    y37           followerCons                       87
    y37           inter37                             1
    y38           COST                                2
    y38           followerCons                       29
    y38           inter38                             1
    y39           COST                               59
    y39           followerCons                       74
    y39           inter39                             1
    y40           COST                                9
    y40           followerCons                       30
    y40           inter40                             1
    y41           COST                                5
    y41           followerCons                       65
    y41           inter41                             1
    y42           COST                               60
    y42           followerCons                       67
    y42           inter42                             1
    y43           COST                               28
    y43           followerCons                       63
    y43           inter43                             1
    y44           COST                               21
    y44           followerCons                      100
    y44           inter44                             1
    y45           COST                               99
    y45           followerCons                       78
    y45           inter45                             1
    y46           COST                               28
    y46           followerCons                       84
    y46           inter46                             1
    y47           COST                               48
    y47           followerCons                       64
    y47           inter47                             1
    y48           COST                               27
    y48           followerCons                       46
    y48           inter48                             1
    y49           COST                               17
    y49           followerCons                       37
    y49           inter49                             1
    y50           COST                               76
    y50           followerCons                       65
    y50           inter50                             1
    y51           COST                               69
    y51           followerCons                       82
    y51           inter51                             1
    y52           COST                               29
    y52           followerCons                       10
    y52           inter52                             1
    y53           COST                               17
    y53           followerCons                       22
    y53           inter53                             1
    y54           COST                               51
    y54           followerCons                       49
    y54           inter54                             1
    y55           COST                               51
    y55           followerCons                       47
    y55           inter55                             1
    y56           COST                               60
    y56           followerCons                       60
    y56           inter56                             1
    y57           COST                               72
    y57           followerCons                       14
    y57           inter57                             1
    y58           COST                              100
    y58           followerCons                       81
    y58           inter58                             1
    y59           COST                               42
    y59           followerCons                       95
    y59           inter59                             1
    y60           COST                               79
    y60           followerCons                       11
    y60           inter60                             1
    y61           COST                               62
    y61           followerCons                       78
    y61           inter61                             1
    y62           COST                               54
    y62           followerCons                        3
    y62           inter62                             1
    y63           COST                               68
    y63           followerCons                       25
    y63           inter63                             1
    y64           COST                               87
    y64           followerCons                       18
    y64           inter64                             1
    y65           COST                              100
    y65           followerCons                       39
    y65           inter65                             1
    y66           COST                               50
    y66           followerCons                       43
    y66           inter66                             1
    y67           COST                               70
    y67           followerCons                       67
    y67           inter67                             1
    y68           COST                               18
    y68           followerCons                       88
    y68           inter68                             1
    y69           COST                               85
    y69           followerCons                       55
    y69           inter69                             1
    y70           COST                               98
    y70           followerCons                        5
    y70           inter70                             1
    y71           COST                               57
    y71           followerCons                       18
    y71           inter71                             1
    y72           COST                               94
    y72           followerCons                       55
    y72           inter72                             1
    y73           COST                               91
    y73           followerCons                       77
    y73           inter73                             1
    y74           COST                               42
    y74           followerCons                       20
    y74           inter74                             1
    y75           COST                               34
    y75           followerCons                       73
    y75           inter75                             1
    y76           COST                               65
    y76           followerCons                       93
    y76           inter76                             1
    y77           COST                               21
    y77           followerCons                       89
    y77           inter77                             1
    y78           COST                               54
    y78           followerCons                       86
    y78           inter78                             1
    y79           COST                               37
    y79           followerCons                       82
    y79           inter79                             1
    y80           COST                               72
    y80           followerCons                       49
    y80           inter80                             1
    y81           COST                               52
    y81           followerCons                       92
    y81           inter81                             1
    y82           COST                               85
    y82           followerCons                       41
    y82           inter82                             1
    y83           COST                               55
    y83           followerCons                       65
    y83           inter83                             1
    y84           COST                               30
    y84           followerCons                       14
    y84           inter84                             1
    y85           COST                               48
    y85           followerCons                       90
    y85           inter85                             1
    y86           COST                               57
    y86           followerCons                       14
    y86           inter86                             1
    y87           COST                               29
    y87           followerCons                        6
    y87           inter87                             1
    y88           COST                               60
    y88           followerCons                       36
    y88           inter88                             1
    y89           COST                               18
    y89           followerCons                       14
    y89           inter89                             1
    y90           COST                               46
    y90           followerCons                       89
    y90           inter90                             1
    y91           COST                               65
    y91           followerCons                       71
    y91           inter91                             1
    y92           COST                               20
    y92           followerCons                       80
    y92           inter92                             1
    y93           COST                               29
    y93           followerCons                       48
    y93           inter93                             1
    y94           COST                               94
    y94           followerCons                       11
    y94           inter94                             1
    y95           COST                               16
    y95           followerCons                       91
    y95           inter95                             1
    y96           COST                               59
    y96           followerCons                       40
    y96           inter96                             1
    y97           COST                               51
    y97           followerCons                       27
    y97           inter97                             1
    y98           COST                               47
    y98           followerCons                       46
    y98           inter98                             1
    y99           COST                               36
    y99           followerCons                       12
    y99           inter99                             1
    y100          COST                               61
    y100          followerCons                       96
    y100          inter100                            1
    y101          COST                               18
    y101          followerCons                       74
    y101          inter101                            1
    y102          COST                               34
    y102          followerCons                       52
    y102          inter102                            1
    y103          COST                               78
    y103          followerCons                       57
    y103          inter103                            1
    y104          COST                                1
    y104          followerCons                       94
    y104          inter104                            1
    y105          COST                                9
    y105          followerCons                       86
    y105          inter105                            1
    y106          COST                               92
    y106          followerCons                       36
    y106          inter106                            1
    y107          COST                               51
    y107          followerCons                       20
    y107          inter107                            1
    y108          COST                               28
    y108          followerCons                       38
    y108          inter108                            1
    y109          COST                               94
    y109          followerCons                       74
    y109          inter109                            1
    y110          COST                                5
    y110          followerCons                       79
    y110          inter110                            1
    y111          COST                               64
    y111          followerCons                       53
    y111          inter111                            1
    y112          COST                               28
    y112          followerCons                       66
    y112          inter112                            1
    y113          COST                               75
    y113          followerCons                       54
    y113          inter113                            1
    y114          COST                               54
    y114          followerCons                       68
    y114          inter114                            1
    y115          COST                               43
    y115          followerCons                       84
    y115          inter115                            1
    y116          COST                               98
    y116          followerCons                       63
    y116          inter116                            1
    y117          COST                               79
    y117          followerCons                       64
    y117          inter117                            1
    y118          COST                               92
    y118          followerCons                       15
    y118          inter118                            1
    y119          COST                               76
    y119          followerCons                        2
    y119          inter119                            1
    y120          COST                               27
    y120          followerCons                       49
    y120          inter120                            1
    y121          COST                               80
    y121          followerCons                       33
    y121          inter121                            1
    y122          COST                               68
    y122          followerCons                       41
    y122          inter122                            1
    y123          COST                               26
    y123          followerCons                       28
    y123          inter123                            1
    y124          COST                               72
    y124          followerCons                       62
    y124          inter124                            1
    y125          COST                               60
    y125          followerCons                       64
    y125          inter125                            1
    y126          COST                               95
    y126          followerCons                       70
    y126          inter126                            1
    y127          COST                               58
    y127          followerCons                       42
    y127          inter127                            1
    y128          COST                                7
    y128          followerCons                       96
    y128          inter128                            1
    y129          COST                               98
    y129          followerCons                       81
    y129          inter129                            1
    y130          COST                               81
    y130          followerCons                       85
    y130          inter130                            1
    y131          COST                               61
    y131          followerCons                       89
    y131          inter131                            1
    y132          COST                               39
    y132          followerCons                       69
    y132          inter132                            1
    y133          COST                               55
    y133          followerCons                       63
    y133          inter133                            1
    y134          COST                               79
    y134          followerCons                       43
    y134          inter134                            1
    y135          COST                               68
    y135          followerCons                       45
    y135          inter135                            1
    y136          COST                               32
    y136          followerCons                       94
    y136          inter136                            1
    y137          COST                               67
    y137          followerCons                       62
    y137          inter137                            1
    y138          COST                               35
    y138          followerCons                       23
    y138          inter138                            1
    y139          COST                               45
    y139          followerCons                       11
    y139          inter139                            1
    y140          COST                               77
    y140          followerCons                        9
    y140          inter140                            1
    y141          COST                                7
    y141          followerCons                       25
    y141          inter141                            1
    y142          COST                               80
    y142          followerCons                       95
    y142          inter142                            1
    y143          COST                               44
    y143          followerCons                       19
    y143          inter143                            1
    y144          COST                                7
    y144          followerCons                      100
    y144          inter144                            1
    y145          COST                               14
    y145          followerCons                       53
    y145          inter145                            1
    y146          COST                               20
    y146          followerCons                       30
    y146          inter146                            1
    y147          COST                                8
    y147          followerCons                       91
    y147          inter147                            1
    y148          COST                               93
    y148          followerCons                        4
    y148          inter148                            1
    y149          COST                               74
    y149          followerCons                       28
    y149          inter149                            1
    y150          COST                               31
    y150          followerCons                       87
    y150          inter150                            1
    y151          COST                               25
    y151          followerCons                       30
    y151          inter151                            1
    y152          COST                               20
    y152          followerCons                        7
    y152          inter152                            1
    y153          COST                               74
    y153          followerCons                       26
    y153          inter153                            1
    y154          COST                               16
    y154          followerCons                       12
    y154          inter154                            1
    y155          COST                               77
    y155          followerCons                       13
    y155          inter155                            1
    y156          COST                               74
    y156          followerCons                       41
    y156          inter156                            1
    y157          COST                               15
    y157          followerCons                       94
    y157          inter157                            1
    y158          COST                               32
    y158          followerCons                       88
    y158          inter158                            1
    y159          COST                               81
    y159          followerCons                       73
    y159          inter159                            1
    y160          COST                               33
    y160          followerCons                       64
    y160          inter160                            1
    y161          COST                               36
    y161          followerCons                        9
    y161          inter161                            1
    y162          COST                               31
    y162          followerCons                       86
    y162          inter162                            1
    y163          COST                               87
    y163          followerCons                       26
    y163          inter163                            1
    y164          COST                               31
    y164          followerCons                       32
    y164          inter164                            1
    y165          COST                               92
    y165          followerCons                       14
    y165          inter165                            1
    y166          COST                               41
    y166          followerCons                       52
    y166          inter166                            1
    y167          COST                               47
    y167          followerCons                        9
    y167          inter167                            1
    y168          COST                               96
    y168          followerCons                       23
    y168          inter168                            1
    y169          COST                               32
    y169          followerCons                       92
    y169          inter169                            1
    y170          COST                               46
    y170          followerCons                       86
    y170          inter170                            1
    y171          COST                                8
    y171          followerCons                       58
    y171          inter171                            1
    y172          COST                               73
    y172          followerCons                       56
    y172          inter172                            1
    y173          COST                               96
    y173          followerCons                       83
    y173          inter173                            1
    y174          COST                               64
    y174          followerCons                       19
    y174          inter174                            1
    y175          COST                               26
    y175          followerCons                        2
    y175          inter175                            1
    y176          COST                               25
    y176          followerCons                       59
    y176          inter176                            1
    y177          COST                               36
    y177          followerCons                       30
    y177          inter177                            1
    y178          COST                               19
    y178          followerCons                       75
    y178          inter178                            1
    y179          COST                               71
    y179          followerCons                       26
    y179          inter179                            1
    y180          COST                               79
    y180          followerCons                       83
    y180          inter180                            1
    y181          COST                               97
    y181          followerCons                       13
    y181          inter181                            1
    y182          COST                               95
    y182          followerCons                       26
    y182          inter182                            1
    y183          COST                               43
    y183          followerCons                       38
    y183          inter183                            1
    y184          COST                               68
    y184          followerCons                       15
    y184          inter184                            1
    y185          COST                               67
    y185          followerCons                       89
    y185          inter185                            1
    y186          COST                               99
    y186          followerCons                       45
    y186          inter186                            1
    y187          COST                               82
    y187          followerCons                        6
    y187          inter187                            1
    y188          COST                               24
    y188          followerCons                        6
    y188          inter188                            1
    y189          COST                               81
    y189          followerCons                       15
    y189          inter189                            1
    y190          COST                               26
    y190          followerCons                       68
    y190          inter190                            1
    y191          COST                               46
    y191          followerCons                       44
    y191          inter191                            1
    y192          COST                               38
    y192          followerCons                       70
    y192          inter192                            1
    y193          COST                               98
    y193          followerCons                       16
    y193          inter193                            1
    y194          COST                               74
    y194          followerCons                       63
    y194          inter194                            1
    y195          COST                               27
    y195          followerCons                       35
    y195          inter195                            1
    y196          COST                               70
    y196          followerCons                       91
    y196          inter196                            1
    y197          COST                               72
    y197          followerCons                       19
    y197          inter197                            1
    y198          COST                               79
    y198          followerCons                       77
    y198          inter198                            1
    y199          COST                               81
    y199          followerCons                       81
    y199          inter199                            1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs           leaderCons                       6517
    rhs           followerCons                     6520
    rhs           inter0                              1
    rhs           inter1                              1
    rhs           inter2                              1
    rhs           inter3                              1
    rhs           inter4                              1
    rhs           inter5                              1
    rhs           inter6                              1
    rhs           inter7                              1
    rhs           inter8                              1
    rhs           inter9                              1
    rhs           inter10                             1
    rhs           inter11                             1
    rhs           inter12                             1
    rhs           inter13                             1
    rhs           inter14                             1
    rhs           inter15                             1
    rhs           inter16                             1
    rhs           inter17                             1
    rhs           inter18                             1
    rhs           inter19                             1
    rhs           inter20                             1
    rhs           inter21                             1
    rhs           inter22                             1
    rhs           inter23                             1
    rhs           inter24                             1
    rhs           inter25                             1
    rhs           inter26                             1
    rhs           inter27                             1
    rhs           inter28                             1
    rhs           inter29                             1
    rhs           inter30                             1
    rhs           inter31                             1
    rhs           inter32                             1
    rhs           inter33                             1
    rhs           inter34                             1
    rhs           inter35                             1
    rhs           inter36                             1
    rhs           inter37                             1
    rhs           inter38                             1
    rhs           inter39                             1
    rhs           inter40                             1
    rhs           inter41                             1
    rhs           inter42                             1
    rhs           inter43                             1
    rhs           inter44                             1
    rhs           inter45                             1
    rhs           inter46                             1
    rhs           inter47                             1
    rhs           inter48                             1
    rhs           inter49                             1
    rhs           inter50                             1
    rhs           inter51                             1
    rhs           inter52                             1
    rhs           inter53                             1
    rhs           inter54                             1
    rhs           inter55                             1
    rhs           inter56                             1
    rhs           inter57                             1
    rhs           inter58                             1
    rhs           inter59                             1
    rhs           inter60                             1
    rhs           inter61                             1
    rhs           inter62                             1
    rhs           inter63                             1
    rhs           inter64                             1
    rhs           inter65                             1
    rhs           inter66                             1
    rhs           inter67                             1
    rhs           inter68                             1
    rhs           inter69                             1
    rhs           inter70                             1
    rhs           inter71                             1
    rhs           inter72                             1
    rhs           inter73                             1
    rhs           inter74                             1
    rhs           inter75                             1
    rhs           inter76                             1
    rhs           inter77                             1
    rhs           inter78                             1
    rhs           inter79                             1
    rhs           inter80                             1
    rhs           inter81                             1
    rhs           inter82                             1
    rhs           inter83                             1
    rhs           inter84                             1
    rhs           inter85                             1
    rhs           inter86                             1
    rhs           inter87                             1
    rhs           inter88                             1
    rhs           inter89                             1
    rhs           inter90                             1
    rhs           inter91                             1
    rhs           inter92                             1
    rhs           inter93                             1
    rhs           inter94                             1
    rhs           inter95                             1
    rhs           inter96                             1
    rhs           inter97                             1
    rhs           inter98                             1
    rhs           inter99                             1
    rhs           inter100                            1
    rhs           inter101                            1
    rhs           inter102                            1
    rhs           inter103                            1
    rhs           inter104                            1
    rhs           inter105                            1
    rhs           inter106                            1
    rhs           inter107                            1
    rhs           inter108                            1
    rhs           inter109                            1
    rhs           inter110                            1
    rhs           inter111                            1
    rhs           inter112                            1
    rhs           inter113                            1
    rhs           inter114                            1
    rhs           inter115                            1
    rhs           inter116                            1
    rhs           inter117                            1
    rhs           inter118                            1
    rhs           inter119                            1
    rhs           inter120                            1
    rhs           inter121                            1
    rhs           inter122                            1
    rhs           inter123                            1
    rhs           inter124                            1
    rhs           inter125                            1
    rhs           inter126                            1
    rhs           inter127                            1
    rhs           inter128                            1
    rhs           inter129                            1
    rhs           inter130                            1
    rhs           inter131                            1
    rhs           inter132                            1
    rhs           inter133                            1
    rhs           inter134                            1
    rhs           inter135                            1
    rhs           inter136                            1
    rhs           inter137                            1
    rhs           inter138                            1
    rhs           inter139                            1
    rhs           inter140                            1
    rhs           inter141                            1
    rhs           inter142                            1
    rhs           inter143                            1
    rhs           inter144                            1
    rhs           inter145                            1
    rhs           inter146                            1
    rhs           inter147                            1
    rhs           inter148                            1
    rhs           inter149                            1
    rhs           inter150                            1
    rhs           inter151                            1
    rhs           inter152                            1
    rhs           inter153                            1
    rhs           inter154                            1
    rhs           inter155                            1
    rhs           inter156                            1
    rhs           inter157                            1
    rhs           inter158                            1
    rhs           inter159                            1
    rhs           inter160                            1
    rhs           inter161                            1
    rhs           inter162                            1
    rhs           inter163                            1
    rhs           inter164                            1
    rhs           inter165                            1
    rhs           inter166                            1
    rhs           inter167                            1
    rhs           inter168                            1
    rhs           inter169                            1
    rhs           inter170                            1
    rhs           inter171                            1
    rhs           inter172                            1
    rhs           inter173                            1
    rhs           inter174                            1
    rhs           inter175                            1
    rhs           inter176                            1
    rhs           inter177                            1
    rhs           inter178                            1
    rhs           inter179                            1
    rhs           inter180                            1
    rhs           inter181                            1
    rhs           inter182                            1
    rhs           inter183                            1
    rhs           inter184                            1
    rhs           inter185                            1
    rhs           inter186                            1
    rhs           inter187                            1
    rhs           inter188                            1
    rhs           inter189                            1
    rhs           inter190                            1
    rhs           inter191                            1
    rhs           inter192                            1
    rhs           inter193                            1
    rhs           inter194                            1
    rhs           inter195                            1
    rhs           inter196                            1
    rhs           inter197                            1
    rhs           inter198                            1
    rhs           inter199                            1
BOUNDS
 BV bnd           x0          
 BV bnd           x1          
 BV bnd           x2          
 BV bnd           x3          
 BV bnd           x4          
 BV bnd           x5          
 BV bnd           x6          
 BV bnd           x7          
 BV bnd           x8          
 BV bnd           x9          
 BV bnd           x10         
 BV bnd           x11         
 BV bnd           x12         
 BV bnd           x13         
 BV bnd           x14         
 BV bnd           x15         
 BV bnd           x16         
 BV bnd           x17         
 BV bnd           x18         
 BV bnd           x19         
 BV bnd           x20         
 BV bnd           x21         
 BV bnd           x22         
 BV bnd           x23         
 BV bnd           x24         
 BV bnd           x25         
 BV bnd           x26         
 BV bnd           x27         
 BV bnd           x28         
 BV bnd           x29         
 BV bnd           x30         
 BV bnd           x31         
 BV bnd           x32         
 BV bnd           x33         
 BV bnd           x34         
 BV bnd           x35         
 BV bnd           x36         
 BV bnd           x37         
 BV bnd           x38         
 BV bnd           x39         
 BV bnd           x40         
 BV bnd           x41         
 BV bnd           x42         
 BV bnd           x43         
 BV bnd           x44         
 BV bnd           x45         
 BV bnd           x46         
 BV bnd           x47         
 BV bnd           x48         
 BV bnd           x49         
 BV bnd           x50         
 BV bnd           x51         
 BV bnd           x52         
 BV bnd           x53         
 BV bnd           x54         
 BV bnd           x55         
 BV bnd           x56         
 BV bnd           x57         
 BV bnd           x58         
 BV bnd           x59         
 BV bnd           x60         
 BV bnd           x61         
 BV bnd           x62         
 BV bnd           x63         
 BV bnd           x64         
 BV bnd           x65         
 BV bnd           x66         
 BV bnd           x67         
 BV bnd           x68         
 BV bnd           x69         
 BV bnd           x70         
 BV bnd           x71         
 BV bnd           x72         
 BV bnd           x73         
 BV bnd           x74         
 BV bnd           x75         
 BV bnd           x76         
 BV bnd           x77         
 BV bnd           x78         
 BV bnd           x79         
 BV bnd           x80         
 BV bnd           x81         
 BV bnd           x82         
 BV bnd           x83         
 BV bnd           x84         
 BV bnd           x85         
 BV bnd           x86         
 BV bnd           x87         
 BV bnd           x88         
 BV bnd           x89         
 BV bnd           x90         
 BV bnd           x91         
 BV bnd           x92         
 BV bnd           x93         
 BV bnd           x94         
 BV bnd           x95         
 BV bnd           x96         
 BV bnd           x97         
 BV bnd           x98         
 BV bnd           x99         
 BV bnd           x100        
 BV bnd           x101        
 BV bnd           x102        
 BV bnd           x103        
 BV bnd           x104        
 BV bnd           x105        
 BV bnd           x106        
 BV bnd           x107        
 BV bnd           x108        
 BV bnd           x109        
 BV bnd           x110        
 BV bnd           x111        
 BV bnd           x112        
 BV bnd           x113        
 BV bnd           x114        
 BV bnd           x115        
 BV bnd           x116        
 BV bnd           x117        
 BV bnd           x118        
 BV bnd           x119        
 BV bnd           x120        
 BV bnd           x121        
 BV bnd           x122        
 BV bnd           x123        
 BV bnd           x124        
 BV bnd           x125        
 BV bnd           x126        
 BV bnd           x127        
 BV bnd           x128        
 BV bnd           x129        
 BV bnd           x130        
 BV bnd           x131        
 BV bnd           x132        
 BV bnd           x133        
 BV bnd           x134        
 BV bnd           x135        
 BV bnd           x136        
 BV bnd           x137        
 BV bnd           x138        
 BV bnd           x139        
 BV bnd           x140        
 BV bnd           x141        
 BV bnd           x142        
 BV bnd           x143        
 BV bnd           x144        
 BV bnd           x145        
 BV bnd           x146        
 BV bnd           x147        
 BV bnd           x148        
 BV bnd           x149        
 BV bnd           x150        
 BV bnd           x151        
 BV bnd           x152        
 BV bnd           x153        
 BV bnd           x154        
 BV bnd           x155        
 BV bnd           x156        
 BV bnd           x157        
 BV bnd           x158        
 BV bnd           x159        
 BV bnd           x160        
 BV bnd           x161        
 BV bnd           x162        
 BV bnd           x163        
 BV bnd           x164        
 BV bnd           x165        
 BV bnd           x166        
 BV bnd           x167        
 BV bnd           x168        
 BV bnd           x169        
 BV bnd           x170        
 BV bnd           x171        
 BV bnd           x172        
 BV bnd           x173        
 BV bnd           x174        
 BV bnd           x175        
 BV bnd           x176        
 BV bnd           x177        
 BV bnd           x178        
 BV bnd           x179        
 BV bnd           x180        
 BV bnd           x181        
 BV bnd           x182        
 BV bnd           x183        
 BV bnd           x184        
 BV bnd           x185        
 BV bnd           x186        
 BV bnd           x187        
 BV bnd           x188        
 BV bnd           x189        
 BV bnd           x190        
 BV bnd           x191        
 BV bnd           x192        
 BV bnd           x193        
 BV bnd           x194        
 BV bnd           x195        
 BV bnd           x196        
 BV bnd           x197        
 BV bnd           x198        
 BV bnd           x199        
 LI bnd           y0            0
 LI bnd           y1            0
 LI bnd           y2            0
 LI bnd           y3            0
 LI bnd           y4            0
 LI bnd           y5            0
 LI bnd           y6            0
 LI bnd           y7            0
 LI bnd           y8            0
 LI bnd           y9            0
 LI bnd           y10           0
 LI bnd           y11           0
 LI bnd           y12           0
 LI bnd           y13           0
 LI bnd           y14           0
 LI bnd           y15           0
 LI bnd           y16           0
 LI bnd           y17           0
 LI bnd           y18           0
 LI bnd           y19           0
 LI bnd           y20           0
 LI bnd           y21           0
 LI bnd           y22           0
 LI bnd           y23           0
 LI bnd           y24           0
 LI bnd           y25           0
 LI bnd           y26           0
 LI bnd           y27           0
 LI bnd           y28           0
 LI bnd           y29           0
 LI bnd           y30           0
 LI bnd           y31           0
 LI bnd           y32           0
 LI bnd           y33           0
 LI bnd           y34           0
 LI bnd           y35           0
 LI bnd           y36           0
 LI bnd           y37           0
 LI bnd           y38           0
 LI bnd           y39           0
 LI bnd           y40           0
 LI bnd           y41           0
 LI bnd           y42           0
 LI bnd           y43           0
 LI bnd           y44           0
 LI bnd           y45           0
 LI bnd           y46           0
 LI bnd           y47           0
 LI bnd           y48           0
 LI bnd           y49           0
 LI bnd           y50           0
 LI bnd           y51           0
 LI bnd           y52           0
 LI bnd           y53           0
 LI bnd           y54           0
 LI bnd           y55           0
 LI bnd           y56           0
 LI bnd           y57           0
 LI bnd           y58           0
 LI bnd           y59           0
 LI bnd           y60           0
 LI bnd           y61           0
 LI bnd           y62           0
 LI bnd           y63           0
 LI bnd           y64           0
 LI bnd           y65           0
 LI bnd           y66           0
 LI bnd           y67           0
 LI bnd           y68           0
 LI bnd           y69           0
 LI bnd           y70           0
 LI bnd           y71           0
 LI bnd           y72           0
 LI bnd           y73           0
 LI bnd           y74           0
 LI bnd           y75           0
 LI bnd           y76           0
 LI bnd           y77           0
 LI bnd           y78           0
 LI bnd           y79           0
 LI bnd           y80           0
 LI bnd           y81           0
 LI bnd           y82           0
 LI bnd           y83           0
 LI bnd           y84           0
 LI bnd           y85           0
 LI bnd           y86           0
 LI bnd           y87           0
 LI bnd           y88           0
 LI bnd           y89           0
 LI bnd           y90           0
 LI bnd           y91           0
 LI bnd           y92           0
 LI bnd           y93           0
 LI bnd           y94           0
 LI bnd           y95           0
 LI bnd           y96           0
 LI bnd           y97           0
 LI bnd           y98           0
 LI bnd           y99           0
 LI bnd           y100          0
 LI bnd           y101          0
 LI bnd           y102          0
 LI bnd           y103          0
 LI bnd           y104          0
 LI bnd           y105          0
 LI bnd           y106          0
 LI bnd           y107          0
 LI bnd           y108          0
 LI bnd           y109          0
 LI bnd           y110          0
 LI bnd           y111          0
 LI bnd           y112          0
 LI bnd           y113          0
 LI bnd           y114          0
 LI bnd           y115          0
 LI bnd           y116          0
 LI bnd           y117          0
 LI bnd           y118          0
 LI bnd           y119          0
 LI bnd           y120          0
 LI bnd           y121          0
 LI bnd           y122          0
 LI bnd           y123          0
 LI bnd           y124          0
 LI bnd           y125          0
 LI bnd           y126          0
 LI bnd           y127          0
 LI bnd           y128          0
 LI bnd           y129          0
 LI bnd           y130          0
 LI bnd           y131          0
 LI bnd           y132          0
 LI bnd           y133          0
 LI bnd           y134          0
 LI bnd           y135          0
 LI bnd           y136          0
 LI bnd           y137          0
 LI bnd           y138          0
 LI bnd           y139          0
 LI bnd           y140          0
 LI bnd           y141          0
 LI bnd           y142          0
 LI bnd           y143          0
 LI bnd           y144          0
 LI bnd           y145          0
 LI bnd           y146          0
 LI bnd           y147          0
 LI bnd           y148          0
 LI bnd           y149          0
 LI bnd           y150          0
 LI bnd           y151          0
 LI bnd           y152          0
 LI bnd           y153          0
 LI bnd           y154          0
 LI bnd           y155          0
 LI bnd           y156          0
 LI bnd           y157          0
 LI bnd           y158          0
 LI bnd           y159          0
 LI bnd           y160          0
 LI bnd           y161          0
 LI bnd           y162          0
 LI bnd           y163          0
 LI bnd           y164          0
 LI bnd           y165          0
 LI bnd           y166          0
 LI bnd           y167          0
 LI bnd           y168          0
 LI bnd           y169          0
 LI bnd           y170          0
 LI bnd           y171          0
 LI bnd           y172          0
 LI bnd           y173          0
 LI bnd           y174          0
 LI bnd           y175          0
 LI bnd           y176          0
 LI bnd           y177          0
 LI bnd           y178          0
 LI bnd           y179          0
 LI bnd           y180          0
 LI bnd           y181          0
 LI bnd           y182          0
 LI bnd           y183          0
 LI bnd           y184          0
 LI bnd           y185          0
 LI bnd           y186          0
 LI bnd           y187          0
 LI bnd           y188          0
 LI bnd           y189          0
 LI bnd           y190          0
 LI bnd           y191          0
 LI bnd           y192          0
 LI bnd           y193          0
 LI bnd           y194          0
 LI bnd           y195          0
 LI bnd           y196          0
 LI bnd           y197          0
 LI bnd           y198          0
 LI bnd           y199          0
ENDATA
