* ENCODING=ISO-8859-1
NAME          interKP-100-100-2-6
ROWS
 N  COST        
 L  leaderCons  
 L  followerCons
 L  inter0      
 L  inter1      
 L  inter2      
 L  inter3      
 L  inter4      
 L  inter5      
 L  inter6      
 L  inter7      
 L  inter8      
 L  inter9      
 L  inter10     
 L  inter11     
 L  inter12     
 L  inter13     
 L  inter14     
 L  inter15     
 L  inter16     
 L  inter17     
 L  inter18     
 L  inter19     
 L  inter20     
 L  inter21     
 L  inter22     
 L  inter23     
 L  inter24     
 L  inter25     
 L  inter26     
 L  inter27     
 L  inter28     
 L  inter29     
 L  inter30     
 L  inter31     
 L  inter32     
 L  inter33     
 L  inter34     
 L  inter35     
 L  inter36     
 L  inter37     
 L  inter38     
 L  inter39     
 L  inter40     
 L  inter41     
 L  inter42     
 L  inter43     
 L  inter44     
 L  inter45     
 L  inter46     
 L  inter47     
 L  inter48     
 L  inter49     
 L  inter50     
 L  inter51     
 L  inter52     
 L  inter53     
 L  inter54     
 L  inter55     
 L  inter56     
 L  inter57     
 L  inter58     
 L  inter59     
 L  inter60     
 L  inter61     
 L  inter62     
 L  inter63     
 L  inter64     
 L  inter65     
 L  inter66     
 L  inter67     
 L  inter68     
 L  inter69     
 L  inter70     
 L  inter71     
 L  inter72     
 L  inter73     
 L  inter74     
 L  inter75     
 L  inter76     
 L  inter77     
 L  inter78     
 L  inter79     
 L  inter80     
 L  inter81     
 L  inter82     
 L  inter83     
 L  inter84     
 L  inter85     
 L  inter86     
 L  inter87     
 L  inter88     
 L  inter89     
 L  inter90     
 L  inter91     
 L  inter92     
 L  inter93     
 L  inter94     
 L  inter95     
 L  inter96     
 L  inter97     
 L  inter98     
 L  inter99     
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0            inter0                              1
    x1            leaderCons                         18
    x1            inter1                              1
    x2            leaderCons                         51
    x2            inter2                              1
    x3            leaderCons                         38
    x3            inter3                              1
    x4            leaderCons                         62
    x4            inter4                              1
    x5            leaderCons                          4
    x5            inter5                              1
    x6            leaderCons                         85
    x6            inter6                              1
    x7            leaderCons                         69
    x7            inter7                              1
    x8            leaderCons                         56
    x8            inter8                              1
    x9            leaderCons                         18
    x9            inter9                              1
    x10           leaderCons                          1
    x10           inter10                             1
    x11           leaderCons                         13
    x11           inter11                             1
    x12           leaderCons                         81
    x12           inter12                             1
    x13           leaderCons                         89
    x13           inter13                             1
    x14           leaderCons                         37
    x14           inter14                             1
    x15           leaderCons                         32
    x15           inter15                             1
    x16           leaderCons                         30
    x16           inter16                             1
    x17           leaderCons                         79
    x17           inter17                             1
    x18           leaderCons                         62
    x18           inter18                             1
    x19           leaderCons                         97
    x19           inter19                             1
    x20           leaderCons                          4
    x20           inter20                             1
    x21           leaderCons                         10
    x21           inter21                             1
    x22           leaderCons                         24
    x22           inter22                             1
    x23           leaderCons                          9
    x23           inter23                             1
    x24           leaderCons                         27
    x24           inter24                             1
    x25           leaderCons                         54
    x25           inter25                             1
    x26           leaderCons                         95
    x26           inter26                             1
    x27           leaderCons                         87
    x27           inter27                             1
    x28           leaderCons                         38
    x28           inter28                             1
    x29           leaderCons                         14
    x29           inter29                             1
    x30           leaderCons                         55
    x30           inter30                             1
    x31           leaderCons                         48
    x31           inter31                             1
    x32           leaderCons                         40
    x32           inter32                             1
    x33           leaderCons                         85
    x33           inter33                             1
    x34           leaderCons                         14
    x34           inter34                             1
    x35           leaderCons                         62
    x35           inter35                             1
    x36           leaderCons                         72
    x36           inter36                             1
    x37           leaderCons                         62
    x37           inter37                             1
    x38           leaderCons                         98
    x38           inter38                             1
    x39           leaderCons                         18
    x39           inter39                             1
    x40           leaderCons                         22
    x40           inter40                             1
    x41           leaderCons                         93
    x41           inter41                             1
    x42           leaderCons                         74
    x42           inter42                             1
    x43           leaderCons                         81
    x43           inter43                             1
    x44           leaderCons                         67
    x44           inter44                             1
    x45           leaderCons                         57
    x45           inter45                             1
    x46           leaderCons                         58
    x46           inter46                             1
    x47           leaderCons                         44
    x47           inter47                             1
    x48           leaderCons                          7
    x48           inter48                             1
    x49           leaderCons                         94
    x49           inter49                             1
    x50           leaderCons                          3
    x50           inter50                             1
    x51           leaderCons                         60
    x51           inter51                             1
    x52           leaderCons                         94
    x52           inter52                             1
    x53           leaderCons                         96
    x53           inter53                             1
    x54           leaderCons                         24
    x54           inter54                             1
    x55           leaderCons                         53
    x55           inter55                             1
    x56           leaderCons                         12
    x56           inter56                             1
    x57           leaderCons                         42
    x57           inter57                             1
    x58           leaderCons                         84
    x58           inter58                             1
    x59           leaderCons                         92
    x59           inter59                             1
    x60           leaderCons                         42
    x60           inter60                             1
    x61           leaderCons                         50
    x61           inter61                             1
    x62           leaderCons                         89
    x62           inter62                             1
    x63           inter63                             1
    x64           leaderCons                          3
    x64           inter64                             1
    x65           leaderCons                         22
    x65           inter65                             1
    x66           leaderCons                         15
    x66           inter66                             1
    x67           leaderCons                         33
    x67           inter67                             1
    x68           leaderCons                         63
    x68           inter68                             1
    x69           leaderCons                         52
    x69           inter69                             1
    x70           leaderCons                         46
    x70           inter70                             1
    x71           leaderCons                         67
    x71           inter71                             1
    x72           leaderCons                         44
    x72           inter72                             1
    x73           leaderCons                         27
    x73           inter73                             1
    x74           leaderCons                         56
    x74           inter74                             1
    x75           leaderCons                         78
    x75           inter75                             1
    x76           leaderCons                         86
    x76           inter76                             1
    x77           leaderCons                         57
    x77           inter77                             1
    x78           leaderCons                         67
    x78           inter78                             1
    x79           leaderCons                         52
    x79           inter79                             1
    x80           leaderCons                         81
    x80           inter80                             1
    x81           leaderCons                         73
    x81           inter81                             1
    x82           leaderCons                         48
    x82           inter82                             1
    x83           leaderCons                          5
    x83           inter83                             1
    x84           leaderCons                         43
    x84           inter84                             1
    x85           leaderCons                         54
    x85           inter85                             1
    x86           leaderCons                         13
    x86           inter86                             1
    x87           leaderCons                         48
    x87           inter87                             1
    x88           leaderCons                         39
    x88           inter88                             1
    x89           leaderCons                         11
    x89           inter89                             1
    x90           leaderCons                         41
    x90           inter90                             1
    x91           leaderCons                         70
    x91           inter91                             1
    x92           leaderCons                         62
    x92           inter92                             1
    x93           leaderCons                         71
    x93           inter93                             1
    x94           leaderCons                         50
    x94           inter94                             1
    x95           leaderCons                         86
    x95           inter95                             1
    x96           leaderCons                         96
    x96           inter96                             1
    x97           leaderCons                         21
    x97           inter97                             1
    x98           leaderCons                         72
    x98           inter98                             1
    x99           leaderCons                         36
    x99           inter99                             1
    y0            COST                               43
    y0            followerCons                       37
    y0            inter0                              1
    y1            COST                               26
    y1            followerCons                       25
    y1            inter1                              1
    y2            COST                               10
    y2            followerCons                       17
    y2            inter2                              1
    y3            COST                               41
    y3            followerCons                       45
    y3            inter3                              1
    y4            COST                               88
    y4            followerCons                       81
    y4            inter4                              1
    y5            COST                               66
    y5            followerCons                       67
    y5            inter5                              1
    y6            COST                               23
    y6            followerCons                       22
    y6            inter6                              1
    y7            COST                               77
    y7            followerCons                       84
    y7            inter7                              1
    y8            COST                              107
    y8            followerCons                       98
    y8            inter8                              1
    y9            COST                               37
    y9            followerCons                       45
    y9            inter9                              1
    y10           COST                               43
    y10           followerCons                       35
    y10           inter10                             1
    y11           COST                               41
    y11           followerCons                       49
    y11           inter11                             1
    y12           COST                               64
    y12           followerCons                       58
    y12           inter12                             1
    y13           COST                               55
    y13           followerCons                       61
    y13           inter13                             1
    y14           COST                               77
    y14           followerCons                       87
    y14           inter14                             1
    y15           COST                               75
    y15           followerCons                       84
    y15           inter15                             1
    y16           COST                               58
    y16           followerCons                       56
    y16           inter16                             1
    y17           COST                                1
    y17           followerCons                        2
    y17           inter17                             1
    y18           COST                               73
    y18           followerCons                       70
    y18           inter18                             1
    y19           COST                               41
    y19           followerCons                       47
    y19           inter19                             1
    y20           COST                                4
    y20           followerCons                       12
    y20           inter20                             1
    y21           COST                              102
    y21           followerCons                       94
    y21           inter21                             1
    y22           COST                               64
    y22           followerCons                       62
    y22           inter22                             1
    y23           COST                               62
    y23           followerCons                       72
    y23           inter23                             1
    y24           COST                               87
    y24           followerCons                       94
    y24           inter24                             1
    y25           COST                               10
    y25           followerCons                        8
    y25           inter25                             1
    y26           COST                               75
    y26           followerCons                       74
    y26           inter26                             1
    y27           COST                               32
    y27           followerCons                       28
    y27           inter27                             1
    y28           COST                               37
    y28           followerCons                       31
    y28           inter28                             1
    y29           COST                               13
    y29           followerCons                       22
    y29           inter29                             1
    y30           COST                               83
    y30           followerCons                       87
    y30           inter30                             1
    y31           COST                               58
    y31           followerCons                       58
    y31           inter31                             1
    y32           COST                                5
    y32           followerCons                        5
    y32           inter32                             1
    y33           COST                                1
    y33           followerCons                        7
    y33           inter33                             1
    y34           COST                               71
    y34           followerCons                       61
    y34           inter34                             1
    y35           COST                               87
    y35           followerCons                       90
    y35           inter35                             1
    y36           COST                               30
    y36           followerCons                       35
    y36           inter36                             1
    y37           COST                               19
    y37           followerCons                       13
    y37           inter37                             1
    y38           COST                               89
    y38           followerCons                       82
    y38           inter38                             1
    y39           COST                               44
    y39           followerCons                       42
    y39           inter39                             1
    y40           COST                               24
    y40           followerCons                       18
    y40           inter40                             1
    y41           COST                               47
    y41           followerCons                       56
    y41           inter41                             1
    y42           COST                                7
    y42           followerCons                        3
    y42           inter42                             1
    y43           COST                               34
    y43           followerCons                       31
    y43           inter43                             1
    y44           COST                               86
    y44           followerCons                       94
    y44           inter44                             1
    y45           COST                               63
    y45           followerCons                       69
    y45           inter45                             1
    y46           COST                               31
    y46           followerCons                       25
    y46           inter46                             1
    y47           COST                               65
    y47           followerCons                       60
    y47           inter47                             1
    y48           COST                               59
    y48           followerCons                       50
    y48           inter48                             1
    y49           COST                               29
    y49           followerCons                       20
    y49           inter49                             1
    y50           COST                               39
    y50           followerCons                       41
    y50           inter50                             1
    y51           COST                               88
    y51           followerCons                       81
    y51           inter51                             1
    y52           COST                               65
    y52           followerCons                       74
    y52           inter52                             1
    y53           COST                               16
    y53           followerCons                       22
    y53           inter53                             1
    y54           COST                               47
    y54           followerCons                       51
    y54           inter54                             1
    y55           COST                               17
    y55           followerCons                       17
    y55           inter55                             1
    y56           COST                               14
    y56           followerCons                       24
    y56           inter56                             1
    y57           COST                               24
    y57           followerCons                       19
    y57           inter57                             1
    y58           COST                               42
    y58           followerCons                       38
    y58           inter58                             1
    y59           COST                               33
    y59           followerCons                       36
    y59           inter59                             1
    y60           COST                               57
    y60           followerCons                       58
    y60           inter60                             1
    y61           COST                               23
    y61           followerCons                       16
    y61           inter61                             1
    y62           COST                               18
    y62           followerCons                       25
    y62           inter62                             1
    y63           COST                               55
    y63           followerCons                       61
    y63           inter63                             1
    y64           COST                               99
    y64           followerCons                       93
    y64           inter64                             1
    y65           COST                               67
    y65           followerCons                       69
    y65           inter65                             1
    y66           COST                               52
    y66           followerCons                       43
    y66           inter66                             1
    y67           COST                               26
    y67           followerCons                       24
    y67           inter67                             1
    y68           COST                               54
    y68           followerCons                       57
    y68           inter68                             1
    y69           COST                               35
    y69           followerCons                       32
    y69           inter69                             1
    y70           COST                               12
    y70           followerCons                       12
    y70           inter70                             1
    y71           COST                               94
    y71           followerCons                       97
    y71           inter71                             1
    y72           COST                               94
    y72           followerCons                       94
    y72           inter72                             1
    y73           COST                               12
    y73           followerCons                        8
    y73           inter73                             1
    y74           COST                               93
    y74           followerCons                       89
    y74           inter74                             1
    y75           COST                               53
    y75           followerCons                       55
    y75           inter75                             1
    y76           COST                               71
    y76           followerCons                       80
    y76           inter76                             1
    y77           COST                              102
    y77           followerCons                       94
    y77           inter77                             1
    y78           COST                               13
    y78           followerCons                       15
    y78           inter78                             1
    y79           COST                               10
    y79           followerCons                       14
    y79           inter79                             1
    y80           COST                               76
    y80           followerCons                       79
    y80           inter80                             1
    y81           COST                               94
    y81           followerCons                       86
    y81           inter81                             1
    y82           COST                               24
    y82           followerCons                       29
    y82           inter82                             1
    y83           COST                               62
    y83           followerCons                       69
    y83           inter83                             1
    y84           COST                               88
    y84           followerCons                       79
    y84           inter84                             1
    y85           COST                               27
    y85           followerCons                       27
    y85           inter85                             1
    y86           COST                               67
    y86           followerCons                       77
    y86           inter86                             1
    y87           COST                               78
    y87           followerCons                       87
    y87           inter87                             1
    y88           COST                               31
    y88           followerCons                       29
    y88           inter88                             1
    y89           COST                               68
    y89           followerCons                       74
    y89           inter89                             1
    y90           COST                               31
    y90           followerCons                       30
    y90           inter90                             1
    y91           COST                               66
    y91           followerCons                       65
    y91           inter91                             1
    y92           COST                               70
    y92           followerCons                       67
    y92           inter92                             1
    y93           COST                               62
    y93           followerCons                       63
    y93           inter93                             1
    y94           COST                               97
    y94           followerCons                      100
    y94           inter94                             1
    y95           COST                               70
    y95           followerCons                       78
    y95           inter95                             1
    y96           COST                               77
    y96           followerCons                       84
    y96           inter96                             1
    y97           COST                               67
    y97           followerCons                       64
    y97           inter97                             1
    y98           COST                               51
    y98           followerCons                       46
    y98           inter98                             1
    y99           COST                               32
    y99           followerCons                       37
    y99           inter99                             1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs           leaderCons                       2820
    rhs           followerCons                     2826
    rhs           inter0                              1
    rhs           inter1                              1
    rhs           inter2                              1
    rhs           inter3                              1
    rhs           inter4                              1
    rhs           inter5                              1
    rhs           inter6                              1
    rhs           inter7                              1
    rhs           inter8                              1
    rhs           inter9                              1
    rhs           inter10                             1
    rhs           inter11                             1
    rhs           inter12                             1
    rhs           inter13                             1
    rhs           inter14                             1
    rhs           inter15                             1
    rhs           inter16                             1
    rhs           inter17                             1
    rhs           inter18                             1
    rhs           inter19                             1
    rhs           inter20                             1
    rhs           inter21                             1
    rhs           inter22                             1
    rhs           inter23                             1
    rhs           inter24                             1
    rhs           inter25                             1
    rhs           inter26                             1
    rhs           inter27                             1
    rhs           inter28                             1
    rhs           inter29                             1
    rhs           inter30                             1
    rhs           inter31                             1
    rhs           inter32                             1
    rhs           inter33                             1
    rhs           inter34                             1
    rhs           inter35                             1
    rhs           inter36                             1
    rhs           inter37                             1
    rhs           inter38                             1
    rhs           inter39                             1
    rhs           inter40                             1
    rhs           inter41                             1
    rhs           inter42                             1
    rhs           inter43                             1
    rhs           inter44                             1
    rhs           inter45                             1
    rhs           inter46                             1
    rhs           inter47                             1
    rhs           inter48                             1
    rhs           inter49                             1
    rhs           inter50                             1
    rhs           inter51                             1
    rhs           inter52                             1
    rhs           inter53                             1
    rhs           inter54                             1
    rhs           inter55                             1
    rhs           inter56                             1
    rhs           inter57                             1
    rhs           inter58                             1
    rhs           inter59                             1
    rhs           inter60                             1
    rhs           inter61                             1
    rhs           inter62                             1
    rhs           inter63                             1
    rhs           inter64                             1
    rhs           inter65                             1
    rhs           inter66                             1
    rhs           inter67                             1
    rhs           inter68                             1
    rhs           inter69                             1
    rhs           inter70                             1
    rhs           inter71                             1
    rhs           inter72                             1
    rhs           inter73                             1
    rhs           inter74                             1
    rhs           inter75                             1
    rhs           inter76                             1
    rhs           inter77                             1
    rhs           inter78                             1
    rhs           inter79                             1
    rhs           inter80                             1
    rhs           inter81                             1
    rhs           inter82                             1
    rhs           inter83                             1
    rhs           inter84                             1
    rhs           inter85                             1
    rhs           inter86                             1
    rhs           inter87                             1
    rhs           inter88                             1
    rhs           inter89                             1
    rhs           inter90                             1
    rhs           inter91                             1
    rhs           inter92                             1
    rhs           inter93                             1
    rhs           inter94                             1
    rhs           inter95                             1
    rhs           inter96                             1
    rhs           inter97                             1
    rhs           inter98                             1
    rhs           inter99                             1
BOUNDS
 BV bnd           x0          
 BV bnd           x1          
 BV bnd           x2          
 BV bnd           x3          
 BV bnd           x4          
 BV bnd           x5          
 BV bnd           x6          
 BV bnd           x7          
 BV bnd           x8          
 BV bnd           x9          
 BV bnd           x10         
 BV bnd           x11         
 BV bnd           x12         
 BV bnd           x13         
 BV bnd           x14         
 BV bnd           x15         
 BV bnd           x16         
 BV bnd           x17         
 BV bnd           x18         
 BV bnd           x19         
 BV bnd           x20         
 BV bnd           x21         
 BV bnd           x22         
 BV bnd           x23         
 BV bnd           x24         
 BV bnd           x25         
 BV bnd           x26         
 BV bnd           x27         
 BV bnd           x28         
 BV bnd           x29         
 BV bnd           x30         
 BV bnd           x31         
 BV bnd           x32         
 BV bnd           x33         
 BV bnd           x34         
 BV bnd           x35         
 BV bnd           x36         
 BV bnd           x37         
 BV bnd           x38         
 BV bnd           x39         
 BV bnd           x40         
 BV bnd           x41         
 BV bnd           x42         
 BV bnd           x43         
 BV bnd           x44         
 BV bnd           x45         
 BV bnd           x46         
 BV bnd           x47         
 BV bnd           x48         
 BV bnd           x49         
 BV bnd           x50         
 BV bnd           x51         
 BV bnd           x52         
 BV bnd           x53         
 BV bnd           x54         
 BV bnd           x55         
 BV bnd           x56         
 BV bnd           x57         
 BV bnd           x58         
 BV bnd           x59         
 BV bnd           x60         
 BV bnd           x61         
 BV bnd           x62         
 BV bnd           x63         
 BV bnd           x64         
 BV bnd           x65         
 BV bnd           x66         
 BV bnd           x67         
 BV bnd           x68         
 BV bnd           x69         
 BV bnd           x70         
 BV bnd           x71         
 BV bnd           x72         
 BV bnd           x73         
 BV bnd           x74         
 BV bnd           x75         
 BV bnd           x76         
 BV bnd           x77         
 BV bnd           x78         
 BV bnd           x79         
 BV bnd           x80         
 BV bnd           x81         
 BV bnd           x82         
 BV bnd           x83         
 BV bnd           x84         
 BV bnd           x85         
 BV bnd           x86         
 BV bnd           x87         
 BV bnd           x88         
 BV bnd           x89         
 BV bnd           x90         
 BV bnd           x91         
 BV bnd           x92         
 BV bnd           x93         
 BV bnd           x94         
 BV bnd           x95         
 BV bnd           x96         
 BV bnd           x97         
 BV bnd           x98         
 BV bnd           x99         
 LI bnd           y0            0
 LI bnd           y1            0
 LI bnd           y2            0
 LI bnd           y3            0
 LI bnd           y4            0
 LI bnd           y5            0
 LI bnd           y6            0
 LI bnd           y7            0
 LI bnd           y8            0
 LI bnd           y9            0
 LI bnd           y10           0
 LI bnd           y11           0
 LI bnd           y12           0
 LI bnd           y13           0
 LI bnd           y14           0
 LI bnd           y15           0
 LI bnd           y16           0
 LI bnd           y17           0
 LI bnd           y18           0
 LI bnd           y19           0
 LI bnd           y20           0
 LI bnd           y21           0
 LI bnd           y22           0
 LI bnd           y23           0
 LI bnd           y24           0
 LI bnd           y25           0
 LI bnd           y26           0
 LI bnd           y27           0
 LI bnd           y28           0
 LI bnd           y29           0
 LI bnd           y30           0
 LI bnd           y31           0
 LI bnd           y32           0
 LI bnd           y33           0
 LI bnd           y34           0
 LI bnd           y35           0
 LI bnd           y36           0
 LI bnd           y37           0
 LI bnd           y38           0
 LI bnd           y39           0
 LI bnd           y40           0
 LI bnd           y41           0
 LI bnd           y42           0
 LI bnd           y43           0
 LI bnd           y44           0
 LI bnd           y45           0
 LI bnd           y46           0
 LI bnd           y47           0
 LI bnd           y48           0
 LI bnd           y49           0
 LI bnd           y50           0
 LI bnd           y51           0
 LI bnd           y52           0
 LI bnd           y53           0
 LI bnd           y54           0
 LI bnd           y55           0
 LI bnd           y56           0
 LI bnd           y57           0
 LI bnd           y58           0
 LI bnd           y59           0
 LI bnd           y60           0
 LI bnd           y61           0
 LI bnd           y62           0
 LI bnd           y63           0
 LI bnd           y64           0
 LI bnd           y65           0
 LI bnd           y66           0
 LI bnd           y67           0
 LI bnd           y68           0
 LI bnd           y69           0
 LI bnd           y70           0
 LI bnd           y71           0
 LI bnd           y72           0
 LI bnd           y73           0
 LI bnd           y74           0
 LI bnd           y75           0
 LI bnd           y76           0
 LI bnd           y77           0
 LI bnd           y78           0
 LI bnd           y79           0
 LI bnd           y80           0
 LI bnd           y81           0
 LI bnd           y82           0
 LI bnd           y83           0
 LI bnd           y84           0
 LI bnd           y85           0
 LI bnd           y86           0
 LI bnd           y87           0
 LI bnd           y88           0
 LI bnd           y89           0
 LI bnd           y90           0
 LI bnd           y91           0
 LI bnd           y92           0
 LI bnd           y93           0
 LI bnd           y94           0
 LI bnd           y95           0
 LI bnd           y96           0
 LI bnd           y97           0
 LI bnd           y98           0
 LI bnd           y99           0
ENDATA
