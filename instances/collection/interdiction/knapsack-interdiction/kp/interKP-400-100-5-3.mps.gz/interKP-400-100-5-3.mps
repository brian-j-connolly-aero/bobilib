* ENCODING=ISO-8859-1
NAME          interKP-400-100-5-3
ROWS
 N  COST        
 L  leaderCons  
 L  followerCons
 L  inter0      
 L  inter1      
 L  inter2      
 L  inter3      
 L  inter4      
 L  inter5      
 L  inter6      
 L  inter7      
 L  inter8      
 L  inter9      
 L  inter10     
 L  inter11     
 L  inter12     
 L  inter13     
 L  inter14     
 L  inter15     
 L  inter16     
 L  inter17     
 L  inter18     
 L  inter19     
 L  inter20     
 L  inter21     
 L  inter22     
 L  inter23     
 L  inter24     
 L  inter25     
 L  inter26     
 L  inter27     
 L  inter28     
 L  inter29     
 L  inter30     
 L  inter31     
 L  inter32     
 L  inter33     
 L  inter34     
 L  inter35     
 L  inter36     
 L  inter37     
 L  inter38     
 L  inter39     
 L  inter40     
 L  inter41     
 L  inter42     
 L  inter43     
 L  inter44     
 L  inter45     
 L  inter46     
 L  inter47     
 L  inter48     
 L  inter49     
 L  inter50     
 L  inter51     
 L  inter52     
 L  inter53     
 L  inter54     
 L  inter55     
 L  inter56     
 L  inter57     
 L  inter58     
 L  inter59     
 L  inter60     
 L  inter61     
 L  inter62     
 L  inter63     
 L  inter64     
 L  inter65     
 L  inter66     
 L  inter67     
 L  inter68     
 L  inter69     
 L  inter70     
 L  inter71     
 L  inter72     
 L  inter73     
 L  inter74     
 L  inter75     
 L  inter76     
 L  inter77     
 L  inter78     
 L  inter79     
 L  inter80     
 L  inter81     
 L  inter82     
 L  inter83     
 L  inter84     
 L  inter85     
 L  inter86     
 L  inter87     
 L  inter88     
 L  inter89     
 L  inter90     
 L  inter91     
 L  inter92     
 L  inter93     
 L  inter94     
 L  inter95     
 L  inter96     
 L  inter97     
 L  inter98     
 L  inter99     
 L  inter100    
 L  inter101    
 L  inter102    
 L  inter103    
 L  inter104    
 L  inter105    
 L  inter106    
 L  inter107    
 L  inter108    
 L  inter109    
 L  inter110    
 L  inter111    
 L  inter112    
 L  inter113    
 L  inter114    
 L  inter115    
 L  inter116    
 L  inter117    
 L  inter118    
 L  inter119    
 L  inter120    
 L  inter121    
 L  inter122    
 L  inter123    
 L  inter124    
 L  inter125    
 L  inter126    
 L  inter127    
 L  inter128    
 L  inter129    
 L  inter130    
 L  inter131    
 L  inter132    
 L  inter133    
 L  inter134    
 L  inter135    
 L  inter136    
 L  inter137    
 L  inter138    
 L  inter139    
 L  inter140    
 L  inter141    
 L  inter142    
 L  inter143    
 L  inter144    
 L  inter145    
 L  inter146    
 L  inter147    
 L  inter148    
 L  inter149    
 L  inter150    
 L  inter151    
 L  inter152    
 L  inter153    
 L  inter154    
 L  inter155    
 L  inter156    
 L  inter157    
 L  inter158    
 L  inter159    
 L  inter160    
 L  inter161    
 L  inter162    
 L  inter163    
 L  inter164    
 L  inter165    
 L  inter166    
 L  inter167    
 L  inter168    
 L  inter169    
 L  inter170    
 L  inter171    
 L  inter172    
 L  inter173    
 L  inter174    
 L  inter175    
 L  inter176    
 L  inter177    
 L  inter178    
 L  inter179    
 L  inter180    
 L  inter181    
 L  inter182    
 L  inter183    
 L  inter184    
 L  inter185    
 L  inter186    
 L  inter187    
 L  inter188    
 L  inter189    
 L  inter190    
 L  inter191    
 L  inter192    
 L  inter193    
 L  inter194    
 L  inter195    
 L  inter196    
 L  inter197    
 L  inter198    
 L  inter199    
 L  inter200    
 L  inter201    
 L  inter202    
 L  inter203    
 L  inter204    
 L  inter205    
 L  inter206    
 L  inter207    
 L  inter208    
 L  inter209    
 L  inter210    
 L  inter211    
 L  inter212    
 L  inter213    
 L  inter214    
 L  inter215    
 L  inter216    
 L  inter217    
 L  inter218    
 L  inter219    
 L  inter220    
 L  inter221    
 L  inter222    
 L  inter223    
 L  inter224    
 L  inter225    
 L  inter226    
 L  inter227    
 L  inter228    
 L  inter229    
 L  inter230    
 L  inter231    
 L  inter232    
 L  inter233    
 L  inter234    
 L  inter235    
 L  inter236    
 L  inter237    
 L  inter238    
 L  inter239    
 L  inter240    
 L  inter241    
 L  inter242    
 L  inter243    
 L  inter244    
 L  inter245    
 L  inter246    
 L  inter247    
 L  inter248    
 L  inter249    
 L  inter250    
 L  inter251    
 L  inter252    
 L  inter253    
 L  inter254    
 L  inter255    
 L  inter256    
 L  inter257    
 L  inter258    
 L  inter259    
 L  inter260    
 L  inter261    
 L  inter262    
 L  inter263    
 L  inter264    
 L  inter265    
 L  inter266    
 L  inter267    
 L  inter268    
 L  inter269    
 L  inter270    
 L  inter271    
 L  inter272    
 L  inter273    
 L  inter274    
 L  inter275    
 L  inter276    
 L  inter277    
 L  inter278    
 L  inter279    
 L  inter280    
 L  inter281    
 L  inter282    
 L  inter283    
 L  inter284    
 L  inter285    
 L  inter286    
 L  inter287    
 L  inter288    
 L  inter289    
 L  inter290    
 L  inter291    
 L  inter292    
 L  inter293    
 L  inter294    
 L  inter295    
 L  inter296    
 L  inter297    
 L  inter298    
 L  inter299    
 L  inter300    
 L  inter301    
 L  inter302    
 L  inter303    
 L  inter304    
 L  inter305    
 L  inter306    
 L  inter307    
 L  inter308    
 L  inter309    
 L  inter310    
 L  inter311    
 L  inter312    
 L  inter313    
 L  inter314    
 L  inter315    
 L  inter316    
 L  inter317    
 L  inter318    
 L  inter319    
 L  inter320    
 L  inter321    
 L  inter322    
 L  inter323    
 L  inter324    
 L  inter325    
 L  inter326    
 L  inter327    
 L  inter328    
 L  inter329    
 L  inter330    
 L  inter331    
 L  inter332    
 L  inter333    
 L  inter334    
 L  inter335    
 L  inter336    
 L  inter337    
 L  inter338    
 L  inter339    
 L  inter340    
 L  inter341    
 L  inter342    
 L  inter343    
 L  inter344    
 L  inter345    
 L  inter346    
 L  inter347    
 L  inter348    
 L  inter349    
 L  inter350    
 L  inter351    
 L  inter352    
 L  inter353    
 L  inter354    
 L  inter355    
 L  inter356    
 L  inter357    
 L  inter358    
 L  inter359    
 L  inter360    
 L  inter361    
 L  inter362    
 L  inter363    
 L  inter364    
 L  inter365    
 L  inter366    
 L  inter367    
 L  inter368    
 L  inter369    
 L  inter370    
 L  inter371    
 L  inter372    
 L  inter373    
 L  inter374    
 L  inter375    
 L  inter376    
 L  inter377    
 L  inter378    
 L  inter379    
 L  inter380    
 L  inter381    
 L  inter382    
 L  inter383    
 L  inter384    
 L  inter385    
 L  inter386    
 L  inter387    
 L  inter388    
 L  inter389    
 L  inter390    
 L  inter391    
 L  inter392    
 L  inter393    
 L  inter394    
 L  inter395    
 L  inter396    
 L  inter397    
 L  inter398    
 L  inter399    
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0            inter0                              1
    x1            leaderCons                         18
    x1            inter1                              1
    x2            leaderCons                         51
    x2            inter2                              1
    x3            leaderCons                         38
    x3            inter3                              1
    x4            leaderCons                         62
    x4            inter4                              1
    x5            leaderCons                          4
    x5            inter5                              1
    x6            leaderCons                         85
    x6            inter6                              1
    x7            leaderCons                         69
    x7            inter7                              1
    x8            leaderCons                         56
    x8            inter8                              1
    x9            leaderCons                         18
    x9            inter9                              1
    x10           leaderCons                          1
    x10           inter10                             1
    x11           leaderCons                         13
    x11           inter11                             1
    x12           leaderCons                         81
    x12           inter12                             1
    x13           leaderCons                         89
    x13           inter13                             1
    x14           leaderCons                         37
    x14           inter14                             1
    x15           leaderCons                         32
    x15           inter15                             1
    x16           leaderCons                         30
    x16           inter16                             1
    x17           leaderCons                         79
    x17           inter17                             1
    x18           leaderCons                         62
    x18           inter18                             1
    x19           leaderCons                         97
    x19           inter19                             1
    x20           leaderCons                          4
    x20           inter20                             1
    x21           leaderCons                         10
    x21           inter21                             1
    x22           leaderCons                         24
    x22           inter22                             1
    x23           leaderCons                          9
    x23           inter23                             1
    x24           leaderCons                         27
    x24           inter24                             1
    x25           leaderCons                         54
    x25           inter25                             1
    x26           leaderCons                         95
    x26           inter26                             1
    x27           leaderCons                         87
    x27           inter27                             1
    x28           leaderCons                         38
    x28           inter28                             1
    x29           leaderCons                         14
    x29           inter29                             1
    x30           leaderCons                         55
    x30           inter30                             1
    x31           leaderCons                         48
    x31           inter31                             1
    x32           leaderCons                         40
    x32           inter32                             1
    x33           leaderCons                         85
    x33           inter33                             1
    x34           leaderCons                         14
    x34           inter34                             1
    x35           leaderCons                         62
    x35           inter35                             1
    x36           leaderCons                         72
    x36           inter36                             1
    x37           leaderCons                         62
    x37           inter37                             1
    x38           leaderCons                         98
    x38           inter38                             1
    x39           leaderCons                         18
    x39           inter39                             1
    x40           leaderCons                         22
    x40           inter40                             1
    x41           leaderCons                         93
    x41           inter41                             1
    x42           leaderCons                         74
    x42           inter42                             1
    x43           leaderCons                         81
    x43           inter43                             1
    x44           leaderCons                         67
    x44           inter44                             1
    x45           leaderCons                         57
    x45           inter45                             1
    x46           leaderCons                         58
    x46           inter46                             1
    x47           leaderCons                         44
    x47           inter47                             1
    x48           leaderCons                          7
    x48           inter48                             1
    x49           leaderCons                         94
    x49           inter49                             1
    x50           leaderCons                          3
    x50           inter50                             1
    x51           leaderCons                         60
    x51           inter51                             1
    x52           leaderCons                         94
    x52           inter52                             1
    x53           leaderCons                         96
    x53           inter53                             1
    x54           leaderCons                         24
    x54           inter54                             1
    x55           leaderCons                         53
    x55           inter55                             1
    x56           leaderCons                         12
    x56           inter56                             1
    x57           leaderCons                         42
    x57           inter57                             1
    x58           leaderCons                         84
    x58           inter58                             1
    x59           leaderCons                         92
    x59           inter59                             1
    x60           leaderCons                         42
    x60           inter60                             1
    x61           leaderCons                         50
    x61           inter61                             1
    x62           leaderCons                         89
    x62           inter62                             1
    x63           inter63                             1
    x64           leaderCons                          3
    x64           inter64                             1
    x65           leaderCons                         22
    x65           inter65                             1
    x66           leaderCons                         15
    x66           inter66                             1
    x67           leaderCons                         33
    x67           inter67                             1
    x68           leaderCons                         63
    x68           inter68                             1
    x69           leaderCons                         52
    x69           inter69                             1
    x70           leaderCons                         46
    x70           inter70                             1
    x71           leaderCons                         67
    x71           inter71                             1
    x72           leaderCons                         44
    x72           inter72                             1
    x73           leaderCons                         27
    x73           inter73                             1
    x74           leaderCons                         56
    x74           inter74                             1
    x75           leaderCons                         78
    x75           inter75                             1
    x76           leaderCons                         86
    x76           inter76                             1
    x77           leaderCons                         57
    x77           inter77                             1
    x78           leaderCons                         67
    x78           inter78                             1
    x79           leaderCons                         52
    x79           inter79                             1
    x80           leaderCons                         81
    x80           inter80                             1
    x81           leaderCons                         73
    x81           inter81                             1
    x82           leaderCons                         48
    x82           inter82                             1
    x83           leaderCons                          5
    x83           inter83                             1
    x84           leaderCons                         43
    x84           inter84                             1
    x85           leaderCons                         54
    x85           inter85                             1
    x86           leaderCons                         13
    x86           inter86                             1
    x87           leaderCons                         48
    x87           inter87                             1
    x88           leaderCons                         39
    x88           inter88                             1
    x89           leaderCons                         11
    x89           inter89                             1
    x90           leaderCons                         41
    x90           inter90                             1
    x91           leaderCons                         70
    x91           inter91                             1
    x92           leaderCons                         62
    x92           inter92                             1
    x93           leaderCons                         71
    x93           inter93                             1
    x94           leaderCons                         50
    x94           inter94                             1
    x95           leaderCons                         86
    x95           inter95                             1
    x96           leaderCons                         96
    x96           inter96                             1
    x97           leaderCons                         21
    x97           inter97                             1
    x98           leaderCons                         72
    x98           inter98                             1
    x99           leaderCons                         36
    x99           inter99                             1
    x100          leaderCons                         27
    x100          inter100                            1
    x101          leaderCons                         36
    x101          inter101                            1
    x102          leaderCons                         45
    x102          inter102                            1
    x103          leaderCons                         24
    x103          inter103                            1
    x104          leaderCons                         13
    x104          inter104                            1
    x105          leaderCons                         16
    x105          inter105                            1
    x106          leaderCons                         61
    x106          inter106                            1
    x107          leaderCons                         44
    x107          inter107                            1
    x108          leaderCons                         12
    x108          inter108                            1
    x109          leaderCons                         80
    x109          inter109                            1
    x110          leaderCons                         16
    x110          inter110                            1
    x111          leaderCons                         66
    x111          inter111                            1
    x112          leaderCons                         27
    x112          inter112                            1
    x113          leaderCons                         21
    x113          inter113                            1
    x114          leaderCons                         26
    x114          inter114                            1
    x115          leaderCons                         83
    x115          inter115                            1
    x116          leaderCons                         91
    x116          inter116                            1
    x117          leaderCons                         97
    x117          inter117                            1
    x118          leaderCons                         12
    x118          inter118                            1
    x119          leaderCons                         44
    x119          inter119                            1
    x120          leaderCons                         27
    x120          inter120                            1
    x121          leaderCons                         34
    x121          inter121                            1
    x122          leaderCons                         26
    x122          inter122                            1
    x123          leaderCons                         48
    x123          inter123                            1
    x124          leaderCons                         50
    x124          inter124                            1
    x125          leaderCons                         57
    x125          inter125                            1
    x126          leaderCons                         33
    x126          inter126                            1
    x127          leaderCons                         60
    x127          inter127                            1
    x128          leaderCons                          8
    x128          inter128                            1
    x129          leaderCons                         86
    x129          inter129                            1
    x130          leaderCons                         82
    x130          inter130                            1
    x131          leaderCons                         83
    x131          inter131                            1
    x132          leaderCons                         64
    x132          inter132                            1
    x133          leaderCons                         55
    x133          inter133                            1
    x134          leaderCons                         52
    x134          inter134                            1
    x135          leaderCons                          1
    x135          inter135                            1
    x136          leaderCons                         33
    x136          inter136                            1
    x137          leaderCons                         69
    x137          inter137                            1
    x138          leaderCons                         31
    x138          inter138                            1
    x139          leaderCons                         46
    x139          inter139                            1
    x140          leaderCons                         23
    x140          inter140                            1
    x141          leaderCons                         11
    x141          inter141                            1
    x142          leaderCons                         18
    x142          inter142                            1
    x143          leaderCons                         93
    x143          inter143                            1
    x144          leaderCons                         37
    x144          inter144                            1
    x145          leaderCons                         61
    x145          inter145                            1
    x146          leaderCons                         24
    x146          inter146                            1
    x147          leaderCons                         71
    x147          inter147                            1
    x148          leaderCons                         58
    x148          inter148                            1
    x149          leaderCons                         93
    x149          inter149                            1
    x150          leaderCons                         71
    x150          inter150                            1
    x151          leaderCons                          7
    x151          inter151                            1
    x152          leaderCons                         57
    x152          inter152                            1
    x153          leaderCons                         73
    x153          inter153                            1
    x154          leaderCons                         34
    x154          inter154                            1
    x155          leaderCons                         27
    x155          inter155                            1
    x156          leaderCons                         98
    x156          inter156                            1
    x157          leaderCons                         30
    x157          inter157                            1
    x158          leaderCons                         34
    x158          inter158                            1
    x159          leaderCons                         21
    x159          inter159                            1
    x160          leaderCons                         94
    x160          inter160                            1
    x161          leaderCons                         86
    x161          inter161                            1
    x162          inter162                            1
    x163          leaderCons                         57
    x163          inter163                            1
    x164          leaderCons                         66
    x164          inter164                            1
    x165          leaderCons                          4
    x165          inter165                            1
    x166          leaderCons                         61
    x166          inter166                            1
    x167          leaderCons                          6
    x167          inter167                            1
    x168          leaderCons                         49
    x168          inter168                            1
    x169          leaderCons                         60
    x169          inter169                            1
    x170          leaderCons                         94
    x170          inter170                            1
    x171          leaderCons                         89
    x171          inter171                            1
    x172          leaderCons                         28
    x172          inter172                            1
    x173          leaderCons                         34
    x173          inter173                            1
    x174          leaderCons                         47
    x174          inter174                            1
    x175          leaderCons                         12
    x175          inter175                            1
    x176          leaderCons                         36
    x176          inter176                            1
    x177          leaderCons                         81
    x177          inter177                            1
    x178          leaderCons                         40
    x178          inter178                            1
    x179          leaderCons                         41
    x179          inter179                            1
    x180          leaderCons                          4
    x180          inter180                            1
    x181          leaderCons                         17
    x181          inter181                            1
    x182          leaderCons                         80
    x182          inter182                            1
    x183          leaderCons                         55
    x183          inter183                            1
    x184          inter184                            1
    x185          leaderCons                          2
    x185          inter185                            1
    x186          leaderCons                         34
    x186          inter186                            1
    x187          leaderCons                         30
    x187          inter187                            1
    x188          leaderCons                         25
    x188          inter188                            1
    x189          leaderCons                         93
    x189          inter189                            1
    x190          leaderCons                         57
    x190          inter190                            1
    x191          leaderCons                         68
    x191          inter191                            1
    x192          leaderCons                         39
    x192          inter192                            1
    x193          leaderCons                         24
    x193          inter193                            1
    x194          leaderCons                         51
    x194          inter194                            1
    x195          leaderCons                         59
    x195          inter195                            1
    x196          leaderCons                         49
    x196          inter196                            1
    x197          leaderCons                         49
    x197          inter197                            1
    x198          leaderCons                         30
    x198          inter198                            1
    x199          leaderCons                         19
    x199          inter199                            1
    x200          leaderCons                          8
    x200          inter200                            1
    x201          leaderCons                         40
    x201          inter201                            1
    x202          leaderCons                         92
    x202          inter202                            1
    x203          leaderCons                         80
    x203          inter203                            1
    x204          leaderCons                         23
    x204          inter204                            1
    x205          leaderCons                         73
    x205          inter205                            1
    x206          leaderCons                         13
    x206          inter206                            1
    x207          leaderCons                         21
    x207          inter207                            1
    x208          leaderCons                         20
    x208          inter208                            1
    x209          leaderCons                         50
    x209          inter209                            1
    x210          leaderCons                         79
    x210          inter210                            1
    x211          leaderCons                         16
    x211          inter211                            1
    x212          leaderCons                         76
    x212          inter212                            1
    x213          leaderCons                         23
    x213          inter213                            1
    x214          leaderCons                         10
    x214          inter214                            1
    x215          leaderCons                         18
    x215          inter215                            1
    x216          leaderCons                         80
    x216          inter216                            1
    x217          leaderCons                         37
    x217          inter217                            1
    x218          leaderCons                         42
    x218          inter218                            1
    x219          leaderCons                         35
    x219          inter219                            1
    x220          leaderCons                         49
    x220          inter220                            1
    x221          leaderCons                         57
    x221          inter221                            1
    x222          leaderCons                         30
    x222          inter222                            1
    x223          leaderCons                         15
    x223          inter223                            1
    x224          leaderCons                         26
    x224          inter224                            1
    x225          leaderCons                         24
    x225          inter225                            1
    x226          leaderCons                         87
    x226          inter226                            1
    x227          leaderCons                         60
    x227          inter227                            1
    x228          leaderCons                         12
    x228          inter228                            1
    x229          leaderCons                         92
    x229          inter229                            1
    x230          leaderCons                         98
    x230          inter230                            1
    x231          leaderCons                         68
    x231          inter231                            1
    x232          leaderCons                         51
    x232          inter232                            1
    x233          leaderCons                         42
    x233          inter233                            1
    x234          leaderCons                         63
    x234          inter234                            1
    x235          leaderCons                         23
    x235          inter235                            1
    x236          leaderCons                         16
    x236          inter236                            1
    x237          leaderCons                         56
    x237          inter237                            1
    x238          leaderCons                         19
    x238          inter238                            1
    x239          leaderCons                         31
    x239          inter239                            1
    x240          leaderCons                         75
    x240          inter240                            1
    x241          leaderCons                         11
    x241          inter241                            1
    x242          leaderCons                         53
    x242          inter242                            1
    x243          leaderCons                         96
    x243          inter243                            1
    x244          leaderCons                         24
    x244          inter244                            1
    x245          leaderCons                         93
    x245          inter245                            1
    x246          leaderCons                         45
    x246          inter246                            1
    x247          leaderCons                          7
    x247          inter247                            1
    x248          leaderCons                          2
    x248          inter248                            1
    x249          leaderCons                         88
    x249          inter249                            1
    x250          leaderCons                         57
    x250          inter250                            1
    x251          leaderCons                         54
    x251          inter251                            1
    x252          leaderCons                         36
    x252          inter252                            1
    x253          leaderCons                         79
    x253          inter253                            1
    x254          leaderCons                         50
    x254          inter254                            1
    x255          leaderCons                         93
    x255          inter255                            1
    x256          leaderCons                         27
    x256          inter256                            1
    x257          leaderCons                         14
    x257          inter257                            1
    x258          leaderCons                         15
    x258          inter258                            1
    x259          leaderCons                         13
    x259          inter259                            1
    x260          leaderCons                         65
    x260          inter260                            1
    x261          leaderCons                         78
    x261          inter261                            1
    x262          leaderCons                         73
    x262          inter262                            1
    x263          leaderCons                         85
    x263          inter263                            1
    x264          leaderCons                         69
    x264          inter264                            1
    x265          leaderCons                         28
    x265          inter265                            1
    x266          leaderCons                         39
    x266          inter266                            1
    x267          leaderCons                         68
    x267          inter267                            1
    x268          leaderCons                          3
    x268          inter268                            1
    x269          leaderCons                         78
    x269          inter269                            1
    x270          leaderCons                         65
    x270          inter270                            1
    x271          leaderCons                         26
    x271          inter271                            1
    x272          leaderCons                         35
    x272          inter272                            1
    x273          leaderCons                         76
    x273          inter273                            1
    x274          leaderCons                         73
    x274          inter274                            1
    x275          leaderCons                         86
    x275          inter275                            1
    x276          leaderCons                         74
    x276          inter276                            1
    x277          leaderCons                         28
    x277          inter277                            1
    x278          leaderCons                          1
    x278          inter278                            1
    x279          leaderCons                         73
    x279          inter279                            1
    x280          leaderCons                         58
    x280          inter280                            1
    x281          leaderCons                         29
    x281          inter281                            1
    x282          leaderCons                          8
    x282          inter282                            1
    x283          leaderCons                         64
    x283          inter283                            1
    x284          leaderCons                          4
    x284          inter284                            1
    x285          leaderCons                         66
    x285          inter285                            1
    x286          leaderCons                         59
    x286          inter286                            1
    x287          leaderCons                         62
    x287          inter287                            1
    x288          leaderCons                         27
    x288          inter288                            1
    x289          leaderCons                         99
    x289          inter289                            1
    x290          leaderCons                         20
    x290          inter290                            1
    x291          leaderCons                         77
    x291          inter291                            1
    x292          leaderCons                         98
    x292          inter292                            1
    x293          leaderCons                         83
    x293          inter293                            1
    x294          leaderCons                         27
    x294          inter294                            1
    x295          leaderCons                         63
    x295          inter295                            1
    x296          leaderCons                         47
    x296          inter296                            1
    x297          leaderCons                         45
    x297          inter297                            1
    x298          leaderCons                         26
    x298          inter298                            1
    x299          leaderCons                         36
    x299          inter299                            1
    x300          leaderCons                         16
    x300          inter300                            1
    x301          leaderCons                         64
    x301          inter301                            1
    x302          leaderCons                         75
    x302          inter302                            1
    x303          leaderCons                         81
    x303          inter303                            1
    x304          leaderCons                         68
    x304          inter304                            1
    x305          leaderCons                          9
    x305          inter305                            1
    x306          leaderCons                         28
    x306          inter306                            1
    x307          leaderCons                         21
    x307          inter307                            1
    x308          leaderCons                         16
    x308          inter308                            1
    x309          leaderCons                         48
    x309          inter309                            1
    x310          leaderCons                         50
    x310          inter310                            1
    x311          leaderCons                         46
    x311          inter311                            1
    x312          leaderCons                         50
    x312          inter312                            1
    x313          leaderCons                         59
    x313          inter313                            1
    x314          leaderCons                         59
    x314          inter314                            1
    x315          leaderCons                         13
    x315          inter315                            1
    x316          leaderCons                         71
    x316          inter316                            1
    x317          leaderCons                         80
    x317          inter317                            1
    x318          leaderCons                         99
    x318          inter318                            1
    x319          leaderCons                         94
    x319          inter319                            1
    x320          leaderCons                         41
    x320          inter320                            1
    x321          leaderCons                         10
    x321          inter321                            1
    x322          leaderCons                         78
    x322          inter322                            1
    x323          leaderCons                         77
    x323          inter323                            1
    x324          leaderCons                         61
    x324          inter324                            1
    x325          leaderCons                          2
    x325          inter325                            1
    x326          leaderCons                         53
    x326          inter326                            1
    x327          leaderCons                         24
    x327          inter327                            1
    x328          leaderCons                         67
    x328          inter328                            1
    x329          leaderCons                         17
    x329          inter329                            1
    x330          leaderCons                         86
    x330          inter330                            1
    x331          leaderCons                         38
    x331          inter331                            1
    x332          leaderCons                         99
    x332          inter332                            1
    x333          leaderCons                         42
    x333          inter333                            1
    x334          leaderCons                         49
    x334          inter334                            1
    x335          leaderCons                         66
    x335          inter335                            1
    x336          leaderCons                         69
    x336          inter336                            1
    x337          leaderCons                         87
    x337          inter337                            1
    x338          leaderCons                         17
    x338          inter338                            1
    x339          leaderCons                         54
    x339          inter339                            1
    x340          leaderCons                         84
    x340          inter340                            1
    x341          leaderCons                          4
    x341          inter341                            1
    x342          leaderCons                         97
    x342          inter342                            1
    x343          leaderCons                         17
    x343          inter343                            1
    x344          leaderCons                         56
    x344          inter344                            1
    x345          leaderCons                         54
    x345          inter345                            1
    x346          leaderCons                         93
    x346          inter346                            1
    x347          leaderCons                         76
    x347          inter347                            1
    x348          leaderCons                         90
    x348          inter348                            1
    x349          leaderCons                         19
    x349          inter349                            1
    x350          leaderCons                         41
    x350          inter350                            1
    x351          leaderCons                         72
    x351          inter351                            1
    x352          leaderCons                         33
    x352          inter352                            1
    x353          leaderCons                         92
    x353          inter353                            1
    x354          leaderCons                         64
    x354          inter354                            1
    x355          leaderCons                         88
    x355          inter355                            1
    x356          leaderCons                         20
    x356          inter356                            1
    x357          leaderCons                         85
    x357          inter357                            1
    x358          leaderCons                         53
    x358          inter358                            1
    x359          leaderCons                         81
    x359          inter359                            1
    x360          leaderCons                         36
    x360          inter360                            1
    x361          leaderCons                         48
    x361          inter361                            1
    x362          leaderCons                         71
    x362          inter362                            1
    x363          leaderCons                         91
    x363          inter363                            1
    x364          leaderCons                         51
    x364          inter364                            1
    x365          leaderCons                         40
    x365          inter365                            1
    x366          leaderCons                         84
    x366          inter366                            1
    x367          leaderCons                         64
    x367          inter367                            1
    x368          leaderCons                         54
    x368          inter368                            1
    x369          leaderCons                         13
    x369          inter369                            1
    x370          leaderCons                         29
    x370          inter370                            1
    x371          leaderCons                         89
    x371          inter371                            1
    x372          leaderCons                         47
    x372          inter372                            1
    x373          leaderCons                         13
    x373          inter373                            1
    x374          leaderCons                         56
    x374          inter374                            1
    x375          leaderCons                          5
    x375          inter375                            1
    x376          leaderCons                         28
    x376          inter376                            1
    x377          leaderCons                         35
    x377          inter377                            1
    x378          leaderCons                         59
    x378          inter378                            1
    x379          leaderCons                         13
    x379          inter379                            1
    x380          leaderCons                         17
    x380          inter380                            1
    x381          leaderCons                         88
    x381          inter381                            1
    x382          leaderCons                         45
    x382          inter382                            1
    x383          leaderCons                         70
    x383          inter383                            1
    x384          leaderCons                         64
    x384          inter384                            1
    x385          leaderCons                         79
    x385          inter385                            1
    x386          leaderCons                         19
    x386          inter386                            1
    x387          leaderCons                         47
    x387          inter387                            1
    x388          leaderCons                         28
    x388          inter388                            1
    x389          leaderCons                         10
    x389          inter389                            1
    x390          leaderCons                         93
    x390          inter390                            1
    x391          leaderCons                         90
    x391          inter391                            1
    x392          leaderCons                         15
    x392          inter392                            1
    x393          leaderCons                         39
    x393          inter393                            1
    x394          leaderCons                         58
    x394          inter394                            1
    x395          leaderCons                         26
    x395          inter395                            1
    x396          leaderCons                         50
    x396          inter396                            1
    x397          leaderCons                         45
    x397          inter397                            1
    x398          leaderCons                         46
    x398          inter398                            1
    x399          leaderCons                         11
    x399          inter399                            1
    y0            COST                              106
    y0            followerCons                       96
    y0            inter0                              1
    y1            COST                               84
    y1            followerCons                       74
    y1            inter1                              1
    y2            COST                               62
    y2            followerCons                       52
    y2            inter2                              1
    y3            COST                               67
    y3            followerCons                       57
    y3            inter3                              1
    y4            COST                              104
    y4            followerCons                       94
    y4            inter4                              1
    y5            COST                               96
    y5            followerCons                       86
    y5            inter5                              1
    y6            COST                               46
    y6            followerCons                       36
    y6            inter6                              1
    y7            COST                               30
    y7            followerCons                       20
    y7            inter7                              1
    y8            COST                               48
    y8            followerCons                       38
    y8            inter8                              1
    y9            COST                               84
    y9            followerCons                       74
    y9            inter9                              1
    y10           COST                               89
    y10           followerCons                       79
    y10           inter10                             1
    y11           COST                               63
    y11           followerCons                       53
    y11           inter11                             1
    y12           COST                               76
    y12           followerCons                       66
    y12           inter12                             1
    y13           COST                               64
    y13           followerCons                       54
    y13           inter13                             1
    y14           COST                               78
    y14           followerCons                       68
    y14           inter14                             1
    y15           COST                               94
    y15           followerCons                       84
    y15           inter15                             1
    y16           COST                               73
    y16           followerCons                       63
    y16           inter16                             1
    y17           COST                               74
    y17           followerCons                       64
    y17           inter17                             1
    y18           COST                               25
    y18           followerCons                       15
    y18           inter18                             1
    y19           COST                               12
    y19           followerCons                        2
    y19           inter19                             1
    y20           COST                               59
    y20           followerCons                       49
    y20           inter20                             1
    y21           COST                               43
    y21           followerCons                       33
    y21           inter21                             1
    y22           COST                               51
    y22           followerCons                       41
    y22           inter22                             1
    y23           COST                               38
    y23           followerCons                       28
    y23           inter23                             1
    y24           COST                               72
    y24           followerCons                       62
    y24           inter24                             1
    y25           COST                               74
    y25           followerCons                       64
    y25           inter25                             1
    y26           COST                               80
    y26           followerCons                       70
    y26           inter26                             1
    y27           COST                               52
    y27           followerCons                       42
    y27           inter27                             1
    y28           COST                              106
    y28           followerCons                       96
    y28           inter28                             1
    y29           COST                               91
    y29           followerCons                       81
    y29           inter29                             1
    y30           COST                               95
    y30           followerCons                       85
    y30           inter30                             1
    y31           COST                               99
    y31           followerCons                       89
    y31           inter31                             1
    y32           COST                               79
    y32           followerCons                       69
    y32           inter32                             1
    y33           COST                               73
    y33           followerCons                       63
    y33           inter33                             1
    y34           COST                               53
    y34           followerCons                       43
    y34           inter34                             1
    y35           COST                               55
    y35           followerCons                       45
    y35           inter35                             1
    y36           COST                              104
    y36           followerCons                       94
    y36           inter36                             1
    y37           COST                               72
    y37           followerCons                       62
    y37           inter37                             1
    y38           COST                               33
    y38           followerCons                       23
    y38           inter38                             1
    y39           COST                               21
    y39           followerCons                       11
    y39           inter39                             1
    y40           COST                               19
    y40           followerCons                        9
    y40           inter40                             1
    y41           COST                               35
    y41           followerCons                       25
    y41           inter41                             1
    y42           COST                              105
    y42           followerCons                       95
    y42           inter42                             1
    y43           COST                               29
    y43           followerCons                       19
    y43           inter43                             1
    y44           COST                              110
    y44           followerCons                      100
    y44           inter44                             1
    y45           COST                               63
    y45           followerCons                       53
    y45           inter45                             1
    y46           COST                               40
    y46           followerCons                       30
    y46           inter46                             1
    y47           COST                              101
    y47           followerCons                       91
    y47           inter47                             1
    y48           COST                               14
    y48           followerCons                        4
    y48           inter48                             1
    y49           COST                               38
    y49           followerCons                       28
    y49           inter49                             1
    y50           COST                               97
    y50           followerCons                       87
    y50           inter50                             1
    y51           COST                               40
    y51           followerCons                       30
    y51           inter51                             1
    y52           COST                               17
    y52           followerCons                        7
    y52           inter52                             1
    y53           COST                               36
    y53           followerCons                       26
    y53           inter53                             1
    y54           COST                               22
    y54           followerCons                       12
    y54           inter54                             1
    y55           COST                               23
    y55           followerCons                       13
    y55           inter55                             1
    y56           COST                               51
    y56           followerCons                       41
    y56           inter56                             1
    y57           COST                              104
    y57           followerCons                       94
    y57           inter57                             1
    y58           COST                               98
    y58           followerCons                       88
    y58           inter58                             1
    y59           COST                               83
    y59           followerCons                       73
    y59           inter59                             1
    y60           COST                               74
    y60           followerCons                       64
    y60           inter60                             1
    y61           COST                               19
    y61           followerCons                        9
    y61           inter61                             1
    y62           COST                               96
    y62           followerCons                       86
    y62           inter62                             1
    y63           COST                               36
    y63           followerCons                       26
    y63           inter63                             1
    y64           COST                               42
    y64           followerCons                       32
    y64           inter64                             1
    y65           COST                               24
    y65           followerCons                       14
    y65           inter65                             1
    y66           COST                               62
    y66           followerCons                       52
    y66           inter66                             1
    y67           COST                               19
    y67           followerCons                        9
    y67           inter67                             1
    y68           COST                               33
    y68           followerCons                       23
    y68           inter68                             1
    y69           COST                              102
    y69           followerCons                       92
    y69           inter69                             1
    y70           COST                               96
    y70           followerCons                       86
    y70           inter70                             1
    y71           COST                               68
    y71           followerCons                       58
    y71           inter71                             1
    y72           COST                               66
    y72           followerCons                       56
    y72           inter72                             1
    y73           COST                               93
    y73           followerCons                       83
    y73           inter73                             1
    y74           COST                               29
    y74           followerCons                       19
    y74           inter74                             1
    y75           COST                               12
    y75           followerCons                        2
    y75           inter75                             1
    y76           COST                               69
    y76           followerCons                       59
    y76           inter76                             1
    y77           COST                               40
    y77           followerCons                       30
    y77           inter77                             1
    y78           COST                               85
    y78           followerCons                       75
    y78           inter78                             1
    y79           COST                               36
    y79           followerCons                       26
    y79           inter79                             1
    y80           COST                               93
    y80           followerCons                       83
    y80           inter80                             1
    y81           COST                               23
    y81           followerCons                       13
    y81           inter81                             1
    y82           COST                               36
    y82           followerCons                       26
    y82           inter82                             1
    y83           COST                               48
    y83           followerCons                       38
    y83           inter83                             1
    y84           COST                               25
    y84           followerCons                       15
    y84           inter84                             1
    y85           COST                               99
    y85           followerCons                       89
    y85           inter85                             1
    y86           COST                               55
    y86           followerCons                       45
    y86           inter86                             1
    y87           COST                               16
    y87           followerCons                        6
    y87           inter87                             1
    y88           COST                               16
    y88           followerCons                        6
    y88           inter88                             1
    y89           COST                               25
    y89           followerCons                       15
    y89           inter89                             1
    y90           COST                               78
    y90           followerCons                       68
    y90           inter90                             1
    y91           COST                               54
    y91           followerCons                       44
    y91           inter91                             1
    y92           COST                               80
    y92           followerCons                       70
    y92           inter92                             1
    y93           COST                               26
    y93           followerCons                       16
    y93           inter93                             1
    y94           COST                               73
    y94           followerCons                       63
    y94           inter94                             1
    y95           COST                               45
    y95           followerCons                       35
    y95           inter95                             1
    y96           COST                              101
    y96           followerCons                       91
    y96           inter96                             1
    y97           COST                               29
    y97           followerCons                       19
    y97           inter97                             1
    y98           COST                               87
    y98           followerCons                       77
    y98           inter98                             1
    y99           COST                               91
    y99           followerCons                       81
    y99           inter99                             1
    y100          COST                               58
    y100          followerCons                       48
    y100          inter100                            1
    y101          COST                               78
    y101          followerCons                       68
    y101          inter101                            1
    y102          COST                               97
    y102          followerCons                       87
    y102          inter102                            1
    y103          COST                               95
    y103          followerCons                       85
    y103          inter103                            1
    y104          COST                              107
    y104          followerCons                       97
    y104          inter104                            1
    y105          COST                              108
    y105          followerCons                       98
    y105          inter105                            1
    y106          COST                               99
    y106          followerCons                       89
    y106          inter106                            1
    y107          COST                               11
    y107          followerCons                        1
    y107          inter107                            1
    y108          COST                               66
    y108          followerCons                       56
    y108          inter108                            1
    y109          COST                               56
    y109          followerCons                       46
    y109          inter109                            1
    y110          COST                               97
    y110          followerCons                       87
    y110          inter110                            1
    y111          COST                               79
    y111          followerCons                       69
    y111          inter111                            1
    y112          COST                               46
    y112          followerCons                       36
    y112          inter112                            1
    y113          COST                               64
    y113          followerCons                       54
    y113          inter113                            1
    y114          COST                               59
    y114          followerCons                       49
    y114          inter114                            1
    y115          COST                               16
    y115          followerCons                        6
    y115          inter115                            1
    y116          COST                               61
    y116          followerCons                       51
    y116          inter116                            1
    y117          COST                               36
    y117          followerCons                       26
    y117          inter117                            1
    y118          COST                               60
    y118          followerCons                       50
    y118          inter118                            1
    y119          COST                               62
    y119          followerCons                       52
    y119          inter119                            1
    y120          COST                               37
    y120          followerCons                       27
    y120          inter120                            1
    y121          COST                               43
    y121          followerCons                       33
    y121          inter121                            1
    y122          COST                               82
    y122          followerCons                       72
    y122          inter122                            1
    y123          COST                              101
    y123          followerCons                       91
    y123          inter123                            1
    y124          COST                               47
    y124          followerCons                       37
    y124          inter124                            1
    y125          COST                               70
    y125          followerCons                       60
    y125          inter125                            1
    y126          COST                               80
    y126          followerCons                       70
    y126          inter126                            1
    y127          COST                               43
    y127          followerCons                       33
    y127          inter127                            1
    y128          COST                              102
    y128          followerCons                       92
    y128          inter128                            1
    y129          COST                               88
    y129          followerCons                       78
    y129          inter129                            1
    y130          COST                               51
    y130          followerCons                       41
    y130          inter130                            1
    y131          COST                               83
    y131          followerCons                       73
    y131          inter131                            1
    y132          COST                               26
    y132          followerCons                       16
    y132          inter132                            1
    y133          COST                               60
    y133          followerCons                       50
    y133          inter133                            1
    y134          COST                               21
    y134          followerCons                       11
    y134          inter134                            1
    y135          COST                               43
    y135          followerCons                       33
    y135          inter135                            1
    y136          COST                               89
    y136          followerCons                       79
    y136          inter136                            1
    y137          COST                               50
    y137          followerCons                       40
    y137          inter137                            1
    y138          COST                              101
    y138          followerCons                       91
    y138          inter138                            1
    y139          COST                               46
    y139          followerCons                       36
    y139          inter139                            1
    y140          COST                               19
    y140          followerCons                        9
    y140          inter140                            1
    y141          COST                               46
    y141          followerCons                       36
    y141          inter141                            1
    y142          COST                               52
    y142          followerCons                       42
    y142          inter142                            1
    y143          COST                               95
    y143          followerCons                       85
    y143          inter143                            1
    y144          COST                               27
    y144          followerCons                       17
    y144          inter144                            1
    y145          COST                              102
    y145          followerCons                       92
    y145          inter145                            1
    y146          COST                               28
    y146          followerCons                       18
    y146          inter146                            1
    y147          COST                               24
    y147          followerCons                       14
    y147          inter147                            1
    y148          COST                               31
    y148          followerCons                       21
    y148          inter148                            1
    y149          COST                               23
    y149          followerCons                       13
    y149          inter149                            1
    y150          COST                               64
    y150          followerCons                       54
    y150          inter150                            1
    y151          COST                               91
    y151          followerCons                       81
    y151          inter151                            1
    y152          COST                               40
    y152          followerCons                       30
    y152          inter152                            1
    y153          COST                               64
    y153          followerCons                       54
    y153          inter153                            1
    y154          COST                               98
    y154          followerCons                       88
    y154          inter154                            1
    y155          COST                              100
    y155          followerCons                       90
    y155          inter155                            1
    y156          COST                               47
    y156          followerCons                       37
    y156          inter156                            1
    y157          COST                               89
    y157          followerCons                       79
    y157          inter157                            1
    y158          COST                               79
    y158          followerCons                       69
    y158          inter158                            1
    y159          COST                              100
    y159          followerCons                       90
    y159          inter159                            1
    y160          COST                               60
    y160          followerCons                       50
    y160          inter160                            1
    y161          COST                               85
    y161          followerCons                       75
    y161          inter161                            1
    y162          COST                               98
    y162          followerCons                       88
    y162          inter162                            1
    y163          COST                               67
    y163          followerCons                       57
    y163          inter163                            1
    y164          COST                               42
    y164          followerCons                       32
    y164          inter164                            1
    y165          COST                               68
    y165          followerCons                       58
    y165          inter165                            1
    y166          COST                               65
    y166          followerCons                       55
    y166          inter166                            1
    y167          COST                               54
    y167          followerCons                       44
    y167          inter167                            1
    y168          COST                               84
    y168          followerCons                       74
    y168          inter168                            1
    y169          COST                               78
    y169          followerCons                       68
    y169          inter169                            1
    y170          COST                               85
    y170          followerCons                       75
    y170          inter170                            1
    y171          COST                               50
    y171          followerCons                       40
    y171          inter171                            1
    y172          COST                               33
    y172          followerCons                       23
    y172          inter172                            1
    y173          COST                               29
    y173          followerCons                       19
    y173          inter173                            1
    y174          COST                               62
    y174          followerCons                       52
    y174          inter174                            1
    y175          COST                               86
    y175          followerCons                       76
    y175          inter175                            1
    y176          COST                               81
    y176          followerCons                       71
    y176          inter176                            1
    y177          COST                               14
    y177          followerCons                        4
    y177          inter177                            1
    y178          COST                              101
    y178          followerCons                       91
    y178          inter178                            1
    y179          COST                              108
    y179          followerCons                       98
    y179          inter179                            1
    y180          COST                               22
    y180          followerCons                       12
    y180          inter180                            1
    y181          COST                              104
    y181          followerCons                       94
    y181          inter181                            1
    y182          COST                               39
    y182          followerCons                       29
    y182          inter182                            1
    y183          COST                               73
    y183          followerCons                       63
    y183          inter183                            1
    y184          COST                               67
    y184          followerCons                       57
    y184          inter184                            1
    y185          COST                               15
    y185          followerCons                        5
    y185          inter185                            1
    y186          COST                               60
    y186          followerCons                       50
    y186          inter186                            1
    y187          COST                               43
    y187          followerCons                       33
    y187          inter187                            1
    y188          COST                               64
    y188          followerCons                       54
    y188          inter188                            1
    y189          COST                               74
    y189          followerCons                       64
    y189          inter189                            1
    y190          COST                               77
    y190          followerCons                       67
    y190          inter190                            1
    y191          COST                               66
    y191          followerCons                       56
    y191          inter191                            1
    y192          COST                               43
    y192          followerCons                       33
    y192          inter192                            1
    y193          COST                              100
    y193          followerCons                       90
    y193          inter193                            1
    y194          COST                               48
    y194          followerCons                       38
    y194          inter194                            1
    y195          COST                               31
    y195          followerCons                       21
    y195          inter195                            1
    y196          COST                              107
    y196          followerCons                       97
    y196          inter196                            1
    y197          COST                               35
    y197          followerCons                       25
    y197          inter197                            1
    y198          COST                               80
    y198          followerCons                       70
    y198          inter198                            1
    y199          COST                               58
    y199          followerCons                       48
    y199          inter199                            1
    y200          COST                               37
    y200          followerCons                       27
    y200          inter200                            1
    y201          COST                               40
    y201          followerCons                       30
    y201          inter201                            1
    y202          COST                               21
    y202          followerCons                       11
    y202          inter202                            1
    y203          COST                               37
    y203          followerCons                       27
    y203          inter203                            1
    y204          COST                               17
    y204          followerCons                        7
    y204          inter204                            1
    y205          COST                               35
    y205          followerCons                       25
    y205          inter205                            1
    y206          COST                               40
    y206          followerCons                       30
    y206          inter206                            1
    y207          COST                               98
    y207          followerCons                       88
    y207          inter207                            1
    y208          COST                              101
    y208          followerCons                       91
    y208          inter208                            1
    y209          COST                              104
    y209          followerCons                       94
    y209          inter209                            1
    y210          COST                               40
    y210          followerCons                       30
    y210          inter210                            1
    y211          COST                               85
    y211          followerCons                       75
    y211          inter211                            1
    y212          COST                               74
    y212          followerCons                       64
    y212          inter212                            1
    y213          COST                               96
    y213          followerCons                       86
    y213          inter213                            1
    y214          COST                               74
    y214          followerCons                       64
    y214          inter214                            1
    y215          COST                               42
    y215          followerCons                       32
    y215          inter215                            1
    y216          COST                               24
    y216          followerCons                       14
    y216          inter216                            1
    y217          COST                               40
    y217          followerCons                       30
    y217          inter217                            1
    y218          COST                               61
    y218          followerCons                       51
    y218          inter218                            1
    y219          COST                               59
    y219          followerCons                       49
    y219          inter219                            1
    y220          COST                              110
    y220          followerCons                      100
    y220          inter220                            1
    y221          COST                               13
    y221          followerCons                        3
    y221          inter221                            1
    y222          COST                               78
    y222          followerCons                       68
    y222          inter222                            1
    y223          COST                               99
    y223          followerCons                       89
    y223          inter223                            1
    y224          COST                               67
    y224          followerCons                       57
    y224          inter224                            1
    y225          COST                               18
    y225          followerCons                        8
    y225          inter225                            1
    y226          COST                               49
    y226          followerCons                       39
    y226          inter226                            1
    y227          COST                               20
    y227          followerCons                       10
    y227          inter227                            1
    y228          COST                               34
    y228          followerCons                       24
    y228          inter228                            1
    y229          COST                               55
    y229          followerCons                       45
    y229          inter229                            1
    y230          COST                               18
    y230          followerCons                        8
    y230          inter230                            1
    y231          COST                               94
    y231          followerCons                       84
    y231          inter231                            1
    y232          COST                               18
    y232          followerCons                        8
    y232          inter232                            1
    y233          COST                               12
    y233          followerCons                        2
    y233          inter233                            1
    y234          COST                               56
    y234          followerCons                       46
    y234          inter234                            1
    y235          COST                               16
    y235          followerCons                        6
    y235          inter235                            1
    y236          COST                               18
    y236          followerCons                        8
    y236          inter236                            1
    y237          COST                               43
    y237          followerCons                       33
    y237          inter237                            1
    y238          COST                               64
    y238          followerCons                       54
    y238          inter238                            1
    y239          COST                               98
    y239          followerCons                       88
    y239          inter239                            1
    y240          COST                               29
    y240          followerCons                       19
    y240          inter240                            1
    y241          COST                               69
    y241          followerCons                       59
    y241          inter241                            1
    y242          COST                              107
    y242          followerCons                       97
    y242          inter242                            1
    y243          COST                               57
    y243          followerCons                       47
    y243          inter243                            1
    y244          COST                               31
    y244          followerCons                       21
    y244          inter244                            1
    y245          COST                               81
    y245          followerCons                       71
    y245          inter245                            1
    y246          COST                               67
    y246          followerCons                       57
    y246          inter246                            1
    y247          COST                               20
    y247          followerCons                       10
    y247          inter247                            1
    y248          COST                               82
    y248          followerCons                       72
    y248          inter248                            1
    y249          COST                               75
    y249          followerCons                       65
    y249          inter249                            1
    y250          COST                               18
    y250          followerCons                        8
    y250          inter250                            1
    y251          COST                               22
    y251          followerCons                       12
    y251          inter251                            1
    y252          COST                               53
    y252          followerCons                       43
    y252          inter252                            1
    y253          COST                               26
    y253          followerCons                       16
    y253          inter253                            1
    y254          COST                               74
    y254          followerCons                       64
    y254          inter254                            1
    y255          COST                               69
    y255          followerCons                       59
    y255          inter255                            1
    y256          COST                               64
    y256          followerCons                       54
    y256          inter256                            1
    y257          COST                               66
    y257          followerCons                       56
    y257          inter257                            1
    y258          COST                               14
    y258          followerCons                        4
    y258          inter258                            1
    y259          COST                               32
    y259          followerCons                       22
    y259          inter259                            1
    y260          COST                               85
    y260          followerCons                       75
    y260          inter260                            1
    y261          COST                               94
    y261          followerCons                       84
    y261          inter261                            1
    y262          COST                              107
    y262          followerCons                       97
    y262          inter262                            1
    y263          COST                               69
    y263          followerCons                       59
    y263          inter263                            1
    y264          COST                               68
    y264          followerCons                       58
    y264          inter264                            1
    y265          COST                               66
    y265          followerCons                       56
    y265          inter265                            1
    y266          COST                               50
    y266          followerCons                       40
    y266          inter266                            1
    y267          COST                               12
    y267          followerCons                        2
    y267          inter267                            1
    y268          COST                               72
    y268          followerCons                       62
    y268          inter268                            1
    y269          COST                               97
    y269          followerCons                       87
    y269          inter269                            1
    y270          COST                               16
    y270          followerCons                        6
    y270          inter270                            1
    y271          COST                               34
    y271          followerCons                       24
    y271          inter271                            1
    y272          COST                               27
    y272          followerCons                       17
    y272          inter272                            1
    y273          COST                               12
    y273          followerCons                        2
    y273          inter273                            1
    y274          COST                               93
    y274          followerCons                       83
    y274          inter274                            1
    y275          COST                               30
    y275          followerCons                       20
    y275          inter275                            1
    y276          COST                               33
    y276          followerCons                       23
    y276          inter276                            1
    y277          COST                              101
    y277          followerCons                       91
    y277          inter277                            1
    y278          COST                               12
    y278          followerCons                        2
    y278          inter278                            1
    y279          COST                               14
    y279          followerCons                        4
    y279          inter279                            1
    y280          COST                               45
    y280          followerCons                       35
    y280          inter280                            1
    y281          COST                               68
    y281          followerCons                       58
    y281          inter281                            1
    y282          COST                               30
    y282          followerCons                       20
    y282          inter282                            1
    y283          COST                               34
    y283          followerCons                       24
    y283          inter283                            1
    y284          COST                               74
    y284          followerCons                       64
    y284          inter284                            1
    y285          COST                               81
    y285          followerCons                       71
    y285          inter285                            1
    y286          COST                              110
    y286          followerCons                      100
    y286          inter286                            1
    y287          COST                               95
    y287          followerCons                       85
    y287          inter287                            1
    y288          COST                              106
    y288          followerCons                       96
    y288          inter288                            1
    y289          COST                               27
    y289          followerCons                       17
    y289          inter289                            1
    y290          COST                              105
    y290          followerCons                       95
    y290          inter290                            1
    y291          COST                               61
    y291          followerCons                       51
    y291          inter291                            1
    y292          COST                               22
    y292          followerCons                       12
    y292          inter292                            1
    y293          COST                               27
    y293          followerCons                       17
    y293          inter293                            1
    y294          COST                               95
    y294          followerCons                       85
    y294          inter294                            1
    y295          COST                               25
    y295          followerCons                       15
    y295          inter295                            1
    y296          COST                               20
    y296          followerCons                       10
    y296          inter296                            1
    y297          COST                               62
    y297          followerCons                       52
    y297          inter297                            1
    y298          COST                               12
    y298          followerCons                        2
    y298          inter298                            1
    y299          COST                               36
    y299          followerCons                       26
    y299          inter299                            1
    y300          COST                               55
    y300          followerCons                       45
    y300          inter300                            1
    y301          COST                               78
    y301          followerCons                       68
    y301          inter301                            1
    y302          COST                               15
    y302          followerCons                        5
    y302          inter302                            1
    y303          COST                               82
    y303          followerCons                       72
    y303          inter303                            1
    y304          COST                               14
    y304          followerCons                        4
    y304          inter304                            1
    y305          COST                               37
    y305          followerCons                       27
    y305          inter305                            1
    y306          COST                               98
    y306          followerCons                       88
    y306          inter306                            1
    y307          COST                               54
    y307          followerCons                       44
    y307          inter307                            1
    y308          COST                               32
    y308          followerCons                       22
    y308          inter308                            1
    y309          COST                               39
    y309          followerCons                       29
    y309          inter309                            1
    y310          COST                               43
    y310          followerCons                       33
    y310          inter310                            1
    y311          COST                               24
    y311          followerCons                       14
    y311          inter311                            1
    y312          COST                               85
    y312          followerCons                       75
    y312          inter312                            1
    y313          COST                               35
    y313          followerCons                       25
    y313          inter313                            1
    y314          COST                              104
    y314          followerCons                       94
    y314          inter314                            1
    y315          COST                               22
    y315          followerCons                       12
    y315          inter315                            1
    y316          COST                               23
    y316          followerCons                       13
    y316          inter316                            1
    y317          COST                               35
    y317          followerCons                       25
    y317          inter317                            1
    y318          COST                               84
    y318          followerCons                       74
    y318          inter318                            1
    y319          COST                               85
    y319          followerCons                       75
    y319          inter319                            1
    y320          COST                               90
    y320          followerCons                       80
    y320          inter320                            1
    y321          COST                              103
    y321          followerCons                       93
    y321          inter321                            1
    y322          COST                               84
    y322          followerCons                       74
    y322          inter322                            1
    y323          COST                               50
    y323          followerCons                       40
    y323          inter323                            1
    y324          COST                               80
    y324          followerCons                       70
    y324          inter324                            1
    y325          COST                               30
    y325          followerCons                       20
    y325          inter325                            1
    y326          COST                               46
    y326          followerCons                       36
    y326          inter326                            1
    y327          COST                               26
    y327          followerCons                       16
    y327          inter327                            1
    y328          COST                               97
    y328          followerCons                       87
    y328          inter328                            1
    y329          COST                               28
    y329          followerCons                       18
    y329          inter329                            1
    y330          COST                               68
    y330          followerCons                       58
    y330          inter330                            1
    y331          COST                               92
    y331          followerCons                       82
    y331          inter331                            1
    y332          COST                              103
    y332          followerCons                       93
    y332          inter332                            1
    y333          COST                              108
    y333          followerCons                       98
    y333          inter333                            1
    y334          COST                               41
    y334          followerCons                       31
    y334          inter334                            1
    y335          COST                              106
    y335          followerCons                       96
    y335          inter335                            1
    y336          COST                               14
    y336          followerCons                        4
    y336          inter336                            1
    y337          COST                               32
    y337          followerCons                       22
    y337          inter337                            1
    y338          COST                               54
    y338          followerCons                       44
    y338          inter338                            1
    y339          COST                               75
    y339          followerCons                       65
    y339          inter339                            1
    y340          COST                               73
    y340          followerCons                       63
    y340          inter340                            1
    y341          COST                               43
    y341          followerCons                       33
    y341          inter341                            1
    y342          COST                               62
    y342          followerCons                       52
    y342          inter342                            1
    y343          COST                               90
    y343          followerCons                       80
    y343          inter343                            1
    y344          COST                               95
    y344          followerCons                       85
    y344          inter344                            1
    y345          COST                               89
    y345          followerCons                       79
    y345          inter345                            1
    y346          COST                               62
    y346          followerCons                       52
    y346          inter346                            1
    y347          COST                               46
    y347          followerCons                       36
    y347          inter347                            1
    y348          COST                               82
    y348          followerCons                       72
    y348          inter348                            1
    y349          COST                               42
    y349          followerCons                       32
    y349          inter349                            1
    y350          COST                               22
    y350          followerCons                       12
    y350          inter350                            1
    y351          COST                               35
    y351          followerCons                       25
    y351          inter351                            1
    y352          COST                               23
    y352          followerCons                       13
    y352          inter352                            1
    y353          COST                               33
    y353          followerCons                       23
    y353          inter353                            1
    y354          COST                               73
    y354          followerCons                       63
    y354          inter354                            1
    y355          COST                               71
    y355          followerCons                       61
    y355          inter355                            1
    y356          COST                               23
    y356          followerCons                       13
    y356          inter356                            1
    y357          COST                               95
    y357          followerCons                       85
    y357          inter357                            1
    y358          COST                               16
    y358          followerCons                        6
    y358          inter358                            1
    y359          COST                               50
    y359          followerCons                       40
    y359          inter359                            1
    y360          COST                               35
    y360          followerCons                       25
    y360          inter360                            1
    y361          COST                              105
    y361          followerCons                       95
    y361          inter361                            1
    y362          COST                               44
    y362          followerCons                       34
    y362          inter362                            1
    y363          COST                               32
    y363          followerCons                       22
    y363          inter363                            1
    y364          COST                               64
    y364          followerCons                       54
    y364          inter364                            1
    y365          COST                               53
    y365          followerCons                       43
    y365          inter365                            1
    y366          COST                               14
    y366          followerCons                        4
    y366          inter366                            1
    y367          COST                               58
    y367          followerCons                       48
    y367          inter367                            1
    y368          COST                               27
    y368          followerCons                       17
    y368          inter368                            1
    y369          COST                               61
    y369          followerCons                       51
    y369          inter369                            1
    y370          COST                               33
    y370          followerCons                       23
    y370          inter370                            1
    y371          COST                               68
    y371          followerCons                       58
    y371          inter371                            1
    y372          COST                               94
    y372          followerCons                       84
    y372          inter372                            1
    y373          COST                               73
    y373          followerCons                       63
    y373          inter373                            1
    y374          COST                               40
    y374          followerCons                       30
    y374          inter374                            1
    y375          COST                               64
    y375          followerCons                       54
    y375          inter375                            1
    y376          COST                               53
    y376          followerCons                       43
    y376          inter376                            1
    y377          COST                              101
    y377          followerCons                       91
    y377          inter377                            1
    y378          COST                               31
    y378          followerCons                       21
    y378          inter378                            1
    y379          COST                               62
    y379          followerCons                       52
    y379          inter379                            1
    y380          COST                               38
    y380          followerCons                       28
    y380          inter380                            1
    y381          COST                               68
    y381          followerCons                       58
    y381          inter381                            1
    y382          COST                               58
    y382          followerCons                       48
    y382          inter382                            1
    y383          COST                               54
    y383          followerCons                       44
    y383          inter383                            1
    y384          COST                               40
    y384          followerCons                       30
    y384          inter384                            1
    y385          COST                               57
    y385          followerCons                       47
    y385          inter385                            1
    y386          COST                               46
    y386          followerCons                       36
    y386          inter386                            1
    y387          COST                               64
    y387          followerCons                       54
    y387          inter387                            1
    y388          COST                               99
    y388          followerCons                       89
    y388          inter388                            1
    y389          COST                               78
    y389          followerCons                       68
    y389          inter389                            1
    y390          COST                               18
    y390          followerCons                        8
    y390          inter390                            1
    y391          COST                               26
    y391          followerCons                       16
    y391          inter391                            1
    y392          COST                               94
    y392          followerCons                       84
    y392          inter392                            1
    y393          COST                               92
    y393          followerCons                       82
    y393          inter393                            1
    y394          COST                               22
    y394          followerCons                       12
    y394          inter394                            1
    y395          COST                               84
    y395          followerCons                       74
    y395          inter395                            1
    y396          COST                               22
    y396          followerCons                       12
    y396          inter396                            1
    y397          COST                               63
    y397          followerCons                       53
    y397          inter397                            1
    y398          COST                               74
    y398          followerCons                       64
    y398          inter398                            1
    y399          COST                              106
    y399          followerCons                       96
    y399          inter399                            1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs           leaderCons                       5349
    rhs           followerCons                     5357
    rhs           inter0                              1
    rhs           inter1                              1
    rhs           inter2                              1
    rhs           inter3                              1
    rhs           inter4                              1
    rhs           inter5                              1
    rhs           inter6                              1
    rhs           inter7                              1
    rhs           inter8                              1
    rhs           inter9                              1
    rhs           inter10                             1
    rhs           inter11                             1
    rhs           inter12                             1
    rhs           inter13                             1
    rhs           inter14                             1
    rhs           inter15                             1
    rhs           inter16                             1
    rhs           inter17                             1
    rhs           inter18                             1
    rhs           inter19                             1
    rhs           inter20                             1
    rhs           inter21                             1
    rhs           inter22                             1
    rhs           inter23                             1
    rhs           inter24                             1
    rhs           inter25                             1
    rhs           inter26                             1
    rhs           inter27                             1
    rhs           inter28                             1
    rhs           inter29                             1
    rhs           inter30                             1
    rhs           inter31                             1
    rhs           inter32                             1
    rhs           inter33                             1
    rhs           inter34                             1
    rhs           inter35                             1
    rhs           inter36                             1
    rhs           inter37                             1
    rhs           inter38                             1
    rhs           inter39                             1
    rhs           inter40                             1
    rhs           inter41                             1
    rhs           inter42                             1
    rhs           inter43                             1
    rhs           inter44                             1
    rhs           inter45                             1
    rhs           inter46                             1
    rhs           inter47                             1
    rhs           inter48                             1
    rhs           inter49                             1
    rhs           inter50                             1
    rhs           inter51                             1
    rhs           inter52                             1
    rhs           inter53                             1
    rhs           inter54                             1
    rhs           inter55                             1
    rhs           inter56                             1
    rhs           inter57                             1
    rhs           inter58                             1
    rhs           inter59                             1
    rhs           inter60                             1
    rhs           inter61                             1
    rhs           inter62                             1
    rhs           inter63                             1
    rhs           inter64                             1
    rhs           inter65                             1
    rhs           inter66                             1
    rhs           inter67                             1
    rhs           inter68                             1
    rhs           inter69                             1
    rhs           inter70                             1
    rhs           inter71                             1
    rhs           inter72                             1
    rhs           inter73                             1
    rhs           inter74                             1
    rhs           inter75                             1
    rhs           inter76                             1
    rhs           inter77                             1
    rhs           inter78                             1
    rhs           inter79                             1
    rhs           inter80                             1
    rhs           inter81                             1
    rhs           inter82                             1
    rhs           inter83                             1
    rhs           inter84                             1
    rhs           inter85                             1
    rhs           inter86                             1
    rhs           inter87                             1
    rhs           inter88                             1
    rhs           inter89                             1
    rhs           inter90                             1
    rhs           inter91                             1
    rhs           inter92                             1
    rhs           inter93                             1
    rhs           inter94                             1
    rhs           inter95                             1
    rhs           inter96                             1
    rhs           inter97                             1
    rhs           inter98                             1
    rhs           inter99                             1
    rhs           inter100                            1
    rhs           inter101                            1
    rhs           inter102                            1
    rhs           inter103                            1
    rhs           inter104                            1
    rhs           inter105                            1
    rhs           inter106                            1
    rhs           inter107                            1
    rhs           inter108                            1
    rhs           inter109                            1
    rhs           inter110                            1
    rhs           inter111                            1
    rhs           inter112                            1
    rhs           inter113                            1
    rhs           inter114                            1
    rhs           inter115                            1
    rhs           inter116                            1
    rhs           inter117                            1
    rhs           inter118                            1
    rhs           inter119                            1
    rhs           inter120                            1
    rhs           inter121                            1
    rhs           inter122                            1
    rhs           inter123                            1
    rhs           inter124                            1
    rhs           inter125                            1
    rhs           inter126                            1
    rhs           inter127                            1
    rhs           inter128                            1
    rhs           inter129                            1
    rhs           inter130                            1
    rhs           inter131                            1
    rhs           inter132                            1
    rhs           inter133                            1
    rhs           inter134                            1
    rhs           inter135                            1
    rhs           inter136                            1
    rhs           inter137                            1
    rhs           inter138                            1
    rhs           inter139                            1
    rhs           inter140                            1
    rhs           inter141                            1
    rhs           inter142                            1
    rhs           inter143                            1
    rhs           inter144                            1
    rhs           inter145                            1
    rhs           inter146                            1
    rhs           inter147                            1
    rhs           inter148                            1
    rhs           inter149                            1
    rhs           inter150                            1
    rhs           inter151                            1
    rhs           inter152                            1
    rhs           inter153                            1
    rhs           inter154                            1
    rhs           inter155                            1
    rhs           inter156                            1
    rhs           inter157                            1
    rhs           inter158                            1
    rhs           inter159                            1
    rhs           inter160                            1
    rhs           inter161                            1
    rhs           inter162                            1
    rhs           inter163                            1
    rhs           inter164                            1
    rhs           inter165                            1
    rhs           inter166                            1
    rhs           inter167                            1
    rhs           inter168                            1
    rhs           inter169                            1
    rhs           inter170                            1
    rhs           inter171                            1
    rhs           inter172                            1
    rhs           inter173                            1
    rhs           inter174                            1
    rhs           inter175                            1
    rhs           inter176                            1
    rhs           inter177                            1
    rhs           inter178                            1
    rhs           inter179                            1
    rhs           inter180                            1
    rhs           inter181                            1
    rhs           inter182                            1
    rhs           inter183                            1
    rhs           inter184                            1
    rhs           inter185                            1
    rhs           inter186                            1
    rhs           inter187                            1
    rhs           inter188                            1
    rhs           inter189                            1
    rhs           inter190                            1
    rhs           inter191                            1
    rhs           inter192                            1
    rhs           inter193                            1
    rhs           inter194                            1
    rhs           inter195                            1
    rhs           inter196                            1
    rhs           inter197                            1
    rhs           inter198                            1
    rhs           inter199                            1
    rhs           inter200                            1
    rhs           inter201                            1
    rhs           inter202                            1
    rhs           inter203                            1
    rhs           inter204                            1
    rhs           inter205                            1
    rhs           inter206                            1
    rhs           inter207                            1
    rhs           inter208                            1
    rhs           inter209                            1
    rhs           inter210                            1
    rhs           inter211                            1
    rhs           inter212                            1
    rhs           inter213                            1
    rhs           inter214                            1
    rhs           inter215                            1
    rhs           inter216                            1
    rhs           inter217                            1
    rhs           inter218                            1
    rhs           inter219                            1
    rhs           inter220                            1
    rhs           inter221                            1
    rhs           inter222                            1
    rhs           inter223                            1
    rhs           inter224                            1
    rhs           inter225                            1
    rhs           inter226                            1
    rhs           inter227                            1
    rhs           inter228                            1
    rhs           inter229                            1
    rhs           inter230                            1
    rhs           inter231                            1
    rhs           inter232                            1
    rhs           inter233                            1
    rhs           inter234                            1
    rhs           inter235                            1
    rhs           inter236                            1
    rhs           inter237                            1
    rhs           inter238                            1
    rhs           inter239                            1
    rhs           inter240                            1
    rhs           inter241                            1
    rhs           inter242                            1
    rhs           inter243                            1
    rhs           inter244                            1
    rhs           inter245                            1
    rhs           inter246                            1
    rhs           inter247                            1
    rhs           inter248                            1
    rhs           inter249                            1
    rhs           inter250                            1
    rhs           inter251                            1
    rhs           inter252                            1
    rhs           inter253                            1
    rhs           inter254                            1
    rhs           inter255                            1
    rhs           inter256                            1
    rhs           inter257                            1
    rhs           inter258                            1
    rhs           inter259                            1
    rhs           inter260                            1
    rhs           inter261                            1
    rhs           inter262                            1
    rhs           inter263                            1
    rhs           inter264                            1
    rhs           inter265                            1
    rhs           inter266                            1
    rhs           inter267                            1
    rhs           inter268                            1
    rhs           inter269                            1
    rhs           inter270                            1
    rhs           inter271                            1
    rhs           inter272                            1
    rhs           inter273                            1
    rhs           inter274                            1
    rhs           inter275                            1
    rhs           inter276                            1
    rhs           inter277                            1
    rhs           inter278                            1
    rhs           inter279                            1
    rhs           inter280                            1
    rhs           inter281                            1
    rhs           inter282                            1
    rhs           inter283                            1
    rhs           inter284                            1
    rhs           inter285                            1
    rhs           inter286                            1
    rhs           inter287                            1
    rhs           inter288                            1
    rhs           inter289                            1
    rhs           inter290                            1
    rhs           inter291                            1
    rhs           inter292                            1
    rhs           inter293                            1
    rhs           inter294                            1
    rhs           inter295                            1
    rhs           inter296                            1
    rhs           inter297                            1
    rhs           inter298                            1
    rhs           inter299                            1
    rhs           inter300                            1
    rhs           inter301                            1
    rhs           inter302                            1
    rhs           inter303                            1
    rhs           inter304                            1
    rhs           inter305                            1
    rhs           inter306                            1
    rhs           inter307                            1
    rhs           inter308                            1
    rhs           inter309                            1
    rhs           inter310                            1
    rhs           inter311                            1
    rhs           inter312                            1
    rhs           inter313                            1
    rhs           inter314                            1
    rhs           inter315                            1
    rhs           inter316                            1
    rhs           inter317                            1
    rhs           inter318                            1
    rhs           inter319                            1
    rhs           inter320                            1
    rhs           inter321                            1
    rhs           inter322                            1
    rhs           inter323                            1
    rhs           inter324                            1
    rhs           inter325                            1
    rhs           inter326                            1
    rhs           inter327                            1
    rhs           inter328                            1
    rhs           inter329                            1
    rhs           inter330                            1
    rhs           inter331                            1
    rhs           inter332                            1
    rhs           inter333                            1
    rhs           inter334                            1
    rhs           inter335                            1
    rhs           inter336                            1
    rhs           inter337                            1
    rhs           inter338                            1
    rhs           inter339                            1
    rhs           inter340                            1
    rhs           inter341                            1
    rhs           inter342                            1
    rhs           inter343                            1
    rhs           inter344                            1
    rhs           inter345                            1
    rhs           inter346                            1
    rhs           inter347                            1
    rhs           inter348                            1
    rhs           inter349                            1
    rhs           inter350                            1
    rhs           inter351                            1
    rhs           inter352                            1
    rhs           inter353                            1
    rhs           inter354                            1
    rhs           inter355                            1
    rhs           inter356                            1
    rhs           inter357                            1
    rhs           inter358                            1
    rhs           inter359                            1
    rhs           inter360                            1
    rhs           inter361                            1
    rhs           inter362                            1
    rhs           inter363                            1
    rhs           inter364                            1
    rhs           inter365                            1
    rhs           inter366                            1
    rhs           inter367                            1
    rhs           inter368                            1
    rhs           inter369                            1
    rhs           inter370                            1
    rhs           inter371                            1
    rhs           inter372                            1
    rhs           inter373                            1
    rhs           inter374                            1
    rhs           inter375                            1
    rhs           inter376                            1
    rhs           inter377                            1
    rhs           inter378                            1
    rhs           inter379                            1
    rhs           inter380                            1
    rhs           inter381                            1
    rhs           inter382                            1
    rhs           inter383                            1
    rhs           inter384                            1
    rhs           inter385                            1
    rhs           inter386                            1
    rhs           inter387                            1
    rhs           inter388                            1
    rhs           inter389                            1
    rhs           inter390                            1
    rhs           inter391                            1
    rhs           inter392                            1
    rhs           inter393                            1
    rhs           inter394                            1
    rhs           inter395                            1
    rhs           inter396                            1
    rhs           inter397                            1
    rhs           inter398                            1
    rhs           inter399                            1
BOUNDS
 BV bnd           x0          
 BV bnd           x1          
 BV bnd           x2          
 BV bnd           x3          
 BV bnd           x4          
 BV bnd           x5          
 BV bnd           x6          
 BV bnd           x7          
 BV bnd           x8          
 BV bnd           x9          
 BV bnd           x10         
 BV bnd           x11         
 BV bnd           x12         
 BV bnd           x13         
 BV bnd           x14         
 BV bnd           x15         
 BV bnd           x16         
 BV bnd           x17         
 BV bnd           x18         
 BV bnd           x19         
 BV bnd           x20         
 BV bnd           x21         
 BV bnd           x22         
 BV bnd           x23         
 BV bnd           x24         
 BV bnd           x25         
 BV bnd           x26         
 BV bnd           x27         
 BV bnd           x28         
 BV bnd           x29         
 BV bnd           x30         
 BV bnd           x31         
 BV bnd           x32         
 BV bnd           x33         
 BV bnd           x34         
 BV bnd           x35         
 BV bnd           x36         
 BV bnd           x37         
 BV bnd           x38         
 BV bnd           x39         
 BV bnd           x40         
 BV bnd           x41         
 BV bnd           x42         
 BV bnd           x43         
 BV bnd           x44         
 BV bnd           x45         
 BV bnd           x46         
 BV bnd           x47         
 BV bnd           x48         
 BV bnd           x49         
 BV bnd           x50         
 BV bnd           x51         
 BV bnd           x52         
 BV bnd           x53         
 BV bnd           x54         
 BV bnd           x55         
 BV bnd           x56         
 BV bnd           x57         
 BV bnd           x58         
 BV bnd           x59         
 BV bnd           x60         
 BV bnd           x61         
 BV bnd           x62         
 BV bnd           x63         
 BV bnd           x64         
 BV bnd           x65         
 BV bnd           x66         
 BV bnd           x67         
 BV bnd           x68         
 BV bnd           x69         
 BV bnd           x70         
 BV bnd           x71         
 BV bnd           x72         
 BV bnd           x73         
 BV bnd           x74         
 BV bnd           x75         
 BV bnd           x76         
 BV bnd           x77         
 BV bnd           x78         
 BV bnd           x79         
 BV bnd           x80         
 BV bnd           x81         
 BV bnd           x82         
 BV bnd           x83         
 BV bnd           x84         
 BV bnd           x85         
 BV bnd           x86         
 BV bnd           x87         
 BV bnd           x88         
 BV bnd           x89         
 BV bnd           x90         
 BV bnd           x91         
 BV bnd           x92         
 BV bnd           x93         
 BV bnd           x94         
 BV bnd           x95         
 BV bnd           x96         
 BV bnd           x97         
 BV bnd           x98         
 BV bnd           x99         
 BV bnd           x100        
 BV bnd           x101        
 BV bnd           x102        
 BV bnd           x103        
 BV bnd           x104        
 BV bnd           x105        
 BV bnd           x106        
 BV bnd           x107        
 BV bnd           x108        
 BV bnd           x109        
 BV bnd           x110        
 BV bnd           x111        
 BV bnd           x112        
 BV bnd           x113        
 BV bnd           x114        
 BV bnd           x115        
 BV bnd           x116        
 BV bnd           x117        
 BV bnd           x118        
 BV bnd           x119        
 BV bnd           x120        
 BV bnd           x121        
 BV bnd           x122        
 BV bnd           x123        
 BV bnd           x124        
 BV bnd           x125        
 BV bnd           x126        
 BV bnd           x127        
 BV bnd           x128        
 BV bnd           x129        
 BV bnd           x130        
 BV bnd           x131        
 BV bnd           x132        
 BV bnd           x133        
 BV bnd           x134        
 BV bnd           x135        
 BV bnd           x136        
 BV bnd           x137        
 BV bnd           x138        
 BV bnd           x139        
 BV bnd           x140        
 BV bnd           x141        
 BV bnd           x142        
 BV bnd           x143        
 BV bnd           x144        
 BV bnd           x145        
 BV bnd           x146        
 BV bnd           x147        
 BV bnd           x148        
 BV bnd           x149        
 BV bnd           x150        
 BV bnd           x151        
 BV bnd           x152        
 BV bnd           x153        
 BV bnd           x154        
 BV bnd           x155        
 BV bnd           x156        
 BV bnd           x157        
 BV bnd           x158        
 BV bnd           x159        
 BV bnd           x160        
 BV bnd           x161        
 BV bnd           x162        
 BV bnd           x163        
 BV bnd           x164        
 BV bnd           x165        
 BV bnd           x166        
 BV bnd           x167        
 BV bnd           x168        
 BV bnd           x169        
 BV bnd           x170        
 BV bnd           x171        
 BV bnd           x172        
 BV bnd           x173        
 BV bnd           x174        
 BV bnd           x175        
 BV bnd           x176        
 BV bnd           x177        
 BV bnd           x178        
 BV bnd           x179        
 BV bnd           x180        
 BV bnd           x181        
 BV bnd           x182        
 BV bnd           x183        
 BV bnd           x184        
 BV bnd           x185        
 BV bnd           x186        
 BV bnd           x187        
 BV bnd           x188        
 BV bnd           x189        
 BV bnd           x190        
 BV bnd           x191        
 BV bnd           x192        
 BV bnd           x193        
 BV bnd           x194        
 BV bnd           x195        
 BV bnd           x196        
 BV bnd           x197        
 BV bnd           x198        
 BV bnd           x199        
 BV bnd           x200        
 BV bnd           x201        
 BV bnd           x202        
 BV bnd           x203        
 BV bnd           x204        
 BV bnd           x205        
 BV bnd           x206        
 BV bnd           x207        
 BV bnd           x208        
 BV bnd           x209        
 BV bnd           x210        
 BV bnd           x211        
 BV bnd           x212        
 BV bnd           x213        
 BV bnd           x214        
 BV bnd           x215        
 BV bnd           x216        
 BV bnd           x217        
 BV bnd           x218        
 BV bnd           x219        
 BV bnd           x220        
 BV bnd           x221        
 BV bnd           x222        
 BV bnd           x223        
 BV bnd           x224        
 BV bnd           x225        
 BV bnd           x226        
 BV bnd           x227        
 BV bnd           x228        
 BV bnd           x229        
 BV bnd           x230        
 BV bnd           x231        
 BV bnd           x232        
 BV bnd           x233        
 BV bnd           x234        
 BV bnd           x235        
 BV bnd           x236        
 BV bnd           x237        
 BV bnd           x238        
 BV bnd           x239        
 BV bnd           x240        
 BV bnd           x241        
 BV bnd           x242        
 BV bnd           x243        
 BV bnd           x244        
 BV bnd           x245        
 BV bnd           x246        
 BV bnd           x247        
 BV bnd           x248        
 BV bnd           x249        
 BV bnd           x250        
 BV bnd           x251        
 BV bnd           x252        
 BV bnd           x253        
 BV bnd           x254        
 BV bnd           x255        
 BV bnd           x256        
 BV bnd           x257        
 BV bnd           x258        
 BV bnd           x259        
 BV bnd           x260        
 BV bnd           x261        
 BV bnd           x262        
 BV bnd           x263        
 BV bnd           x264        
 BV bnd           x265        
 BV bnd           x266        
 BV bnd           x267        
 BV bnd           x268        
 BV bnd           x269        
 BV bnd           x270        
 BV bnd           x271        
 BV bnd           x272        
 BV bnd           x273        
 BV bnd           x274        
 BV bnd           x275        
 BV bnd           x276        
 BV bnd           x277        
 BV bnd           x278        
 BV bnd           x279        
 BV bnd           x280        
 BV bnd           x281        
 BV bnd           x282        
 BV bnd           x283        
 BV bnd           x284        
 BV bnd           x285        
 BV bnd           x286        
 BV bnd           x287        
 BV bnd           x288        
 BV bnd           x289        
 BV bnd           x290        
 BV bnd           x291        
 BV bnd           x292        
 BV bnd           x293        
 BV bnd           x294        
 BV bnd           x295        
 BV bnd           x296        
 BV bnd           x297        
 BV bnd           x298        
 BV bnd           x299        
 BV bnd           x300        
 BV bnd           x301        
 BV bnd           x302        
 BV bnd           x303        
 BV bnd           x304        
 BV bnd           x305        
 BV bnd           x306        
 BV bnd           x307        
 BV bnd           x308        
 BV bnd           x309        
 BV bnd           x310        
 BV bnd           x311        
 BV bnd           x312        
 BV bnd           x313        
 BV bnd           x314        
 BV bnd           x315        
 BV bnd           x316        
 BV bnd           x317        
 BV bnd           x318        
 BV bnd           x319        
 BV bnd           x320        
 BV bnd           x321        
 BV bnd           x322        
 BV bnd           x323        
 BV bnd           x324        
 BV bnd           x325        
 BV bnd           x326        
 BV bnd           x327        
 BV bnd           x328        
 BV bnd           x329        
 BV bnd           x330        
 BV bnd           x331        
 BV bnd           x332        
 BV bnd           x333        
 BV bnd           x334        
 BV bnd           x335        
 BV bnd           x336        
 BV bnd           x337        
 BV bnd           x338        
 BV bnd           x339        
 BV bnd           x340        
 BV bnd           x341        
 BV bnd           x342        
 BV bnd           x343        
 BV bnd           x344        
 BV bnd           x345        
 BV bnd           x346        
 BV bnd           x347        
 BV bnd           x348        
 BV bnd           x349        
 BV bnd           x350        
 BV bnd           x351        
 BV bnd           x352        
 BV bnd           x353        
 BV bnd           x354        
 BV bnd           x355        
 BV bnd           x356        
 BV bnd           x357        
 BV bnd           x358        
 BV bnd           x359        
 BV bnd           x360        
 BV bnd           x361        
 BV bnd           x362        
 BV bnd           x363        
 BV bnd           x364        
 BV bnd           x365        
 BV bnd           x366        
 BV bnd           x367        
 BV bnd           x368        
 BV bnd           x369        
 BV bnd           x370        
 BV bnd           x371        
 BV bnd           x372        
 BV bnd           x373        
 BV bnd           x374        
 BV bnd           x375        
 BV bnd           x376        
 BV bnd           x377        
 BV bnd           x378        
 BV bnd           x379        
 BV bnd           x380        
 BV bnd           x381        
 BV bnd           x382        
 BV bnd           x383        
 BV bnd           x384        
 BV bnd           x385        
 BV bnd           x386        
 BV bnd           x387        
 BV bnd           x388        
 BV bnd           x389        
 BV bnd           x390        
 BV bnd           x391        
 BV bnd           x392        
 BV bnd           x393        
 BV bnd           x394        
 BV bnd           x395        
 BV bnd           x396        
 BV bnd           x397        
 BV bnd           x398        
 BV bnd           x399        
 LI bnd           y0            0
 LI bnd           y1            0
 LI bnd           y2            0
 LI bnd           y3            0
 LI bnd           y4            0
 LI bnd           y5            0
 LI bnd           y6            0
 LI bnd           y7            0
 LI bnd           y8            0
 LI bnd           y9            0
 LI bnd           y10           0
 LI bnd           y11           0
 LI bnd           y12           0
 LI bnd           y13           0
 LI bnd           y14           0
 LI bnd           y15           0
 LI bnd           y16           0
 LI bnd           y17           0
 LI bnd           y18           0
 LI bnd           y19           0
 LI bnd           y20           0
 LI bnd           y21           0
 LI bnd           y22           0
 LI bnd           y23           0
 LI bnd           y24           0
 LI bnd           y25           0
 LI bnd           y26           0
 LI bnd           y27           0
 LI bnd           y28           0
 LI bnd           y29           0
 LI bnd           y30           0
 LI bnd           y31           0
 LI bnd           y32           0
 LI bnd           y33           0
 LI bnd           y34           0
 LI bnd           y35           0
 LI bnd           y36           0
 LI bnd           y37           0
 LI bnd           y38           0
 LI bnd           y39           0
 LI bnd           y40           0
 LI bnd           y41           0
 LI bnd           y42           0
 LI bnd           y43           0
 LI bnd           y44           0
 LI bnd           y45           0
 LI bnd           y46           0
 LI bnd           y47           0
 LI bnd           y48           0
 LI bnd           y49           0
 LI bnd           y50           0
 LI bnd           y51           0
 LI bnd           y52           0
 LI bnd           y53           0
 LI bnd           y54           0
 LI bnd           y55           0
 LI bnd           y56           0
 LI bnd           y57           0
 LI bnd           y58           0
 LI bnd           y59           0
 LI bnd           y60           0
 LI bnd           y61           0
 LI bnd           y62           0
 LI bnd           y63           0
 LI bnd           y64           0
 LI bnd           y65           0
 LI bnd           y66           0
 LI bnd           y67           0
 LI bnd           y68           0
 LI bnd           y69           0
 LI bnd           y70           0
 LI bnd           y71           0
 LI bnd           y72           0
 LI bnd           y73           0
 LI bnd           y74           0
 LI bnd           y75           0
 LI bnd           y76           0
 LI bnd           y77           0
 LI bnd           y78           0
 LI bnd           y79           0
 LI bnd           y80           0
 LI bnd           y81           0
 LI bnd           y82           0
 LI bnd           y83           0
 LI bnd           y84           0
 LI bnd           y85           0
 LI bnd           y86           0
 LI bnd           y87           0
 LI bnd           y88           0
 LI bnd           y89           0
 LI bnd           y90           0
 LI bnd           y91           0
 LI bnd           y92           0
 LI bnd           y93           0
 LI bnd           y94           0
 LI bnd           y95           0
 LI bnd           y96           0
 LI bnd           y97           0
 LI bnd           y98           0
 LI bnd           y99           0
 LI bnd           y100          0
 LI bnd           y101          0
 LI bnd           y102          0
 LI bnd           y103          0
 LI bnd           y104          0
 LI bnd           y105          0
 LI bnd           y106          0
 LI bnd           y107          0
 LI bnd           y108          0
 LI bnd           y109          0
 LI bnd           y110          0
 LI bnd           y111          0
 LI bnd           y112          0
 LI bnd           y113          0
 LI bnd           y114          0
 LI bnd           y115          0
 LI bnd           y116          0
 LI bnd           y117          0
 LI bnd           y118          0
 LI bnd           y119          0
 LI bnd           y120          0
 LI bnd           y121          0
 LI bnd           y122          0
 LI bnd           y123          0
 LI bnd           y124          0
 LI bnd           y125          0
 LI bnd           y126          0
 LI bnd           y127          0
 LI bnd           y128          0
 LI bnd           y129          0
 LI bnd           y130          0
 LI bnd           y131          0
 LI bnd           y132          0
 LI bnd           y133          0
 LI bnd           y134          0
 LI bnd           y135          0
 LI bnd           y136          0
 LI bnd           y137          0
 LI bnd           y138          0
 LI bnd           y139          0
 LI bnd           y140          0
 LI bnd           y141          0
 LI bnd           y142          0
 LI bnd           y143          0
 LI bnd           y144          0
 LI bnd           y145          0
 LI bnd           y146          0
 LI bnd           y147          0
 LI bnd           y148          0
 LI bnd           y149          0
 LI bnd           y150          0
 LI bnd           y151          0
 LI bnd           y152          0
 LI bnd           y153          0
 LI bnd           y154          0
 LI bnd           y155          0
 LI bnd           y156          0
 LI bnd           y157          0
 LI bnd           y158          0
 LI bnd           y159          0
 LI bnd           y160          0
 LI bnd           y161          0
 LI bnd           y162          0
 LI bnd           y163          0
 LI bnd           y164          0
 LI bnd           y165          0
 LI bnd           y166          0
 LI bnd           y167          0
 LI bnd           y168          0
 LI bnd           y169          0
 LI bnd           y170          0
 LI bnd           y171          0
 LI bnd           y172          0
 LI bnd           y173          0
 LI bnd           y174          0
 LI bnd           y175          0
 LI bnd           y176          0
 LI bnd           y177          0
 LI bnd           y178          0
 LI bnd           y179          0
 LI bnd           y180          0
 LI bnd           y181          0
 LI bnd           y182          0
 LI bnd           y183          0
 LI bnd           y184          0
 LI bnd           y185          0
 LI bnd           y186          0
 LI bnd           y187          0
 LI bnd           y188          0
 LI bnd           y189          0
 LI bnd           y190          0
 LI bnd           y191          0
 LI bnd           y192          0
 LI bnd           y193          0
 LI bnd           y194          0
 LI bnd           y195          0
 LI bnd           y196          0
 LI bnd           y197          0
 LI bnd           y198          0
 LI bnd           y199          0
 LI bnd           y200          0
 LI bnd           y201          0
 LI bnd           y202          0
 LI bnd           y203          0
 LI bnd           y204          0
 LI bnd           y205          0
 LI bnd           y206          0
 LI bnd           y207          0
 LI bnd           y208          0
 LI bnd           y209          0
 LI bnd           y210          0
 LI bnd           y211          0
 LI bnd           y212          0
 LI bnd           y213          0
 LI bnd           y214          0
 LI bnd           y215          0
 LI bnd           y216          0
 LI bnd           y217          0
 LI bnd           y218          0
 LI bnd           y219          0
 LI bnd           y220          0
 LI bnd           y221          0
 LI bnd           y222          0
 LI bnd           y223          0
 LI bnd           y224          0
 LI bnd           y225          0
 LI bnd           y226          0
 LI bnd           y227          0
 LI bnd           y228          0
 LI bnd           y229          0
 LI bnd           y230          0
 LI bnd           y231          0
 LI bnd           y232          0
 LI bnd           y233          0
 LI bnd           y234          0
 LI bnd           y235          0
 LI bnd           y236          0
 LI bnd           y237          0
 LI bnd           y238          0
 LI bnd           y239          0
 LI bnd           y240          0
 LI bnd           y241          0
 LI bnd           y242          0
 LI bnd           y243          0
 LI bnd           y244          0
 LI bnd           y245          0
 LI bnd           y246          0
 LI bnd           y247          0
 LI bnd           y248          0
 LI bnd           y249          0
 LI bnd           y250          0
 LI bnd           y251          0
 LI bnd           y252          0
 LI bnd           y253          0
 LI bnd           y254          0
 LI bnd           y255          0
 LI bnd           y256          0
 LI bnd           y257          0
 LI bnd           y258          0
 LI bnd           y259          0
 LI bnd           y260          0
 LI bnd           y261          0
 LI bnd           y262          0
 LI bnd           y263          0
 LI bnd           y264          0
 LI bnd           y265          0
 LI bnd           y266          0
 LI bnd           y267          0
 LI bnd           y268          0
 LI bnd           y269          0
 LI bnd           y270          0
 LI bnd           y271          0
 LI bnd           y272          0
 LI bnd           y273          0
 LI bnd           y274          0
 LI bnd           y275          0
 LI bnd           y276          0
 LI bnd           y277          0
 LI bnd           y278          0
 LI bnd           y279          0
 LI bnd           y280          0
 LI bnd           y281          0
 LI bnd           y282          0
 LI bnd           y283          0
 LI bnd           y284          0
 LI bnd           y285          0
 LI bnd           y286          0
 LI bnd           y287          0
 LI bnd           y288          0
 LI bnd           y289          0
 LI bnd           y290          0
 LI bnd           y291          0
 LI bnd           y292          0
 LI bnd           y293          0
 LI bnd           y294          0
 LI bnd           y295          0
 LI bnd           y296          0
 LI bnd           y297          0
 LI bnd           y298          0
 LI bnd           y299          0
 LI bnd           y300          0
 LI bnd           y301          0
 LI bnd           y302          0
 LI bnd           y303          0
 LI bnd           y304          0
 LI bnd           y305          0
 LI bnd           y306          0
 LI bnd           y307          0
 LI bnd           y308          0
 LI bnd           y309          0
 LI bnd           y310          0
 LI bnd           y311          0
 LI bnd           y312          0
 LI bnd           y313          0
 LI bnd           y314          0
 LI bnd           y315          0
 LI bnd           y316          0
 LI bnd           y317          0
 LI bnd           y318          0
 LI bnd           y319          0
 LI bnd           y320          0
 LI bnd           y321          0
 LI bnd           y322          0
 LI bnd           y323          0
 LI bnd           y324          0
 LI bnd           y325          0
 LI bnd           y326          0
 LI bnd           y327          0
 LI bnd           y328          0
 LI bnd           y329          0
 LI bnd           y330          0
 LI bnd           y331          0
 LI bnd           y332          0
 LI bnd           y333          0
 LI bnd           y334          0
 LI bnd           y335          0
 LI bnd           y336          0
 LI bnd           y337          0
 LI bnd           y338          0
 LI bnd           y339          0
 LI bnd           y340          0
 LI bnd           y341          0
 LI bnd           y342          0
 LI bnd           y343          0
 LI bnd           y344          0
 LI bnd           y345          0
 LI bnd           y346          0
 LI bnd           y347          0
 LI bnd           y348          0
 LI bnd           y349          0
 LI bnd           y350          0
 LI bnd           y351          0
 LI bnd           y352          0
 LI bnd           y353          0
 LI bnd           y354          0
 LI bnd           y355          0
 LI bnd           y356          0
 LI bnd           y357          0
 LI bnd           y358          0
 LI bnd           y359          0
 LI bnd           y360          0
 LI bnd           y361          0
 LI bnd           y362          0
 LI bnd           y363          0
 LI bnd           y364          0
 LI bnd           y365          0
 LI bnd           y366          0
 LI bnd           y367          0
 LI bnd           y368          0
 LI bnd           y369          0
 LI bnd           y370          0
 LI bnd           y371          0
 LI bnd           y372          0
 LI bnd           y373          0
 LI bnd           y374          0
 LI bnd           y375          0
 LI bnd           y376          0
 LI bnd           y377          0
 LI bnd           y378          0
 LI bnd           y379          0
 LI bnd           y380          0
 LI bnd           y381          0
 LI bnd           y382          0
 LI bnd           y383          0
 LI bnd           y384          0
 LI bnd           y385          0
 LI bnd           y386          0
 LI bnd           y387          0
 LI bnd           y388          0
 LI bnd           y389          0
 LI bnd           y390          0
 LI bnd           y391          0
 LI bnd           y392          0
 LI bnd           y393          0
 LI bnd           y394          0
 LI bnd           y395          0
 LI bnd           y396          0
 LI bnd           y397          0
 LI bnd           y398          0
 LI bnd           y399          0
ENDATA
