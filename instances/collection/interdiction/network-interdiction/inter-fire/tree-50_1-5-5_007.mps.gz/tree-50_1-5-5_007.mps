* ENCODING=ISO-8859-1
NAME          tree-50_1-5-5_007
ROWS
 N  obj     
 L  Phi     
 L  Lambda  
 L  V1      
 L  V2      
 L  V3      
 L  V4      
 L  V6      
 L  V7      
 L  V8      
 L  V9      
 L  V10     
 L  V11     
 L  V12     
 L  V13     
 L  V14     
 L  V15     
 L  V16     
 L  V17     
 L  V18     
 L  V19     
 L  V20     
 L  V21     
 L  V22     
 L  V23     
 L  V24     
 L  V25     
 L  V26     
 L  V27     
 L  V28     
 L  V29     
 L  V30     
 L  V31     
 L  V32     
 L  V33     
 L  V34     
 L  V35     
 L  V36     
 L  V37     
 L  V38     
 L  V39     
 L  V40     
 L  V41     
 L  V42     
 L  V43     
 L  V44     
 L  V45     
 L  V46     
 L  V47     
 L  V48     
 L  V49     
 L  V50     
 L  A2-1    
 L  A1-2    
 L  A3-2    
 L  A2-3    
 L  A4-1    
 L  A1-4    
 L  A7-4    
 L  A4-7    
 L  A8-3    
 L  A3-8    
 L  A9-7    
 L  A7-9    
 L  A10-7   
 L  A7-10   
 L  A11-10  
 L  A10-11  
 L  A12-10  
 L  A10-12  
 L  A13-10  
 L  A10-13  
 L  A14-13  
 L  A13-14  
 L  A16-4   
 L  A4-16   
 L  A17-6   
 L  A6-17   
 L  A18-6   
 L  A6-18   
 L  A19-9   
 L  A9-19   
 L  A20-16  
 L  A16-20  
 L  A21-1   
 L  A1-21   
 L  A22-11  
 L  A11-22  
 L  A23-22  
 L  A22-23  
 L  A24-7   
 L  A7-24   
 L  A25-2   
 L  A2-25   
 L  A26-8   
 L  A8-26   
 L  A27-20  
 L  A20-27  
 L  A28-9   
 L  A9-28   
 L  A29-20  
 L  A20-29  
 L  A31-4   
 L  A4-31   
 L  A32-3   
 L  A3-32   
 L  A33-17  
 L  A17-33  
 L  A34-30  
 L  A30-34  
 L  A35-16  
 L  A16-35  
 L  A36-15  
 L  A15-36  
 L  A37-33  
 L  A33-37  
 L  A38-36  
 L  A36-38  
 L  A39-7   
 L  A7-39   
 L  A40-11  
 L  A11-40  
 L  A41-31  
 L  A31-41  
 L  A42-24  
 L  A24-42  
 L  A43-11  
 L  A11-43  
 L  A44-4   
 L  A4-44   
 L  A45-17  
 L  A17-45  
 L  A46-21  
 L  A21-46  
 L  A47-35  
 L  A35-47  
 L  A48-36  
 L  A36-48  
 L  A49-16  
 L  A16-49  
 L  A50-6   
 L  A6-50   
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    a_1       obj                             1
    a_1       V1                              1
    a_1       A2-1                            1
    a_1       A1-2                           -1
    a_1       A4-1                            1
    a_1       A1-4                           -1
    a_1       A21-1                           1
    a_1       A1-21                          -1
    a_2       obj                             1
    a_2       V2                              1
    a_2       A2-1                           -1
    a_2       A1-2                            1
    a_2       A3-2                            1
    a_2       A2-3                           -1
    a_2       A25-2                           1
    a_2       A2-25                          -1
    a_3       obj                             1
    a_3       V3                              1
    a_3       A3-2                           -1
    a_3       A2-3                            1
    a_3       A8-3                            1
    a_3       A3-8                           -1
    a_3       A32-3                           1
    a_3       A3-32                          -1
    a_4       obj                             1
    a_4       V4                              1
    a_4       A4-1                           -1
    a_4       A1-4                            1
    a_4       A7-4                            1
    a_4       A4-7                           -1
    a_4       A16-4                           1
    a_4       A4-16                          -1
    a_4       A31-4                           1
    a_4       A4-31                          -1
    a_4       A44-4                           1
    a_4       A4-44                          -1
    a_6       obj                             1
    a_6       V6                              1
    a_6       A17-6                           1
    a_6       A6-17                          -1
    a_6       A18-6                           1
    a_6       A6-18                          -1
    a_6       A50-6                           1
    a_6       A6-50                          -1
    a_7       obj                             1
    a_7       V7                              1
    a_7       A7-4                           -1
    a_7       A4-7                            1
    a_7       A9-7                            1
    a_7       A7-9                           -1
    a_7       A10-7                           1
    a_7       A7-10                          -1
    a_7       A24-7                           1
    a_7       A7-24                          -1
    a_7       A39-7                           1
    a_7       A7-39                          -1
    a_8       obj                             1
    a_8       V8                              1
    a_8       A8-3                           -1
    a_8       A3-8                            1
    a_8       A26-8                           1
    a_8       A8-26                          -1
    a_9       obj                             1
    a_9       V9                              1
    a_9       A9-7                           -1
    a_9       A7-9                            1
    a_9       A19-9                           1
    a_9       A9-19                          -1
    a_9       A28-9                           1
    a_9       A9-28                          -1
    a_10      obj                             1
    a_10      V10                             1
    a_10      A10-7                          -1
    a_10      A7-10                           1
    a_10      A11-10                          1
    a_10      A10-11                         -1
    a_10      A12-10                          1
    a_10      A10-12                         -1
    a_10      A13-10                          1
    a_10      A10-13                         -1
    a_11      obj                             1
    a_11      V11                             1
    a_11      A11-10                         -1
    a_11      A10-11                          1
    a_11      A22-11                          1
    a_11      A11-22                         -1
    a_11      A40-11                          1
    a_11      A11-40                         -1
    a_11      A43-11                          1
    a_11      A11-43                         -1
    a_12      obj                             1
    a_12      V12                             1
    a_12      A12-10                         -1
    a_12      A10-12                          1
    a_13      obj                             1
    a_13      V13                             1
    a_13      A13-10                         -1
    a_13      A10-13                          1
    a_13      A14-13                          1
    a_13      A13-14                         -1
    a_14      obj                             1
    a_14      V14                             1
    a_14      A14-13                         -1
    a_14      A13-14                          1
    a_15      obj                             1
    a_15      V15                             1
    a_15      A36-15                          1
    a_15      A15-36                         -1
    a_16      obj                             1
    a_16      V16                             1
    a_16      A16-4                          -1
    a_16      A4-16                           1
    a_16      A20-16                          1
    a_16      A16-20                         -1
    a_16      A35-16                          1
    a_16      A16-35                         -1
    a_16      A49-16                          1
    a_16      A16-49                         -1
    a_17      obj                             1
    a_17      V17                             1
    a_17      A17-6                          -1
    a_17      A6-17                           1
    a_17      A33-17                          1
    a_17      A17-33                         -1
    a_17      A45-17                          1
    a_17      A17-45                         -1
    a_18      obj                             1
    a_18      V18                             1
    a_18      A18-6                          -1
    a_18      A6-18                           1
    a_19      obj                             1
    a_19      V19                             1
    a_19      A19-9                          -1
    a_19      A9-19                           1
    a_20      obj                             1
    a_20      V20                             1
    a_20      A20-16                         -1
    a_20      A16-20                          1
    a_20      A27-20                          1
    a_20      A20-27                         -1
    a_20      A29-20                          1
    a_20      A20-29                         -1
    a_21      obj                             1
    a_21      V21                             1
    a_21      A21-1                          -1
    a_21      A1-21                           1
    a_21      A46-21                          1
    a_21      A21-46                         -1
    a_22      obj                             1
    a_22      V22                             1
    a_22      A22-11                         -1
    a_22      A11-22                          1
    a_22      A23-22                          1
    a_22      A22-23                         -1
    a_23      obj                             1
    a_23      V23                             1
    a_23      A23-22                         -1
    a_23      A22-23                          1
    a_24      obj                             1
    a_24      V24                             1
    a_24      A24-7                          -1
    a_24      A7-24                           1
    a_24      A42-24                          1
    a_24      A24-42                         -1
    a_25      obj                             1
    a_25      V25                             1
    a_25      A25-2                          -1
    a_25      A2-25                           1
    a_26      obj                             1
    a_26      V26                             1
    a_26      A26-8                          -1
    a_26      A8-26                           1
    a_27      obj                             1
    a_27      V27                             1
    a_27      A27-20                         -1
    a_27      A20-27                          1
    a_28      obj                             1
    a_28      V28                             1
    a_28      A28-9                          -1
    a_28      A9-28                           1
    a_29      obj                             1
    a_29      V29                             1
    a_29      A29-20                         -1
    a_29      A20-29                          1
    a_30      obj                             1
    a_30      V30                             1
    a_30      A34-30                          1
    a_30      A30-34                         -1
    a_31      obj                             1
    a_31      V31                             1
    a_31      A31-4                          -1
    a_31      A4-31                           1
    a_31      A41-31                          1
    a_31      A31-41                         -1
    a_32      obj                             1
    a_32      V32                             1
    a_32      A32-3                          -1
    a_32      A3-32                           1
    a_33      obj                             1
    a_33      V33                             1
    a_33      A33-17                         -1
    a_33      A17-33                          1
    a_33      A37-33                          1
    a_33      A33-37                         -1
    a_34      obj                             1
    a_34      V34                             1
    a_34      A34-30                         -1
    a_34      A30-34                          1
    a_35      obj                             1
    a_35      V35                             1
    a_35      A35-16                         -1
    a_35      A16-35                          1
    a_35      A47-35                          1
    a_35      A35-47                         -1
    a_36      obj                             1
    a_36      V36                             1
    a_36      A36-15                         -1
    a_36      A15-36                          1
    a_36      A38-36                          1
    a_36      A36-38                         -1
    a_36      A48-36                          1
    a_36      A36-48                         -1
    a_37      obj                             1
    a_37      V37                             1
    a_37      A37-33                         -1
    a_37      A33-37                          1
    a_38      obj                             1
    a_38      V38                             1
    a_38      A38-36                         -1
    a_38      A36-38                          1
    a_39      obj                             1
    a_39      V39                             1
    a_39      A39-7                          -1
    a_39      A7-39                           1
    a_40      obj                             1
    a_40      V40                             1
    a_40      A40-11                         -1
    a_40      A11-40                          1
    a_41      obj                             1
    a_41      V41                             1
    a_41      A41-31                         -1
    a_41      A31-41                          1
    a_42      obj                             1
    a_42      V42                             1
    a_42      A42-24                         -1
    a_42      A24-42                          1
    a_43      obj                             1
    a_43      V43                             1
    a_43      A43-11                         -1
    a_43      A11-43                          1
    a_44      obj                             1
    a_44      V44                             1
    a_44      A44-4                          -1
    a_44      A4-44                           1
    a_45      obj                             1
    a_45      V45                             1
    a_45      A45-17                         -1
    a_45      A17-45                          1
    a_46      obj                             1
    a_46      V46                             1
    a_46      A46-21                         -1
    a_46      A21-46                          1
    a_47      obj                             1
    a_47      V47                             1
    a_47      A47-35                         -1
    a_47      A35-47                          1
    a_48      obj                             1
    a_48      V48                             1
    a_48      A48-36                         -1
    a_48      A36-48                          1
    a_49      obj                             1
    a_49      V49                             1
    a_49      A49-16                         -1
    a_49      A16-49                          1
    a_50      obj                             1
    a_50      V50                             1
    a_50      A50-6                          -1
    a_50      A6-50                           1
    y_1       Phi                             1
    y_1       V1                              1
    y_2       Phi                             1
    y_2       V2                              1
    y_3       Phi                             1
    y_3       V3                              1
    y_4       Phi                             1
    y_4       V4                              1
    y_6       Phi                             1
    y_6       V6                              1
    y_7       Phi                             1
    y_7       V7                              1
    y_8       Phi                             1
    y_8       V8                              1
    y_9       Phi                             1
    y_9       V9                              1
    y_10      Phi                             1
    y_10      V10                             1
    y_11      Phi                             1
    y_11      V11                             1
    y_12      Phi                             1
    y_12      V12                             1
    y_13      Phi                             1
    y_13      V13                             1
    y_14      Phi                             1
    y_14      V14                             1
    y_15      Phi                             1
    y_15      V15                             1
    y_16      Phi                             1
    y_16      V16                             1
    y_17      Phi                             1
    y_17      V17                             1
    y_18      Phi                             1
    y_18      V18                             1
    y_19      Phi                             1
    y_19      V19                             1
    y_20      Phi                             1
    y_20      V20                             1
    y_21      Phi                             1
    y_21      V21                             1
    y_22      Phi                             1
    y_22      V22                             1
    y_23      Phi                             1
    y_23      V23                             1
    y_24      Phi                             1
    y_24      V24                             1
    y_25      Phi                             1
    y_25      V25                             1
    y_26      Phi                             1
    y_26      V26                             1
    y_27      Phi                             1
    y_27      V27                             1
    y_28      Phi                             1
    y_28      V28                             1
    y_29      Phi                             1
    y_29      V29                             1
    y_30      Phi                             1
    y_30      V30                             1
    y_31      Phi                             1
    y_31      V31                             1
    y_32      Phi                             1
    y_32      V32                             1
    y_33      Phi                             1
    y_33      V33                             1
    y_34      Phi                             1
    y_34      V34                             1
    y_35      Phi                             1
    y_35      V35                             1
    y_36      Phi                             1
    y_36      V36                             1
    y_37      Phi                             1
    y_37      V37                             1
    y_38      Phi                             1
    y_38      V38                             1
    y_39      Phi                             1
    y_39      V39                             1
    y_40      Phi                             1
    y_40      V40                             1
    y_41      Phi                             1
    y_41      V41                             1
    y_42      Phi                             1
    y_42      V42                             1
    y_43      Phi                             1
    y_43      V43                             1
    y_44      Phi                             1
    y_44      V44                             1
    y_45      Phi                             1
    y_45      V45                             1
    y_46      Phi                             1
    y_46      V46                             1
    y_47      Phi                             1
    y_47      V47                             1
    y_48      Phi                             1
    y_48      V48                             1
    y_49      Phi                             1
    y_49      V49                             1
    y_50      Phi                             1
    y_50      V50                             1
    x_1       Lambda                          1
    x_1       A2-1                           -1
    x_1       A4-1                           -1
    x_1       A21-1                          -1
    x_2       Lambda                          1
    x_2       A1-2                           -1
    x_2       A3-2                           -1
    x_2       A25-2                          -1
    x_3       Lambda                          1
    x_3       A2-3                           -1
    x_3       A8-3                           -1
    x_3       A32-3                          -1
    x_4       Lambda                          1
    x_4       A1-4                           -1
    x_4       A7-4                           -1
    x_4       A16-4                          -1
    x_4       A31-4                          -1
    x_4       A44-4                          -1
    x_6       Lambda                          1
    x_6       A17-6                          -1
    x_6       A18-6                          -1
    x_6       A50-6                          -1
    x_7       Lambda                          1
    x_7       A4-7                           -1
    x_7       A9-7                           -1
    x_7       A10-7                          -1
    x_7       A24-7                          -1
    x_7       A39-7                          -1
    x_8       Lambda                          1
    x_8       A3-8                           -1
    x_8       A26-8                          -1
    x_9       Lambda                          1
    x_9       A7-9                           -1
    x_9       A19-9                          -1
    x_9       A28-9                          -1
    x_10      Lambda                          1
    x_10      A7-10                          -1
    x_10      A11-10                         -1
    x_10      A12-10                         -1
    x_10      A13-10                         -1
    x_11      Lambda                          1
    x_11      A10-11                         -1
    x_11      A22-11                         -1
    x_11      A40-11                         -1
    x_11      A43-11                         -1
    x_12      Lambda                          1
    x_12      A10-12                         -1
    x_13      Lambda                          1
    x_13      A10-13                         -1
    x_13      A14-13                         -1
    x_14      Lambda                          1
    x_14      A13-14                         -1
    x_15      Lambda                          1
    x_15      A36-15                         -1
    x_16      Lambda                          1
    x_16      A4-16                          -1
    x_16      A20-16                         -1
    x_16      A35-16                         -1
    x_16      A49-16                         -1
    x_17      Lambda                          1
    x_17      A6-17                          -1
    x_17      A33-17                         -1
    x_17      A45-17                         -1
    x_18      Lambda                          1
    x_18      A6-18                          -1
    x_19      Lambda                          1
    x_19      A9-19                          -1
    x_20      Lambda                          1
    x_20      A16-20                         -1
    x_20      A27-20                         -1
    x_20      A29-20                         -1
    x_21      Lambda                          1
    x_21      A1-21                          -1
    x_21      A46-21                         -1
    x_22      Lambda                          1
    x_22      A11-22                         -1
    x_22      A23-22                         -1
    x_23      Lambda                          1
    x_23      A22-23                         -1
    x_24      Lambda                          1
    x_24      A7-24                          -1
    x_24      A42-24                         -1
    x_25      Lambda                          1
    x_25      A2-25                          -1
    x_26      Lambda                          1
    x_26      A8-26                          -1
    x_27      Lambda                          1
    x_27      A20-27                         -1
    x_28      Lambda                          1
    x_28      A9-28                          -1
    x_29      Lambda                          1
    x_29      A20-29                         -1
    x_30      Lambda                          1
    x_30      A34-30                         -1
    x_31      Lambda                          1
    x_31      A4-31                          -1
    x_31      A41-31                         -1
    x_32      Lambda                          1
    x_32      A3-32                          -1
    x_33      Lambda                          1
    x_33      A17-33                         -1
    x_33      A37-33                         -1
    x_34      Lambda                          1
    x_34      A30-34                         -1
    x_35      Lambda                          1
    x_35      A16-35                         -1
    x_35      A47-35                         -1
    x_36      Lambda                          1
    x_36      A15-36                         -1
    x_36      A38-36                         -1
    x_36      A48-36                         -1
    x_37      Lambda                          1
    x_37      A33-37                         -1
    x_38      Lambda                          1
    x_38      A36-38                         -1
    x_39      Lambda                          1
    x_39      A7-39                          -1
    x_40      Lambda                          1
    x_40      A11-40                         -1
    x_41      Lambda                          1
    x_41      A31-41                         -1
    x_42      Lambda                          1
    x_42      A24-42                         -1
    x_43      Lambda                          1
    x_43      A11-43                         -1
    x_44      Lambda                          1
    x_44      A4-44                          -1
    x_45      Lambda                          1
    x_45      A17-45                         -1
    x_46      Lambda                          1
    x_46      A21-46                         -1
    x_47      Lambda                          1
    x_47      A35-47                         -1
    x_48      Lambda                          1
    x_48      A36-48                         -1
    x_49      Lambda                          1
    x_49      A16-49                         -1
    x_50      Lambda                          1
    x_50      A6-50                          -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       Phi                             5
    rhs       Lambda                          5
    rhs       V1                              1
    rhs       V2                              1
    rhs       V3                              1
    rhs       V4                              1
    rhs       V6                              1
    rhs       V7                              1
    rhs       V8                              1
    rhs       V9                              1
    rhs       V10                             1
    rhs       V11                             1
    rhs       V12                             1
    rhs       V13                             1
    rhs       V14                             1
    rhs       V15                             1
    rhs       V16                             1
    rhs       V17                             1
    rhs       V18                             1
    rhs       V19                             1
    rhs       V20                             1
    rhs       V21                             1
    rhs       V22                             1
    rhs       V23                             1
    rhs       V24                             1
    rhs       V25                             1
    rhs       V26                             1
    rhs       V27                             1
    rhs       V28                             1
    rhs       V29                             1
    rhs       V30                             1
    rhs       V31                             1
    rhs       V32                             1
    rhs       V33                             1
    rhs       V34                             1
    rhs       V35                             1
    rhs       V36                             1
    rhs       V37                             1
    rhs       V38                             1
    rhs       V39                             1
    rhs       V40                             1
    rhs       V41                             1
    rhs       V42                             1
    rhs       V43                             1
    rhs       V44                             1
    rhs       V45                             1
    rhs       V46                             1
    rhs       V47                             1
    rhs       V48                             1
    rhs       V49                             1
    rhs       V50                             1
BOUNDS
 BV bnd       a_1     
 BV bnd       a_2     
 BV bnd       a_3     
 BV bnd       a_4     
 BV bnd       a_6     
 BV bnd       a_7     
 BV bnd       a_8     
 BV bnd       a_9     
 BV bnd       a_10    
 BV bnd       a_11    
 BV bnd       a_12    
 BV bnd       a_13    
 BV bnd       a_14    
 BV bnd       a_15    
 BV bnd       a_16    
 BV bnd       a_17    
 BV bnd       a_18    
 BV bnd       a_19    
 BV bnd       a_20    
 BV bnd       a_21    
 BV bnd       a_22    
 BV bnd       a_23    
 BV bnd       a_24    
 BV bnd       a_25    
 BV bnd       a_26    
 BV bnd       a_27    
 BV bnd       a_28    
 BV bnd       a_29    
 BV bnd       a_30    
 BV bnd       a_31    
 BV bnd       a_32    
 BV bnd       a_33    
 BV bnd       a_34    
 BV bnd       a_35    
 BV bnd       a_36    
 BV bnd       a_37    
 BV bnd       a_38    
 BV bnd       a_39    
 BV bnd       a_40    
 BV bnd       a_41    
 BV bnd       a_42    
 BV bnd       a_43    
 BV bnd       a_44    
 BV bnd       a_45    
 BV bnd       a_46    
 BV bnd       a_47    
 BV bnd       a_48    
 BV bnd       a_49    
 BV bnd       a_50    
 BV bnd       y_1     
 BV bnd       y_2     
 BV bnd       y_3     
 BV bnd       y_4     
 BV bnd       y_6     
 BV bnd       y_7     
 BV bnd       y_8     
 BV bnd       y_9     
 BV bnd       y_10    
 BV bnd       y_11    
 BV bnd       y_12    
 BV bnd       y_13    
 BV bnd       y_14    
 BV bnd       y_15    
 BV bnd       y_16    
 BV bnd       y_17    
 BV bnd       y_18    
 BV bnd       y_19    
 BV bnd       y_20    
 BV bnd       y_21    
 BV bnd       y_22    
 BV bnd       y_23    
 BV bnd       y_24    
 BV bnd       y_25    
 BV bnd       y_26    
 BV bnd       y_27    
 BV bnd       y_28    
 BV bnd       y_29    
 BV bnd       y_30    
 BV bnd       y_31    
 BV bnd       y_32    
 BV bnd       y_33    
 BV bnd       y_34    
 BV bnd       y_35    
 BV bnd       y_36    
 BV bnd       y_37    
 BV bnd       y_38    
 BV bnd       y_39    
 BV bnd       y_40    
 BV bnd       y_41    
 BV bnd       y_42    
 BV bnd       y_43    
 BV bnd       y_44    
 BV bnd       y_45    
 BV bnd       y_46    
 BV bnd       y_47    
 BV bnd       y_48    
 BV bnd       y_49    
 BV bnd       y_50    
 BV bnd       x_1     
 BV bnd       x_2     
 BV bnd       x_3     
 BV bnd       x_4     
 BV bnd       x_6     
 BV bnd       x_7     
 BV bnd       x_8     
 BV bnd       x_9     
 BV bnd       x_10    
 BV bnd       x_11    
 BV bnd       x_12    
 BV bnd       x_13    
 BV bnd       x_14    
 BV bnd       x_15    
 BV bnd       x_16    
 BV bnd       x_17    
 BV bnd       x_18    
 BV bnd       x_19    
 BV bnd       x_20    
 BV bnd       x_21    
 BV bnd       x_22    
 BV bnd       x_23    
 BV bnd       x_24    
 BV bnd       x_25    
 BV bnd       x_26    
 BV bnd       x_27    
 BV bnd       x_28    
 BV bnd       x_29    
 BV bnd       x_30    
 BV bnd       x_31    
 BV bnd       x_32    
 BV bnd       x_33    
 BV bnd       x_34    
 BV bnd       x_35    
 BV bnd       x_36    
 BV bnd       x_37    
 BV bnd       x_38    
 BV bnd       x_39    
 BV bnd       x_40    
 BV bnd       x_41    
 BV bnd       x_42    
 BV bnd       x_43    
 BV bnd       x_44    
 BV bnd       x_45    
 BV bnd       x_46    
 BV bnd       x_47    
 BV bnd       x_48    
 BV bnd       x_49    
 BV bnd       x_50    
ENDATA
