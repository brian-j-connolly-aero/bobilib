* ENCODING=ISO-8859-1
NAME          tree-80_3-3-1_005
ROWS
 N  obj     
 L  Phi     
 L  Lambda  
 L  V1      
 L  V3      
 L  V4      
 L  V5      
 L  V8      
 L  V9      
 L  V10     
 L  V11     
 L  V12     
 L  V13     
 L  V14     
 L  V15     
 L  V16     
 L  V17     
 L  V18     
 L  V19     
 L  V20     
 L  V21     
 L  V22     
 L  V23     
 L  V24     
 L  V25     
 L  V26     
 L  V27     
 L  V28     
 L  V29     
 L  V30     
 L  V31     
 L  V32     
 L  V33     
 L  V34     
 L  V35     
 L  V36     
 L  V37     
 L  V38     
 L  V39     
 L  V40     
 L  V41     
 L  V42     
 L  V43     
 L  V44     
 L  V45     
 L  V46     
 L  V47     
 L  V48     
 L  V49     
 L  V50     
 L  V51     
 L  V52     
 L  V53     
 L  V54     
 L  V55     
 L  V56     
 L  V57     
 L  V58     
 L  V59     
 L  V60     
 L  V61     
 L  V62     
 L  V63     
 L  V64     
 L  V65     
 L  V66     
 L  V67     
 L  V68     
 L  V69     
 L  V70     
 L  V71     
 L  V72     
 L  V73     
 L  V74     
 L  V75     
 L  V76     
 L  V77     
 L  V78     
 L  V79     
 L  V80     
 L  A4-1    
 L  A1-4    
 L  A10-4   
 L  A4-10   
 L  A11-3   
 L  A3-11   
 L  A15-14  
 L  A14-15  
 L  A17-14  
 L  A14-17  
 L  A18-12  
 L  A12-18  
 L  A19-1   
 L  A1-19   
 L  A21-15  
 L  A15-21  
 L  A22-3   
 L  A3-22   
 L  A24-5   
 L  A5-24   
 L  A25-9   
 L  A9-25   
 L  A26-5   
 L  A5-26   
 L  A27-23  
 L  A23-27  
 L  A28-18  
 L  A18-28  
 L  A29-15  
 L  A15-29  
 L  A30-28  
 L  A28-30  
 L  A31-19  
 L  A19-31  
 L  A32-19  
 L  A19-32  
 L  A33-3   
 L  A3-33   
 L  A34-12  
 L  A12-34  
 L  A35-18  
 L  A18-35  
 L  A36-23  
 L  A23-36  
 L  A37-25  
 L  A25-37  
 L  A38-3   
 L  A3-38   
 L  A39-34  
 L  A34-39  
 L  A40-38  
 L  A38-40  
 L  A41-15  
 L  A15-41  
 L  A42-34  
 L  A34-42  
 L  A43-3   
 L  A3-43   
 L  A44-29  
 L  A29-44  
 L  A45-10  
 L  A10-45  
 L  A46-20  
 L  A20-46  
 L  A47-46  
 L  A46-47  
 L  A48-40  
 L  A40-48  
 L  A49-39  
 L  A39-49  
 L  A50-38  
 L  A38-50  
 L  A51-13  
 L  A13-51  
 L  A52-35  
 L  A35-52  
 L  A53-37  
 L  A37-53  
 L  A54-19  
 L  A19-54  
 L  A55-42  
 L  A42-55  
 L  A56-24  
 L  A24-56  
 L  A57-4   
 L  A4-57   
 L  A58-13  
 L  A13-58  
 L  A59-8   
 L  A8-59   
 L  A60-52  
 L  A52-60  
 L  A61-59  
 L  A59-61  
 L  A62-52  
 L  A52-62  
 L  A63-24  
 L  A24-63  
 L  A64-5   
 L  A5-64   
 L  A65-29  
 L  A29-65  
 L  A66-63  
 L  A63-66  
 L  A67-35  
 L  A35-67  
 L  A68-39  
 L  A39-68  
 L  A69-5   
 L  A5-69   
 L  A70-53  
 L  A53-70  
 L  A71-46  
 L  A46-71  
 L  A72-66  
 L  A66-72  
 L  A73-23  
 L  A23-73  
 L  A74-64  
 L  A64-74  
 L  A75-46  
 L  A46-75  
 L  A76-20  
 L  A20-76  
 L  A77-45  
 L  A45-77  
 L  A78-63  
 L  A63-78  
 L  A79-55  
 L  A55-79  
 L  A80-29  
 L  A29-80  
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    a_1       obj                             1
    a_1       V1                              1
    a_1       A4-1                            1
    a_1       A1-4                           -1
    a_1       A19-1                           1
    a_1       A1-19                          -1
    a_3       obj                             1
    a_3       V3                              1
    a_3       A11-3                           1
    a_3       A3-11                          -1
    a_3       A22-3                           1
    a_3       A3-22                          -1
    a_3       A33-3                           1
    a_3       A3-33                          -1
    a_3       A38-3                           1
    a_3       A3-38                          -1
    a_3       A43-3                           1
    a_3       A3-43                          -1
    a_4       obj                             1
    a_4       V4                              1
    a_4       A4-1                           -1
    a_4       A1-4                            1
    a_4       A10-4                           1
    a_4       A4-10                          -1
    a_4       A57-4                           1
    a_4       A4-57                          -1
    a_5       obj                             1
    a_5       V5                              1
    a_5       A24-5                           1
    a_5       A5-24                          -1
    a_5       A26-5                           1
    a_5       A5-26                          -1
    a_5       A64-5                           1
    a_5       A5-64                          -1
    a_5       A69-5                           1
    a_5       A5-69                          -1
    a_8       obj                             1
    a_8       V8                              1
    a_8       A59-8                           1
    a_8       A8-59                          -1
    a_9       obj                             1
    a_9       V9                              1
    a_9       A25-9                           1
    a_9       A9-25                          -1
    a_10      obj                             1
    a_10      V10                             1
    a_10      A10-4                          -1
    a_10      A4-10                           1
    a_10      A45-10                          1
    a_10      A10-45                         -1
    a_11      obj                             1
    a_11      V11                             1
    a_11      A11-3                          -1
    a_11      A3-11                           1
    a_12      obj                             1
    a_12      V12                             1
    a_12      A18-12                          1
    a_12      A12-18                         -1
    a_12      A34-12                          1
    a_12      A12-34                         -1
    a_13      obj                             1
    a_13      V13                             1
    a_13      A51-13                          1
    a_13      A13-51                         -1
    a_13      A58-13                          1
    a_13      A13-58                         -1
    a_14      obj                             1
    a_14      V14                             1
    a_14      A15-14                          1
    a_14      A14-15                         -1
    a_14      A17-14                          1
    a_14      A14-17                         -1
    a_15      obj                             1
    a_15      V15                             1
    a_15      A15-14                         -1
    a_15      A14-15                          1
    a_15      A21-15                          1
    a_15      A15-21                         -1
    a_15      A29-15                          1
    a_15      A15-29                         -1
    a_15      A41-15                          1
    a_15      A15-41                         -1
    a_16      obj                             1
    a_16      V16                             1
    a_17      obj                             1
    a_17      V17                             1
    a_17      A17-14                         -1
    a_17      A14-17                          1
    a_18      obj                             1
    a_18      V18                             1
    a_18      A18-12                         -1
    a_18      A12-18                          1
    a_18      A28-18                          1
    a_18      A18-28                         -1
    a_18      A35-18                          1
    a_18      A18-35                         -1
    a_19      obj                             1
    a_19      V19                             1
    a_19      A19-1                          -1
    a_19      A1-19                           1
    a_19      A31-19                          1
    a_19      A19-31                         -1
    a_19      A32-19                          1
    a_19      A19-32                         -1
    a_19      A54-19                          1
    a_19      A19-54                         -1
    a_20      obj                             1
    a_20      V20                             1
    a_20      A46-20                          1
    a_20      A20-46                         -1
    a_20      A76-20                          1
    a_20      A20-76                         -1
    a_21      obj                             1
    a_21      V21                             1
    a_21      A21-15                         -1
    a_21      A15-21                          1
    a_22      obj                             1
    a_22      V22                             1
    a_22      A22-3                          -1
    a_22      A3-22                           1
    a_23      obj                             1
    a_23      V23                             1
    a_23      A27-23                          1
    a_23      A23-27                         -1
    a_23      A36-23                          1
    a_23      A23-36                         -1
    a_23      A73-23                          1
    a_23      A23-73                         -1
    a_24      obj                             1
    a_24      V24                             1
    a_24      A24-5                          -1
    a_24      A5-24                           1
    a_24      A56-24                          1
    a_24      A24-56                         -1
    a_24      A63-24                          1
    a_24      A24-63                         -1
    a_25      obj                             1
    a_25      V25                             1
    a_25      A25-9                          -1
    a_25      A9-25                           1
    a_25      A37-25                          1
    a_25      A25-37                         -1
    a_26      obj                             1
    a_26      V26                             1
    a_26      A26-5                          -1
    a_26      A5-26                           1
    a_27      obj                             1
    a_27      V27                             1
    a_27      A27-23                         -1
    a_27      A23-27                          1
    a_28      obj                             1
    a_28      V28                             1
    a_28      A28-18                         -1
    a_28      A18-28                          1
    a_28      A30-28                          1
    a_28      A28-30                         -1
    a_29      obj                             1
    a_29      V29                             1
    a_29      A29-15                         -1
    a_29      A15-29                          1
    a_29      A44-29                          1
    a_29      A29-44                         -1
    a_29      A65-29                          1
    a_29      A29-65                         -1
    a_29      A80-29                          1
    a_29      A29-80                         -1
    a_30      obj                             1
    a_30      V30                             1
    a_30      A30-28                         -1
    a_30      A28-30                          1
    a_31      obj                             1
    a_31      V31                             1
    a_31      A31-19                         -1
    a_31      A19-31                          1
    a_32      obj                             1
    a_32      V32                             1
    a_32      A32-19                         -1
    a_32      A19-32                          1
    a_33      obj                             1
    a_33      V33                             1
    a_33      A33-3                          -1
    a_33      A3-33                           1
    a_34      obj                             1
    a_34      V34                             1
    a_34      A34-12                         -1
    a_34      A12-34                          1
    a_34      A39-34                          1
    a_34      A34-39                         -1
    a_34      A42-34                          1
    a_34      A34-42                         -1
    a_35      obj                             1
    a_35      V35                             1
    a_35      A35-18                         -1
    a_35      A18-35                          1
    a_35      A52-35                          1
    a_35      A35-52                         -1
    a_35      A67-35                          1
    a_35      A35-67                         -1
    a_36      obj                             1
    a_36      V36                             1
    a_36      A36-23                         -1
    a_36      A23-36                          1
    a_37      obj                             1
    a_37      V37                             1
    a_37      A37-25                         -1
    a_37      A25-37                          1
    a_37      A53-37                          1
    a_37      A37-53                         -1
    a_38      obj                             1
    a_38      V38                             1
    a_38      A38-3                          -1
    a_38      A3-38                           1
    a_38      A40-38                          1
    a_38      A38-40                         -1
    a_38      A50-38                          1
    a_38      A38-50                         -1
    a_39      obj                             1
    a_39      V39                             1
    a_39      A39-34                         -1
    a_39      A34-39                          1
    a_39      A49-39                          1
    a_39      A39-49                         -1
    a_39      A68-39                          1
    a_39      A39-68                         -1
    a_40      obj                             1
    a_40      V40                             1
    a_40      A40-38                         -1
    a_40      A38-40                          1
    a_40      A48-40                          1
    a_40      A40-48                         -1
    a_41      obj                             1
    a_41      V41                             1
    a_41      A41-15                         -1
    a_41      A15-41                          1
    a_42      obj                             1
    a_42      V42                             1
    a_42      A42-34                         -1
    a_42      A34-42                          1
    a_42      A55-42                          1
    a_42      A42-55                         -1
    a_43      obj                             1
    a_43      V43                             1
    a_43      A43-3                          -1
    a_43      A3-43                           1
    a_44      obj                             1
    a_44      V44                             1
    a_44      A44-29                         -1
    a_44      A29-44                          1
    a_45      obj                             1
    a_45      V45                             1
    a_45      A45-10                         -1
    a_45      A10-45                          1
    a_45      A77-45                          1
    a_45      A45-77                         -1
    a_46      obj                             1
    a_46      V46                             1
    a_46      A46-20                         -1
    a_46      A20-46                          1
    a_46      A47-46                          1
    a_46      A46-47                         -1
    a_46      A71-46                          1
    a_46      A46-71                         -1
    a_46      A75-46                          1
    a_46      A46-75                         -1
    a_47      obj                             1
    a_47      V47                             1
    a_47      A47-46                         -1
    a_47      A46-47                          1
    a_48      obj                             1
    a_48      V48                             1
    a_48      A48-40                         -1
    a_48      A40-48                          1
    a_49      obj                             1
    a_49      V49                             1
    a_49      A49-39                         -1
    a_49      A39-49                          1
    a_50      obj                             1
    a_50      V50                             1
    a_50      A50-38                         -1
    a_50      A38-50                          1
    a_51      obj                             1
    a_51      V51                             1
    a_51      A51-13                         -1
    a_51      A13-51                          1
    a_52      obj                             1
    a_52      V52                             1
    a_52      A52-35                         -1
    a_52      A35-52                          1
    a_52      A60-52                          1
    a_52      A52-60                         -1
    a_52      A62-52                          1
    a_52      A52-62                         -1
    a_53      obj                             1
    a_53      V53                             1
    a_53      A53-37                         -1
    a_53      A37-53                          1
    a_53      A70-53                          1
    a_53      A53-70                         -1
    a_54      obj                             1
    a_54      V54                             1
    a_54      A54-19                         -1
    a_54      A19-54                          1
    a_55      obj                             1
    a_55      V55                             1
    a_55      A55-42                         -1
    a_55      A42-55                          1
    a_55      A79-55                          1
    a_55      A55-79                         -1
    a_56      obj                             1
    a_56      V56                             1
    a_56      A56-24                         -1
    a_56      A24-56                          1
    a_57      obj                             1
    a_57      V57                             1
    a_57      A57-4                          -1
    a_57      A4-57                           1
    a_58      obj                             1
    a_58      V58                             1
    a_58      A58-13                         -1
    a_58      A13-58                          1
    a_59      obj                             1
    a_59      V59                             1
    a_59      A59-8                          -1
    a_59      A8-59                           1
    a_59      A61-59                          1
    a_59      A59-61                         -1
    a_60      obj                             1
    a_60      V60                             1
    a_60      A60-52                         -1
    a_60      A52-60                          1
    a_61      obj                             1
    a_61      V61                             1
    a_61      A61-59                         -1
    a_61      A59-61                          1
    a_62      obj                             1
    a_62      V62                             1
    a_62      A62-52                         -1
    a_62      A52-62                          1
    a_63      obj                             1
    a_63      V63                             1
    a_63      A63-24                         -1
    a_63      A24-63                          1
    a_63      A66-63                          1
    a_63      A63-66                         -1
    a_63      A78-63                          1
    a_63      A63-78                         -1
    a_64      obj                             1
    a_64      V64                             1
    a_64      A64-5                          -1
    a_64      A5-64                           1
    a_64      A74-64                          1
    a_64      A64-74                         -1
    a_65      obj                             1
    a_65      V65                             1
    a_65      A65-29                         -1
    a_65      A29-65                          1
    a_66      obj                             1
    a_66      V66                             1
    a_66      A66-63                         -1
    a_66      A63-66                          1
    a_66      A72-66                          1
    a_66      A66-72                         -1
    a_67      obj                             1
    a_67      V67                             1
    a_67      A67-35                         -1
    a_67      A35-67                          1
    a_68      obj                             1
    a_68      V68                             1
    a_68      A68-39                         -1
    a_68      A39-68                          1
    a_69      obj                             1
    a_69      V69                             1
    a_69      A69-5                          -1
    a_69      A5-69                           1
    a_70      obj                             1
    a_70      V70                             1
    a_70      A70-53                         -1
    a_70      A53-70                          1
    a_71      obj                             1
    a_71      V71                             1
    a_71      A71-46                         -1
    a_71      A46-71                          1
    a_72      obj                             1
    a_72      V72                             1
    a_72      A72-66                         -1
    a_72      A66-72                          1
    a_73      obj                             1
    a_73      V73                             1
    a_73      A73-23                         -1
    a_73      A23-73                          1
    a_74      obj                             1
    a_74      V74                             1
    a_74      A74-64                         -1
    a_74      A64-74                          1
    a_75      obj                             1
    a_75      V75                             1
    a_75      A75-46                         -1
    a_75      A46-75                          1
    a_76      obj                             1
    a_76      V76                             1
    a_76      A76-20                         -1
    a_76      A20-76                          1
    a_77      obj                             1
    a_77      V77                             1
    a_77      A77-45                         -1
    a_77      A45-77                          1
    a_78      obj                             1
    a_78      V78                             1
    a_78      A78-63                         -1
    a_78      A63-78                          1
    a_79      obj                             1
    a_79      V79                             1
    a_79      A79-55                         -1
    a_79      A55-79                          1
    a_80      obj                             1
    a_80      V80                             1
    a_80      A80-29                         -1
    a_80      A29-80                          1
    y_1       Phi                             1
    y_1       V1                              1
    y_3       Phi                             1
    y_3       V3                              1
    y_4       Phi                             1
    y_4       V4                              1
    y_5       Phi                             1
    y_5       V5                              1
    y_8       Phi                             1
    y_8       V8                              1
    y_9       Phi                             1
    y_9       V9                              1
    y_10      Phi                             1
    y_10      V10                             1
    y_11      Phi                             1
    y_11      V11                             1
    y_12      Phi                             1
    y_12      V12                             1
    y_13      Phi                             1
    y_13      V13                             1
    y_14      Phi                             1
    y_14      V14                             1
    y_15      Phi                             1
    y_15      V15                             1
    y_16      Phi                             1
    y_16      V16                             1
    y_17      Phi                             1
    y_17      V17                             1
    y_18      Phi                             1
    y_18      V18                             1
    y_19      Phi                             1
    y_19      V19                             1
    y_20      Phi                             1
    y_20      V20                             1
    y_21      Phi                             1
    y_21      V21                             1
    y_22      Phi                             1
    y_22      V22                             1
    y_23      Phi                             1
    y_23      V23                             1
    y_24      Phi                             1
    y_24      V24                             1
    y_25      Phi                             1
    y_25      V25                             1
    y_26      Phi                             1
    y_26      V26                             1
    y_27      Phi                             1
    y_27      V27                             1
    y_28      Phi                             1
    y_28      V28                             1
    y_29      Phi                             1
    y_29      V29                             1
    y_30      Phi                             1
    y_30      V30                             1
    y_31      Phi                             1
    y_31      V31                             1
    y_32      Phi                             1
    y_32      V32                             1
    y_33      Phi                             1
    y_33      V33                             1
    y_34      Phi                             1
    y_34      V34                             1
    y_35      Phi                             1
    y_35      V35                             1
    y_36      Phi                             1
    y_36      V36                             1
    y_37      Phi                             1
    y_37      V37                             1
    y_38      Phi                             1
    y_38      V38                             1
    y_39      Phi                             1
    y_39      V39                             1
    y_40      Phi                             1
    y_40      V40                             1
    y_41      Phi                             1
    y_41      V41                             1
    y_42      Phi                             1
    y_42      V42                             1
    y_43      Phi                             1
    y_43      V43                             1
    y_44      Phi                             1
    y_44      V44                             1
    y_45      Phi                             1
    y_45      V45                             1
    y_46      Phi                             1
    y_46      V46                             1
    y_47      Phi                             1
    y_47      V47                             1
    y_48      Phi                             1
    y_48      V48                             1
    y_49      Phi                             1
    y_49      V49                             1
    y_50      Phi                             1
    y_50      V50                             1
    y_51      Phi                             1
    y_51      V51                             1
    y_52      Phi                             1
    y_52      V52                             1
    y_53      Phi                             1
    y_53      V53                             1
    y_54      Phi                             1
    y_54      V54                             1
    y_55      Phi                             1
    y_55      V55                             1
    y_56      Phi                             1
    y_56      V56                             1
    y_57      Phi                             1
    y_57      V57                             1
    y_58      Phi                             1
    y_58      V58                             1
    y_59      Phi                             1
    y_59      V59                             1
    y_60      Phi                             1
    y_60      V60                             1
    y_61      Phi                             1
    y_61      V61                             1
    y_62      Phi                             1
    y_62      V62                             1
    y_63      Phi                             1
    y_63      V63                             1
    y_64      Phi                             1
    y_64      V64                             1
    y_65      Phi                             1
    y_65      V65                             1
    y_66      Phi                             1
    y_66      V66                             1
    y_67      Phi                             1
    y_67      V67                             1
    y_68      Phi                             1
    y_68      V68                             1
    y_69      Phi                             1
    y_69      V69                             1
    y_70      Phi                             1
    y_70      V70                             1
    y_71      Phi                             1
    y_71      V71                             1
    y_72      Phi                             1
    y_72      V72                             1
    y_73      Phi                             1
    y_73      V73                             1
    y_74      Phi                             1
    y_74      V74                             1
    y_75      Phi                             1
    y_75      V75                             1
    y_76      Phi                             1
    y_76      V76                             1
    y_77      Phi                             1
    y_77      V77                             1
    y_78      Phi                             1
    y_78      V78                             1
    y_79      Phi                             1
    y_79      V79                             1
    y_80      Phi                             1
    y_80      V80                             1
    x_1       Lambda                          1
    x_1       A4-1                           -1
    x_1       A19-1                          -1
    x_3       Lambda                          1
    x_3       A11-3                          -1
    x_3       A22-3                          -1
    x_3       A33-3                          -1
    x_3       A38-3                          -1
    x_3       A43-3                          -1
    x_4       Lambda                          1
    x_4       A1-4                           -1
    x_4       A10-4                          -1
    x_4       A57-4                          -1
    x_5       Lambda                          1
    x_5       A24-5                          -1
    x_5       A26-5                          -1
    x_5       A64-5                          -1
    x_5       A69-5                          -1
    x_8       Lambda                          1
    x_8       A59-8                          -1
    x_9       Lambda                          1
    x_9       A25-9                          -1
    x_10      Lambda                          1
    x_10      A4-10                          -1
    x_10      A45-10                         -1
    x_11      Lambda                          1
    x_11      A3-11                          -1
    x_12      Lambda                          1
    x_12      A18-12                         -1
    x_12      A34-12                         -1
    x_13      Lambda                          1
    x_13      A51-13                         -1
    x_13      A58-13                         -1
    x_14      Lambda                          1
    x_14      A15-14                         -1
    x_14      A17-14                         -1
    x_15      Lambda                          1
    x_15      A14-15                         -1
    x_15      A21-15                         -1
    x_15      A29-15                         -1
    x_15      A41-15                         -1
    x_16      Lambda                          1
    x_17      Lambda                          1
    x_17      A14-17                         -1
    x_18      Lambda                          1
    x_18      A12-18                         -1
    x_18      A28-18                         -1
    x_18      A35-18                         -1
    x_19      Lambda                          1
    x_19      A1-19                          -1
    x_19      A31-19                         -1
    x_19      A32-19                         -1
    x_19      A54-19                         -1
    x_20      Lambda                          1
    x_20      A46-20                         -1
    x_20      A76-20                         -1
    x_21      Lambda                          1
    x_21      A15-21                         -1
    x_22      Lambda                          1
    x_22      A3-22                          -1
    x_23      Lambda                          1
    x_23      A27-23                         -1
    x_23      A36-23                         -1
    x_23      A73-23                         -1
    x_24      Lambda                          1
    x_24      A5-24                          -1
    x_24      A56-24                         -1
    x_24      A63-24                         -1
    x_25      Lambda                          1
    x_25      A9-25                          -1
    x_25      A37-25                         -1
    x_26      Lambda                          1
    x_26      A5-26                          -1
    x_27      Lambda                          1
    x_27      A23-27                         -1
    x_28      Lambda                          1
    x_28      A18-28                         -1
    x_28      A30-28                         -1
    x_29      Lambda                          1
    x_29      A15-29                         -1
    x_29      A44-29                         -1
    x_29      A65-29                         -1
    x_29      A80-29                         -1
    x_30      Lambda                          1
    x_30      A28-30                         -1
    x_31      Lambda                          1
    x_31      A19-31                         -1
    x_32      Lambda                          1
    x_32      A19-32                         -1
    x_33      Lambda                          1
    x_33      A3-33                          -1
    x_34      Lambda                          1
    x_34      A12-34                         -1
    x_34      A39-34                         -1
    x_34      A42-34                         -1
    x_35      Lambda                          1
    x_35      A18-35                         -1
    x_35      A52-35                         -1
    x_35      A67-35                         -1
    x_36      Lambda                          1
    x_36      A23-36                         -1
    x_37      Lambda                          1
    x_37      A25-37                         -1
    x_37      A53-37                         -1
    x_38      Lambda                          1
    x_38      A3-38                          -1
    x_38      A40-38                         -1
    x_38      A50-38                         -1
    x_39      Lambda                          1
    x_39      A34-39                         -1
    x_39      A49-39                         -1
    x_39      A68-39                         -1
    x_40      Lambda                          1
    x_40      A38-40                         -1
    x_40      A48-40                         -1
    x_41      Lambda                          1
    x_41      A15-41                         -1
    x_42      Lambda                          1
    x_42      A34-42                         -1
    x_42      A55-42                         -1
    x_43      Lambda                          1
    x_43      A3-43                          -1
    x_44      Lambda                          1
    x_44      A29-44                         -1
    x_45      Lambda                          1
    x_45      A10-45                         -1
    x_45      A77-45                         -1
    x_46      Lambda                          1
    x_46      A20-46                         -1
    x_46      A47-46                         -1
    x_46      A71-46                         -1
    x_46      A75-46                         -1
    x_47      Lambda                          1
    x_47      A46-47                         -1
    x_48      Lambda                          1
    x_48      A40-48                         -1
    x_49      Lambda                          1
    x_49      A39-49                         -1
    x_50      Lambda                          1
    x_50      A38-50                         -1
    x_51      Lambda                          1
    x_51      A13-51                         -1
    x_52      Lambda                          1
    x_52      A35-52                         -1
    x_52      A60-52                         -1
    x_52      A62-52                         -1
    x_53      Lambda                          1
    x_53      A37-53                         -1
    x_53      A70-53                         -1
    x_54      Lambda                          1
    x_54      A19-54                         -1
    x_55      Lambda                          1
    x_55      A42-55                         -1
    x_55      A79-55                         -1
    x_56      Lambda                          1
    x_56      A24-56                         -1
    x_57      Lambda                          1
    x_57      A4-57                          -1
    x_58      Lambda                          1
    x_58      A13-58                         -1
    x_59      Lambda                          1
    x_59      A8-59                          -1
    x_59      A61-59                         -1
    x_60      Lambda                          1
    x_60      A52-60                         -1
    x_61      Lambda                          1
    x_61      A59-61                         -1
    x_62      Lambda                          1
    x_62      A52-62                         -1
    x_63      Lambda                          1
    x_63      A24-63                         -1
    x_63      A66-63                         -1
    x_63      A78-63                         -1
    x_64      Lambda                          1
    x_64      A5-64                          -1
    x_64      A74-64                         -1
    x_65      Lambda                          1
    x_65      A29-65                         -1
    x_66      Lambda                          1
    x_66      A63-66                         -1
    x_66      A72-66                         -1
    x_67      Lambda                          1
    x_67      A35-67                         -1
    x_68      Lambda                          1
    x_68      A39-68                         -1
    x_69      Lambda                          1
    x_69      A5-69                          -1
    x_70      Lambda                          1
    x_70      A53-70                         -1
    x_71      Lambda                          1
    x_71      A46-71                         -1
    x_72      Lambda                          1
    x_72      A66-72                         -1
    x_73      Lambda                          1
    x_73      A23-73                         -1
    x_74      Lambda                          1
    x_74      A64-74                         -1
    x_75      Lambda                          1
    x_75      A46-75                         -1
    x_76      Lambda                          1
    x_76      A20-76                         -1
    x_77      Lambda                          1
    x_77      A45-77                         -1
    x_78      Lambda                          1
    x_78      A63-78                         -1
    x_79      Lambda                          1
    x_79      A55-79                         -1
    x_80      Lambda                          1
    x_80      A29-80                         -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       Phi                             3
    rhs       Lambda                          1
    rhs       V1                              1
    rhs       V3                              1
    rhs       V4                              1
    rhs       V5                              1
    rhs       V8                              1
    rhs       V9                              1
    rhs       V10                             1
    rhs       V11                             1
    rhs       V12                             1
    rhs       V13                             1
    rhs       V14                             1
    rhs       V15                             1
    rhs       V16                             1
    rhs       V17                             1
    rhs       V18                             1
    rhs       V19                             1
    rhs       V20                             1
    rhs       V21                             1
    rhs       V22                             1
    rhs       V23                             1
    rhs       V24                             1
    rhs       V25                             1
    rhs       V26                             1
    rhs       V27                             1
    rhs       V28                             1
    rhs       V29                             1
    rhs       V30                             1
    rhs       V31                             1
    rhs       V32                             1
    rhs       V33                             1
    rhs       V34                             1
    rhs       V35                             1
    rhs       V36                             1
    rhs       V37                             1
    rhs       V38                             1
    rhs       V39                             1
    rhs       V40                             1
    rhs       V41                             1
    rhs       V42                             1
    rhs       V43                             1
    rhs       V44                             1
    rhs       V45                             1
    rhs       V46                             1
    rhs       V47                             1
    rhs       V48                             1
    rhs       V49                             1
    rhs       V50                             1
    rhs       V51                             1
    rhs       V52                             1
    rhs       V53                             1
    rhs       V54                             1
    rhs       V55                             1
    rhs       V56                             1
    rhs       V57                             1
    rhs       V58                             1
    rhs       V59                             1
    rhs       V60                             1
    rhs       V61                             1
    rhs       V62                             1
    rhs       V63                             1
    rhs       V64                             1
    rhs       V65                             1
    rhs       V66                             1
    rhs       V67                             1
    rhs       V68                             1
    rhs       V69                             1
    rhs       V70                             1
    rhs       V71                             1
    rhs       V72                             1
    rhs       V73                             1
    rhs       V74                             1
    rhs       V75                             1
    rhs       V76                             1
    rhs       V77                             1
    rhs       V78                             1
    rhs       V79                             1
    rhs       V80                             1
BOUNDS
 BV bnd       a_1     
 BV bnd       a_3     
 BV bnd       a_4     
 BV bnd       a_5     
 BV bnd       a_8     
 BV bnd       a_9     
 BV bnd       a_10    
 BV bnd       a_11    
 BV bnd       a_12    
 BV bnd       a_13    
 BV bnd       a_14    
 BV bnd       a_15    
 BV bnd       a_16    
 BV bnd       a_17    
 BV bnd       a_18    
 BV bnd       a_19    
 BV bnd       a_20    
 BV bnd       a_21    
 BV bnd       a_22    
 BV bnd       a_23    
 BV bnd       a_24    
 BV bnd       a_25    
 BV bnd       a_26    
 BV bnd       a_27    
 BV bnd       a_28    
 BV bnd       a_29    
 BV bnd       a_30    
 BV bnd       a_31    
 BV bnd       a_32    
 BV bnd       a_33    
 BV bnd       a_34    
 BV bnd       a_35    
 BV bnd       a_36    
 BV bnd       a_37    
 BV bnd       a_38    
 BV bnd       a_39    
 BV bnd       a_40    
 BV bnd       a_41    
 BV bnd       a_42    
 BV bnd       a_43    
 BV bnd       a_44    
 BV bnd       a_45    
 BV bnd       a_46    
 BV bnd       a_47    
 BV bnd       a_48    
 BV bnd       a_49    
 BV bnd       a_50    
 BV bnd       a_51    
 BV bnd       a_52    
 BV bnd       a_53    
 BV bnd       a_54    
 BV bnd       a_55    
 BV bnd       a_56    
 BV bnd       a_57    
 BV bnd       a_58    
 BV bnd       a_59    
 BV bnd       a_60    
 BV bnd       a_61    
 BV bnd       a_62    
 BV bnd       a_63    
 BV bnd       a_64    
 BV bnd       a_65    
 BV bnd       a_66    
 BV bnd       a_67    
 BV bnd       a_68    
 BV bnd       a_69    
 BV bnd       a_70    
 BV bnd       a_71    
 BV bnd       a_72    
 BV bnd       a_73    
 BV bnd       a_74    
 BV bnd       a_75    
 BV bnd       a_76    
 BV bnd       a_77    
 BV bnd       a_78    
 BV bnd       a_79    
 BV bnd       a_80    
 BV bnd       y_1     
 BV bnd       y_3     
 BV bnd       y_4     
 BV bnd       y_5     
 BV bnd       y_8     
 BV bnd       y_9     
 BV bnd       y_10    
 BV bnd       y_11    
 BV bnd       y_12    
 BV bnd       y_13    
 BV bnd       y_14    
 BV bnd       y_15    
 BV bnd       y_16    
 BV bnd       y_17    
 BV bnd       y_18    
 BV bnd       y_19    
 BV bnd       y_20    
 BV bnd       y_21    
 BV bnd       y_22    
 BV bnd       y_23    
 BV bnd       y_24    
 BV bnd       y_25    
 BV bnd       y_26    
 BV bnd       y_27    
 BV bnd       y_28    
 BV bnd       y_29    
 BV bnd       y_30    
 BV bnd       y_31    
 BV bnd       y_32    
 BV bnd       y_33    
 BV bnd       y_34    
 BV bnd       y_35    
 BV bnd       y_36    
 BV bnd       y_37    
 BV bnd       y_38    
 BV bnd       y_39    
 BV bnd       y_40    
 BV bnd       y_41    
 BV bnd       y_42    
 BV bnd       y_43    
 BV bnd       y_44    
 BV bnd       y_45    
 BV bnd       y_46    
 BV bnd       y_47    
 BV bnd       y_48    
 BV bnd       y_49    
 BV bnd       y_50    
 BV bnd       y_51    
 BV bnd       y_52    
 BV bnd       y_53    
 BV bnd       y_54    
 BV bnd       y_55    
 BV bnd       y_56    
 BV bnd       y_57    
 BV bnd       y_58    
 BV bnd       y_59    
 BV bnd       y_60    
 BV bnd       y_61    
 BV bnd       y_62    
 BV bnd       y_63    
 BV bnd       y_64    
 BV bnd       y_65    
 BV bnd       y_66    
 BV bnd       y_67    
 BV bnd       y_68    
 BV bnd       y_69    
 BV bnd       y_70    
 BV bnd       y_71    
 BV bnd       y_72    
 BV bnd       y_73    
 BV bnd       y_74    
 BV bnd       y_75    
 BV bnd       y_76    
 BV bnd       y_77    
 BV bnd       y_78    
 BV bnd       y_79    
 BV bnd       y_80    
 BV bnd       x_1     
 BV bnd       x_3     
 BV bnd       x_4     
 BV bnd       x_5     
 BV bnd       x_8     
 BV bnd       x_9     
 BV bnd       x_10    
 BV bnd       x_11    
 BV bnd       x_12    
 BV bnd       x_13    
 BV bnd       x_14    
 BV bnd       x_15    
 BV bnd       x_16    
 BV bnd       x_17    
 BV bnd       x_18    
 BV bnd       x_19    
 BV bnd       x_20    
 BV bnd       x_21    
 BV bnd       x_22    
 BV bnd       x_23    
 BV bnd       x_24    
 BV bnd       x_25    
 BV bnd       x_26    
 BV bnd       x_27    
 BV bnd       x_28    
 BV bnd       x_29    
 BV bnd       x_30    
 BV bnd       x_31    
 BV bnd       x_32    
 BV bnd       x_33    
 BV bnd       x_34    
 BV bnd       x_35    
 BV bnd       x_36    
 BV bnd       x_37    
 BV bnd       x_38    
 BV bnd       x_39    
 BV bnd       x_40    
 BV bnd       x_41    
 BV bnd       x_42    
 BV bnd       x_43    
 BV bnd       x_44    
 BV bnd       x_45    
 BV bnd       x_46    
 BV bnd       x_47    
 BV bnd       x_48    
 BV bnd       x_49    
 BV bnd       x_50    
 BV bnd       x_51    
 BV bnd       x_52    
 BV bnd       x_53    
 BV bnd       x_54    
 BV bnd       x_55    
 BV bnd       x_56    
 BV bnd       x_57    
 BV bnd       x_58    
 BV bnd       x_59    
 BV bnd       x_60    
 BV bnd       x_61    
 BV bnd       x_62    
 BV bnd       x_63    
 BV bnd       x_64    
 BV bnd       x_65    
 BV bnd       x_66    
 BV bnd       x_67    
 BV bnd       x_68    
 BV bnd       x_69    
 BV bnd       x_70    
 BV bnd       x_71    
 BV bnd       x_72    
 BV bnd       x_73    
 BV bnd       x_74    
 BV bnd       x_75    
 BV bnd       x_76    
 BV bnd       x_77    
 BV bnd       x_78    
 BV bnd       x_79    
 BV bnd       x_80    
ENDATA
