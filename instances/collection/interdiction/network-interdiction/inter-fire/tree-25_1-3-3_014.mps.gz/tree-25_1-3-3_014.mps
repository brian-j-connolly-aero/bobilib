* ENCODING=ISO-8859-1
NAME          tree-25_1-3-3_014
ROWS
 N  obj     
 L  Phi     
 L  Lambda  
 L  V2      
 L  V3      
 L  V4      
 L  V5      
 L  V6      
 L  V7      
 L  V8      
 L  V9      
 L  V10     
 L  V11     
 L  V12     
 L  V13     
 L  V14     
 L  V15     
 L  V16     
 L  V17     
 L  V18     
 L  V19     
 L  V20     
 L  V21     
 L  V22     
 L  V23     
 L  V24     
 L  V25     
 L  A4-3    
 L  A3-4    
 L  A5-3    
 L  A3-5    
 L  A6-5    
 L  A5-6    
 L  A7-6    
 L  A6-7    
 L  A8-7    
 L  A7-8    
 L  A9-5    
 L  A5-9    
 L  A12-9   
 L  A9-12   
 L  A13-7   
 L  A7-13   
 L  A14-8   
 L  A8-14   
 L  A16-5   
 L  A5-16   
 L  A17-6   
 L  A6-17   
 L  A18-12  
 L  A12-18  
 L  A19-16  
 L  A16-19  
 L  A20-2   
 L  A2-20   
 L  A21-8   
 L  A8-21   
 L  A22-9   
 L  A9-22   
 L  A23-12  
 L  A12-23  
 L  A24-19  
 L  A19-24  
 L  A25-15  
 L  A15-25  
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    a_2       obj                             1
    a_2       V2                              1
    a_2       A20-2                           1
    a_2       A2-20                          -1
    a_3       obj                             1
    a_3       V3                              1
    a_3       A4-3                            1
    a_3       A3-4                           -1
    a_3       A5-3                            1
    a_3       A3-5                           -1
    a_4       obj                             1
    a_4       V4                              1
    a_4       A4-3                           -1
    a_4       A3-4                            1
    a_5       obj                             1
    a_5       V5                              1
    a_5       A5-3                           -1
    a_5       A3-5                            1
    a_5       A6-5                            1
    a_5       A5-6                           -1
    a_5       A9-5                            1
    a_5       A5-9                           -1
    a_5       A16-5                           1
    a_5       A5-16                          -1
    a_6       obj                             1
    a_6       V6                              1
    a_6       A6-5                           -1
    a_6       A5-6                            1
    a_6       A7-6                            1
    a_6       A6-7                           -1
    a_6       A17-6                           1
    a_6       A6-17                          -1
    a_7       obj                             1
    a_7       V7                              1
    a_7       A7-6                           -1
    a_7       A6-7                            1
    a_7       A8-7                            1
    a_7       A7-8                           -1
    a_7       A13-7                           1
    a_7       A7-13                          -1
    a_8       obj                             1
    a_8       V8                              1
    a_8       A8-7                           -1
    a_8       A7-8                            1
    a_8       A14-8                           1
    a_8       A8-14                          -1
    a_8       A21-8                           1
    a_8       A8-21                          -1
    a_9       obj                             1
    a_9       V9                              1
    a_9       A9-5                           -1
    a_9       A5-9                            1
    a_9       A12-9                           1
    a_9       A9-12                          -1
    a_9       A22-9                           1
    a_9       A9-22                          -1
    a_10      obj                             1
    a_10      V10                             1
    a_11      obj                             1
    a_11      V11                             1
    a_12      obj                             1
    a_12      V12                             1
    a_12      A12-9                          -1
    a_12      A9-12                           1
    a_12      A18-12                          1
    a_12      A12-18                         -1
    a_12      A23-12                          1
    a_12      A12-23                         -1
    a_13      obj                             1
    a_13      V13                             1
    a_13      A13-7                          -1
    a_13      A7-13                           1
    a_14      obj                             1
    a_14      V14                             1
    a_14      A14-8                          -1
    a_14      A8-14                           1
    a_15      obj                             1
    a_15      V15                             1
    a_15      A25-15                          1
    a_15      A15-25                         -1
    a_16      obj                             1
    a_16      V16                             1
    a_16      A16-5                          -1
    a_16      A5-16                           1
    a_16      A19-16                          1
    a_16      A16-19                         -1
    a_17      obj                             1
    a_17      V17                             1
    a_17      A17-6                          -1
    a_17      A6-17                           1
    a_18      obj                             1
    a_18      V18                             1
    a_18      A18-12                         -1
    a_18      A12-18                          1
    a_19      obj                             1
    a_19      V19                             1
    a_19      A19-16                         -1
    a_19      A16-19                          1
    a_19      A24-19                          1
    a_19      A19-24                         -1
    a_20      obj                             1
    a_20      V20                             1
    a_20      A20-2                          -1
    a_20      A2-20                           1
    a_21      obj                             1
    a_21      V21                             1
    a_21      A21-8                          -1
    a_21      A8-21                           1
    a_22      obj                             1
    a_22      V22                             1
    a_22      A22-9                          -1
    a_22      A9-22                           1
    a_23      obj                             1
    a_23      V23                             1
    a_23      A23-12                         -1
    a_23      A12-23                          1
    a_24      obj                             1
    a_24      V24                             1
    a_24      A24-19                         -1
    a_24      A19-24                          1
    a_25      obj                             1
    a_25      V25                             1
    a_25      A25-15                         -1
    a_25      A15-25                          1
    y_2       Phi                             1
    y_2       V2                              1
    y_3       Phi                             1
    y_3       V3                              1
    y_4       Phi                             1
    y_4       V4                              1
    y_5       Phi                             1
    y_5       V5                              1
    y_6       Phi                             1
    y_6       V6                              1
    y_7       Phi                             1
    y_7       V7                              1
    y_8       Phi                             1
    y_8       V8                              1
    y_9       Phi                             1
    y_9       V9                              1
    y_10      Phi                             1
    y_10      V10                             1
    y_11      Phi                             1
    y_11      V11                             1
    y_12      Phi                             1
    y_12      V12                             1
    y_13      Phi                             1
    y_13      V13                             1
    y_14      Phi                             1
    y_14      V14                             1
    y_15      Phi                             1
    y_15      V15                             1
    y_16      Phi                             1
    y_16      V16                             1
    y_17      Phi                             1
    y_17      V17                             1
    y_18      Phi                             1
    y_18      V18                             1
    y_19      Phi                             1
    y_19      V19                             1
    y_20      Phi                             1
    y_20      V20                             1
    y_21      Phi                             1
    y_21      V21                             1
    y_22      Phi                             1
    y_22      V22                             1
    y_23      Phi                             1
    y_23      V23                             1
    y_24      Phi                             1
    y_24      V24                             1
    y_25      Phi                             1
    y_25      V25                             1
    x_2       Lambda                          1
    x_2       A20-2                          -1
    x_3       Lambda                          1
    x_3       A4-3                           -1
    x_3       A5-3                           -1
    x_4       Lambda                          1
    x_4       A3-4                           -1
    x_5       Lambda                          1
    x_5       A3-5                           -1
    x_5       A6-5                           -1
    x_5       A9-5                           -1
    x_5       A16-5                          -1
    x_6       Lambda                          1
    x_6       A5-6                           -1
    x_6       A7-6                           -1
    x_6       A17-6                          -1
    x_7       Lambda                          1
    x_7       A6-7                           -1
    x_7       A8-7                           -1
    x_7       A13-7                          -1
    x_8       Lambda                          1
    x_8       A7-8                           -1
    x_8       A14-8                          -1
    x_8       A21-8                          -1
    x_9       Lambda                          1
    x_9       A5-9                           -1
    x_9       A12-9                          -1
    x_9       A22-9                          -1
    x_10      Lambda                          1
    x_11      Lambda                          1
    x_12      Lambda                          1
    x_12      A9-12                          -1
    x_12      A18-12                         -1
    x_12      A23-12                         -1
    x_13      Lambda                          1
    x_13      A7-13                          -1
    x_14      Lambda                          1
    x_14      A8-14                          -1
    x_15      Lambda                          1
    x_15      A25-15                         -1
    x_16      Lambda                          1
    x_16      A5-16                          -1
    x_16      A19-16                         -1
    x_17      Lambda                          1
    x_17      A6-17                          -1
    x_18      Lambda                          1
    x_18      A12-18                         -1
    x_19      Lambda                          1
    x_19      A16-19                         -1
    x_19      A24-19                         -1
    x_20      Lambda                          1
    x_20      A2-20                          -1
    x_21      Lambda                          1
    x_21      A8-21                          -1
    x_22      Lambda                          1
    x_22      A9-22                          -1
    x_23      Lambda                          1
    x_23      A12-23                         -1
    x_24      Lambda                          1
    x_24      A19-24                         -1
    x_25      Lambda                          1
    x_25      A15-25                         -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       Phi                             3
    rhs       Lambda                          3
    rhs       V2                              1
    rhs       V3                              1
    rhs       V4                              1
    rhs       V5                              1
    rhs       V6                              1
    rhs       V7                              1
    rhs       V8                              1
    rhs       V9                              1
    rhs       V10                             1
    rhs       V11                             1
    rhs       V12                             1
    rhs       V13                             1
    rhs       V14                             1
    rhs       V15                             1
    rhs       V16                             1
    rhs       V17                             1
    rhs       V18                             1
    rhs       V19                             1
    rhs       V20                             1
    rhs       V21                             1
    rhs       V22                             1
    rhs       V23                             1
    rhs       V24                             1
    rhs       V25                             1
BOUNDS
 BV bnd       a_2     
 BV bnd       a_3     
 BV bnd       a_4     
 BV bnd       a_5     
 BV bnd       a_6     
 BV bnd       a_7     
 BV bnd       a_8     
 BV bnd       a_9     
 BV bnd       a_10    
 BV bnd       a_11    
 BV bnd       a_12    
 BV bnd       a_13    
 BV bnd       a_14    
 BV bnd       a_15    
 BV bnd       a_16    
 BV bnd       a_17    
 BV bnd       a_18    
 BV bnd       a_19    
 BV bnd       a_20    
 BV bnd       a_21    
 BV bnd       a_22    
 BV bnd       a_23    
 BV bnd       a_24    
 BV bnd       a_25    
 BV bnd       y_2     
 BV bnd       y_3     
 BV bnd       y_4     
 BV bnd       y_5     
 BV bnd       y_6     
 BV bnd       y_7     
 BV bnd       y_8     
 BV bnd       y_9     
 BV bnd       y_10    
 BV bnd       y_11    
 BV bnd       y_12    
 BV bnd       y_13    
 BV bnd       y_14    
 BV bnd       y_15    
 BV bnd       y_16    
 BV bnd       y_17    
 BV bnd       y_18    
 BV bnd       y_19    
 BV bnd       y_20    
 BV bnd       y_21    
 BV bnd       y_22    
 BV bnd       y_23    
 BV bnd       y_24    
 BV bnd       y_25    
 BV bnd       x_2     
 BV bnd       x_3     
 BV bnd       x_4     
 BV bnd       x_5     
 BV bnd       x_6     
 BV bnd       x_7     
 BV bnd       x_8     
 BV bnd       x_9     
 BV bnd       x_10    
 BV bnd       x_11    
 BV bnd       x_12    
 BV bnd       x_13    
 BV bnd       x_14    
 BV bnd       x_15    
 BV bnd       x_16    
 BV bnd       x_17    
 BV bnd       x_18    
 BV bnd       x_19    
 BV bnd       x_20    
 BV bnd       x_21    
 BV bnd       x_22    
 BV bnd       x_23    
 BV bnd       x_24    
 BV bnd       x_25    
ENDATA
