* ENCODING=ISO-8859-1
NAME          tree-80_3-3-3_010
ROWS
 N  obj     
 L  Phi     
 L  Lambda  
 L  V2      
 L  V4      
 L  V5      
 L  V6      
 L  V7      
 L  V8      
 L  V9      
 L  V10     
 L  V11     
 L  V12     
 L  V13     
 L  V14     
 L  V15     
 L  V17     
 L  V18     
 L  V19     
 L  V20     
 L  V21     
 L  V22     
 L  V23     
 L  V24     
 L  V25     
 L  V26     
 L  V27     
 L  V28     
 L  V29     
 L  V30     
 L  V31     
 L  V32     
 L  V33     
 L  V34     
 L  V35     
 L  V36     
 L  V37     
 L  V38     
 L  V39     
 L  V40     
 L  V41     
 L  V42     
 L  V43     
 L  V44     
 L  V45     
 L  V46     
 L  V47     
 L  V48     
 L  V49     
 L  V50     
 L  V51     
 L  V52     
 L  V53     
 L  V54     
 L  V55     
 L  V56     
 L  V57     
 L  V58     
 L  V59     
 L  V60     
 L  V61     
 L  V62     
 L  V63     
 L  V64     
 L  V65     
 L  V66     
 L  V67     
 L  V68     
 L  V69     
 L  V70     
 L  V71     
 L  V72     
 L  V73     
 L  V74     
 L  V75     
 L  V76     
 L  V77     
 L  V78     
 L  V79     
 L  V80     
 L  A6-5    
 L  A5-6    
 L  A7-6    
 L  A6-7    
 L  A9-6    
 L  A6-9    
 L  A10-2   
 L  A2-10   
 L  A12-11  
 L  A11-12  
 L  A14-9   
 L  A9-14   
 L  A15-14  
 L  A14-15  
 L  A17-14  
 L  A14-17  
 L  A19-9   
 L  A9-19   
 L  A20-18  
 L  A18-20  
 L  A22-13  
 L  A13-22  
 L  A23-5   
 L  A5-23   
 L  A25-19  
 L  A19-25  
 L  A26-23  
 L  A23-26  
 L  A27-23  
 L  A23-27  
 L  A28-8   
 L  A8-28   
 L  A29-28  
 L  A28-29  
 L  A30-26  
 L  A26-30  
 L  A31-28  
 L  A28-31  
 L  A32-18  
 L  A18-32  
 L  A33-13  
 L  A13-33  
 L  A34-10  
 L  A10-34  
 L  A35-34  
 L  A34-35  
 L  A36-19  
 L  A19-36  
 L  A37-34  
 L  A34-37  
 L  A38-15  
 L  A15-38  
 L  A39-20  
 L  A20-39  
 L  A41-8   
 L  A8-41   
 L  A42-14  
 L  A14-42  
 L  A43-5   
 L  A5-43   
 L  A44-11  
 L  A11-44  
 L  A45-22  
 L  A22-45  
 L  A46-32  
 L  A32-46  
 L  A47-31  
 L  A31-47  
 L  A48-21  
 L  A21-48  
 L  A49-43  
 L  A43-49  
 L  A51-50  
 L  A50-51  
 L  A52-40  
 L  A40-52  
 L  A56-19  
 L  A19-56  
 L  A57-51  
 L  A51-57  
 L  A58-31  
 L  A31-58  
 L  A59-24  
 L  A24-59  
 L  A60-17  
 L  A17-60  
 L  A61-13  
 L  A13-61  
 L  A62-25  
 L  A25-62  
 L  A63-38  
 L  A38-63  
 L  A64-4   
 L  A4-64   
 L  A65-55  
 L  A55-65  
 L  A66-59  
 L  A59-66  
 L  A67-64  
 L  A64-67  
 L  A68-48  
 L  A48-68  
 L  A69-25  
 L  A25-69  
 L  A70-19  
 L  A19-70  
 L  A71-70  
 L  A70-71  
 L  A72-30  
 L  A30-72  
 L  A73-23  
 L  A23-73  
 L  A74-2   
 L  A2-74   
 L  A75-11  
 L  A11-75  
 L  A76-49  
 L  A49-76  
 L  A77-38  
 L  A38-77  
 L  A78-64  
 L  A64-78  
 L  A79-41  
 L  A41-79  
 L  A80-31  
 L  A31-80  
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    a_2       obj                             1
    a_2       V2                              1
    a_2       A10-2                           1
    a_2       A2-10                          -1
    a_2       A74-2                           1
    a_2       A2-74                          -1
    a_4       obj                             1
    a_4       V4                              1
    a_4       A64-4                           1
    a_4       A4-64                          -1
    a_5       obj                             1
    a_5       V5                              1
    a_5       A6-5                            1
    a_5       A5-6                           -1
    a_5       A23-5                           1
    a_5       A5-23                          -1
    a_5       A43-5                           1
    a_5       A5-43                          -1
    a_6       obj                             1
    a_6       V6                              1
    a_6       A6-5                           -1
    a_6       A5-6                            1
    a_6       A7-6                            1
    a_6       A6-7                           -1
    a_6       A9-6                            1
    a_6       A6-9                           -1
    a_7       obj                             1
    a_7       V7                              1
    a_7       A7-6                           -1
    a_7       A6-7                            1
    a_8       obj                             1
    a_8       V8                              1
    a_8       A28-8                           1
    a_8       A8-28                          -1
    a_8       A41-8                           1
    a_8       A8-41                          -1
    a_9       obj                             1
    a_9       V9                              1
    a_9       A9-6                           -1
    a_9       A6-9                            1
    a_9       A14-9                           1
    a_9       A9-14                          -1
    a_9       A19-9                           1
    a_9       A9-19                          -1
    a_10      obj                             1
    a_10      V10                             1
    a_10      A10-2                          -1
    a_10      A2-10                           1
    a_10      A34-10                          1
    a_10      A10-34                         -1
    a_11      obj                             1
    a_11      V11                             1
    a_11      A12-11                          1
    a_11      A11-12                         -1
    a_11      A44-11                          1
    a_11      A11-44                         -1
    a_11      A75-11                          1
    a_11      A11-75                         -1
    a_12      obj                             1
    a_12      V12                             1
    a_12      A12-11                         -1
    a_12      A11-12                          1
    a_13      obj                             1
    a_13      V13                             1
    a_13      A22-13                          1
    a_13      A13-22                         -1
    a_13      A33-13                          1
    a_13      A13-33                         -1
    a_13      A61-13                          1
    a_13      A13-61                         -1
    a_14      obj                             1
    a_14      V14                             1
    a_14      A14-9                          -1
    a_14      A9-14                           1
    a_14      A15-14                          1
    a_14      A14-15                         -1
    a_14      A17-14                          1
    a_14      A14-17                         -1
    a_14      A42-14                          1
    a_14      A14-42                         -1
    a_15      obj                             1
    a_15      V15                             1
    a_15      A15-14                         -1
    a_15      A14-15                          1
    a_15      A38-15                          1
    a_15      A15-38                         -1
    a_17      obj                             1
    a_17      V17                             1
    a_17      A17-14                         -1
    a_17      A14-17                          1
    a_17      A60-17                          1
    a_17      A17-60                         -1
    a_18      obj                             1
    a_18      V18                             1
    a_18      A20-18                          1
    a_18      A18-20                         -1
    a_18      A32-18                          1
    a_18      A18-32                         -1
    a_19      obj                             1
    a_19      V19                             1
    a_19      A19-9                          -1
    a_19      A9-19                           1
    a_19      A25-19                          1
    a_19      A19-25                         -1
    a_19      A36-19                          1
    a_19      A19-36                         -1
    a_19      A56-19                          1
    a_19      A19-56                         -1
    a_19      A70-19                          1
    a_19      A19-70                         -1
    a_20      obj                             1
    a_20      V20                             1
    a_20      A20-18                         -1
    a_20      A18-20                          1
    a_20      A39-20                          1
    a_20      A20-39                         -1
    a_21      obj                             1
    a_21      V21                             1
    a_21      A48-21                          1
    a_21      A21-48                         -1
    a_22      obj                             1
    a_22      V22                             1
    a_22      A22-13                         -1
    a_22      A13-22                          1
    a_22      A45-22                          1
    a_22      A22-45                         -1
    a_23      obj                             1
    a_23      V23                             1
    a_23      A23-5                          -1
    a_23      A5-23                           1
    a_23      A26-23                          1
    a_23      A23-26                         -1
    a_23      A27-23                          1
    a_23      A23-27                         -1
    a_23      A73-23                          1
    a_23      A23-73                         -1
    a_24      obj                             1
    a_24      V24                             1
    a_24      A59-24                          1
    a_24      A24-59                         -1
    a_25      obj                             1
    a_25      V25                             1
    a_25      A25-19                         -1
    a_25      A19-25                          1
    a_25      A62-25                          1
    a_25      A25-62                         -1
    a_25      A69-25                          1
    a_25      A25-69                         -1
    a_26      obj                             1
    a_26      V26                             1
    a_26      A26-23                         -1
    a_26      A23-26                          1
    a_26      A30-26                          1
    a_26      A26-30                         -1
    a_27      obj                             1
    a_27      V27                             1
    a_27      A27-23                         -1
    a_27      A23-27                          1
    a_28      obj                             1
    a_28      V28                             1
    a_28      A28-8                          -1
    a_28      A8-28                           1
    a_28      A29-28                          1
    a_28      A28-29                         -1
    a_28      A31-28                          1
    a_28      A28-31                         -1
    a_29      obj                             1
    a_29      V29                             1
    a_29      A29-28                         -1
    a_29      A28-29                          1
    a_30      obj                             1
    a_30      V30                             1
    a_30      A30-26                         -1
    a_30      A26-30                          1
    a_30      A72-30                          1
    a_30      A30-72                         -1
    a_31      obj                             1
    a_31      V31                             1
    a_31      A31-28                         -1
    a_31      A28-31                          1
    a_31      A47-31                          1
    a_31      A31-47                         -1
    a_31      A58-31                          1
    a_31      A31-58                         -1
    a_31      A80-31                          1
    a_31      A31-80                         -1
    a_32      obj                             1
    a_32      V32                             1
    a_32      A32-18                         -1
    a_32      A18-32                          1
    a_32      A46-32                          1
    a_32      A32-46                         -1
    a_33      obj                             1
    a_33      V33                             1
    a_33      A33-13                         -1
    a_33      A13-33                          1
    a_34      obj                             1
    a_34      V34                             1
    a_34      A34-10                         -1
    a_34      A10-34                          1
    a_34      A35-34                          1
    a_34      A34-35                         -1
    a_34      A37-34                          1
    a_34      A34-37                         -1
    a_35      obj                             1
    a_35      V35                             1
    a_35      A35-34                         -1
    a_35      A34-35                          1
    a_36      obj                             1
    a_36      V36                             1
    a_36      A36-19                         -1
    a_36      A19-36                          1
    a_37      obj                             1
    a_37      V37                             1
    a_37      A37-34                         -1
    a_37      A34-37                          1
    a_38      obj                             1
    a_38      V38                             1
    a_38      A38-15                         -1
    a_38      A15-38                          1
    a_38      A63-38                          1
    a_38      A38-63                         -1
    a_38      A77-38                          1
    a_38      A38-77                         -1
    a_39      obj                             1
    a_39      V39                             1
    a_39      A39-20                         -1
    a_39      A20-39                          1
    a_40      obj                             1
    a_40      V40                             1
    a_40      A52-40                          1
    a_40      A40-52                         -1
    a_41      obj                             1
    a_41      V41                             1
    a_41      A41-8                          -1
    a_41      A8-41                           1
    a_41      A79-41                          1
    a_41      A41-79                         -1
    a_42      obj                             1
    a_42      V42                             1
    a_42      A42-14                         -1
    a_42      A14-42                          1
    a_43      obj                             1
    a_43      V43                             1
    a_43      A43-5                          -1
    a_43      A5-43                           1
    a_43      A49-43                          1
    a_43      A43-49                         -1
    a_44      obj                             1
    a_44      V44                             1
    a_44      A44-11                         -1
    a_44      A11-44                          1
    a_45      obj                             1
    a_45      V45                             1
    a_45      A45-22                         -1
    a_45      A22-45                          1
    a_46      obj                             1
    a_46      V46                             1
    a_46      A46-32                         -1
    a_46      A32-46                          1
    a_47      obj                             1
    a_47      V47                             1
    a_47      A47-31                         -1
    a_47      A31-47                          1
    a_48      obj                             1
    a_48      V48                             1
    a_48      A48-21                         -1
    a_48      A21-48                          1
    a_48      A68-48                          1
    a_48      A48-68                         -1
    a_49      obj                             1
    a_49      V49                             1
    a_49      A49-43                         -1
    a_49      A43-49                          1
    a_49      A76-49                          1
    a_49      A49-76                         -1
    a_50      obj                             1
    a_50      V50                             1
    a_50      A51-50                          1
    a_50      A50-51                         -1
    a_51      obj                             1
    a_51      V51                             1
    a_51      A51-50                         -1
    a_51      A50-51                          1
    a_51      A57-51                          1
    a_51      A51-57                         -1
    a_52      obj                             1
    a_52      V52                             1
    a_52      A52-40                         -1
    a_52      A40-52                          1
    a_53      obj                             1
    a_53      V53                             1
    a_54      obj                             1
    a_54      V54                             1
    a_55      obj                             1
    a_55      V55                             1
    a_55      A65-55                          1
    a_55      A55-65                         -1
    a_56      obj                             1
    a_56      V56                             1
    a_56      A56-19                         -1
    a_56      A19-56                          1
    a_57      obj                             1
    a_57      V57                             1
    a_57      A57-51                         -1
    a_57      A51-57                          1
    a_58      obj                             1
    a_58      V58                             1
    a_58      A58-31                         -1
    a_58      A31-58                          1
    a_59      obj                             1
    a_59      V59                             1
    a_59      A59-24                         -1
    a_59      A24-59                          1
    a_59      A66-59                          1
    a_59      A59-66                         -1
    a_60      obj                             1
    a_60      V60                             1
    a_60      A60-17                         -1
    a_60      A17-60                          1
    a_61      obj                             1
    a_61      V61                             1
    a_61      A61-13                         -1
    a_61      A13-61                          1
    a_62      obj                             1
    a_62      V62                             1
    a_62      A62-25                         -1
    a_62      A25-62                          1
    a_63      obj                             1
    a_63      V63                             1
    a_63      A63-38                         -1
    a_63      A38-63                          1
    a_64      obj                             1
    a_64      V64                             1
    a_64      A64-4                          -1
    a_64      A4-64                           1
    a_64      A67-64                          1
    a_64      A64-67                         -1
    a_64      A78-64                          1
    a_64      A64-78                         -1
    a_65      obj                             1
    a_65      V65                             1
    a_65      A65-55                         -1
    a_65      A55-65                          1
    a_66      obj                             1
    a_66      V66                             1
    a_66      A66-59                         -1
    a_66      A59-66                          1
    a_67      obj                             1
    a_67      V67                             1
    a_67      A67-64                         -1
    a_67      A64-67                          1
    a_68      obj                             1
    a_68      V68                             1
    a_68      A68-48                         -1
    a_68      A48-68                          1
    a_69      obj                             1
    a_69      V69                             1
    a_69      A69-25                         -1
    a_69      A25-69                          1
    a_70      obj                             1
    a_70      V70                             1
    a_70      A70-19                         -1
    a_70      A19-70                          1
    a_70      A71-70                          1
    a_70      A70-71                         -1
    a_71      obj                             1
    a_71      V71                             1
    a_71      A71-70                         -1
    a_71      A70-71                          1
    a_72      obj                             1
    a_72      V72                             1
    a_72      A72-30                         -1
    a_72      A30-72                          1
    a_73      obj                             1
    a_73      V73                             1
    a_73      A73-23                         -1
    a_73      A23-73                          1
    a_74      obj                             1
    a_74      V74                             1
    a_74      A74-2                          -1
    a_74      A2-74                           1
    a_75      obj                             1
    a_75      V75                             1
    a_75      A75-11                         -1
    a_75      A11-75                          1
    a_76      obj                             1
    a_76      V76                             1
    a_76      A76-49                         -1
    a_76      A49-76                          1
    a_77      obj                             1
    a_77      V77                             1
    a_77      A77-38                         -1
    a_77      A38-77                          1
    a_78      obj                             1
    a_78      V78                             1
    a_78      A78-64                         -1
    a_78      A64-78                          1
    a_79      obj                             1
    a_79      V79                             1
    a_79      A79-41                         -1
    a_79      A41-79                          1
    a_80      obj                             1
    a_80      V80                             1
    a_80      A80-31                         -1
    a_80      A31-80                          1
    y_2       Phi                             1
    y_2       V2                              1
    y_4       Phi                             1
    y_4       V4                              1
    y_5       Phi                             1
    y_5       V5                              1
    y_6       Phi                             1
    y_6       V6                              1
    y_7       Phi                             1
    y_7       V7                              1
    y_8       Phi                             1
    y_8       V8                              1
    y_9       Phi                             1
    y_9       V9                              1
    y_10      Phi                             1
    y_10      V10                             1
    y_11      Phi                             1
    y_11      V11                             1
    y_12      Phi                             1
    y_12      V12                             1
    y_13      Phi                             1
    y_13      V13                             1
    y_14      Phi                             1
    y_14      V14                             1
    y_15      Phi                             1
    y_15      V15                             1
    y_17      Phi                             1
    y_17      V17                             1
    y_18      Phi                             1
    y_18      V18                             1
    y_19      Phi                             1
    y_19      V19                             1
    y_20      Phi                             1
    y_20      V20                             1
    y_21      Phi                             1
    y_21      V21                             1
    y_22      Phi                             1
    y_22      V22                             1
    y_23      Phi                             1
    y_23      V23                             1
    y_24      Phi                             1
    y_24      V24                             1
    y_25      Phi                             1
    y_25      V25                             1
    y_26      Phi                             1
    y_26      V26                             1
    y_27      Phi                             1
    y_27      V27                             1
    y_28      Phi                             1
    y_28      V28                             1
    y_29      Phi                             1
    y_29      V29                             1
    y_30      Phi                             1
    y_30      V30                             1
    y_31      Phi                             1
    y_31      V31                             1
    y_32      Phi                             1
    y_32      V32                             1
    y_33      Phi                             1
    y_33      V33                             1
    y_34      Phi                             1
    y_34      V34                             1
    y_35      Phi                             1
    y_35      V35                             1
    y_36      Phi                             1
    y_36      V36                             1
    y_37      Phi                             1
    y_37      V37                             1
    y_38      Phi                             1
    y_38      V38                             1
    y_39      Phi                             1
    y_39      V39                             1
    y_40      Phi                             1
    y_40      V40                             1
    y_41      Phi                             1
    y_41      V41                             1
    y_42      Phi                             1
    y_42      V42                             1
    y_43      Phi                             1
    y_43      V43                             1
    y_44      Phi                             1
    y_44      V44                             1
    y_45      Phi                             1
    y_45      V45                             1
    y_46      Phi                             1
    y_46      V46                             1
    y_47      Phi                             1
    y_47      V47                             1
    y_48      Phi                             1
    y_48      V48                             1
    y_49      Phi                             1
    y_49      V49                             1
    y_50      Phi                             1
    y_50      V50                             1
    y_51      Phi                             1
    y_51      V51                             1
    y_52      Phi                             1
    y_52      V52                             1
    y_53      Phi                             1
    y_53      V53                             1
    y_54      Phi                             1
    y_54      V54                             1
    y_55      Phi                             1
    y_55      V55                             1
    y_56      Phi                             1
    y_56      V56                             1
    y_57      Phi                             1
    y_57      V57                             1
    y_58      Phi                             1
    y_58      V58                             1
    y_59      Phi                             1
    y_59      V59                             1
    y_60      Phi                             1
    y_60      V60                             1
    y_61      Phi                             1
    y_61      V61                             1
    y_62      Phi                             1
    y_62      V62                             1
    y_63      Phi                             1
    y_63      V63                             1
    y_64      Phi                             1
    y_64      V64                             1
    y_65      Phi                             1
    y_65      V65                             1
    y_66      Phi                             1
    y_66      V66                             1
    y_67      Phi                             1
    y_67      V67                             1
    y_68      Phi                             1
    y_68      V68                             1
    y_69      Phi                             1
    y_69      V69                             1
    y_70      Phi                             1
    y_70      V70                             1
    y_71      Phi                             1
    y_71      V71                             1
    y_72      Phi                             1
    y_72      V72                             1
    y_73      Phi                             1
    y_73      V73                             1
    y_74      Phi                             1
    y_74      V74                             1
    y_75      Phi                             1
    y_75      V75                             1
    y_76      Phi                             1
    y_76      V76                             1
    y_77      Phi                             1
    y_77      V77                             1
    y_78      Phi                             1
    y_78      V78                             1
    y_79      Phi                             1
    y_79      V79                             1
    y_80      Phi                             1
    y_80      V80                             1
    x_2       Lambda                          1
    x_2       A10-2                          -1
    x_2       A74-2                          -1
    x_4       Lambda                          1
    x_4       A64-4                          -1
    x_5       Lambda                          1
    x_5       A6-5                           -1
    x_5       A23-5                          -1
    x_5       A43-5                          -1
    x_6       Lambda                          1
    x_6       A5-6                           -1
    x_6       A7-6                           -1
    x_6       A9-6                           -1
    x_7       Lambda                          1
    x_7       A6-7                           -1
    x_8       Lambda                          1
    x_8       A28-8                          -1
    x_8       A41-8                          -1
    x_9       Lambda                          1
    x_9       A6-9                           -1
    x_9       A14-9                          -1
    x_9       A19-9                          -1
    x_10      Lambda                          1
    x_10      A2-10                          -1
    x_10      A34-10                         -1
    x_11      Lambda                          1
    x_11      A12-11                         -1
    x_11      A44-11                         -1
    x_11      A75-11                         -1
    x_12      Lambda                          1
    x_12      A11-12                         -1
    x_13      Lambda                          1
    x_13      A22-13                         -1
    x_13      A33-13                         -1
    x_13      A61-13                         -1
    x_14      Lambda                          1
    x_14      A9-14                          -1
    x_14      A15-14                         -1
    x_14      A17-14                         -1
    x_14      A42-14                         -1
    x_15      Lambda                          1
    x_15      A14-15                         -1
    x_15      A38-15                         -1
    x_17      Lambda                          1
    x_17      A14-17                         -1
    x_17      A60-17                         -1
    x_18      Lambda                          1
    x_18      A20-18                         -1
    x_18      A32-18                         -1
    x_19      Lambda                          1
    x_19      A9-19                          -1
    x_19      A25-19                         -1
    x_19      A36-19                         -1
    x_19      A56-19                         -1
    x_19      A70-19                         -1
    x_20      Lambda                          1
    x_20      A18-20                         -1
    x_20      A39-20                         -1
    x_21      Lambda                          1
    x_21      A48-21                         -1
    x_22      Lambda                          1
    x_22      A13-22                         -1
    x_22      A45-22                         -1
    x_23      Lambda                          1
    x_23      A5-23                          -1
    x_23      A26-23                         -1
    x_23      A27-23                         -1
    x_23      A73-23                         -1
    x_24      Lambda                          1
    x_24      A59-24                         -1
    x_25      Lambda                          1
    x_25      A19-25                         -1
    x_25      A62-25                         -1
    x_25      A69-25                         -1
    x_26      Lambda                          1
    x_26      A23-26                         -1
    x_26      A30-26                         -1
    x_27      Lambda                          1
    x_27      A23-27                         -1
    x_28      Lambda                          1
    x_28      A8-28                          -1
    x_28      A29-28                         -1
    x_28      A31-28                         -1
    x_29      Lambda                          1
    x_29      A28-29                         -1
    x_30      Lambda                          1
    x_30      A26-30                         -1
    x_30      A72-30                         -1
    x_31      Lambda                          1
    x_31      A28-31                         -1
    x_31      A47-31                         -1
    x_31      A58-31                         -1
    x_31      A80-31                         -1
    x_32      Lambda                          1
    x_32      A18-32                         -1
    x_32      A46-32                         -1
    x_33      Lambda                          1
    x_33      A13-33                         -1
    x_34      Lambda                          1
    x_34      A10-34                         -1
    x_34      A35-34                         -1
    x_34      A37-34                         -1
    x_35      Lambda                          1
    x_35      A34-35                         -1
    x_36      Lambda                          1
    x_36      A19-36                         -1
    x_37      Lambda                          1
    x_37      A34-37                         -1
    x_38      Lambda                          1
    x_38      A15-38                         -1
    x_38      A63-38                         -1
    x_38      A77-38                         -1
    x_39      Lambda                          1
    x_39      A20-39                         -1
    x_40      Lambda                          1
    x_40      A52-40                         -1
    x_41      Lambda                          1
    x_41      A8-41                          -1
    x_41      A79-41                         -1
    x_42      Lambda                          1
    x_42      A14-42                         -1
    x_43      Lambda                          1
    x_43      A5-43                          -1
    x_43      A49-43                         -1
    x_44      Lambda                          1
    x_44      A11-44                         -1
    x_45      Lambda                          1
    x_45      A22-45                         -1
    x_46      Lambda                          1
    x_46      A32-46                         -1
    x_47      Lambda                          1
    x_47      A31-47                         -1
    x_48      Lambda                          1
    x_48      A21-48                         -1
    x_48      A68-48                         -1
    x_49      Lambda                          1
    x_49      A43-49                         -1
    x_49      A76-49                         -1
    x_50      Lambda                          1
    x_50      A51-50                         -1
    x_51      Lambda                          1
    x_51      A50-51                         -1
    x_51      A57-51                         -1
    x_52      Lambda                          1
    x_52      A40-52                         -1
    x_53      Lambda                          1
    x_54      Lambda                          1
    x_55      Lambda                          1
    x_55      A65-55                         -1
    x_56      Lambda                          1
    x_56      A19-56                         -1
    x_57      Lambda                          1
    x_57      A51-57                         -1
    x_58      Lambda                          1
    x_58      A31-58                         -1
    x_59      Lambda                          1
    x_59      A24-59                         -1
    x_59      A66-59                         -1
    x_60      Lambda                          1
    x_60      A17-60                         -1
    x_61      Lambda                          1
    x_61      A13-61                         -1
    x_62      Lambda                          1
    x_62      A25-62                         -1
    x_63      Lambda                          1
    x_63      A38-63                         -1
    x_64      Lambda                          1
    x_64      A4-64                          -1
    x_64      A67-64                         -1
    x_64      A78-64                         -1
    x_65      Lambda                          1
    x_65      A55-65                         -1
    x_66      Lambda                          1
    x_66      A59-66                         -1
    x_67      Lambda                          1
    x_67      A64-67                         -1
    x_68      Lambda                          1
    x_68      A48-68                         -1
    x_69      Lambda                          1
    x_69      A25-69                         -1
    x_70      Lambda                          1
    x_70      A19-70                         -1
    x_70      A71-70                         -1
    x_71      Lambda                          1
    x_71      A70-71                         -1
    x_72      Lambda                          1
    x_72      A30-72                         -1
    x_73      Lambda                          1
    x_73      A23-73                         -1
    x_74      Lambda                          1
    x_74      A2-74                          -1
    x_75      Lambda                          1
    x_75      A11-75                         -1
    x_76      Lambda                          1
    x_76      A49-76                         -1
    x_77      Lambda                          1
    x_77      A38-77                         -1
    x_78      Lambda                          1
    x_78      A64-78                         -1
    x_79      Lambda                          1
    x_79      A41-79                         -1
    x_80      Lambda                          1
    x_80      A31-80                         -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       Phi                             3
    rhs       Lambda                          3
    rhs       V2                              1
    rhs       V4                              1
    rhs       V5                              1
    rhs       V6                              1
    rhs       V7                              1
    rhs       V8                              1
    rhs       V9                              1
    rhs       V10                             1
    rhs       V11                             1
    rhs       V12                             1
    rhs       V13                             1
    rhs       V14                             1
    rhs       V15                             1
    rhs       V17                             1
    rhs       V18                             1
    rhs       V19                             1
    rhs       V20                             1
    rhs       V21                             1
    rhs       V22                             1
    rhs       V23                             1
    rhs       V24                             1
    rhs       V25                             1
    rhs       V26                             1
    rhs       V27                             1
    rhs       V28                             1
    rhs       V29                             1
    rhs       V30                             1
    rhs       V31                             1
    rhs       V32                             1
    rhs       V33                             1
    rhs       V34                             1
    rhs       V35                             1
    rhs       V36                             1
    rhs       V37                             1
    rhs       V38                             1
    rhs       V39                             1
    rhs       V40                             1
    rhs       V41                             1
    rhs       V42                             1
    rhs       V43                             1
    rhs       V44                             1
    rhs       V45                             1
    rhs       V46                             1
    rhs       V47                             1
    rhs       V48                             1
    rhs       V49                             1
    rhs       V50                             1
    rhs       V51                             1
    rhs       V52                             1
    rhs       V53                             1
    rhs       V54                             1
    rhs       V55                             1
    rhs       V56                             1
    rhs       V57                             1
    rhs       V58                             1
    rhs       V59                             1
    rhs       V60                             1
    rhs       V61                             1
    rhs       V62                             1
    rhs       V63                             1
    rhs       V64                             1
    rhs       V65                             1
    rhs       V66                             1
    rhs       V67                             1
    rhs       V68                             1
    rhs       V69                             1
    rhs       V70                             1
    rhs       V71                             1
    rhs       V72                             1
    rhs       V73                             1
    rhs       V74                             1
    rhs       V75                             1
    rhs       V76                             1
    rhs       V77                             1
    rhs       V78                             1
    rhs       V79                             1
    rhs       V80                             1
BOUNDS
 BV bnd       a_2     
 BV bnd       a_4     
 BV bnd       a_5     
 BV bnd       a_6     
 BV bnd       a_7     
 BV bnd       a_8     
 BV bnd       a_9     
 BV bnd       a_10    
 BV bnd       a_11    
 BV bnd       a_12    
 BV bnd       a_13    
 BV bnd       a_14    
 BV bnd       a_15    
 BV bnd       a_17    
 BV bnd       a_18    
 BV bnd       a_19    
 BV bnd       a_20    
 BV bnd       a_21    
 BV bnd       a_22    
 BV bnd       a_23    
 BV bnd       a_24    
 BV bnd       a_25    
 BV bnd       a_26    
 BV bnd       a_27    
 BV bnd       a_28    
 BV bnd       a_29    
 BV bnd       a_30    
 BV bnd       a_31    
 BV bnd       a_32    
 BV bnd       a_33    
 BV bnd       a_34    
 BV bnd       a_35    
 BV bnd       a_36    
 BV bnd       a_37    
 BV bnd       a_38    
 BV bnd       a_39    
 BV bnd       a_40    
 BV bnd       a_41    
 BV bnd       a_42    
 BV bnd       a_43    
 BV bnd       a_44    
 BV bnd       a_45    
 BV bnd       a_46    
 BV bnd       a_47    
 BV bnd       a_48    
 BV bnd       a_49    
 BV bnd       a_50    
 BV bnd       a_51    
 BV bnd       a_52    
 BV bnd       a_53    
 BV bnd       a_54    
 BV bnd       a_55    
 BV bnd       a_56    
 BV bnd       a_57    
 BV bnd       a_58    
 BV bnd       a_59    
 BV bnd       a_60    
 BV bnd       a_61    
 BV bnd       a_62    
 BV bnd       a_63    
 BV bnd       a_64    
 BV bnd       a_65    
 BV bnd       a_66    
 BV bnd       a_67    
 BV bnd       a_68    
 BV bnd       a_69    
 BV bnd       a_70    
 BV bnd       a_71    
 BV bnd       a_72    
 BV bnd       a_73    
 BV bnd       a_74    
 BV bnd       a_75    
 BV bnd       a_76    
 BV bnd       a_77    
 BV bnd       a_78    
 BV bnd       a_79    
 BV bnd       a_80    
 BV bnd       y_2     
 BV bnd       y_4     
 BV bnd       y_5     
 BV bnd       y_6     
 BV bnd       y_7     
 BV bnd       y_8     
 BV bnd       y_9     
 BV bnd       y_10    
 BV bnd       y_11    
 BV bnd       y_12    
 BV bnd       y_13    
 BV bnd       y_14    
 BV bnd       y_15    
 BV bnd       y_17    
 BV bnd       y_18    
 BV bnd       y_19    
 BV bnd       y_20    
 BV bnd       y_21    
 BV bnd       y_22    
 BV bnd       y_23    
 BV bnd       y_24    
 BV bnd       y_25    
 BV bnd       y_26    
 BV bnd       y_27    
 BV bnd       y_28    
 BV bnd       y_29    
 BV bnd       y_30    
 BV bnd       y_31    
 BV bnd       y_32    
 BV bnd       y_33    
 BV bnd       y_34    
 BV bnd       y_35    
 BV bnd       y_36    
 BV bnd       y_37    
 BV bnd       y_38    
 BV bnd       y_39    
 BV bnd       y_40    
 BV bnd       y_41    
 BV bnd       y_42    
 BV bnd       y_43    
 BV bnd       y_44    
 BV bnd       y_45    
 BV bnd       y_46    
 BV bnd       y_47    
 BV bnd       y_48    
 BV bnd       y_49    
 BV bnd       y_50    
 BV bnd       y_51    
 BV bnd       y_52    
 BV bnd       y_53    
 BV bnd       y_54    
 BV bnd       y_55    
 BV bnd       y_56    
 BV bnd       y_57    
 BV bnd       y_58    
 BV bnd       y_59    
 BV bnd       y_60    
 BV bnd       y_61    
 BV bnd       y_62    
 BV bnd       y_63    
 BV bnd       y_64    
 BV bnd       y_65    
 BV bnd       y_66    
 BV bnd       y_67    
 BV bnd       y_68    
 BV bnd       y_69    
 BV bnd       y_70    
 BV bnd       y_71    
 BV bnd       y_72    
 BV bnd       y_73    
 BV bnd       y_74    
 BV bnd       y_75    
 BV bnd       y_76    
 BV bnd       y_77    
 BV bnd       y_78    
 BV bnd       y_79    
 BV bnd       y_80    
 BV bnd       x_2     
 BV bnd       x_4     
 BV bnd       x_5     
 BV bnd       x_6     
 BV bnd       x_7     
 BV bnd       x_8     
 BV bnd       x_9     
 BV bnd       x_10    
 BV bnd       x_11    
 BV bnd       x_12    
 BV bnd       x_13    
 BV bnd       x_14    
 BV bnd       x_15    
 BV bnd       x_17    
 BV bnd       x_18    
 BV bnd       x_19    
 BV bnd       x_20    
 BV bnd       x_21    
 BV bnd       x_22    
 BV bnd       x_23    
 BV bnd       x_24    
 BV bnd       x_25    
 BV bnd       x_26    
 BV bnd       x_27    
 BV bnd       x_28    
 BV bnd       x_29    
 BV bnd       x_30    
 BV bnd       x_31    
 BV bnd       x_32    
 BV bnd       x_33    
 BV bnd       x_34    
 BV bnd       x_35    
 BV bnd       x_36    
 BV bnd       x_37    
 BV bnd       x_38    
 BV bnd       x_39    
 BV bnd       x_40    
 BV bnd       x_41    
 BV bnd       x_42    
 BV bnd       x_43    
 BV bnd       x_44    
 BV bnd       x_45    
 BV bnd       x_46    
 BV bnd       x_47    
 BV bnd       x_48    
 BV bnd       x_49    
 BV bnd       x_50    
 BV bnd       x_51    
 BV bnd       x_52    
 BV bnd       x_53    
 BV bnd       x_54    
 BV bnd       x_55    
 BV bnd       x_56    
 BV bnd       x_57    
 BV bnd       x_58    
 BV bnd       x_59    
 BV bnd       x_60    
 BV bnd       x_61    
 BV bnd       x_62    
 BV bnd       x_63    
 BV bnd       x_64    
 BV bnd       x_65    
 BV bnd       x_66    
 BV bnd       x_67    
 BV bnd       x_68    
 BV bnd       x_69    
 BV bnd       x_70    
 BV bnd       x_71    
 BV bnd       x_72    
 BV bnd       x_73    
 BV bnd       x_74    
 BV bnd       x_75    
 BV bnd       x_76    
 BV bnd       x_77    
 BV bnd       x_78    
 BV bnd       x_79    
 BV bnd       x_80    
ENDATA
