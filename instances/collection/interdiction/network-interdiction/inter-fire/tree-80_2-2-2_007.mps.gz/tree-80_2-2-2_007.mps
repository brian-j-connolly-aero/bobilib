* ENCODING=ISO-8859-1
NAME          tree-80_2-2-2_007
ROWS
 N  obj     
 L  Phi     
 L  Lambda  
 L  V1      
 L  V4      
 L  V5      
 L  V6      
 L  V7      
 L  V8      
 L  V9      
 L  V10     
 L  V11     
 L  V12     
 L  V13     
 L  V14     
 L  V15     
 L  V16     
 L  V17     
 L  V18     
 L  V19     
 L  V20     
 L  V21     
 L  V22     
 L  V23     
 L  V24     
 L  V25     
 L  V26     
 L  V27     
 L  V28     
 L  V29     
 L  V30     
 L  V31     
 L  V32     
 L  V33     
 L  V34     
 L  V35     
 L  V36     
 L  V37     
 L  V38     
 L  V39     
 L  V40     
 L  V41     
 L  V42     
 L  V43     
 L  V44     
 L  V45     
 L  V46     
 L  V47     
 L  V48     
 L  V49     
 L  V50     
 L  V51     
 L  V52     
 L  V53     
 L  V54     
 L  V55     
 L  V56     
 L  V57     
 L  V58     
 L  V59     
 L  V60     
 L  V61     
 L  V62     
 L  V63     
 L  V64     
 L  V65     
 L  V66     
 L  V67     
 L  V68     
 L  V69     
 L  V70     
 L  V71     
 L  V72     
 L  V73     
 L  V74     
 L  V75     
 L  V76     
 L  V77     
 L  V78     
 L  V79     
 L  V80     
 L  A8-1    
 L  A1-8    
 L  A9-5    
 L  A5-9    
 L  A13-10  
 L  A10-13  
 L  A15-11  
 L  A11-15  
 L  A18-16  
 L  A16-18  
 L  A20-5   
 L  A5-20   
 L  A21-10  
 L  A10-21  
 L  A22-20  
 L  A20-22  
 L  A23-6   
 L  A6-23   
 L  A24-9   
 L  A9-24   
 L  A25-16  
 L  A16-25  
 L  A26-13  
 L  A13-26  
 L  A27-9   
 L  A9-27   
 L  A28-26  
 L  A26-28  
 L  A29-5   
 L  A5-29   
 L  A30-13  
 L  A13-30  
 L  A31-7   
 L  A7-31   
 L  A33-12  
 L  A12-33  
 L  A34-4   
 L  A4-34   
 L  A35-8   
 L  A8-35   
 L  A36-18  
 L  A18-36  
 L  A37-4   
 L  A4-37   
 L  A38-4   
 L  A4-38   
 L  A39-32  
 L  A32-39  
 L  A40-13  
 L  A13-40  
 L  A41-22  
 L  A22-41  
 L  A42-41  
 L  A41-42  
 L  A43-38  
 L  A38-43  
 L  A44-1   
 L  A1-44   
 L  A45-32  
 L  A32-45  
 L  A46-19  
 L  A19-46  
 L  A47-31  
 L  A31-47  
 L  A48-47  
 L  A47-48  
 L  A49-28  
 L  A28-49  
 L  A50-8   
 L  A8-50   
 L  A51-47  
 L  A47-51  
 L  A52-29  
 L  A29-52  
 L  A53-21  
 L  A21-53  
 L  A54-20  
 L  A20-54  
 L  A55-52  
 L  A52-55  
 L  A56-32  
 L  A32-56  
 L  A57-53  
 L  A53-57  
 L  A58-21  
 L  A21-58  
 L  A59-16  
 L  A16-59  
 L  A60-58  
 L  A58-60  
 L  A61-40  
 L  A40-61  
 L  A62-58  
 L  A58-62  
 L  A63-36  
 L  A36-63  
 L  A64-4   
 L  A4-64   
 L  A65-13  
 L  A13-65  
 L  A66-58  
 L  A58-66  
 L  A67-32  
 L  A32-67  
 L  A68-42  
 L  A42-68  
 L  A69-41  
 L  A41-69  
 L  A70-59  
 L  A59-70  
 L  A71-43  
 L  A43-71  
 L  A72-45  
 L  A45-72  
 L  A73-44  
 L  A44-73  
 L  A74-21  
 L  A21-74  
 L  A75-48  
 L  A48-75  
 L  A76-70  
 L  A70-76  
 L  A77-60  
 L  A60-77  
 L  A78-28  
 L  A28-78  
 L  A79-52  
 L  A52-79  
 L  A80-35  
 L  A35-80  
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    a_1       obj                             1
    a_1       V1                              1
    a_1       A8-1                            1
    a_1       A1-8                           -1
    a_1       A44-1                           1
    a_1       A1-44                          -1
    a_4       obj                             1
    a_4       V4                              1
    a_4       A34-4                           1
    a_4       A4-34                          -1
    a_4       A37-4                           1
    a_4       A4-37                          -1
    a_4       A38-4                           1
    a_4       A4-38                          -1
    a_4       A64-4                           1
    a_4       A4-64                          -1
    a_5       obj                             1
    a_5       V5                              1
    a_5       A9-5                            1
    a_5       A5-9                           -1
    a_5       A20-5                           1
    a_5       A5-20                          -1
    a_5       A29-5                           1
    a_5       A5-29                          -1
    a_6       obj                             1
    a_6       V6                              1
    a_6       A23-6                           1
    a_6       A6-23                          -1
    a_7       obj                             1
    a_7       V7                              1
    a_7       A31-7                           1
    a_7       A7-31                          -1
    a_8       obj                             1
    a_8       V8                              1
    a_8       A8-1                           -1
    a_8       A1-8                            1
    a_8       A35-8                           1
    a_8       A8-35                          -1
    a_8       A50-8                           1
    a_8       A8-50                          -1
    a_9       obj                             1
    a_9       V9                              1
    a_9       A9-5                           -1
    a_9       A5-9                            1
    a_9       A24-9                           1
    a_9       A9-24                          -1
    a_9       A27-9                           1
    a_9       A9-27                          -1
    a_10      obj                             1
    a_10      V10                             1
    a_10      A13-10                          1
    a_10      A10-13                         -1
    a_10      A21-10                          1
    a_10      A10-21                         -1
    a_11      obj                             1
    a_11      V11                             1
    a_11      A15-11                          1
    a_11      A11-15                         -1
    a_12      obj                             1
    a_12      V12                             1
    a_12      A33-12                          1
    a_12      A12-33                         -1
    a_13      obj                             1
    a_13      V13                             1
    a_13      A13-10                         -1
    a_13      A10-13                          1
    a_13      A26-13                          1
    a_13      A13-26                         -1
    a_13      A30-13                          1
    a_13      A13-30                         -1
    a_13      A40-13                          1
    a_13      A13-40                         -1
    a_13      A65-13                          1
    a_13      A13-65                         -1
    a_14      obj                             1
    a_14      V14                             1
    a_15      obj                             1
    a_15      V15                             1
    a_15      A15-11                         -1
    a_15      A11-15                          1
    a_16      obj                             1
    a_16      V16                             1
    a_16      A18-16                          1
    a_16      A16-18                         -1
    a_16      A25-16                          1
    a_16      A16-25                         -1
    a_16      A59-16                          1
    a_16      A16-59                         -1
    a_17      obj                             1
    a_17      V17                             1
    a_18      obj                             1
    a_18      V18                             1
    a_18      A18-16                         -1
    a_18      A16-18                          1
    a_18      A36-18                          1
    a_18      A18-36                         -1
    a_19      obj                             1
    a_19      V19                             1
    a_19      A46-19                          1
    a_19      A19-46                         -1
    a_20      obj                             1
    a_20      V20                             1
    a_20      A20-5                          -1
    a_20      A5-20                           1
    a_20      A22-20                          1
    a_20      A20-22                         -1
    a_20      A54-20                          1
    a_20      A20-54                         -1
    a_21      obj                             1
    a_21      V21                             1
    a_21      A21-10                         -1
    a_21      A10-21                          1
    a_21      A53-21                          1
    a_21      A21-53                         -1
    a_21      A58-21                          1
    a_21      A21-58                         -1
    a_21      A74-21                          1
    a_21      A21-74                         -1
    a_22      obj                             1
    a_22      V22                             1
    a_22      A22-20                         -1
    a_22      A20-22                          1
    a_22      A41-22                          1
    a_22      A22-41                         -1
    a_23      obj                             1
    a_23      V23                             1
    a_23      A23-6                          -1
    a_23      A6-23                           1
    a_24      obj                             1
    a_24      V24                             1
    a_24      A24-9                          -1
    a_24      A9-24                           1
    a_25      obj                             1
    a_25      V25                             1
    a_25      A25-16                         -1
    a_25      A16-25                          1
    a_26      obj                             1
    a_26      V26                             1
    a_26      A26-13                         -1
    a_26      A13-26                          1
    a_26      A28-26                          1
    a_26      A26-28                         -1
    a_27      obj                             1
    a_27      V27                             1
    a_27      A27-9                          -1
    a_27      A9-27                           1
    a_28      obj                             1
    a_28      V28                             1
    a_28      A28-26                         -1
    a_28      A26-28                          1
    a_28      A49-28                          1
    a_28      A28-49                         -1
    a_28      A78-28                          1
    a_28      A28-78                         -1
    a_29      obj                             1
    a_29      V29                             1
    a_29      A29-5                          -1
    a_29      A5-29                           1
    a_29      A52-29                          1
    a_29      A29-52                         -1
    a_30      obj                             1
    a_30      V30                             1
    a_30      A30-13                         -1
    a_30      A13-30                          1
    a_31      obj                             1
    a_31      V31                             1
    a_31      A31-7                          -1
    a_31      A7-31                           1
    a_31      A47-31                          1
    a_31      A31-47                         -1
    a_32      obj                             1
    a_32      V32                             1
    a_32      A39-32                          1
    a_32      A32-39                         -1
    a_32      A45-32                          1
    a_32      A32-45                         -1
    a_32      A56-32                          1
    a_32      A32-56                         -1
    a_32      A67-32                          1
    a_32      A32-67                         -1
    a_33      obj                             1
    a_33      V33                             1
    a_33      A33-12                         -1
    a_33      A12-33                          1
    a_34      obj                             1
    a_34      V34                             1
    a_34      A34-4                          -1
    a_34      A4-34                           1
    a_35      obj                             1
    a_35      V35                             1
    a_35      A35-8                          -1
    a_35      A8-35                           1
    a_35      A80-35                          1
    a_35      A35-80                         -1
    a_36      obj                             1
    a_36      V36                             1
    a_36      A36-18                         -1
    a_36      A18-36                          1
    a_36      A63-36                          1
    a_36      A36-63                         -1
    a_37      obj                             1
    a_37      V37                             1
    a_37      A37-4                          -1
    a_37      A4-37                           1
    a_38      obj                             1
    a_38      V38                             1
    a_38      A38-4                          -1
    a_38      A4-38                           1
    a_38      A43-38                          1
    a_38      A38-43                         -1
    a_39      obj                             1
    a_39      V39                             1
    a_39      A39-32                         -1
    a_39      A32-39                          1
    a_40      obj                             1
    a_40      V40                             1
    a_40      A40-13                         -1
    a_40      A13-40                          1
    a_40      A61-40                          1
    a_40      A40-61                         -1
    a_41      obj                             1
    a_41      V41                             1
    a_41      A41-22                         -1
    a_41      A22-41                          1
    a_41      A42-41                          1
    a_41      A41-42                         -1
    a_41      A69-41                          1
    a_41      A41-69                         -1
    a_42      obj                             1
    a_42      V42                             1
    a_42      A42-41                         -1
    a_42      A41-42                          1
    a_42      A68-42                          1
    a_42      A42-68                         -1
    a_43      obj                             1
    a_43      V43                             1
    a_43      A43-38                         -1
    a_43      A38-43                          1
    a_43      A71-43                          1
    a_43      A43-71                         -1
    a_44      obj                             1
    a_44      V44                             1
    a_44      A44-1                          -1
    a_44      A1-44                           1
    a_44      A73-44                          1
    a_44      A44-73                         -1
    a_45      obj                             1
    a_45      V45                             1
    a_45      A45-32                         -1
    a_45      A32-45                          1
    a_45      A72-45                          1
    a_45      A45-72                         -1
    a_46      obj                             1
    a_46      V46                             1
    a_46      A46-19                         -1
    a_46      A19-46                          1
    a_47      obj                             1
    a_47      V47                             1
    a_47      A47-31                         -1
    a_47      A31-47                          1
    a_47      A48-47                          1
    a_47      A47-48                         -1
    a_47      A51-47                          1
    a_47      A47-51                         -1
    a_48      obj                             1
    a_48      V48                             1
    a_48      A48-47                         -1
    a_48      A47-48                          1
    a_48      A75-48                          1
    a_48      A48-75                         -1
    a_49      obj                             1
    a_49      V49                             1
    a_49      A49-28                         -1
    a_49      A28-49                          1
    a_50      obj                             1
    a_50      V50                             1
    a_50      A50-8                          -1
    a_50      A8-50                           1
    a_51      obj                             1
    a_51      V51                             1
    a_51      A51-47                         -1
    a_51      A47-51                          1
    a_52      obj                             1
    a_52      V52                             1
    a_52      A52-29                         -1
    a_52      A29-52                          1
    a_52      A55-52                          1
    a_52      A52-55                         -1
    a_52      A79-52                          1
    a_52      A52-79                         -1
    a_53      obj                             1
    a_53      V53                             1
    a_53      A53-21                         -1
    a_53      A21-53                          1
    a_53      A57-53                          1
    a_53      A53-57                         -1
    a_54      obj                             1
    a_54      V54                             1
    a_54      A54-20                         -1
    a_54      A20-54                          1
    a_55      obj                             1
    a_55      V55                             1
    a_55      A55-52                         -1
    a_55      A52-55                          1
    a_56      obj                             1
    a_56      V56                             1
    a_56      A56-32                         -1
    a_56      A32-56                          1
    a_57      obj                             1
    a_57      V57                             1
    a_57      A57-53                         -1
    a_57      A53-57                          1
    a_58      obj                             1
    a_58      V58                             1
    a_58      A58-21                         -1
    a_58      A21-58                          1
    a_58      A60-58                          1
    a_58      A58-60                         -1
    a_58      A62-58                          1
    a_58      A58-62                         -1
    a_58      A66-58                          1
    a_58      A58-66                         -1
    a_59      obj                             1
    a_59      V59                             1
    a_59      A59-16                         -1
    a_59      A16-59                          1
    a_59      A70-59                          1
    a_59      A59-70                         -1
    a_60      obj                             1
    a_60      V60                             1
    a_60      A60-58                         -1
    a_60      A58-60                          1
    a_60      A77-60                          1
    a_60      A60-77                         -1
    a_61      obj                             1
    a_61      V61                             1
    a_61      A61-40                         -1
    a_61      A40-61                          1
    a_62      obj                             1
    a_62      V62                             1
    a_62      A62-58                         -1
    a_62      A58-62                          1
    a_63      obj                             1
    a_63      V63                             1
    a_63      A63-36                         -1
    a_63      A36-63                          1
    a_64      obj                             1
    a_64      V64                             1
    a_64      A64-4                          -1
    a_64      A4-64                           1
    a_65      obj                             1
    a_65      V65                             1
    a_65      A65-13                         -1
    a_65      A13-65                          1
    a_66      obj                             1
    a_66      V66                             1
    a_66      A66-58                         -1
    a_66      A58-66                          1
    a_67      obj                             1
    a_67      V67                             1
    a_67      A67-32                         -1
    a_67      A32-67                          1
    a_68      obj                             1
    a_68      V68                             1
    a_68      A68-42                         -1
    a_68      A42-68                          1
    a_69      obj                             1
    a_69      V69                             1
    a_69      A69-41                         -1
    a_69      A41-69                          1
    a_70      obj                             1
    a_70      V70                             1
    a_70      A70-59                         -1
    a_70      A59-70                          1
    a_70      A76-70                          1
    a_70      A70-76                         -1
    a_71      obj                             1
    a_71      V71                             1
    a_71      A71-43                         -1
    a_71      A43-71                          1
    a_72      obj                             1
    a_72      V72                             1
    a_72      A72-45                         -1
    a_72      A45-72                          1
    a_73      obj                             1
    a_73      V73                             1
    a_73      A73-44                         -1
    a_73      A44-73                          1
    a_74      obj                             1
    a_74      V74                             1
    a_74      A74-21                         -1
    a_74      A21-74                          1
    a_75      obj                             1
    a_75      V75                             1
    a_75      A75-48                         -1
    a_75      A48-75                          1
    a_76      obj                             1
    a_76      V76                             1
    a_76      A76-70                         -1
    a_76      A70-76                          1
    a_77      obj                             1
    a_77      V77                             1
    a_77      A77-60                         -1
    a_77      A60-77                          1
    a_78      obj                             1
    a_78      V78                             1
    a_78      A78-28                         -1
    a_78      A28-78                          1
    a_79      obj                             1
    a_79      V79                             1
    a_79      A79-52                         -1
    a_79      A52-79                          1
    a_80      obj                             1
    a_80      V80                             1
    a_80      A80-35                         -1
    a_80      A35-80                          1
    y_1       Phi                             1
    y_1       V1                              1
    y_4       Phi                             1
    y_4       V4                              1
    y_5       Phi                             1
    y_5       V5                              1
    y_6       Phi                             1
    y_6       V6                              1
    y_7       Phi                             1
    y_7       V7                              1
    y_8       Phi                             1
    y_8       V8                              1
    y_9       Phi                             1
    y_9       V9                              1
    y_10      Phi                             1
    y_10      V10                             1
    y_11      Phi                             1
    y_11      V11                             1
    y_12      Phi                             1
    y_12      V12                             1
    y_13      Phi                             1
    y_13      V13                             1
    y_14      Phi                             1
    y_14      V14                             1
    y_15      Phi                             1
    y_15      V15                             1
    y_16      Phi                             1
    y_16      V16                             1
    y_17      Phi                             1
    y_17      V17                             1
    y_18      Phi                             1
    y_18      V18                             1
    y_19      Phi                             1
    y_19      V19                             1
    y_20      Phi                             1
    y_20      V20                             1
    y_21      Phi                             1
    y_21      V21                             1
    y_22      Phi                             1
    y_22      V22                             1
    y_23      Phi                             1
    y_23      V23                             1
    y_24      Phi                             1
    y_24      V24                             1
    y_25      Phi                             1
    y_25      V25                             1
    y_26      Phi                             1
    y_26      V26                             1
    y_27      Phi                             1
    y_27      V27                             1
    y_28      Phi                             1
    y_28      V28                             1
    y_29      Phi                             1
    y_29      V29                             1
    y_30      Phi                             1
    y_30      V30                             1
    y_31      Phi                             1
    y_31      V31                             1
    y_32      Phi                             1
    y_32      V32                             1
    y_33      Phi                             1
    y_33      V33                             1
    y_34      Phi                             1
    y_34      V34                             1
    y_35      Phi                             1
    y_35      V35                             1
    y_36      Phi                             1
    y_36      V36                             1
    y_37      Phi                             1
    y_37      V37                             1
    y_38      Phi                             1
    y_38      V38                             1
    y_39      Phi                             1
    y_39      V39                             1
    y_40      Phi                             1
    y_40      V40                             1
    y_41      Phi                             1
    y_41      V41                             1
    y_42      Phi                             1
    y_42      V42                             1
    y_43      Phi                             1
    y_43      V43                             1
    y_44      Phi                             1
    y_44      V44                             1
    y_45      Phi                             1
    y_45      V45                             1
    y_46      Phi                             1
    y_46      V46                             1
    y_47      Phi                             1
    y_47      V47                             1
    y_48      Phi                             1
    y_48      V48                             1
    y_49      Phi                             1
    y_49      V49                             1
    y_50      Phi                             1
    y_50      V50                             1
    y_51      Phi                             1
    y_51      V51                             1
    y_52      Phi                             1
    y_52      V52                             1
    y_53      Phi                             1
    y_53      V53                             1
    y_54      Phi                             1
    y_54      V54                             1
    y_55      Phi                             1
    y_55      V55                             1
    y_56      Phi                             1
    y_56      V56                             1
    y_57      Phi                             1
    y_57      V57                             1
    y_58      Phi                             1
    y_58      V58                             1
    y_59      Phi                             1
    y_59      V59                             1
    y_60      Phi                             1
    y_60      V60                             1
    y_61      Phi                             1
    y_61      V61                             1
    y_62      Phi                             1
    y_62      V62                             1
    y_63      Phi                             1
    y_63      V63                             1
    y_64      Phi                             1
    y_64      V64                             1
    y_65      Phi                             1
    y_65      V65                             1
    y_66      Phi                             1
    y_66      V66                             1
    y_67      Phi                             1
    y_67      V67                             1
    y_68      Phi                             1
    y_68      V68                             1
    y_69      Phi                             1
    y_69      V69                             1
    y_70      Phi                             1
    y_70      V70                             1
    y_71      Phi                             1
    y_71      V71                             1
    y_72      Phi                             1
    y_72      V72                             1
    y_73      Phi                             1
    y_73      V73                             1
    y_74      Phi                             1
    y_74      V74                             1
    y_75      Phi                             1
    y_75      V75                             1
    y_76      Phi                             1
    y_76      V76                             1
    y_77      Phi                             1
    y_77      V77                             1
    y_78      Phi                             1
    y_78      V78                             1
    y_79      Phi                             1
    y_79      V79                             1
    y_80      Phi                             1
    y_80      V80                             1
    x_1       Lambda                          1
    x_1       A8-1                           -1
    x_1       A44-1                          -1
    x_4       Lambda                          1
    x_4       A34-4                          -1
    x_4       A37-4                          -1
    x_4       A38-4                          -1
    x_4       A64-4                          -1
    x_5       Lambda                          1
    x_5       A9-5                           -1
    x_5       A20-5                          -1
    x_5       A29-5                          -1
    x_6       Lambda                          1
    x_6       A23-6                          -1
    x_7       Lambda                          1
    x_7       A31-7                          -1
    x_8       Lambda                          1
    x_8       A1-8                           -1
    x_8       A35-8                          -1
    x_8       A50-8                          -1
    x_9       Lambda                          1
    x_9       A5-9                           -1
    x_9       A24-9                          -1
    x_9       A27-9                          -1
    x_10      Lambda                          1
    x_10      A13-10                         -1
    x_10      A21-10                         -1
    x_11      Lambda                          1
    x_11      A15-11                         -1
    x_12      Lambda                          1
    x_12      A33-12                         -1
    x_13      Lambda                          1
    x_13      A10-13                         -1
    x_13      A26-13                         -1
    x_13      A30-13                         -1
    x_13      A40-13                         -1
    x_13      A65-13                         -1
    x_14      Lambda                          1
    x_15      Lambda                          1
    x_15      A11-15                         -1
    x_16      Lambda                          1
    x_16      A18-16                         -1
    x_16      A25-16                         -1
    x_16      A59-16                         -1
    x_17      Lambda                          1
    x_18      Lambda                          1
    x_18      A16-18                         -1
    x_18      A36-18                         -1
    x_19      Lambda                          1
    x_19      A46-19                         -1
    x_20      Lambda                          1
    x_20      A5-20                          -1
    x_20      A22-20                         -1
    x_20      A54-20                         -1
    x_21      Lambda                          1
    x_21      A10-21                         -1
    x_21      A53-21                         -1
    x_21      A58-21                         -1
    x_21      A74-21                         -1
    x_22      Lambda                          1
    x_22      A20-22                         -1
    x_22      A41-22                         -1
    x_23      Lambda                          1
    x_23      A6-23                          -1
    x_24      Lambda                          1
    x_24      A9-24                          -1
    x_25      Lambda                          1
    x_25      A16-25                         -1
    x_26      Lambda                          1
    x_26      A13-26                         -1
    x_26      A28-26                         -1
    x_27      Lambda                          1
    x_27      A9-27                          -1
    x_28      Lambda                          1
    x_28      A26-28                         -1
    x_28      A49-28                         -1
    x_28      A78-28                         -1
    x_29      Lambda                          1
    x_29      A5-29                          -1
    x_29      A52-29                         -1
    x_30      Lambda                          1
    x_30      A13-30                         -1
    x_31      Lambda                          1
    x_31      A7-31                          -1
    x_31      A47-31                         -1
    x_32      Lambda                          1
    x_32      A39-32                         -1
    x_32      A45-32                         -1
    x_32      A56-32                         -1
    x_32      A67-32                         -1
    x_33      Lambda                          1
    x_33      A12-33                         -1
    x_34      Lambda                          1
    x_34      A4-34                          -1
    x_35      Lambda                          1
    x_35      A8-35                          -1
    x_35      A80-35                         -1
    x_36      Lambda                          1
    x_36      A18-36                         -1
    x_36      A63-36                         -1
    x_37      Lambda                          1
    x_37      A4-37                          -1
    x_38      Lambda                          1
    x_38      A4-38                          -1
    x_38      A43-38                         -1
    x_39      Lambda                          1
    x_39      A32-39                         -1
    x_40      Lambda                          1
    x_40      A13-40                         -1
    x_40      A61-40                         -1
    x_41      Lambda                          1
    x_41      A22-41                         -1
    x_41      A42-41                         -1
    x_41      A69-41                         -1
    x_42      Lambda                          1
    x_42      A41-42                         -1
    x_42      A68-42                         -1
    x_43      Lambda                          1
    x_43      A38-43                         -1
    x_43      A71-43                         -1
    x_44      Lambda                          1
    x_44      A1-44                          -1
    x_44      A73-44                         -1
    x_45      Lambda                          1
    x_45      A32-45                         -1
    x_45      A72-45                         -1
    x_46      Lambda                          1
    x_46      A19-46                         -1
    x_47      Lambda                          1
    x_47      A31-47                         -1
    x_47      A48-47                         -1
    x_47      A51-47                         -1
    x_48      Lambda                          1
    x_48      A47-48                         -1
    x_48      A75-48                         -1
    x_49      Lambda                          1
    x_49      A28-49                         -1
    x_50      Lambda                          1
    x_50      A8-50                          -1
    x_51      Lambda                          1
    x_51      A47-51                         -1
    x_52      Lambda                          1
    x_52      A29-52                         -1
    x_52      A55-52                         -1
    x_52      A79-52                         -1
    x_53      Lambda                          1
    x_53      A21-53                         -1
    x_53      A57-53                         -1
    x_54      Lambda                          1
    x_54      A20-54                         -1
    x_55      Lambda                          1
    x_55      A52-55                         -1
    x_56      Lambda                          1
    x_56      A32-56                         -1
    x_57      Lambda                          1
    x_57      A53-57                         -1
    x_58      Lambda                          1
    x_58      A21-58                         -1
    x_58      A60-58                         -1
    x_58      A62-58                         -1
    x_58      A66-58                         -1
    x_59      Lambda                          1
    x_59      A16-59                         -1
    x_59      A70-59                         -1
    x_60      Lambda                          1
    x_60      A58-60                         -1
    x_60      A77-60                         -1
    x_61      Lambda                          1
    x_61      A40-61                         -1
    x_62      Lambda                          1
    x_62      A58-62                         -1
    x_63      Lambda                          1
    x_63      A36-63                         -1
    x_64      Lambda                          1
    x_64      A4-64                          -1
    x_65      Lambda                          1
    x_65      A13-65                         -1
    x_66      Lambda                          1
    x_66      A58-66                         -1
    x_67      Lambda                          1
    x_67      A32-67                         -1
    x_68      Lambda                          1
    x_68      A42-68                         -1
    x_69      Lambda                          1
    x_69      A41-69                         -1
    x_70      Lambda                          1
    x_70      A59-70                         -1
    x_70      A76-70                         -1
    x_71      Lambda                          1
    x_71      A43-71                         -1
    x_72      Lambda                          1
    x_72      A45-72                         -1
    x_73      Lambda                          1
    x_73      A44-73                         -1
    x_74      Lambda                          1
    x_74      A21-74                         -1
    x_75      Lambda                          1
    x_75      A48-75                         -1
    x_76      Lambda                          1
    x_76      A70-76                         -1
    x_77      Lambda                          1
    x_77      A60-77                         -1
    x_78      Lambda                          1
    x_78      A28-78                         -1
    x_79      Lambda                          1
    x_79      A52-79                         -1
    x_80      Lambda                          1
    x_80      A35-80                         -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       Phi                             2
    rhs       Lambda                          2
    rhs       V1                              1
    rhs       V4                              1
    rhs       V5                              1
    rhs       V6                              1
    rhs       V7                              1
    rhs       V8                              1
    rhs       V9                              1
    rhs       V10                             1
    rhs       V11                             1
    rhs       V12                             1
    rhs       V13                             1
    rhs       V14                             1
    rhs       V15                             1
    rhs       V16                             1
    rhs       V17                             1
    rhs       V18                             1
    rhs       V19                             1
    rhs       V20                             1
    rhs       V21                             1
    rhs       V22                             1
    rhs       V23                             1
    rhs       V24                             1
    rhs       V25                             1
    rhs       V26                             1
    rhs       V27                             1
    rhs       V28                             1
    rhs       V29                             1
    rhs       V30                             1
    rhs       V31                             1
    rhs       V32                             1
    rhs       V33                             1
    rhs       V34                             1
    rhs       V35                             1
    rhs       V36                             1
    rhs       V37                             1
    rhs       V38                             1
    rhs       V39                             1
    rhs       V40                             1
    rhs       V41                             1
    rhs       V42                             1
    rhs       V43                             1
    rhs       V44                             1
    rhs       V45                             1
    rhs       V46                             1
    rhs       V47                             1
    rhs       V48                             1
    rhs       V49                             1
    rhs       V50                             1
    rhs       V51                             1
    rhs       V52                             1
    rhs       V53                             1
    rhs       V54                             1
    rhs       V55                             1
    rhs       V56                             1
    rhs       V57                             1
    rhs       V58                             1
    rhs       V59                             1
    rhs       V60                             1
    rhs       V61                             1
    rhs       V62                             1
    rhs       V63                             1
    rhs       V64                             1
    rhs       V65                             1
    rhs       V66                             1
    rhs       V67                             1
    rhs       V68                             1
    rhs       V69                             1
    rhs       V70                             1
    rhs       V71                             1
    rhs       V72                             1
    rhs       V73                             1
    rhs       V74                             1
    rhs       V75                             1
    rhs       V76                             1
    rhs       V77                             1
    rhs       V78                             1
    rhs       V79                             1
    rhs       V80                             1
BOUNDS
 BV bnd       a_1     
 BV bnd       a_4     
 BV bnd       a_5     
 BV bnd       a_6     
 BV bnd       a_7     
 BV bnd       a_8     
 BV bnd       a_9     
 BV bnd       a_10    
 BV bnd       a_11    
 BV bnd       a_12    
 BV bnd       a_13    
 BV bnd       a_14    
 BV bnd       a_15    
 BV bnd       a_16    
 BV bnd       a_17    
 BV bnd       a_18    
 BV bnd       a_19    
 BV bnd       a_20    
 BV bnd       a_21    
 BV bnd       a_22    
 BV bnd       a_23    
 BV bnd       a_24    
 BV bnd       a_25    
 BV bnd       a_26    
 BV bnd       a_27    
 BV bnd       a_28    
 BV bnd       a_29    
 BV bnd       a_30    
 BV bnd       a_31    
 BV bnd       a_32    
 BV bnd       a_33    
 BV bnd       a_34    
 BV bnd       a_35    
 BV bnd       a_36    
 BV bnd       a_37    
 BV bnd       a_38    
 BV bnd       a_39    
 BV bnd       a_40    
 BV bnd       a_41    
 BV bnd       a_42    
 BV bnd       a_43    
 BV bnd       a_44    
 BV bnd       a_45    
 BV bnd       a_46    
 BV bnd       a_47    
 BV bnd       a_48    
 BV bnd       a_49    
 BV bnd       a_50    
 BV bnd       a_51    
 BV bnd       a_52    
 BV bnd       a_53    
 BV bnd       a_54    
 BV bnd       a_55    
 BV bnd       a_56    
 BV bnd       a_57    
 BV bnd       a_58    
 BV bnd       a_59    
 BV bnd       a_60    
 BV bnd       a_61    
 BV bnd       a_62    
 BV bnd       a_63    
 BV bnd       a_64    
 BV bnd       a_65    
 BV bnd       a_66    
 BV bnd       a_67    
 BV bnd       a_68    
 BV bnd       a_69    
 BV bnd       a_70    
 BV bnd       a_71    
 BV bnd       a_72    
 BV bnd       a_73    
 BV bnd       a_74    
 BV bnd       a_75    
 BV bnd       a_76    
 BV bnd       a_77    
 BV bnd       a_78    
 BV bnd       a_79    
 BV bnd       a_80    
 BV bnd       y_1     
 BV bnd       y_4     
 BV bnd       y_5     
 BV bnd       y_6     
 BV bnd       y_7     
 BV bnd       y_8     
 BV bnd       y_9     
 BV bnd       y_10    
 BV bnd       y_11    
 BV bnd       y_12    
 BV bnd       y_13    
 BV bnd       y_14    
 BV bnd       y_15    
 BV bnd       y_16    
 BV bnd       y_17    
 BV bnd       y_18    
 BV bnd       y_19    
 BV bnd       y_20    
 BV bnd       y_21    
 BV bnd       y_22    
 BV bnd       y_23    
 BV bnd       y_24    
 BV bnd       y_25    
 BV bnd       y_26    
 BV bnd       y_27    
 BV bnd       y_28    
 BV bnd       y_29    
 BV bnd       y_30    
 BV bnd       y_31    
 BV bnd       y_32    
 BV bnd       y_33    
 BV bnd       y_34    
 BV bnd       y_35    
 BV bnd       y_36    
 BV bnd       y_37    
 BV bnd       y_38    
 BV bnd       y_39    
 BV bnd       y_40    
 BV bnd       y_41    
 BV bnd       y_42    
 BV bnd       y_43    
 BV bnd       y_44    
 BV bnd       y_45    
 BV bnd       y_46    
 BV bnd       y_47    
 BV bnd       y_48    
 BV bnd       y_49    
 BV bnd       y_50    
 BV bnd       y_51    
 BV bnd       y_52    
 BV bnd       y_53    
 BV bnd       y_54    
 BV bnd       y_55    
 BV bnd       y_56    
 BV bnd       y_57    
 BV bnd       y_58    
 BV bnd       y_59    
 BV bnd       y_60    
 BV bnd       y_61    
 BV bnd       y_62    
 BV bnd       y_63    
 BV bnd       y_64    
 BV bnd       y_65    
 BV bnd       y_66    
 BV bnd       y_67    
 BV bnd       y_68    
 BV bnd       y_69    
 BV bnd       y_70    
 BV bnd       y_71    
 BV bnd       y_72    
 BV bnd       y_73    
 BV bnd       y_74    
 BV bnd       y_75    
 BV bnd       y_76    
 BV bnd       y_77    
 BV bnd       y_78    
 BV bnd       y_79    
 BV bnd       y_80    
 BV bnd       x_1     
 BV bnd       x_4     
 BV bnd       x_5     
 BV bnd       x_6     
 BV bnd       x_7     
 BV bnd       x_8     
 BV bnd       x_9     
 BV bnd       x_10    
 BV bnd       x_11    
 BV bnd       x_12    
 BV bnd       x_13    
 BV bnd       x_14    
 BV bnd       x_15    
 BV bnd       x_16    
 BV bnd       x_17    
 BV bnd       x_18    
 BV bnd       x_19    
 BV bnd       x_20    
 BV bnd       x_21    
 BV bnd       x_22    
 BV bnd       x_23    
 BV bnd       x_24    
 BV bnd       x_25    
 BV bnd       x_26    
 BV bnd       x_27    
 BV bnd       x_28    
 BV bnd       x_29    
 BV bnd       x_30    
 BV bnd       x_31    
 BV bnd       x_32    
 BV bnd       x_33    
 BV bnd       x_34    
 BV bnd       x_35    
 BV bnd       x_36    
 BV bnd       x_37    
 BV bnd       x_38    
 BV bnd       x_39    
 BV bnd       x_40    
 BV bnd       x_41    
 BV bnd       x_42    
 BV bnd       x_43    
 BV bnd       x_44    
 BV bnd       x_45    
 BV bnd       x_46    
 BV bnd       x_47    
 BV bnd       x_48    
 BV bnd       x_49    
 BV bnd       x_50    
 BV bnd       x_51    
 BV bnd       x_52    
 BV bnd       x_53    
 BV bnd       x_54    
 BV bnd       x_55    
 BV bnd       x_56    
 BV bnd       x_57    
 BV bnd       x_58    
 BV bnd       x_59    
 BV bnd       x_60    
 BV bnd       x_61    
 BV bnd       x_62    
 BV bnd       x_63    
 BV bnd       x_64    
 BV bnd       x_65    
 BV bnd       x_66    
 BV bnd       x_67    
 BV bnd       x_68    
 BV bnd       x_69    
 BV bnd       x_70    
 BV bnd       x_71    
 BV bnd       x_72    
 BV bnd       x_73    
 BV bnd       x_74    
 BV bnd       x_75    
 BV bnd       x_76    
 BV bnd       x_77    
 BV bnd       x_78    
 BV bnd       x_79    
 BV bnd       x_80    
ENDATA
