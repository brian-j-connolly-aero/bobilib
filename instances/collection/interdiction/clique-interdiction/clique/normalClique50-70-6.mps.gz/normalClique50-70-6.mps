* ENCODING=ISO-8859-1
NAME          normalClique50-70-6
ROWS
 N  cost    
 L  KL      
 L  C0,4    
 L  C0,12   
 L  C0,21   
 L  C0,24   
 L  C0,27   
 L  C0,28   
 L  C0,29   
 L  C0,30   
 L  C0,35   
 L  C0,36   
 L  C0,37   
 L  C0,39   
 L  C0,41   
 L  C0,42   
 L  C0,49   
 L  C1,4    
 L  C1,7    
 L  C1,13   
 L  C1,23   
 L  C1,25   
 L  C1,28   
 L  C1,30   
 L  C1,33   
 L  C1,36   
 L  C1,39   
 L  C1,47   
 L  C2,3    
 L  C2,6    
 L  C2,8    
 L  C2,13   
 L  C2,15   
 L  C2,16   
 L  C2,17   
 L  C2,23   
 L  C2,24   
 L  C2,25   
 L  C2,26   
 L  C2,29   
 L  C2,36   
 L  C2,37   
 L  C2,38   
 L  C2,43   
 L  C2,46   
 L  C2,48   
 L  C3,4    
 L  C3,7    
 L  C3,10   
 L  C3,11   
 L  C3,12   
 L  C3,13   
 L  C3,15   
 L  C3,16   
 L  C3,18   
 L  C3,28   
 L  C3,29   
 L  C3,30   
 L  C3,31   
 L  C3,32   
 L  C3,36   
 L  C3,46   
 L  C3,48   
 L  C4,7    
 L  C4,10   
 L  C4,12   
 L  C4,14   
 L  C4,17   
 L  C4,19   
 L  C4,21   
 L  C4,23   
 L  C4,24   
 L  C4,27   
 L  C4,35   
 L  C4,36   
 L  C4,42   
 L  C4,44   
 L  C4,48   
 L  C5,9    
 L  C5,13   
 L  C5,14   
 L  C5,15   
 L  C5,17   
 L  C5,38   
 L  C5,44   
 L  C5,46   
 L  C5,48   
 L  C6,7    
 L  C6,9    
 L  C6,11   
 L  C6,14   
 L  C6,16   
 L  C6,21   
 L  C6,26   
 L  C6,31   
 L  C6,32   
 L  C6,35   
 L  C6,36   
 L  C6,37   
 L  C7,9    
 L  C7,11   
 L  C7,13   
 L  C7,15   
 L  C7,22   
 L  C7,25   
 L  C7,26   
 L  C7,34   
 L  C7,36   
 L  C7,38   
 L  C7,40   
 L  C7,43   
 L  C7,46   
 L  C8,11   
 L  C8,14   
 L  C8,16   
 L  C8,21   
 L  C8,22   
 L  C8,23   
 L  C8,25   
 L  C8,28   
 L  C8,29   
 L  C8,30   
 L  C8,36   
 L  C8,37   
 L  C8,38   
 L  C8,39   
 L  C8,40   
 L  C8,47   
 L  C8,48   
 L  C8,49   
 L  C9,14   
 L  C9,20   
 L  C9,25   
 L  C9,28   
 L  C9,31   
 L  C9,37   
 L  C9,39   
 L  C10,12  
 L  C10,13  
 L  C10,16  
 L  C10,28  
 L  C10,30  
 L  C10,34  
 L  C10,45  
 L  C10,46  
 L  C10,49  
 L  C11,20  
 L  C11,23  
 L  C11,24  
 L  C11,30  
 L  C11,32  
 L  C11,35  
 L  C11,36  
 L  C11,37  
 L  C11,41  
 L  C11,43  
 L  C11,45  
 L  C12,14  
 L  C12,16  
 L  C12,19  
 L  C12,25  
 L  C12,27  
 L  C12,33  
 L  C12,34  
 L  C12,35  
 L  C12,38  
 L  C12,42  
 L  C12,46  
 L  C12,47  
 L  C13,16  
 L  C13,17  
 L  C13,19  
 L  C13,21  
 L  C13,22  
 L  C13,27  
 L  C13,33  
 L  C13,34  
 L  C13,44  
 L  C14,21  
 L  C14,26  
 L  C14,28  
 L  C14,29  
 L  C14,36  
 L  C14,39  
 L  C14,40  
 L  C14,41  
 L  C15,20  
 L  C15,25  
 L  C15,28  
 L  C15,35  
 L  C15,38  
 L  C15,42  
 L  C15,45  
 L  C16,17  
 L  C16,19  
 L  C16,25  
 L  C16,26  
 L  C16,31  
 L  C16,36  
 L  C16,49  
 L  C17,19  
 L  C17,21  
 L  C17,23  
 L  C17,24  
 L  C17,29  
 L  C17,31  
 L  C17,35  
 L  C17,36  
 L  C17,37  
 L  C17,40  
 L  C17,41  
 L  C17,42  
 L  C17,44  
 L  C17,45  
 L  C17,48  
 L  C18,26  
 L  C18,29  
 L  C18,32  
 L  C18,33  
 L  C18,39  
 L  C18,44  
 L  C18,49  
 L  C19,21  
 L  C19,27  
 L  C19,30  
 L  C19,32  
 L  C19,33  
 L  C19,35  
 L  C19,36  
 L  C19,38  
 L  C19,42  
 L  C19,43  
 L  C19,44  
 L  C20,21  
 L  C20,24  
 L  C20,26  
 L  C20,27  
 L  C20,33  
 L  C20,39  
 L  C20,43  
 L  C20,44  
 L  C20,47  
 L  C21,23  
 L  C21,34  
 L  C21,35  
 L  C21,36  
 L  C21,38  
 L  C21,40  
 L  C21,42  
 L  C21,44  
 L  C21,46  
 L  C22,24  
 L  C22,26  
 L  C22,28  
 L  C22,29  
 L  C22,31  
 L  C22,32  
 L  C22,34  
 L  C22,35  
 L  C22,37  
 L  C22,47  
 L  C22,48  
 L  C23,30  
 L  C23,31  
 L  C23,33  
 L  C23,40  
 L  C23,41  
 L  C23,43  
 L  C23,47  
 L  C24,25  
 L  C24,27  
 L  C24,34  
 L  C24,35  
 L  C24,37  
 L  C24,41  
 L  C24,45  
 L  C24,49  
 L  C25,27  
 L  C25,32  
 L  C25,33  
 L  C25,34  
 L  C25,35  
 L  C25,36  
 L  C25,40  
 L  C25,41  
 L  C25,42  
 L  C25,48  
 L  C25,49  
 L  C26,27  
 L  C26,32  
 L  C26,33  
 L  C26,35  
 L  C26,36  
 L  C26,39  
 L  C26,40  
 L  C26,41  
 L  C26,46  
 L  C27,31  
 L  C27,36  
 L  C27,37  
 L  C27,38  
 L  C27,39  
 L  C27,46  
 L  C27,48  
 L  C28,30  
 L  C28,35  
 L  C28,37  
 L  C28,38  
 L  C28,42  
 L  C28,48  
 L  C29,33  
 L  C29,35  
 L  C29,40  
 L  C29,44  
 L  C29,45  
 L  C30,32  
 L  C30,35  
 L  C30,39  
 L  C30,44  
 L  C30,45  
 L  C30,49  
 L  C31,34  
 L  C31,36  
 L  C31,37  
 L  C31,40  
 L  C31,44  
 L  C31,46  
 L  C31,47  
 L  C32,36  
 L  C32,49  
 L  C33,39  
 L  C33,42  
 L  C34,36  
 L  C34,44  
 L  C34,46  
 L  C34,48  
 L  C34,49  
 L  C35,37  
 L  C35,40  
 L  C35,43  
 L  C36,37  
 L  C36,40  
 L  C36,42  
 L  C36,46  
 L  C36,49  
 L  C37,40  
 L  C37,48  
 L  C38,39  
 L  C38,40  
 L  C38,44  
 L  C39,48  
 L  C39,49  
 L  C40,41  
 L  C40,42  
 L  C40,43  
 L  C40,46  
 L  C41,42  
 L  C41,44  
 L  C42,43  
 L  C42,45  
 L  C42,46  
 L  C43,46  
 L  C43,47  
 L  C43,48  
 L  C44,46  
 L  C44,49  
 L  C45,46  
 L  C45,48  
 L  C46,47  
 L  C47,49  
 L  E0,1    
 L  E0,2    
 L  E0,3    
 L  E0,5    
 L  E0,6    
 L  E0,7    
 L  E0,8    
 L  E0,9    
 L  E0,10   
 L  E0,11   
 L  E0,13   
 L  E0,14   
 L  E0,15   
 L  E0,16   
 L  E0,17   
 L  E0,18   
 L  E0,19   
 L  E0,20   
 L  E0,22   
 L  E0,23   
 L  E0,25   
 L  E0,26   
 L  E0,31   
 L  E0,32   
 L  E0,33   
 L  E0,34   
 L  E0,38   
 L  E0,40   
 L  E0,43   
 L  E0,44   
 L  E0,45   
 L  E0,46   
 L  E0,47   
 L  E0,48   
 L  E1,2    
 L  E1,3    
 L  E1,5    
 L  E1,6    
 L  E1,8    
 L  E1,9    
 L  E1,10   
 L  E1,11   
 L  E1,12   
 L  E1,14   
 L  E1,15   
 L  E1,16   
 L  E1,17   
 L  E1,18   
 L  E1,19   
 L  E1,20   
 L  E1,21   
 L  E1,22   
 L  E1,24   
 L  E1,26   
 L  E1,27   
 L  E1,29   
 L  E1,31   
 L  E1,32   
 L  E1,34   
 L  E1,35   
 L  E1,37   
 L  E1,38   
 L  E1,40   
 L  E1,41   
 L  E1,42   
 L  E1,43   
 L  E1,44   
 L  E1,45   
 L  E1,46   
 L  E1,48   
 L  E1,49   
 L  E2,4    
 L  E2,5    
 L  E2,7    
 L  E2,9    
 L  E2,10   
 L  E2,11   
 L  E2,12   
 L  E2,14   
 L  E2,18   
 L  E2,19   
 L  E2,20   
 L  E2,21   
 L  E2,22   
 L  E2,27   
 L  E2,28   
 L  E2,30   
 L  E2,31   
 L  E2,32   
 L  E2,33   
 L  E2,34   
 L  E2,35   
 L  E2,39   
 L  E2,40   
 L  E2,41   
 L  E2,42   
 L  E2,44   
 L  E2,45   
 L  E2,47   
 L  E2,49   
 L  E3,5    
 L  E3,6    
 L  E3,8    
 L  E3,9    
 L  E3,14   
 L  E3,17   
 L  E3,19   
 L  E3,20   
 L  E3,21   
 L  E3,22   
 L  E3,23   
 L  E3,24   
 L  E3,25   
 L  E3,26   
 L  E3,27   
 L  E3,33   
 L  E3,34   
 L  E3,35   
 L  E3,37   
 L  E3,38   
 L  E3,39   
 L  E3,40   
 L  E3,41   
 L  E3,42   
 L  E3,43   
 L  E3,44   
 L  E3,45   
 L  E3,47   
 L  E3,49   
 L  E4,5    
 L  E4,6    
 L  E4,8    
 L  E4,9    
 L  E4,11   
 L  E4,13   
 L  E4,15   
 L  E4,16   
 L  E4,18   
 L  E4,20   
 L  E4,22   
 L  E4,25   
 L  E4,26   
 L  E4,28   
 L  E4,29   
 L  E4,30   
 L  E4,31   
 L  E4,32   
 L  E4,33   
 L  E4,34   
 L  E4,37   
 L  E4,38   
 L  E4,39   
 L  E4,40   
 L  E4,41   
 L  E4,43   
 L  E4,45   
 L  E4,46   
 L  E4,47   
 L  E4,49   
 L  E5,6    
 L  E5,7    
 L  E5,8    
 L  E5,10   
 L  E5,11   
 L  E5,12   
 L  E5,16   
 L  E5,18   
 L  E5,19   
 L  E5,20   
 L  E5,21   
 L  E5,22   
 L  E5,23   
 L  E5,24   
 L  E5,25   
 L  E5,26   
 L  E5,27   
 L  E5,28   
 L  E5,29   
 L  E5,30   
 L  E5,31   
 L  E5,32   
 L  E5,33   
 L  E5,34   
 L  E5,35   
 L  E5,36   
 L  E5,37   
 L  E5,39   
 L  E5,40   
 L  E5,41   
 L  E5,42   
 L  E5,43   
 L  E5,45   
 L  E5,47   
 L  E5,49   
 L  E6,8    
 L  E6,10   
 L  E6,12   
 L  E6,13   
 L  E6,15   
 L  E6,17   
 L  E6,18   
 L  E6,19   
 L  E6,20   
 L  E6,22   
 L  E6,23   
 L  E6,24   
 L  E6,25   
 L  E6,27   
 L  E6,28   
 L  E6,29   
 L  E6,30   
 L  E6,33   
 L  E6,34   
 L  E6,38   
 L  E6,39   
 L  E6,40   
 L  E6,41   
 L  E6,42   
 L  E6,43   
 L  E6,44   
 L  E6,45   
 L  E6,46   
 L  E6,47   
 L  E6,48   
 L  E6,49   
 L  E7,8    
 L  E7,10   
 L  E7,12   
 L  E7,14   
 L  E7,16   
 L  E7,17   
 L  E7,18   
 L  E7,19   
 L  E7,20   
 L  E7,21   
 L  E7,23   
 L  E7,24   
 L  E7,27   
 L  E7,28   
 L  E7,29   
 L  E7,30   
 L  E7,31   
 L  E7,32   
 L  E7,33   
 L  E7,35   
 L  E7,37   
 L  E7,39   
 L  E7,41   
 L  E7,42   
 L  E7,44   
 L  E7,45   
 L  E7,47   
 L  E7,48   
 L  E7,49   
 L  E8,9    
 L  E8,10   
 L  E8,12   
 L  E8,13   
 L  E8,15   
 L  E8,17   
 L  E8,18   
 L  E8,19   
 L  E8,20   
 L  E8,24   
 L  E8,26   
 L  E8,27   
 L  E8,31   
 L  E8,32   
 L  E8,33   
 L  E8,34   
 L  E8,35   
 L  E8,41   
 L  E8,42   
 L  E8,43   
 L  E8,44   
 L  E8,45   
 L  E8,46   
 L  E9,10   
 L  E9,11   
 L  E9,12   
 L  E9,13   
 L  E9,15   
 L  E9,16   
 L  E9,17   
 L  E9,18   
 L  E9,19   
 L  E9,21   
 L  E9,22   
 L  E9,23   
 L  E9,24   
 L  E9,26   
 L  E9,27   
 L  E9,29   
 L  E9,30   
 L  E9,32   
 L  E9,33   
 L  E9,34   
 L  E9,35   
 L  E9,36   
 L  E9,38   
 L  E9,40   
 L  E9,41   
 L  E9,42   
 L  E9,43   
 L  E9,44   
 L  E9,45   
 L  E9,46   
 L  E9,47   
 L  E9,48   
 L  E9,49   
 L  E10,11  
 L  E10,14  
 L  E10,15  
 L  E10,17  
 L  E10,18  
 L  E10,19  
 L  E10,20  
 L  E10,21  
 L  E10,22  
 L  E10,23  
 L  E10,24  
 L  E10,25  
 L  E10,26  
 L  E10,27  
 L  E10,29  
 L  E10,31  
 L  E10,32  
 L  E10,33  
 L  E10,35  
 L  E10,36  
 L  E10,37  
 L  E10,38  
 L  E10,39  
 L  E10,40  
 L  E10,41  
 L  E10,42  
 L  E10,43  
 L  E10,44  
 L  E10,47  
 L  E10,48  
 L  E11,12  
 L  E11,13  
 L  E11,14  
 L  E11,15  
 L  E11,16  
 L  E11,17  
 L  E11,18  
 L  E11,19  
 L  E11,21  
 L  E11,22  
 L  E11,25  
 L  E11,26  
 L  E11,27  
 L  E11,28  
 L  E11,29  
 L  E11,31  
 L  E11,33  
 L  E11,34  
 L  E11,38  
 L  E11,39  
 L  E11,40  
 L  E11,42  
 L  E11,44  
 L  E11,46  
 L  E11,47  
 L  E11,48  
 L  E11,49  
 L  E12,13  
 L  E12,15  
 L  E12,17  
 L  E12,18  
 L  E12,20  
 L  E12,21  
 L  E12,22  
 L  E12,23  
 L  E12,24  
 L  E12,26  
 L  E12,28  
 L  E12,29  
 L  E12,30  
 L  E12,31  
 L  E12,32  
 L  E12,36  
 L  E12,37  
 L  E12,39  
 L  E12,40  
 L  E12,41  
 L  E12,43  
 L  E12,44  
 L  E12,45  
 L  E12,48  
 L  E12,49  
 L  E13,14  
 L  E13,15  
 L  E13,18  
 L  E13,20  
 L  E13,23  
 L  E13,24  
 L  E13,25  
 L  E13,26  
 L  E13,28  
 L  E13,29  
 L  E13,30  
 L  E13,31  
 L  E13,32  
 L  E13,35  
 L  E13,36  
 L  E13,37  
 L  E13,38  
 L  E13,39  
 L  E13,40  
 L  E13,41  
 L  E13,42  
 L  E13,43  
 L  E13,45  
 L  E13,46  
 L  E13,47  
 L  E13,48  
 L  E13,49  
 L  E14,15  
 L  E14,16  
 L  E14,17  
 L  E14,18  
 L  E14,19  
 L  E14,20  
 L  E14,22  
 L  E14,23  
 L  E14,24  
 L  E14,25  
 L  E14,27  
 L  E14,30  
 L  E14,31  
 L  E14,32  
 L  E14,33  
 L  E14,34  
 L  E14,35  
 L  E14,37  
 L  E14,38  
 L  E14,42  
 L  E14,43  
 L  E14,44  
 L  E14,45  
 L  E14,46  
 L  E14,47  
 L  E14,48  
 L  E14,49  
 L  E15,16  
 L  E15,17  
 L  E15,18  
 L  E15,19  
 L  E15,21  
 L  E15,22  
 L  E15,23  
 L  E15,24  
 L  E15,26  
 L  E15,27  
 L  E15,29  
 L  E15,30  
 L  E15,31  
 L  E15,32  
 L  E15,33  
 L  E15,34  
 L  E15,36  
 L  E15,37  
 L  E15,39  
 L  E15,40  
 L  E15,41  
 L  E15,43  
 L  E15,44  
 L  E15,46  
 L  E15,47  
 L  E15,48  
 L  E15,49  
 L  E16,18  
 L  E16,20  
 L  E16,21  
 L  E16,22  
 L  E16,23  
 L  E16,24  
 L  E16,27  
 L  E16,28  
 L  E16,29  
 L  E16,30  
 L  E16,32  
 L  E16,33  
 L  E16,34  
 L  E16,35  
 L  E16,37  
 L  E16,38  
 L  E16,39  
 L  E16,40  
 L  E16,41  
 L  E16,42  
 L  E16,43  
 L  E16,44  
 L  E16,45  
 L  E16,46  
 L  E16,47  
 L  E16,48  
 L  E17,18  
 L  E17,20  
 L  E17,22  
 L  E17,25  
 L  E17,26  
 L  E17,27  
 L  E17,28  
 L  E17,30  
 L  E17,32  
 L  E17,33  
 L  E17,34  
 L  E17,38  
 L  E17,39  
 L  E17,43  
 L  E17,46  
 L  E17,47  
 L  E17,49  
 L  E18,19  
 L  E18,20  
 L  E18,21  
 L  E18,22  
 L  E18,23  
 L  E18,24  
 L  E18,25  
 L  E18,27  
 L  E18,28  
 L  E18,30  
 L  E18,31  
 L  E18,34  
 L  E18,35  
 L  E18,36  
 L  E18,37  
 L  E18,38  
 L  E18,40  
 L  E18,41  
 L  E18,42  
 L  E18,43  
 L  E18,45  
 L  E18,46  
 L  E18,47  
 L  E18,48  
 L  E19,20  
 L  E19,22  
 L  E19,23  
 L  E19,24  
 L  E19,25  
 L  E19,26  
 L  E19,28  
 L  E19,29  
 L  E19,31  
 L  E19,34  
 L  E19,37  
 L  E19,39  
 L  E19,40  
 L  E19,41  
 L  E19,45  
 L  E19,46  
 L  E19,47  
 L  E19,48  
 L  E19,49  
 L  E20,22  
 L  E20,23  
 L  E20,25  
 L  E20,28  
 L  E20,29  
 L  E20,30  
 L  E20,31  
 L  E20,32  
 L  E20,34  
 L  E20,35  
 L  E20,36  
 L  E20,37  
 L  E20,38  
 L  E20,40  
 L  E20,41  
 L  E20,42  
 L  E20,45  
 L  E20,46  
 L  E20,48  
 L  E20,49  
 L  E21,22  
 L  E21,24  
 L  E21,25  
 L  E21,26  
 L  E21,27  
 L  E21,28  
 L  E21,29  
 L  E21,30  
 L  E21,31  
 L  E21,32  
 L  E21,33  
 L  E21,37  
 L  E21,39  
 L  E21,41  
 L  E21,43  
 L  E21,45  
 L  E21,47  
 L  E21,48  
 L  E21,49  
 L  E22,23  
 L  E22,25  
 L  E22,27  
 L  E22,30  
 L  E22,33  
 L  E22,36  
 L  E22,38  
 L  E22,39  
 L  E22,40  
 L  E22,41  
 L  E22,42  
 L  E22,43  
 L  E22,44  
 L  E22,45  
 L  E22,46  
 L  E22,49  
 L  E23,24  
 L  E23,25  
 L  E23,26  
 L  E23,27  
 L  E23,28  
 L  E23,29  
 L  E23,32  
 L  E23,34  
 L  E23,35  
 L  E23,36  
 L  E23,37  
 L  E23,38  
 L  E23,39  
 L  E23,42  
 L  E23,44  
 L  E23,45  
 L  E23,46  
 L  E23,48  
 L  E23,49  
 L  E24,26  
 L  E24,28  
 L  E24,29  
 L  E24,30  
 L  E24,31  
 L  E24,32  
 L  E24,33  
 L  E24,36  
 L  E24,38  
 L  E24,39  
 L  E24,40  
 L  E24,42  
 L  E24,43  
 L  E24,44  
 L  E24,46  
 L  E24,47  
 L  E24,48  
 L  E25,26  
 L  E25,28  
 L  E25,29  
 L  E25,30  
 L  E25,31  
 L  E25,37  
 L  E25,38  
 L  E25,39  
 L  E25,43  
 L  E25,44  
 L  E25,45  
 L  E25,46  
 L  E25,47  
 L  E26,28  
 L  E26,29  
 L  E26,30  
 L  E26,31  
 L  E26,34  
 L  E26,37  
 L  E26,38  
 L  E26,42  
 L  E26,43  
 L  E26,44  
 L  E26,45  
 L  E26,47  
 L  E26,48  
 L  E26,49  
 L  E27,28  
 L  E27,29  
 L  E27,30  
 L  E27,32  
 L  E27,33  
 L  E27,34  
 L  E27,35  
 L  E27,40  
 L  E27,41  
 L  E27,42  
 L  E27,43  
 L  E27,44  
 L  E27,45  
 L  E27,47  
 L  E27,49  
 L  E28,29  
 L  E28,31  
 L  E28,32  
 L  E28,33  
 L  E28,34  
 L  E28,36  
 L  E28,39  
 L  E28,40  
 L  E28,41  
 L  E28,43  
 L  E28,44  
 L  E28,45  
 L  E28,46  
 L  E28,47  
 L  E28,49  
 L  E29,30  
 L  E29,31  
 L  E29,32  
 L  E29,34  
 L  E29,36  
 L  E29,37  
 L  E29,38  
 L  E29,39  
 L  E29,41  
 L  E29,42  
 L  E29,43  
 L  E29,46  
 L  E29,47  
 L  E29,48  
 L  E29,49  
 L  E30,31  
 L  E30,33  
 L  E30,34  
 L  E30,36  
 L  E30,37  
 L  E30,38  
 L  E30,40  
 L  E30,41  
 L  E30,42  
 L  E30,43  
 L  E30,46  
 L  E30,47  
 L  E30,48  
 L  E31,32  
 L  E31,33  
 L  E31,35  
 L  E31,38  
 L  E31,39  
 L  E31,41  
 L  E31,42  
 L  E31,43  
 L  E31,45  
 L  E31,48  
 L  E31,49  
 L  E32,33  
 L  E32,34  
 L  E32,35  
 L  E32,37  
 L  E32,38  
 L  E32,39  
 L  E32,40  
 L  E32,41  
 L  E32,42  
 L  E32,43  
 L  E32,44  
 L  E32,45  
 L  E32,46  
 L  E32,47  
 L  E32,48  
 L  E33,34  
 L  E33,35  
 L  E33,36  
 L  E33,37  
 L  E33,38  
 L  E33,40  
 L  E33,41  
 L  E33,43  
 L  E33,44  
 L  E33,45  
 L  E33,46  
 L  E33,47  
 L  E33,48  
 L  E33,49  
 L  E34,35  
 L  E34,37  
 L  E34,38  
 L  E34,39  
 L  E34,40  
 L  E34,41  
 L  E34,42  
 L  E34,43  
 L  E34,45  
 L  E34,47  
 L  E35,36  
 L  E35,38  
 L  E35,39  
 L  E35,41  
 L  E35,42  
 L  E35,44  
 L  E35,45  
 L  E35,46  
 L  E35,47  
 L  E35,48  
 L  E35,49  
 L  E36,38  
 L  E36,39  
 L  E36,41  
 L  E36,43  
 L  E36,44  
 L  E36,45  
 L  E36,47  
 L  E36,48  
 L  E37,38  
 L  E37,39  
 L  E37,41  
 L  E37,42  
 L  E37,43  
 L  E37,44  
 L  E37,45  
 L  E37,46  
 L  E37,47  
 L  E37,49  
 L  E38,41  
 L  E38,42  
 L  E38,43  
 L  E38,45  
 L  E38,46  
 L  E38,47  
 L  E38,48  
 L  E38,49  
 L  E39,40  
 L  E39,41  
 L  E39,42  
 L  E39,43  
 L  E39,44  
 L  E39,45  
 L  E39,46  
 L  E39,47  
 L  E40,44  
 L  E40,45  
 L  E40,47  
 L  E40,48  
 L  E40,49  
 L  E41,43  
 L  E41,45  
 L  E41,46  
 L  E41,47  
 L  E41,48  
 L  E41,49  
 L  E42,44  
 L  E42,47  
 L  E42,48  
 L  E42,49  
 L  E43,44  
 L  E43,45  
 L  E43,49  
 L  E44,45  
 L  E44,47  
 L  E44,48  
 L  E45,47  
 L  E45,49  
 L  E46,48  
 L  E46,49  
 L  E47,48  
 L  E48,49  
 L  I0,1    
 L  I0,2    
 L  I0,3    
 L  I0,5    
 L  I0,6    
 L  I0,7    
 L  I0,8    
 L  I0,9    
 L  I0,10   
 L  I0,11   
 L  I0,13   
 L  I0,14   
 L  I0,15   
 L  I0,16   
 L  I0,17   
 L  I0,18   
 L  I0,19   
 L  I0,20   
 L  I0,22   
 L  I0,23   
 L  I0,25   
 L  I0,26   
 L  I0,31   
 L  I0,32   
 L  I0,33   
 L  I0,34   
 L  I0,38   
 L  I0,40   
 L  I0,43   
 L  I0,44   
 L  I0,45   
 L  I0,46   
 L  I0,47   
 L  I0,48   
 L  I1,2    
 L  I1,3    
 L  I1,5    
 L  I1,6    
 L  I1,8    
 L  I1,9    
 L  I1,10   
 L  I1,11   
 L  I1,12   
 L  I1,14   
 L  I1,15   
 L  I1,16   
 L  I1,17   
 L  I1,18   
 L  I1,19   
 L  I1,20   
 L  I1,21   
 L  I1,22   
 L  I1,24   
 L  I1,26   
 L  I1,27   
 L  I1,29   
 L  I1,31   
 L  I1,32   
 L  I1,34   
 L  I1,35   
 L  I1,37   
 L  I1,38   
 L  I1,40   
 L  I1,41   
 L  I1,42   
 L  I1,43   
 L  I1,44   
 L  I1,45   
 L  I1,46   
 L  I1,48   
 L  I1,49   
 L  I2,4    
 L  I2,5    
 L  I2,7    
 L  I2,9    
 L  I2,10   
 L  I2,11   
 L  I2,12   
 L  I2,14   
 L  I2,18   
 L  I2,19   
 L  I2,20   
 L  I2,21   
 L  I2,22   
 L  I2,27   
 L  I2,28   
 L  I2,30   
 L  I2,31   
 L  I2,32   
 L  I2,33   
 L  I2,34   
 L  I2,35   
 L  I2,39   
 L  I2,40   
 L  I2,41   
 L  I2,42   
 L  I2,44   
 L  I2,45   
 L  I2,47   
 L  I2,49   
 L  I3,5    
 L  I3,6    
 L  I3,8    
 L  I3,9    
 L  I3,14   
 L  I3,17   
 L  I3,19   
 L  I3,20   
 L  I3,21   
 L  I3,22   
 L  I3,23   
 L  I3,24   
 L  I3,25   
 L  I3,26   
 L  I3,27   
 L  I3,33   
 L  I3,34   
 L  I3,35   
 L  I3,37   
 L  I3,38   
 L  I3,39   
 L  I3,40   
 L  I3,41   
 L  I3,42   
 L  I3,43   
 L  I3,44   
 L  I3,45   
 L  I3,47   
 L  I3,49   
 L  I4,5    
 L  I4,6    
 L  I4,8    
 L  I4,9    
 L  I4,11   
 L  I4,13   
 L  I4,15   
 L  I4,16   
 L  I4,18   
 L  I4,20   
 L  I4,22   
 L  I4,25   
 L  I4,26   
 L  I4,28   
 L  I4,29   
 L  I4,30   
 L  I4,31   
 L  I4,32   
 L  I4,33   
 L  I4,34   
 L  I4,37   
 L  I4,38   
 L  I4,39   
 L  I4,40   
 L  I4,41   
 L  I4,43   
 L  I4,45   
 L  I4,46   
 L  I4,47   
 L  I4,49   
 L  I5,6    
 L  I5,7    
 L  I5,8    
 L  I5,10   
 L  I5,11   
 L  I5,12   
 L  I5,16   
 L  I5,18   
 L  I5,19   
 L  I5,20   
 L  I5,21   
 L  I5,22   
 L  I5,23   
 L  I5,24   
 L  I5,25   
 L  I5,26   
 L  I5,27   
 L  I5,28   
 L  I5,29   
 L  I5,30   
 L  I5,31   
 L  I5,32   
 L  I5,33   
 L  I5,34   
 L  I5,35   
 L  I5,36   
 L  I5,37   
 L  I5,39   
 L  I5,40   
 L  I5,41   
 L  I5,42   
 L  I5,43   
 L  I5,45   
 L  I5,47   
 L  I5,49   
 L  I6,8    
 L  I6,10   
 L  I6,12   
 L  I6,13   
 L  I6,15   
 L  I6,17   
 L  I6,18   
 L  I6,19   
 L  I6,20   
 L  I6,22   
 L  I6,23   
 L  I6,24   
 L  I6,25   
 L  I6,27   
 L  I6,28   
 L  I6,29   
 L  I6,30   
 L  I6,33   
 L  I6,34   
 L  I6,38   
 L  I6,39   
 L  I6,40   
 L  I6,41   
 L  I6,42   
 L  I6,43   
 L  I6,44   
 L  I6,45   
 L  I6,46   
 L  I6,47   
 L  I6,48   
 L  I6,49   
 L  I7,8    
 L  I7,10   
 L  I7,12   
 L  I7,14   
 L  I7,16   
 L  I7,17   
 L  I7,18   
 L  I7,19   
 L  I7,20   
 L  I7,21   
 L  I7,23   
 L  I7,24   
 L  I7,27   
 L  I7,28   
 L  I7,29   
 L  I7,30   
 L  I7,31   
 L  I7,32   
 L  I7,33   
 L  I7,35   
 L  I7,37   
 L  I7,39   
 L  I7,41   
 L  I7,42   
 L  I7,44   
 L  I7,45   
 L  I7,47   
 L  I7,48   
 L  I7,49   
 L  I8,9    
 L  I8,10   
 L  I8,12   
 L  I8,13   
 L  I8,15   
 L  I8,17   
 L  I8,18   
 L  I8,19   
 L  I8,20   
 L  I8,24   
 L  I8,26   
 L  I8,27   
 L  I8,31   
 L  I8,32   
 L  I8,33   
 L  I8,34   
 L  I8,35   
 L  I8,41   
 L  I8,42   
 L  I8,43   
 L  I8,44   
 L  I8,45   
 L  I8,46   
 L  I9,10   
 L  I9,11   
 L  I9,12   
 L  I9,13   
 L  I9,15   
 L  I9,16   
 L  I9,17   
 L  I9,18   
 L  I9,19   
 L  I9,21   
 L  I9,22   
 L  I9,23   
 L  I9,24   
 L  I9,26   
 L  I9,27   
 L  I9,29   
 L  I9,30   
 L  I9,32   
 L  I9,33   
 L  I9,34   
 L  I9,35   
 L  I9,36   
 L  I9,38   
 L  I9,40   
 L  I9,41   
 L  I9,42   
 L  I9,43   
 L  I9,44   
 L  I9,45   
 L  I9,46   
 L  I9,47   
 L  I9,48   
 L  I9,49   
 L  I10,11  
 L  I10,14  
 L  I10,15  
 L  I10,17  
 L  I10,18  
 L  I10,19  
 L  I10,20  
 L  I10,21  
 L  I10,22  
 L  I10,23  
 L  I10,24  
 L  I10,25  
 L  I10,26  
 L  I10,27  
 L  I10,29  
 L  I10,31  
 L  I10,32  
 L  I10,33  
 L  I10,35  
 L  I10,36  
 L  I10,37  
 L  I10,38  
 L  I10,39  
 L  I10,40  
 L  I10,41  
 L  I10,42  
 L  I10,43  
 L  I10,44  
 L  I10,47  
 L  I10,48  
 L  I11,12  
 L  I11,13  
 L  I11,14  
 L  I11,15  
 L  I11,16  
 L  I11,17  
 L  I11,18  
 L  I11,19  
 L  I11,21  
 L  I11,22  
 L  I11,25  
 L  I11,26  
 L  I11,27  
 L  I11,28  
 L  I11,29  
 L  I11,31  
 L  I11,33  
 L  I11,34  
 L  I11,38  
 L  I11,39  
 L  I11,40  
 L  I11,42  
 L  I11,44  
 L  I11,46  
 L  I11,47  
 L  I11,48  
 L  I11,49  
 L  I12,13  
 L  I12,15  
 L  I12,17  
 L  I12,18  
 L  I12,20  
 L  I12,21  
 L  I12,22  
 L  I12,23  
 L  I12,24  
 L  I12,26  
 L  I12,28  
 L  I12,29  
 L  I12,30  
 L  I12,31  
 L  I12,32  
 L  I12,36  
 L  I12,37  
 L  I12,39  
 L  I12,40  
 L  I12,41  
 L  I12,43  
 L  I12,44  
 L  I12,45  
 L  I12,48  
 L  I12,49  
 L  I13,14  
 L  I13,15  
 L  I13,18  
 L  I13,20  
 L  I13,23  
 L  I13,24  
 L  I13,25  
 L  I13,26  
 L  I13,28  
 L  I13,29  
 L  I13,30  
 L  I13,31  
 L  I13,32  
 L  I13,35  
 L  I13,36  
 L  I13,37  
 L  I13,38  
 L  I13,39  
 L  I13,40  
 L  I13,41  
 L  I13,42  
 L  I13,43  
 L  I13,45  
 L  I13,46  
 L  I13,47  
 L  I13,48  
 L  I13,49  
 L  I14,15  
 L  I14,16  
 L  I14,17  
 L  I14,18  
 L  I14,19  
 L  I14,20  
 L  I14,22  
 L  I14,23  
 L  I14,24  
 L  I14,25  
 L  I14,27  
 L  I14,30  
 L  I14,31  
 L  I14,32  
 L  I14,33  
 L  I14,34  
 L  I14,35  
 L  I14,37  
 L  I14,38  
 L  I14,42  
 L  I14,43  
 L  I14,44  
 L  I14,45  
 L  I14,46  
 L  I14,47  
 L  I14,48  
 L  I14,49  
 L  I15,16  
 L  I15,17  
 L  I15,18  
 L  I15,19  
 L  I15,21  
 L  I15,22  
 L  I15,23  
 L  I15,24  
 L  I15,26  
 L  I15,27  
 L  I15,29  
 L  I15,30  
 L  I15,31  
 L  I15,32  
 L  I15,33  
 L  I15,34  
 L  I15,36  
 L  I15,37  
 L  I15,39  
 L  I15,40  
 L  I15,41  
 L  I15,43  
 L  I15,44  
 L  I15,46  
 L  I15,47  
 L  I15,48  
 L  I15,49  
 L  I16,18  
 L  I16,20  
 L  I16,21  
 L  I16,22  
 L  I16,23  
 L  I16,24  
 L  I16,27  
 L  I16,28  
 L  I16,29  
 L  I16,30  
 L  I16,32  
 L  I16,33  
 L  I16,34  
 L  I16,35  
 L  I16,37  
 L  I16,38  
 L  I16,39  
 L  I16,40  
 L  I16,41  
 L  I16,42  
 L  I16,43  
 L  I16,44  
 L  I16,45  
 L  I16,46  
 L  I16,47  
 L  I16,48  
 L  I17,18  
 L  I17,20  
 L  I17,22  
 L  I17,25  
 L  I17,26  
 L  I17,27  
 L  I17,28  
 L  I17,30  
 L  I17,32  
 L  I17,33  
 L  I17,34  
 L  I17,38  
 L  I17,39  
 L  I17,43  
 L  I17,46  
 L  I17,47  
 L  I17,49  
 L  I18,19  
 L  I18,20  
 L  I18,21  
 L  I18,22  
 L  I18,23  
 L  I18,24  
 L  I18,25  
 L  I18,27  
 L  I18,28  
 L  I18,30  
 L  I18,31  
 L  I18,34  
 L  I18,35  
 L  I18,36  
 L  I18,37  
 L  I18,38  
 L  I18,40  
 L  I18,41  
 L  I18,42  
 L  I18,43  
 L  I18,45  
 L  I18,46  
 L  I18,47  
 L  I18,48  
 L  I19,20  
 L  I19,22  
 L  I19,23  
 L  I19,24  
 L  I19,25  
 L  I19,26  
 L  I19,28  
 L  I19,29  
 L  I19,31  
 L  I19,34  
 L  I19,37  
 L  I19,39  
 L  I19,40  
 L  I19,41  
 L  I19,45  
 L  I19,46  
 L  I19,47  
 L  I19,48  
 L  I19,49  
 L  I20,22  
 L  I20,23  
 L  I20,25  
 L  I20,28  
 L  I20,29  
 L  I20,30  
 L  I20,31  
 L  I20,32  
 L  I20,34  
 L  I20,35  
 L  I20,36  
 L  I20,37  
 L  I20,38  
 L  I20,40  
 L  I20,41  
 L  I20,42  
 L  I20,45  
 L  I20,46  
 L  I20,48  
 L  I20,49  
 L  I21,22  
 L  I21,24  
 L  I21,25  
 L  I21,26  
 L  I21,27  
 L  I21,28  
 L  I21,29  
 L  I21,30  
 L  I21,31  
 L  I21,32  
 L  I21,33  
 L  I21,37  
 L  I21,39  
 L  I21,41  
 L  I21,43  
 L  I21,45  
 L  I21,47  
 L  I21,48  
 L  I21,49  
 L  I22,23  
 L  I22,25  
 L  I22,27  
 L  I22,30  
 L  I22,33  
 L  I22,36  
 L  I22,38  
 L  I22,39  
 L  I22,40  
 L  I22,41  
 L  I22,42  
 L  I22,43  
 L  I22,44  
 L  I22,45  
 L  I22,46  
 L  I22,49  
 L  I23,24  
 L  I23,25  
 L  I23,26  
 L  I23,27  
 L  I23,28  
 L  I23,29  
 L  I23,32  
 L  I23,34  
 L  I23,35  
 L  I23,36  
 L  I23,37  
 L  I23,38  
 L  I23,39  
 L  I23,42  
 L  I23,44  
 L  I23,45  
 L  I23,46  
 L  I23,48  
 L  I23,49  
 L  I24,26  
 L  I24,28  
 L  I24,29  
 L  I24,30  
 L  I24,31  
 L  I24,32  
 L  I24,33  
 L  I24,36  
 L  I24,38  
 L  I24,39  
 L  I24,40  
 L  I24,42  
 L  I24,43  
 L  I24,44  
 L  I24,46  
 L  I24,47  
 L  I24,48  
 L  I25,26  
 L  I25,28  
 L  I25,29  
 L  I25,30  
 L  I25,31  
 L  I25,37  
 L  I25,38  
 L  I25,39  
 L  I25,43  
 L  I25,44  
 L  I25,45  
 L  I25,46  
 L  I25,47  
 L  I26,28  
 L  I26,29  
 L  I26,30  
 L  I26,31  
 L  I26,34  
 L  I26,37  
 L  I26,38  
 L  I26,42  
 L  I26,43  
 L  I26,44  
 L  I26,45  
 L  I26,47  
 L  I26,48  
 L  I26,49  
 L  I27,28  
 L  I27,29  
 L  I27,30  
 L  I27,32  
 L  I27,33  
 L  I27,34  
 L  I27,35  
 L  I27,40  
 L  I27,41  
 L  I27,42  
 L  I27,43  
 L  I27,44  
 L  I27,45  
 L  I27,47  
 L  I27,49  
 L  I28,29  
 L  I28,31  
 L  I28,32  
 L  I28,33  
 L  I28,34  
 L  I28,36  
 L  I28,39  
 L  I28,40  
 L  I28,41  
 L  I28,43  
 L  I28,44  
 L  I28,45  
 L  I28,46  
 L  I28,47  
 L  I28,49  
 L  I29,30  
 L  I29,31  
 L  I29,32  
 L  I29,34  
 L  I29,36  
 L  I29,37  
 L  I29,38  
 L  I29,39  
 L  I29,41  
 L  I29,42  
 L  I29,43  
 L  I29,46  
 L  I29,47  
 L  I29,48  
 L  I29,49  
 L  I30,31  
 L  I30,33  
 L  I30,34  
 L  I30,36  
 L  I30,37  
 L  I30,38  
 L  I30,40  
 L  I30,41  
 L  I30,42  
 L  I30,43  
 L  I30,46  
 L  I30,47  
 L  I30,48  
 L  I31,32  
 L  I31,33  
 L  I31,35  
 L  I31,38  
 L  I31,39  
 L  I31,41  
 L  I31,42  
 L  I31,43  
 L  I31,45  
 L  I31,48  
 L  I31,49  
 L  I32,33  
 L  I32,34  
 L  I32,35  
 L  I32,37  
 L  I32,38  
 L  I32,39  
 L  I32,40  
 L  I32,41  
 L  I32,42  
 L  I32,43  
 L  I32,44  
 L  I32,45  
 L  I32,46  
 L  I32,47  
 L  I32,48  
 L  I33,34  
 L  I33,35  
 L  I33,36  
 L  I33,37  
 L  I33,38  
 L  I33,40  
 L  I33,41  
 L  I33,43  
 L  I33,44  
 L  I33,45  
 L  I33,46  
 L  I33,47  
 L  I33,48  
 L  I33,49  
 L  I34,35  
 L  I34,37  
 L  I34,38  
 L  I34,39  
 L  I34,40  
 L  I34,41  
 L  I34,42  
 L  I34,43  
 L  I34,45  
 L  I34,47  
 L  I35,36  
 L  I35,38  
 L  I35,39  
 L  I35,41  
 L  I35,42  
 L  I35,44  
 L  I35,45  
 L  I35,46  
 L  I35,47  
 L  I35,48  
 L  I35,49  
 L  I36,38  
 L  I36,39  
 L  I36,41  
 L  I36,43  
 L  I36,44  
 L  I36,45  
 L  I36,47  
 L  I36,48  
 L  I37,38  
 L  I37,39  
 L  I37,41  
 L  I37,42  
 L  I37,43  
 L  I37,44  
 L  I37,45  
 L  I37,46  
 L  I37,47  
 L  I37,49  
 L  I38,41  
 L  I38,42  
 L  I38,43  
 L  I38,45  
 L  I38,46  
 L  I38,47  
 L  I38,48  
 L  I38,49  
 L  I39,40  
 L  I39,41  
 L  I39,42  
 L  I39,43  
 L  I39,44  
 L  I39,45  
 L  I39,46  
 L  I39,47  
 L  I40,44  
 L  I40,45  
 L  I40,47  
 L  I40,48  
 L  I40,49  
 L  I41,43  
 L  I41,45  
 L  I41,46  
 L  I41,47  
 L  I41,48  
 L  I41,49  
 L  I42,44  
 L  I42,47  
 L  I42,48  
 L  I42,49  
 L  I43,44  
 L  I43,45  
 L  I43,49  
 L  I44,45  
 L  I44,47  
 L  I44,48  
 L  I45,47  
 L  I45,49  
 L  I46,48  
 L  I46,49  
 L  I47,48  
 L  I48,49  
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    w0,1      KL                              1
    w0,1      I0,1                            1
    w0,2      KL                              1
    w0,2      I0,2                            1
    w0,3      KL                              1
    w0,3      I0,3                            1
    w0,5      KL                              1
    w0,5      I0,5                            1
    w0,6      KL                              1
    w0,6      I0,6                            1
    w0,7      KL                              1
    w0,7      I0,7                            1
    w0,8      KL                              1
    w0,8      I0,8                            1
    w0,9      KL                              1
    w0,9      I0,9                            1
    w0,10     KL                              1
    w0,10     I0,10                           1
    w0,11     KL                              1
    w0,11     I0,11                           1
    w0,13     KL                              1
    w0,13     I0,13                           1
    w0,14     KL                              1
    w0,14     I0,14                           1
    w0,15     KL                              1
    w0,15     I0,15                           1
    w0,16     KL                              1
    w0,16     I0,16                           1
    w0,17     KL                              1
    w0,17     I0,17                           1
    w0,18     KL                              1
    w0,18     I0,18                           1
    w0,19     KL                              1
    w0,19     I0,19                           1
    w0,20     KL                              1
    w0,20     I0,20                           1
    w0,22     KL                              1
    w0,22     I0,22                           1
    w0,23     KL                              1
    w0,23     I0,23                           1
    w0,25     KL                              1
    w0,25     I0,25                           1
    w0,26     KL                              1
    w0,26     I0,26                           1
    w0,31     KL                              1
    w0,31     I0,31                           1
    w0,32     KL                              1
    w0,32     I0,32                           1
    w0,33     KL                              1
    w0,33     I0,33                           1
    w0,34     KL                              1
    w0,34     I0,34                           1
    w0,38     KL                              1
    w0,38     I0,38                           1
    w0,40     KL                              1
    w0,40     I0,40                           1
    w0,43     KL                              1
    w0,43     I0,43                           1
    w0,44     KL                              1
    w0,44     I0,44                           1
    w0,45     KL                              1
    w0,45     I0,45                           1
    w0,46     KL                              1
    w0,46     I0,46                           1
    w0,47     KL                              1
    w0,47     I0,47                           1
    w0,48     KL                              1
    w0,48     I0,48                           1
    w1,2      KL                              1
    w1,2      I1,2                            1
    w1,3      KL                              1
    w1,3      I1,3                            1
    w1,5      KL                              1
    w1,5      I1,5                            1
    w1,6      KL                              1
    w1,6      I1,6                            1
    w1,8      KL                              1
    w1,8      I1,8                            1
    w1,9      KL                              1
    w1,9      I1,9                            1
    w1,10     KL                              1
    w1,10     I1,10                           1
    w1,11     KL                              1
    w1,11     I1,11                           1
    w1,12     KL                              1
    w1,12     I1,12                           1
    w1,14     KL                              1
    w1,14     I1,14                           1
    w1,15     KL                              1
    w1,15     I1,15                           1
    w1,16     KL                              1
    w1,16     I1,16                           1
    w1,17     KL                              1
    w1,17     I1,17                           1
    w1,18     KL                              1
    w1,18     I1,18                           1
    w1,19     KL                              1
    w1,19     I1,19                           1
    w1,20     KL                              1
    w1,20     I1,20                           1
    w1,21     KL                              1
    w1,21     I1,21                           1
    w1,22     KL                              1
    w1,22     I1,22                           1
    w1,24     KL                              1
    w1,24     I1,24                           1
    w1,26     KL                              1
    w1,26     I1,26                           1
    w1,27     KL                              1
    w1,27     I1,27                           1
    w1,29     KL                              1
    w1,29     I1,29                           1
    w1,31     KL                              1
    w1,31     I1,31                           1
    w1,32     KL                              1
    w1,32     I1,32                           1
    w1,34     KL                              1
    w1,34     I1,34                           1
    w1,35     KL                              1
    w1,35     I1,35                           1
    w1,37     KL                              1
    w1,37     I1,37                           1
    w1,38     KL                              1
    w1,38     I1,38                           1
    w1,40     KL                              1
    w1,40     I1,40                           1
    w1,41     KL                              1
    w1,41     I1,41                           1
    w1,42     KL                              1
    w1,42     I1,42                           1
    w1,43     KL                              1
    w1,43     I1,43                           1
    w1,44     KL                              1
    w1,44     I1,44                           1
    w1,45     KL                              1
    w1,45     I1,45                           1
    w1,46     KL                              1
    w1,46     I1,46                           1
    w1,48     KL                              1
    w1,48     I1,48                           1
    w1,49     KL                              1
    w1,49     I1,49                           1
    w2,4      KL                              1
    w2,4      I2,4                            1
    w2,5      KL                              1
    w2,5      I2,5                            1
    w2,7      KL                              1
    w2,7      I2,7                            1
    w2,9      KL                              1
    w2,9      I2,9                            1
    w2,10     KL                              1
    w2,10     I2,10                           1
    w2,11     KL                              1
    w2,11     I2,11                           1
    w2,12     KL                              1
    w2,12     I2,12                           1
    w2,14     KL                              1
    w2,14     I2,14                           1
    w2,18     KL                              1
    w2,18     I2,18                           1
    w2,19     KL                              1
    w2,19     I2,19                           1
    w2,20     KL                              1
    w2,20     I2,20                           1
    w2,21     KL                              1
    w2,21     I2,21                           1
    w2,22     KL                              1
    w2,22     I2,22                           1
    w2,27     KL                              1
    w2,27     I2,27                           1
    w2,28     KL                              1
    w2,28     I2,28                           1
    w2,30     KL                              1
    w2,30     I2,30                           1
    w2,31     KL                              1
    w2,31     I2,31                           1
    w2,32     KL                              1
    w2,32     I2,32                           1
    w2,33     KL                              1
    w2,33     I2,33                           1
    w2,34     KL                              1
    w2,34     I2,34                           1
    w2,35     KL                              1
    w2,35     I2,35                           1
    w2,39     KL                              1
    w2,39     I2,39                           1
    w2,40     KL                              1
    w2,40     I2,40                           1
    w2,41     KL                              1
    w2,41     I2,41                           1
    w2,42     KL                              1
    w2,42     I2,42                           1
    w2,44     KL                              1
    w2,44     I2,44                           1
    w2,45     KL                              1
    w2,45     I2,45                           1
    w2,47     KL                              1
    w2,47     I2,47                           1
    w2,49     KL                              1
    w2,49     I2,49                           1
    w3,5      KL                              1
    w3,5      I3,5                            1
    w3,6      KL                              1
    w3,6      I3,6                            1
    w3,8      KL                              1
    w3,8      I3,8                            1
    w3,9      KL                              1
    w3,9      I3,9                            1
    w3,14     KL                              1
    w3,14     I3,14                           1
    w3,17     KL                              1
    w3,17     I3,17                           1
    w3,19     KL                              1
    w3,19     I3,19                           1
    w3,20     KL                              1
    w3,20     I3,20                           1
    w3,21     KL                              1
    w3,21     I3,21                           1
    w3,22     KL                              1
    w3,22     I3,22                           1
    w3,23     KL                              1
    w3,23     I3,23                           1
    w3,24     KL                              1
    w3,24     I3,24                           1
    w3,25     KL                              1
    w3,25     I3,25                           1
    w3,26     KL                              1
    w3,26     I3,26                           1
    w3,27     KL                              1
    w3,27     I3,27                           1
    w3,33     KL                              1
    w3,33     I3,33                           1
    w3,34     KL                              1
    w3,34     I3,34                           1
    w3,35     KL                              1
    w3,35     I3,35                           1
    w3,37     KL                              1
    w3,37     I3,37                           1
    w3,38     KL                              1
    w3,38     I3,38                           1
    w3,39     KL                              1
    w3,39     I3,39                           1
    w3,40     KL                              1
    w3,40     I3,40                           1
    w3,41     KL                              1
    w3,41     I3,41                           1
    w3,42     KL                              1
    w3,42     I3,42                           1
    w3,43     KL                              1
    w3,43     I3,43                           1
    w3,44     KL                              1
    w3,44     I3,44                           1
    w3,45     KL                              1
    w3,45     I3,45                           1
    w3,47     KL                              1
    w3,47     I3,47                           1
    w3,49     KL                              1
    w3,49     I3,49                           1
    w4,5      KL                              1
    w4,5      I4,5                            1
    w4,6      KL                              1
    w4,6      I4,6                            1
    w4,8      KL                              1
    w4,8      I4,8                            1
    w4,9      KL                              1
    w4,9      I4,9                            1
    w4,11     KL                              1
    w4,11     I4,11                           1
    w4,13     KL                              1
    w4,13     I4,13                           1
    w4,15     KL                              1
    w4,15     I4,15                           1
    w4,16     KL                              1
    w4,16     I4,16                           1
    w4,18     KL                              1
    w4,18     I4,18                           1
    w4,20     KL                              1
    w4,20     I4,20                           1
    w4,22     KL                              1
    w4,22     I4,22                           1
    w4,25     KL                              1
    w4,25     I4,25                           1
    w4,26     KL                              1
    w4,26     I4,26                           1
    w4,28     KL                              1
    w4,28     I4,28                           1
    w4,29     KL                              1
    w4,29     I4,29                           1
    w4,30     KL                              1
    w4,30     I4,30                           1
    w4,31     KL                              1
    w4,31     I4,31                           1
    w4,32     KL                              1
    w4,32     I4,32                           1
    w4,33     KL                              1
    w4,33     I4,33                           1
    w4,34     KL                              1
    w4,34     I4,34                           1
    w4,37     KL                              1
    w4,37     I4,37                           1
    w4,38     KL                              1
    w4,38     I4,38                           1
    w4,39     KL                              1
    w4,39     I4,39                           1
    w4,40     KL                              1
    w4,40     I4,40                           1
    w4,41     KL                              1
    w4,41     I4,41                           1
    w4,43     KL                              1
    w4,43     I4,43                           1
    w4,45     KL                              1
    w4,45     I4,45                           1
    w4,46     KL                              1
    w4,46     I4,46                           1
    w4,47     KL                              1
    w4,47     I4,47                           1
    w4,49     KL                              1
    w4,49     I4,49                           1
    w5,6      KL                              1
    w5,6      I5,6                            1
    w5,7      KL                              1
    w5,7      I5,7                            1
    w5,8      KL                              1
    w5,8      I5,8                            1
    w5,10     KL                              1
    w5,10     I5,10                           1
    w5,11     KL                              1
    w5,11     I5,11                           1
    w5,12     KL                              1
    w5,12     I5,12                           1
    w5,16     KL                              1
    w5,16     I5,16                           1
    w5,18     KL                              1
    w5,18     I5,18                           1
    w5,19     KL                              1
    w5,19     I5,19                           1
    w5,20     KL                              1
    w5,20     I5,20                           1
    w5,21     KL                              1
    w5,21     I5,21                           1
    w5,22     KL                              1
    w5,22     I5,22                           1
    w5,23     KL                              1
    w5,23     I5,23                           1
    w5,24     KL                              1
    w5,24     I5,24                           1
    w5,25     KL                              1
    w5,25     I5,25                           1
    w5,26     KL                              1
    w5,26     I5,26                           1
    w5,27     KL                              1
    w5,27     I5,27                           1
    w5,28     KL                              1
    w5,28     I5,28                           1
    w5,29     KL                              1
    w5,29     I5,29                           1
    w5,30     KL                              1
    w5,30     I5,30                           1
    w5,31     KL                              1
    w5,31     I5,31                           1
    w5,32     KL                              1
    w5,32     I5,32                           1
    w5,33     KL                              1
    w5,33     I5,33                           1
    w5,34     KL                              1
    w5,34     I5,34                           1
    w5,35     KL                              1
    w5,35     I5,35                           1
    w5,36     KL                              1
    w5,36     I5,36                           1
    w5,37     KL                              1
    w5,37     I5,37                           1
    w5,39     KL                              1
    w5,39     I5,39                           1
    w5,40     KL                              1
    w5,40     I5,40                           1
    w5,41     KL                              1
    w5,41     I5,41                           1
    w5,42     KL                              1
    w5,42     I5,42                           1
    w5,43     KL                              1
    w5,43     I5,43                           1
    w5,45     KL                              1
    w5,45     I5,45                           1
    w5,47     KL                              1
    w5,47     I5,47                           1
    w5,49     KL                              1
    w5,49     I5,49                           1
    w6,8      KL                              1
    w6,8      I6,8                            1
    w6,10     KL                              1
    w6,10     I6,10                           1
    w6,12     KL                              1
    w6,12     I6,12                           1
    w6,13     KL                              1
    w6,13     I6,13                           1
    w6,15     KL                              1
    w6,15     I6,15                           1
    w6,17     KL                              1
    w6,17     I6,17                           1
    w6,18     KL                              1
    w6,18     I6,18                           1
    w6,19     KL                              1
    w6,19     I6,19                           1
    w6,20     KL                              1
    w6,20     I6,20                           1
    w6,22     KL                              1
    w6,22     I6,22                           1
    w6,23     KL                              1
    w6,23     I6,23                           1
    w6,24     KL                              1
    w6,24     I6,24                           1
    w6,25     KL                              1
    w6,25     I6,25                           1
    w6,27     KL                              1
    w6,27     I6,27                           1
    w6,28     KL                              1
    w6,28     I6,28                           1
    w6,29     KL                              1
    w6,29     I6,29                           1
    w6,30     KL                              1
    w6,30     I6,30                           1
    w6,33     KL                              1
    w6,33     I6,33                           1
    w6,34     KL                              1
    w6,34     I6,34                           1
    w6,38     KL                              1
    w6,38     I6,38                           1
    w6,39     KL                              1
    w6,39     I6,39                           1
    w6,40     KL                              1
    w6,40     I6,40                           1
    w6,41     KL                              1
    w6,41     I6,41                           1
    w6,42     KL                              1
    w6,42     I6,42                           1
    w6,43     KL                              1
    w6,43     I6,43                           1
    w6,44     KL                              1
    w6,44     I6,44                           1
    w6,45     KL                              1
    w6,45     I6,45                           1
    w6,46     KL                              1
    w6,46     I6,46                           1
    w6,47     KL                              1
    w6,47     I6,47                           1
    w6,48     KL                              1
    w6,48     I6,48                           1
    w6,49     KL                              1
    w6,49     I6,49                           1
    w7,8      KL                              1
    w7,8      I7,8                            1
    w7,10     KL                              1
    w7,10     I7,10                           1
    w7,12     KL                              1
    w7,12     I7,12                           1
    w7,14     KL                              1
    w7,14     I7,14                           1
    w7,16     KL                              1
    w7,16     I7,16                           1
    w7,17     KL                              1
    w7,17     I7,17                           1
    w7,18     KL                              1
    w7,18     I7,18                           1
    w7,19     KL                              1
    w7,19     I7,19                           1
    w7,20     KL                              1
    w7,20     I7,20                           1
    w7,21     KL                              1
    w7,21     I7,21                           1
    w7,23     KL                              1
    w7,23     I7,23                           1
    w7,24     KL                              1
    w7,24     I7,24                           1
    w7,27     KL                              1
    w7,27     I7,27                           1
    w7,28     KL                              1
    w7,28     I7,28                           1
    w7,29     KL                              1
    w7,29     I7,29                           1
    w7,30     KL                              1
    w7,30     I7,30                           1
    w7,31     KL                              1
    w7,31     I7,31                           1
    w7,32     KL                              1
    w7,32     I7,32                           1
    w7,33     KL                              1
    w7,33     I7,33                           1
    w7,35     KL                              1
    w7,35     I7,35                           1
    w7,37     KL                              1
    w7,37     I7,37                           1
    w7,39     KL                              1
    w7,39     I7,39                           1
    w7,41     KL                              1
    w7,41     I7,41                           1
    w7,42     KL                              1
    w7,42     I7,42                           1
    w7,44     KL                              1
    w7,44     I7,44                           1
    w7,45     KL                              1
    w7,45     I7,45                           1
    w7,47     KL                              1
    w7,47     I7,47                           1
    w7,48     KL                              1
    w7,48     I7,48                           1
    w7,49     KL                              1
    w7,49     I7,49                           1
    w8,9      KL                              1
    w8,9      I8,9                            1
    w8,10     KL                              1
    w8,10     I8,10                           1
    w8,12     KL                              1
    w8,12     I8,12                           1
    w8,13     KL                              1
    w8,13     I8,13                           1
    w8,15     KL                              1
    w8,15     I8,15                           1
    w8,17     KL                              1
    w8,17     I8,17                           1
    w8,18     KL                              1
    w8,18     I8,18                           1
    w8,19     KL                              1
    w8,19     I8,19                           1
    w8,20     KL                              1
    w8,20     I8,20                           1
    w8,24     KL                              1
    w8,24     I8,24                           1
    w8,26     KL                              1
    w8,26     I8,26                           1
    w8,27     KL                              1
    w8,27     I8,27                           1
    w8,31     KL                              1
    w8,31     I8,31                           1
    w8,32     KL                              1
    w8,32     I8,32                           1
    w8,33     KL                              1
    w8,33     I8,33                           1
    w8,34     KL                              1
    w8,34     I8,34                           1
    w8,35     KL                              1
    w8,35     I8,35                           1
    w8,41     KL                              1
    w8,41     I8,41                           1
    w8,42     KL                              1
    w8,42     I8,42                           1
    w8,43     KL                              1
    w8,43     I8,43                           1
    w8,44     KL                              1
    w8,44     I8,44                           1
    w8,45     KL                              1
    w8,45     I8,45                           1
    w8,46     KL                              1
    w8,46     I8,46                           1
    w9,10     KL                              1
    w9,10     I9,10                           1
    w9,11     KL                              1
    w9,11     I9,11                           1
    w9,12     KL                              1
    w9,12     I9,12                           1
    w9,13     KL                              1
    w9,13     I9,13                           1
    w9,15     KL                              1
    w9,15     I9,15                           1
    w9,16     KL                              1
    w9,16     I9,16                           1
    w9,17     KL                              1
    w9,17     I9,17                           1
    w9,18     KL                              1
    w9,18     I9,18                           1
    w9,19     KL                              1
    w9,19     I9,19                           1
    w9,21     KL                              1
    w9,21     I9,21                           1
    w9,22     KL                              1
    w9,22     I9,22                           1
    w9,23     KL                              1
    w9,23     I9,23                           1
    w9,24     KL                              1
    w9,24     I9,24                           1
    w9,26     KL                              1
    w9,26     I9,26                           1
    w9,27     KL                              1
    w9,27     I9,27                           1
    w9,29     KL                              1
    w9,29     I9,29                           1
    w9,30     KL                              1
    w9,30     I9,30                           1
    w9,32     KL                              1
    w9,32     I9,32                           1
    w9,33     KL                              1
    w9,33     I9,33                           1
    w9,34     KL                              1
    w9,34     I9,34                           1
    w9,35     KL                              1
    w9,35     I9,35                           1
    w9,36     KL                              1
    w9,36     I9,36                           1
    w9,38     KL                              1
    w9,38     I9,38                           1
    w9,40     KL                              1
    w9,40     I9,40                           1
    w9,41     KL                              1
    w9,41     I9,41                           1
    w9,42     KL                              1
    w9,42     I9,42                           1
    w9,43     KL                              1
    w9,43     I9,43                           1
    w9,44     KL                              1
    w9,44     I9,44                           1
    w9,45     KL                              1
    w9,45     I9,45                           1
    w9,46     KL                              1
    w9,46     I9,46                           1
    w9,47     KL                              1
    w9,47     I9,47                           1
    w9,48     KL                              1
    w9,48     I9,48                           1
    w9,49     KL                              1
    w9,49     I9,49                           1
    w10,11    KL                              1
    w10,11    I10,11                          1
    w10,14    KL                              1
    w10,14    I10,14                          1
    w10,15    KL                              1
    w10,15    I10,15                          1
    w10,17    KL                              1
    w10,17    I10,17                          1
    w10,18    KL                              1
    w10,18    I10,18                          1
    w10,19    KL                              1
    w10,19    I10,19                          1
    w10,20    KL                              1
    w10,20    I10,20                          1
    w10,21    KL                              1
    w10,21    I10,21                          1
    w10,22    KL                              1
    w10,22    I10,22                          1
    w10,23    KL                              1
    w10,23    I10,23                          1
    w10,24    KL                              1
    w10,24    I10,24                          1
    w10,25    KL                              1
    w10,25    I10,25                          1
    w10,26    KL                              1
    w10,26    I10,26                          1
    w10,27    KL                              1
    w10,27    I10,27                          1
    w10,29    KL                              1
    w10,29    I10,29                          1
    w10,31    KL                              1
    w10,31    I10,31                          1
    w10,32    KL                              1
    w10,32    I10,32                          1
    w10,33    KL                              1
    w10,33    I10,33                          1
    w10,35    KL                              1
    w10,35    I10,35                          1
    w10,36    KL                              1
    w10,36    I10,36                          1
    w10,37    KL                              1
    w10,37    I10,37                          1
    w10,38    KL                              1
    w10,38    I10,38                          1
    w10,39    KL                              1
    w10,39    I10,39                          1
    w10,40    KL                              1
    w10,40    I10,40                          1
    w10,41    KL                              1
    w10,41    I10,41                          1
    w10,42    KL                              1
    w10,42    I10,42                          1
    w10,43    KL                              1
    w10,43    I10,43                          1
    w10,44    KL                              1
    w10,44    I10,44                          1
    w10,47    KL                              1
    w10,47    I10,47                          1
    w10,48    KL                              1
    w10,48    I10,48                          1
    w11,12    KL                              1
    w11,12    I11,12                          1
    w11,13    KL                              1
    w11,13    I11,13                          1
    w11,14    KL                              1
    w11,14    I11,14                          1
    w11,15    KL                              1
    w11,15    I11,15                          1
    w11,16    KL                              1
    w11,16    I11,16                          1
    w11,17    KL                              1
    w11,17    I11,17                          1
    w11,18    KL                              1
    w11,18    I11,18                          1
    w11,19    KL                              1
    w11,19    I11,19                          1
    w11,21    KL                              1
    w11,21    I11,21                          1
    w11,22    KL                              1
    w11,22    I11,22                          1
    w11,25    KL                              1
    w11,25    I11,25                          1
    w11,26    KL                              1
    w11,26    I11,26                          1
    w11,27    KL                              1
    w11,27    I11,27                          1
    w11,28    KL                              1
    w11,28    I11,28                          1
    w11,29    KL                              1
    w11,29    I11,29                          1
    w11,31    KL                              1
    w11,31    I11,31                          1
    w11,33    KL                              1
    w11,33    I11,33                          1
    w11,34    KL                              1
    w11,34    I11,34                          1
    w11,38    KL                              1
    w11,38    I11,38                          1
    w11,39    KL                              1
    w11,39    I11,39                          1
    w11,40    KL                              1
    w11,40    I11,40                          1
    w11,42    KL                              1
    w11,42    I11,42                          1
    w11,44    KL                              1
    w11,44    I11,44                          1
    w11,46    KL                              1
    w11,46    I11,46                          1
    w11,47    KL                              1
    w11,47    I11,47                          1
    w11,48    KL                              1
    w11,48    I11,48                          1
    w11,49    KL                              1
    w11,49    I11,49                          1
    w12,13    KL                              1
    w12,13    I12,13                          1
    w12,15    KL                              1
    w12,15    I12,15                          1
    w12,17    KL                              1
    w12,17    I12,17                          1
    w12,18    KL                              1
    w12,18    I12,18                          1
    w12,20    KL                              1
    w12,20    I12,20                          1
    w12,21    KL                              1
    w12,21    I12,21                          1
    w12,22    KL                              1
    w12,22    I12,22                          1
    w12,23    KL                              1
    w12,23    I12,23                          1
    w12,24    KL                              1
    w12,24    I12,24                          1
    w12,26    KL                              1
    w12,26    I12,26                          1
    w12,28    KL                              1
    w12,28    I12,28                          1
    w12,29    KL                              1
    w12,29    I12,29                          1
    w12,30    KL                              1
    w12,30    I12,30                          1
    w12,31    KL                              1
    w12,31    I12,31                          1
    w12,32    KL                              1
    w12,32    I12,32                          1
    w12,36    KL                              1
    w12,36    I12,36                          1
    w12,37    KL                              1
    w12,37    I12,37                          1
    w12,39    KL                              1
    w12,39    I12,39                          1
    w12,40    KL                              1
    w12,40    I12,40                          1
    w12,41    KL                              1
    w12,41    I12,41                          1
    w12,43    KL                              1
    w12,43    I12,43                          1
    w12,44    KL                              1
    w12,44    I12,44                          1
    w12,45    KL                              1
    w12,45    I12,45                          1
    w12,48    KL                              1
    w12,48    I12,48                          1
    w12,49    KL                              1
    w12,49    I12,49                          1
    w13,14    KL                              1
    w13,14    I13,14                          1
    w13,15    KL                              1
    w13,15    I13,15                          1
    w13,18    KL                              1
    w13,18    I13,18                          1
    w13,20    KL                              1
    w13,20    I13,20                          1
    w13,23    KL                              1
    w13,23    I13,23                          1
    w13,24    KL                              1
    w13,24    I13,24                          1
    w13,25    KL                              1
    w13,25    I13,25                          1
    w13,26    KL                              1
    w13,26    I13,26                          1
    w13,28    KL                              1
    w13,28    I13,28                          1
    w13,29    KL                              1
    w13,29    I13,29                          1
    w13,30    KL                              1
    w13,30    I13,30                          1
    w13,31    KL                              1
    w13,31    I13,31                          1
    w13,32    KL                              1
    w13,32    I13,32                          1
    w13,35    KL                              1
    w13,35    I13,35                          1
    w13,36    KL                              1
    w13,36    I13,36                          1
    w13,37    KL                              1
    w13,37    I13,37                          1
    w13,38    KL                              1
    w13,38    I13,38                          1
    w13,39    KL                              1
    w13,39    I13,39                          1
    w13,40    KL                              1
    w13,40    I13,40                          1
    w13,41    KL                              1
    w13,41    I13,41                          1
    w13,42    KL                              1
    w13,42    I13,42                          1
    w13,43    KL                              1
    w13,43    I13,43                          1
    w13,45    KL                              1
    w13,45    I13,45                          1
    w13,46    KL                              1
    w13,46    I13,46                          1
    w13,47    KL                              1
    w13,47    I13,47                          1
    w13,48    KL                              1
    w13,48    I13,48                          1
    w13,49    KL                              1
    w13,49    I13,49                          1
    w14,15    KL                              1
    w14,15    I14,15                          1
    w14,16    KL                              1
    w14,16    I14,16                          1
    w14,17    KL                              1
    w14,17    I14,17                          1
    w14,18    KL                              1
    w14,18    I14,18                          1
    w14,19    KL                              1
    w14,19    I14,19                          1
    w14,20    KL                              1
    w14,20    I14,20                          1
    w14,22    KL                              1
    w14,22    I14,22                          1
    w14,23    KL                              1
    w14,23    I14,23                          1
    w14,24    KL                              1
    w14,24    I14,24                          1
    w14,25    KL                              1
    w14,25    I14,25                          1
    w14,27    KL                              1
    w14,27    I14,27                          1
    w14,30    KL                              1
    w14,30    I14,30                          1
    w14,31    KL                              1
    w14,31    I14,31                          1
    w14,32    KL                              1
    w14,32    I14,32                          1
    w14,33    KL                              1
    w14,33    I14,33                          1
    w14,34    KL                              1
    w14,34    I14,34                          1
    w14,35    KL                              1
    w14,35    I14,35                          1
    w14,37    KL                              1
    w14,37    I14,37                          1
    w14,38    KL                              1
    w14,38    I14,38                          1
    w14,42    KL                              1
    w14,42    I14,42                          1
    w14,43    KL                              1
    w14,43    I14,43                          1
    w14,44    KL                              1
    w14,44    I14,44                          1
    w14,45    KL                              1
    w14,45    I14,45                          1
    w14,46    KL                              1
    w14,46    I14,46                          1
    w14,47    KL                              1
    w14,47    I14,47                          1
    w14,48    KL                              1
    w14,48    I14,48                          1
    w14,49    KL                              1
    w14,49    I14,49                          1
    w15,16    KL                              1
    w15,16    I15,16                          1
    w15,17    KL                              1
    w15,17    I15,17                          1
    w15,18    KL                              1
    w15,18    I15,18                          1
    w15,19    KL                              1
    w15,19    I15,19                          1
    w15,21    KL                              1
    w15,21    I15,21                          1
    w15,22    KL                              1
    w15,22    I15,22                          1
    w15,23    KL                              1
    w15,23    I15,23                          1
    w15,24    KL                              1
    w15,24    I15,24                          1
    w15,26    KL                              1
    w15,26    I15,26                          1
    w15,27    KL                              1
    w15,27    I15,27                          1
    w15,29    KL                              1
    w15,29    I15,29                          1
    w15,30    KL                              1
    w15,30    I15,30                          1
    w15,31    KL                              1
    w15,31    I15,31                          1
    w15,32    KL                              1
    w15,32    I15,32                          1
    w15,33    KL                              1
    w15,33    I15,33                          1
    w15,34    KL                              1
    w15,34    I15,34                          1
    w15,36    KL                              1
    w15,36    I15,36                          1
    w15,37    KL                              1
    w15,37    I15,37                          1
    w15,39    KL                              1
    w15,39    I15,39                          1
    w15,40    KL                              1
    w15,40    I15,40                          1
    w15,41    KL                              1
    w15,41    I15,41                          1
    w15,43    KL                              1
    w15,43    I15,43                          1
    w15,44    KL                              1
    w15,44    I15,44                          1
    w15,46    KL                              1
    w15,46    I15,46                          1
    w15,47    KL                              1
    w15,47    I15,47                          1
    w15,48    KL                              1
    w15,48    I15,48                          1
    w15,49    KL                              1
    w15,49    I15,49                          1
    w16,18    KL                              1
    w16,18    I16,18                          1
    w16,20    KL                              1
    w16,20    I16,20                          1
    w16,21    KL                              1
    w16,21    I16,21                          1
    w16,22    KL                              1
    w16,22    I16,22                          1
    w16,23    KL                              1
    w16,23    I16,23                          1
    w16,24    KL                              1
    w16,24    I16,24                          1
    w16,27    KL                              1
    w16,27    I16,27                          1
    w16,28    KL                              1
    w16,28    I16,28                          1
    w16,29    KL                              1
    w16,29    I16,29                          1
    w16,30    KL                              1
    w16,30    I16,30                          1
    w16,32    KL                              1
    w16,32    I16,32                          1
    w16,33    KL                              1
    w16,33    I16,33                          1
    w16,34    KL                              1
    w16,34    I16,34                          1
    w16,35    KL                              1
    w16,35    I16,35                          1
    w16,37    KL                              1
    w16,37    I16,37                          1
    w16,38    KL                              1
    w16,38    I16,38                          1
    w16,39    KL                              1
    w16,39    I16,39                          1
    w16,40    KL                              1
    w16,40    I16,40                          1
    w16,41    KL                              1
    w16,41    I16,41                          1
    w16,42    KL                              1
    w16,42    I16,42                          1
    w16,43    KL                              1
    w16,43    I16,43                          1
    w16,44    KL                              1
    w16,44    I16,44                          1
    w16,45    KL                              1
    w16,45    I16,45                          1
    w16,46    KL                              1
    w16,46    I16,46                          1
    w16,47    KL                              1
    w16,47    I16,47                          1
    w16,48    KL                              1
    w16,48    I16,48                          1
    w17,18    KL                              1
    w17,18    I17,18                          1
    w17,20    KL                              1
    w17,20    I17,20                          1
    w17,22    KL                              1
    w17,22    I17,22                          1
    w17,25    KL                              1
    w17,25    I17,25                          1
    w17,26    KL                              1
    w17,26    I17,26                          1
    w17,27    KL                              1
    w17,27    I17,27                          1
    w17,28    KL                              1
    w17,28    I17,28                          1
    w17,30    KL                              1
    w17,30    I17,30                          1
    w17,32    KL                              1
    w17,32    I17,32                          1
    w17,33    KL                              1
    w17,33    I17,33                          1
    w17,34    KL                              1
    w17,34    I17,34                          1
    w17,38    KL                              1
    w17,38    I17,38                          1
    w17,39    KL                              1
    w17,39    I17,39                          1
    w17,43    KL                              1
    w17,43    I17,43                          1
    w17,46    KL                              1
    w17,46    I17,46                          1
    w17,47    KL                              1
    w17,47    I17,47                          1
    w17,49    KL                              1
    w17,49    I17,49                          1
    w18,19    KL                              1
    w18,19    I18,19                          1
    w18,20    KL                              1
    w18,20    I18,20                          1
    w18,21    KL                              1
    w18,21    I18,21                          1
    w18,22    KL                              1
    w18,22    I18,22                          1
    w18,23    KL                              1
    w18,23    I18,23                          1
    w18,24    KL                              1
    w18,24    I18,24                          1
    w18,25    KL                              1
    w18,25    I18,25                          1
    w18,27    KL                              1
    w18,27    I18,27                          1
    w18,28    KL                              1
    w18,28    I18,28                          1
    w18,30    KL                              1
    w18,30    I18,30                          1
    w18,31    KL                              1
    w18,31    I18,31                          1
    w18,34    KL                              1
    w18,34    I18,34                          1
    w18,35    KL                              1
    w18,35    I18,35                          1
    w18,36    KL                              1
    w18,36    I18,36                          1
    w18,37    KL                              1
    w18,37    I18,37                          1
    w18,38    KL                              1
    w18,38    I18,38                          1
    w18,40    KL                              1
    w18,40    I18,40                          1
    w18,41    KL                              1
    w18,41    I18,41                          1
    w18,42    KL                              1
    w18,42    I18,42                          1
    w18,43    KL                              1
    w18,43    I18,43                          1
    w18,45    KL                              1
    w18,45    I18,45                          1
    w18,46    KL                              1
    w18,46    I18,46                          1
    w18,47    KL                              1
    w18,47    I18,47                          1
    w18,48    KL                              1
    w18,48    I18,48                          1
    w19,20    KL                              1
    w19,20    I19,20                          1
    w19,22    KL                              1
    w19,22    I19,22                          1
    w19,23    KL                              1
    w19,23    I19,23                          1
    w19,24    KL                              1
    w19,24    I19,24                          1
    w19,25    KL                              1
    w19,25    I19,25                          1
    w19,26    KL                              1
    w19,26    I19,26                          1
    w19,28    KL                              1
    w19,28    I19,28                          1
    w19,29    KL                              1
    w19,29    I19,29                          1
    w19,31    KL                              1
    w19,31    I19,31                          1
    w19,34    KL                              1
    w19,34    I19,34                          1
    w19,37    KL                              1
    w19,37    I19,37                          1
    w19,39    KL                              1
    w19,39    I19,39                          1
    w19,40    KL                              1
    w19,40    I19,40                          1
    w19,41    KL                              1
    w19,41    I19,41                          1
    w19,45    KL                              1
    w19,45    I19,45                          1
    w19,46    KL                              1
    w19,46    I19,46                          1
    w19,47    KL                              1
    w19,47    I19,47                          1
    w19,48    KL                              1
    w19,48    I19,48                          1
    w19,49    KL                              1
    w19,49    I19,49                          1
    w20,22    KL                              1
    w20,22    I20,22                          1
    w20,23    KL                              1
    w20,23    I20,23                          1
    w20,25    KL                              1
    w20,25    I20,25                          1
    w20,28    KL                              1
    w20,28    I20,28                          1
    w20,29    KL                              1
    w20,29    I20,29                          1
    w20,30    KL                              1
    w20,30    I20,30                          1
    w20,31    KL                              1
    w20,31    I20,31                          1
    w20,32    KL                              1
    w20,32    I20,32                          1
    w20,34    KL                              1
    w20,34    I20,34                          1
    w20,35    KL                              1
    w20,35    I20,35                          1
    w20,36    KL                              1
    w20,36    I20,36                          1
    w20,37    KL                              1
    w20,37    I20,37                          1
    w20,38    KL                              1
    w20,38    I20,38                          1
    w20,40    KL                              1
    w20,40    I20,40                          1
    w20,41    KL                              1
    w20,41    I20,41                          1
    w20,42    KL                              1
    w20,42    I20,42                          1
    w20,45    KL                              1
    w20,45    I20,45                          1
    w20,46    KL                              1
    w20,46    I20,46                          1
    w20,48    KL                              1
    w20,48    I20,48                          1
    w20,49    KL                              1
    w20,49    I20,49                          1
    w21,22    KL                              1
    w21,22    I21,22                          1
    w21,24    KL                              1
    w21,24    I21,24                          1
    w21,25    KL                              1
    w21,25    I21,25                          1
    w21,26    KL                              1
    w21,26    I21,26                          1
    w21,27    KL                              1
    w21,27    I21,27                          1
    w21,28    KL                              1
    w21,28    I21,28                          1
    w21,29    KL                              1
    w21,29    I21,29                          1
    w21,30    KL                              1
    w21,30    I21,30                          1
    w21,31    KL                              1
    w21,31    I21,31                          1
    w21,32    KL                              1
    w21,32    I21,32                          1
    w21,33    KL                              1
    w21,33    I21,33                          1
    w21,37    KL                              1
    w21,37    I21,37                          1
    w21,39    KL                              1
    w21,39    I21,39                          1
    w21,41    KL                              1
    w21,41    I21,41                          1
    w21,43    KL                              1
    w21,43    I21,43                          1
    w21,45    KL                              1
    w21,45    I21,45                          1
    w21,47    KL                              1
    w21,47    I21,47                          1
    w21,48    KL                              1
    w21,48    I21,48                          1
    w21,49    KL                              1
    w21,49    I21,49                          1
    w22,23    KL                              1
    w22,23    I22,23                          1
    w22,25    KL                              1
    w22,25    I22,25                          1
    w22,27    KL                              1
    w22,27    I22,27                          1
    w22,30    KL                              1
    w22,30    I22,30                          1
    w22,33    KL                              1
    w22,33    I22,33                          1
    w22,36    KL                              1
    w22,36    I22,36                          1
    w22,38    KL                              1
    w22,38    I22,38                          1
    w22,39    KL                              1
    w22,39    I22,39                          1
    w22,40    KL                              1
    w22,40    I22,40                          1
    w22,41    KL                              1
    w22,41    I22,41                          1
    w22,42    KL                              1
    w22,42    I22,42                          1
    w22,43    KL                              1
    w22,43    I22,43                          1
    w22,44    KL                              1
    w22,44    I22,44                          1
    w22,45    KL                              1
    w22,45    I22,45                          1
    w22,46    KL                              1
    w22,46    I22,46                          1
    w22,49    KL                              1
    w22,49    I22,49                          1
    w23,24    KL                              1
    w23,24    I23,24                          1
    w23,25    KL                              1
    w23,25    I23,25                          1
    w23,26    KL                              1
    w23,26    I23,26                          1
    w23,27    KL                              1
    w23,27    I23,27                          1
    w23,28    KL                              1
    w23,28    I23,28                          1
    w23,29    KL                              1
    w23,29    I23,29                          1
    w23,32    KL                              1
    w23,32    I23,32                          1
    w23,34    KL                              1
    w23,34    I23,34                          1
    w23,35    KL                              1
    w23,35    I23,35                          1
    w23,36    KL                              1
    w23,36    I23,36                          1
    w23,37    KL                              1
    w23,37    I23,37                          1
    w23,38    KL                              1
    w23,38    I23,38                          1
    w23,39    KL                              1
    w23,39    I23,39                          1
    w23,42    KL                              1
    w23,42    I23,42                          1
    w23,44    KL                              1
    w23,44    I23,44                          1
    w23,45    KL                              1
    w23,45    I23,45                          1
    w23,46    KL                              1
    w23,46    I23,46                          1
    w23,48    KL                              1
    w23,48    I23,48                          1
    w23,49    KL                              1
    w23,49    I23,49                          1
    w24,26    KL                              1
    w24,26    I24,26                          1
    w24,28    KL                              1
    w24,28    I24,28                          1
    w24,29    KL                              1
    w24,29    I24,29                          1
    w24,30    KL                              1
    w24,30    I24,30                          1
    w24,31    KL                              1
    w24,31    I24,31                          1
    w24,32    KL                              1
    w24,32    I24,32                          1
    w24,33    KL                              1
    w24,33    I24,33                          1
    w24,36    KL                              1
    w24,36    I24,36                          1
    w24,38    KL                              1
    w24,38    I24,38                          1
    w24,39    KL                              1
    w24,39    I24,39                          1
    w24,40    KL                              1
    w24,40    I24,40                          1
    w24,42    KL                              1
    w24,42    I24,42                          1
    w24,43    KL                              1
    w24,43    I24,43                          1
    w24,44    KL                              1
    w24,44    I24,44                          1
    w24,46    KL                              1
    w24,46    I24,46                          1
    w24,47    KL                              1
    w24,47    I24,47                          1
    w24,48    KL                              1
    w24,48    I24,48                          1
    w25,26    KL                              1
    w25,26    I25,26                          1
    w25,28    KL                              1
    w25,28    I25,28                          1
    w25,29    KL                              1
    w25,29    I25,29                          1
    w25,30    KL                              1
    w25,30    I25,30                          1
    w25,31    KL                              1
    w25,31    I25,31                          1
    w25,37    KL                              1
    w25,37    I25,37                          1
    w25,38    KL                              1
    w25,38    I25,38                          1
    w25,39    KL                              1
    w25,39    I25,39                          1
    w25,43    KL                              1
    w25,43    I25,43                          1
    w25,44    KL                              1
    w25,44    I25,44                          1
    w25,45    KL                              1
    w25,45    I25,45                          1
    w25,46    KL                              1
    w25,46    I25,46                          1
    w25,47    KL                              1
    w25,47    I25,47                          1
    w26,28    KL                              1
    w26,28    I26,28                          1
    w26,29    KL                              1
    w26,29    I26,29                          1
    w26,30    KL                              1
    w26,30    I26,30                          1
    w26,31    KL                              1
    w26,31    I26,31                          1
    w26,34    KL                              1
    w26,34    I26,34                          1
    w26,37    KL                              1
    w26,37    I26,37                          1
    w26,38    KL                              1
    w26,38    I26,38                          1
    w26,42    KL                              1
    w26,42    I26,42                          1
    w26,43    KL                              1
    w26,43    I26,43                          1
    w26,44    KL                              1
    w26,44    I26,44                          1
    w26,45    KL                              1
    w26,45    I26,45                          1
    w26,47    KL                              1
    w26,47    I26,47                          1
    w26,48    KL                              1
    w26,48    I26,48                          1
    w26,49    KL                              1
    w26,49    I26,49                          1
    w27,28    KL                              1
    w27,28    I27,28                          1
    w27,29    KL                              1
    w27,29    I27,29                          1
    w27,30    KL                              1
    w27,30    I27,30                          1
    w27,32    KL                              1
    w27,32    I27,32                          1
    w27,33    KL                              1
    w27,33    I27,33                          1
    w27,34    KL                              1
    w27,34    I27,34                          1
    w27,35    KL                              1
    w27,35    I27,35                          1
    w27,40    KL                              1
    w27,40    I27,40                          1
    w27,41    KL                              1
    w27,41    I27,41                          1
    w27,42    KL                              1
    w27,42    I27,42                          1
    w27,43    KL                              1
    w27,43    I27,43                          1
    w27,44    KL                              1
    w27,44    I27,44                          1
    w27,45    KL                              1
    w27,45    I27,45                          1
    w27,47    KL                              1
    w27,47    I27,47                          1
    w27,49    KL                              1
    w27,49    I27,49                          1
    w28,29    KL                              1
    w28,29    I28,29                          1
    w28,31    KL                              1
    w28,31    I28,31                          1
    w28,32    KL                              1
    w28,32    I28,32                          1
    w28,33    KL                              1
    w28,33    I28,33                          1
    w28,34    KL                              1
    w28,34    I28,34                          1
    w28,36    KL                              1
    w28,36    I28,36                          1
    w28,39    KL                              1
    w28,39    I28,39                          1
    w28,40    KL                              1
    w28,40    I28,40                          1
    w28,41    KL                              1
    w28,41    I28,41                          1
    w28,43    KL                              1
    w28,43    I28,43                          1
    w28,44    KL                              1
    w28,44    I28,44                          1
    w28,45    KL                              1
    w28,45    I28,45                          1
    w28,46    KL                              1
    w28,46    I28,46                          1
    w28,47    KL                              1
    w28,47    I28,47                          1
    w28,49    KL                              1
    w28,49    I28,49                          1
    w29,30    KL                              1
    w29,30    I29,30                          1
    w29,31    KL                              1
    w29,31    I29,31                          1
    w29,32    KL                              1
    w29,32    I29,32                          1
    w29,34    KL                              1
    w29,34    I29,34                          1
    w29,36    KL                              1
    w29,36    I29,36                          1
    w29,37    KL                              1
    w29,37    I29,37                          1
    w29,38    KL                              1
    w29,38    I29,38                          1
    w29,39    KL                              1
    w29,39    I29,39                          1
    w29,41    KL                              1
    w29,41    I29,41                          1
    w29,42    KL                              1
    w29,42    I29,42                          1
    w29,43    KL                              1
    w29,43    I29,43                          1
    w29,46    KL                              1
    w29,46    I29,46                          1
    w29,47    KL                              1
    w29,47    I29,47                          1
    w29,48    KL                              1
    w29,48    I29,48                          1
    w29,49    KL                              1
    w29,49    I29,49                          1
    w30,31    KL                              1
    w30,31    I30,31                          1
    w30,33    KL                              1
    w30,33    I30,33                          1
    w30,34    KL                              1
    w30,34    I30,34                          1
    w30,36    KL                              1
    w30,36    I30,36                          1
    w30,37    KL                              1
    w30,37    I30,37                          1
    w30,38    KL                              1
    w30,38    I30,38                          1
    w30,40    KL                              1
    w30,40    I30,40                          1
    w30,41    KL                              1
    w30,41    I30,41                          1
    w30,42    KL                              1
    w30,42    I30,42                          1
    w30,43    KL                              1
    w30,43    I30,43                          1
    w30,46    KL                              1
    w30,46    I30,46                          1
    w30,47    KL                              1
    w30,47    I30,47                          1
    w30,48    KL                              1
    w30,48    I30,48                          1
    w31,32    KL                              1
    w31,32    I31,32                          1
    w31,33    KL                              1
    w31,33    I31,33                          1
    w31,35    KL                              1
    w31,35    I31,35                          1
    w31,38    KL                              1
    w31,38    I31,38                          1
    w31,39    KL                              1
    w31,39    I31,39                          1
    w31,41    KL                              1
    w31,41    I31,41                          1
    w31,42    KL                              1
    w31,42    I31,42                          1
    w31,43    KL                              1
    w31,43    I31,43                          1
    w31,45    KL                              1
    w31,45    I31,45                          1
    w31,48    KL                              1
    w31,48    I31,48                          1
    w31,49    KL                              1
    w31,49    I31,49                          1
    w32,33    KL                              1
    w32,33    I32,33                          1
    w32,34    KL                              1
    w32,34    I32,34                          1
    w32,35    KL                              1
    w32,35    I32,35                          1
    w32,37    KL                              1
    w32,37    I32,37                          1
    w32,38    KL                              1
    w32,38    I32,38                          1
    w32,39    KL                              1
    w32,39    I32,39                          1
    w32,40    KL                              1
    w32,40    I32,40                          1
    w32,41    KL                              1
    w32,41    I32,41                          1
    w32,42    KL                              1
    w32,42    I32,42                          1
    w32,43    KL                              1
    w32,43    I32,43                          1
    w32,44    KL                              1
    w32,44    I32,44                          1
    w32,45    KL                              1
    w32,45    I32,45                          1
    w32,46    KL                              1
    w32,46    I32,46                          1
    w32,47    KL                              1
    w32,47    I32,47                          1
    w32,48    KL                              1
    w32,48    I32,48                          1
    w33,34    KL                              1
    w33,34    I33,34                          1
    w33,35    KL                              1
    w33,35    I33,35                          1
    w33,36    KL                              1
    w33,36    I33,36                          1
    w33,37    KL                              1
    w33,37    I33,37                          1
    w33,38    KL                              1
    w33,38    I33,38                          1
    w33,40    KL                              1
    w33,40    I33,40                          1
    w33,41    KL                              1
    w33,41    I33,41                          1
    w33,43    KL                              1
    w33,43    I33,43                          1
    w33,44    KL                              1
    w33,44    I33,44                          1
    w33,45    KL                              1
    w33,45    I33,45                          1
    w33,46    KL                              1
    w33,46    I33,46                          1
    w33,47    KL                              1
    w33,47    I33,47                          1
    w33,48    KL                              1
    w33,48    I33,48                          1
    w33,49    KL                              1
    w33,49    I33,49                          1
    w34,35    KL                              1
    w34,35    I34,35                          1
    w34,37    KL                              1
    w34,37    I34,37                          1
    w34,38    KL                              1
    w34,38    I34,38                          1
    w34,39    KL                              1
    w34,39    I34,39                          1
    w34,40    KL                              1
    w34,40    I34,40                          1
    w34,41    KL                              1
    w34,41    I34,41                          1
    w34,42    KL                              1
    w34,42    I34,42                          1
    w34,43    KL                              1
    w34,43    I34,43                          1
    w34,45    KL                              1
    w34,45    I34,45                          1
    w34,47    KL                              1
    w34,47    I34,47                          1
    w35,36    KL                              1
    w35,36    I35,36                          1
    w35,38    KL                              1
    w35,38    I35,38                          1
    w35,39    KL                              1
    w35,39    I35,39                          1
    w35,41    KL                              1
    w35,41    I35,41                          1
    w35,42    KL                              1
    w35,42    I35,42                          1
    w35,44    KL                              1
    w35,44    I35,44                          1
    w35,45    KL                              1
    w35,45    I35,45                          1
    w35,46    KL                              1
    w35,46    I35,46                          1
    w35,47    KL                              1
    w35,47    I35,47                          1
    w35,48    KL                              1
    w35,48    I35,48                          1
    w35,49    KL                              1
    w35,49    I35,49                          1
    w36,38    KL                              1
    w36,38    I36,38                          1
    w36,39    KL                              1
    w36,39    I36,39                          1
    w36,41    KL                              1
    w36,41    I36,41                          1
    w36,43    KL                              1
    w36,43    I36,43                          1
    w36,44    KL                              1
    w36,44    I36,44                          1
    w36,45    KL                              1
    w36,45    I36,45                          1
    w36,47    KL                              1
    w36,47    I36,47                          1
    w36,48    KL                              1
    w36,48    I36,48                          1
    w37,38    KL                              1
    w37,38    I37,38                          1
    w37,39    KL                              1
    w37,39    I37,39                          1
    w37,41    KL                              1
    w37,41    I37,41                          1
    w37,42    KL                              1
    w37,42    I37,42                          1
    w37,43    KL                              1
    w37,43    I37,43                          1
    w37,44    KL                              1
    w37,44    I37,44                          1
    w37,45    KL                              1
    w37,45    I37,45                          1
    w37,46    KL                              1
    w37,46    I37,46                          1
    w37,47    KL                              1
    w37,47    I37,47                          1
    w37,49    KL                              1
    w37,49    I37,49                          1
    w38,41    KL                              1
    w38,41    I38,41                          1
    w38,42    KL                              1
    w38,42    I38,42                          1
    w38,43    KL                              1
    w38,43    I38,43                          1
    w38,45    KL                              1
    w38,45    I38,45                          1
    w38,46    KL                              1
    w38,46    I38,46                          1
    w38,47    KL                              1
    w38,47    I38,47                          1
    w38,48    KL                              1
    w38,48    I38,48                          1
    w38,49    KL                              1
    w38,49    I38,49                          1
    w39,40    KL                              1
    w39,40    I39,40                          1
    w39,41    KL                              1
    w39,41    I39,41                          1
    w39,42    KL                              1
    w39,42    I39,42                          1
    w39,43    KL                              1
    w39,43    I39,43                          1
    w39,44    KL                              1
    w39,44    I39,44                          1
    w39,45    KL                              1
    w39,45    I39,45                          1
    w39,46    KL                              1
    w39,46    I39,46                          1
    w39,47    KL                              1
    w39,47    I39,47                          1
    w40,44    KL                              1
    w40,44    I40,44                          1
    w40,45    KL                              1
    w40,45    I40,45                          1
    w40,47    KL                              1
    w40,47    I40,47                          1
    w40,48    KL                              1
    w40,48    I40,48                          1
    w40,49    KL                              1
    w40,49    I40,49                          1
    w41,43    KL                              1
    w41,43    I41,43                          1
    w41,45    KL                              1
    w41,45    I41,45                          1
    w41,46    KL                              1
    w41,46    I41,46                          1
    w41,47    KL                              1
    w41,47    I41,47                          1
    w41,48    KL                              1
    w41,48    I41,48                          1
    w41,49    KL                              1
    w41,49    I41,49                          1
    w42,44    KL                              1
    w42,44    I42,44                          1
    w42,47    KL                              1
    w42,47    I42,47                          1
    w42,48    KL                              1
    w42,48    I42,48                          1
    w42,49    KL                              1
    w42,49    I42,49                          1
    w43,44    KL                              1
    w43,44    I43,44                          1
    w43,45    KL                              1
    w43,45    I43,45                          1
    w43,49    KL                              1
    w43,49    I43,49                          1
    w44,45    KL                              1
    w44,45    I44,45                          1
    w44,47    KL                              1
    w44,47    I44,47                          1
    w44,48    KL                              1
    w44,48    I44,48                          1
    w45,47    KL                              1
    w45,47    I45,47                          1
    w45,49    KL                              1
    w45,49    I45,49                          1
    w46,48    KL                              1
    w46,48    I46,48                          1
    w46,49    KL                              1
    w46,49    I46,49                          1
    w47,48    KL                              1
    w47,48    I47,48                          1
    w48,49    KL                              1
    w48,49    I48,49                          1
    y0,1      E0,1                           -1
    y0,1      I0,1                            1
    y0,2      E0,2                           -1
    y0,2      I0,2                            1
    y0,3      E0,3                           -1
    y0,3      I0,3                            1
    y0,5      E0,5                           -1
    y0,5      I0,5                            1
    y0,6      E0,6                           -1
    y0,6      I0,6                            1
    y0,7      E0,7                           -1
    y0,7      I0,7                            1
    y0,8      E0,8                           -1
    y0,8      I0,8                            1
    y0,9      E0,9                           -1
    y0,9      I0,9                            1
    y0,10     E0,10                          -1
    y0,10     I0,10                           1
    y0,11     E0,11                          -1
    y0,11     I0,11                           1
    y0,13     E0,13                          -1
    y0,13     I0,13                           1
    y0,14     E0,14                          -1
    y0,14     I0,14                           1
    y0,15     E0,15                          -1
    y0,15     I0,15                           1
    y0,16     E0,16                          -1
    y0,16     I0,16                           1
    y0,17     E0,17                          -1
    y0,17     I0,17                           1
    y0,18     E0,18                          -1
    y0,18     I0,18                           1
    y0,19     E0,19                          -1
    y0,19     I0,19                           1
    y0,20     E0,20                          -1
    y0,20     I0,20                           1
    y0,22     E0,22                          -1
    y0,22     I0,22                           1
    y0,23     E0,23                          -1
    y0,23     I0,23                           1
    y0,25     E0,25                          -1
    y0,25     I0,25                           1
    y0,26     E0,26                          -1
    y0,26     I0,26                           1
    y0,31     E0,31                          -1
    y0,31     I0,31                           1
    y0,32     E0,32                          -1
    y0,32     I0,32                           1
    y0,33     E0,33                          -1
    y0,33     I0,33                           1
    y0,34     E0,34                          -1
    y0,34     I0,34                           1
    y0,38     E0,38                          -1
    y0,38     I0,38                           1
    y0,40     E0,40                          -1
    y0,40     I0,40                           1
    y0,43     E0,43                          -1
    y0,43     I0,43                           1
    y0,44     E0,44                          -1
    y0,44     I0,44                           1
    y0,45     E0,45                          -1
    y0,45     I0,45                           1
    y0,46     E0,46                          -1
    y0,46     I0,46                           1
    y0,47     E0,47                          -1
    y0,47     I0,47                           1
    y0,48     E0,48                          -1
    y0,48     I0,48                           1
    y1,2      E1,2                           -1
    y1,2      I1,2                            1
    y1,3      E1,3                           -1
    y1,3      I1,3                            1
    y1,5      E1,5                           -1
    y1,5      I1,5                            1
    y1,6      E1,6                           -1
    y1,6      I1,6                            1
    y1,8      E1,8                           -1
    y1,8      I1,8                            1
    y1,9      E1,9                           -1
    y1,9      I1,9                            1
    y1,10     E1,10                          -1
    y1,10     I1,10                           1
    y1,11     E1,11                          -1
    y1,11     I1,11                           1
    y1,12     E1,12                          -1
    y1,12     I1,12                           1
    y1,14     E1,14                          -1
    y1,14     I1,14                           1
    y1,15     E1,15                          -1
    y1,15     I1,15                           1
    y1,16     E1,16                          -1
    y1,16     I1,16                           1
    y1,17     E1,17                          -1
    y1,17     I1,17                           1
    y1,18     E1,18                          -1
    y1,18     I1,18                           1
    y1,19     E1,19                          -1
    y1,19     I1,19                           1
    y1,20     E1,20                          -1
    y1,20     I1,20                           1
    y1,21     E1,21                          -1
    y1,21     I1,21                           1
    y1,22     E1,22                          -1
    y1,22     I1,22                           1
    y1,24     E1,24                          -1
    y1,24     I1,24                           1
    y1,26     E1,26                          -1
    y1,26     I1,26                           1
    y1,27     E1,27                          -1
    y1,27     I1,27                           1
    y1,29     E1,29                          -1
    y1,29     I1,29                           1
    y1,31     E1,31                          -1
    y1,31     I1,31                           1
    y1,32     E1,32                          -1
    y1,32     I1,32                           1
    y1,34     E1,34                          -1
    y1,34     I1,34                           1
    y1,35     E1,35                          -1
    y1,35     I1,35                           1
    y1,37     E1,37                          -1
    y1,37     I1,37                           1
    y1,38     E1,38                          -1
    y1,38     I1,38                           1
    y1,40     E1,40                          -1
    y1,40     I1,40                           1
    y1,41     E1,41                          -1
    y1,41     I1,41                           1
    y1,42     E1,42                          -1
    y1,42     I1,42                           1
    y1,43     E1,43                          -1
    y1,43     I1,43                           1
    y1,44     E1,44                          -1
    y1,44     I1,44                           1
    y1,45     E1,45                          -1
    y1,45     I1,45                           1
    y1,46     E1,46                          -1
    y1,46     I1,46                           1
    y1,48     E1,48                          -1
    y1,48     I1,48                           1
    y1,49     E1,49                          -1
    y1,49     I1,49                           1
    y2,4      E2,4                           -1
    y2,4      I2,4                            1
    y2,5      E2,5                           -1
    y2,5      I2,5                            1
    y2,7      E2,7                           -1
    y2,7      I2,7                            1
    y2,9      E2,9                           -1
    y2,9      I2,9                            1
    y2,10     E2,10                          -1
    y2,10     I2,10                           1
    y2,11     E2,11                          -1
    y2,11     I2,11                           1
    y2,12     E2,12                          -1
    y2,12     I2,12                           1
    y2,14     E2,14                          -1
    y2,14     I2,14                           1
    y2,18     E2,18                          -1
    y2,18     I2,18                           1
    y2,19     E2,19                          -1
    y2,19     I2,19                           1
    y2,20     E2,20                          -1
    y2,20     I2,20                           1
    y2,21     E2,21                          -1
    y2,21     I2,21                           1
    y2,22     E2,22                          -1
    y2,22     I2,22                           1
    y2,27     E2,27                          -1
    y2,27     I2,27                           1
    y2,28     E2,28                          -1
    y2,28     I2,28                           1
    y2,30     E2,30                          -1
    y2,30     I2,30                           1
    y2,31     E2,31                          -1
    y2,31     I2,31                           1
    y2,32     E2,32                          -1
    y2,32     I2,32                           1
    y2,33     E2,33                          -1
    y2,33     I2,33                           1
    y2,34     E2,34                          -1
    y2,34     I2,34                           1
    y2,35     E2,35                          -1
    y2,35     I2,35                           1
    y2,39     E2,39                          -1
    y2,39     I2,39                           1
    y2,40     E2,40                          -1
    y2,40     I2,40                           1
    y2,41     E2,41                          -1
    y2,41     I2,41                           1
    y2,42     E2,42                          -1
    y2,42     I2,42                           1
    y2,44     E2,44                          -1
    y2,44     I2,44                           1
    y2,45     E2,45                          -1
    y2,45     I2,45                           1
    y2,47     E2,47                          -1
    y2,47     I2,47                           1
    y2,49     E2,49                          -1
    y2,49     I2,49                           1
    y3,5      E3,5                           -1
    y3,5      I3,5                            1
    y3,6      E3,6                           -1
    y3,6      I3,6                            1
    y3,8      E3,8                           -1
    y3,8      I3,8                            1
    y3,9      E3,9                           -1
    y3,9      I3,9                            1
    y3,14     E3,14                          -1
    y3,14     I3,14                           1
    y3,17     E3,17                          -1
    y3,17     I3,17                           1
    y3,19     E3,19                          -1
    y3,19     I3,19                           1
    y3,20     E3,20                          -1
    y3,20     I3,20                           1
    y3,21     E3,21                          -1
    y3,21     I3,21                           1
    y3,22     E3,22                          -1
    y3,22     I3,22                           1
    y3,23     E3,23                          -1
    y3,23     I3,23                           1
    y3,24     E3,24                          -1
    y3,24     I3,24                           1
    y3,25     E3,25                          -1
    y3,25     I3,25                           1
    y3,26     E3,26                          -1
    y3,26     I3,26                           1
    y3,27     E3,27                          -1
    y3,27     I3,27                           1
    y3,33     E3,33                          -1
    y3,33     I3,33                           1
    y3,34     E3,34                          -1
    y3,34     I3,34                           1
    y3,35     E3,35                          -1
    y3,35     I3,35                           1
    y3,37     E3,37                          -1
    y3,37     I3,37                           1
    y3,38     E3,38                          -1
    y3,38     I3,38                           1
    y3,39     E3,39                          -1
    y3,39     I3,39                           1
    y3,40     E3,40                          -1
    y3,40     I3,40                           1
    y3,41     E3,41                          -1
    y3,41     I3,41                           1
    y3,42     E3,42                          -1
    y3,42     I3,42                           1
    y3,43     E3,43                          -1
    y3,43     I3,43                           1
    y3,44     E3,44                          -1
    y3,44     I3,44                           1
    y3,45     E3,45                          -1
    y3,45     I3,45                           1
    y3,47     E3,47                          -1
    y3,47     I3,47                           1
    y3,49     E3,49                          -1
    y3,49     I3,49                           1
    y4,5      E4,5                           -1
    y4,5      I4,5                            1
    y4,6      E4,6                           -1
    y4,6      I4,6                            1
    y4,8      E4,8                           -1
    y4,8      I4,8                            1
    y4,9      E4,9                           -1
    y4,9      I4,9                            1
    y4,11     E4,11                          -1
    y4,11     I4,11                           1
    y4,13     E4,13                          -1
    y4,13     I4,13                           1
    y4,15     E4,15                          -1
    y4,15     I4,15                           1
    y4,16     E4,16                          -1
    y4,16     I4,16                           1
    y4,18     E4,18                          -1
    y4,18     I4,18                           1
    y4,20     E4,20                          -1
    y4,20     I4,20                           1
    y4,22     E4,22                          -1
    y4,22     I4,22                           1
    y4,25     E4,25                          -1
    y4,25     I4,25                           1
    y4,26     E4,26                          -1
    y4,26     I4,26                           1
    y4,28     E4,28                          -1
    y4,28     I4,28                           1
    y4,29     E4,29                          -1
    y4,29     I4,29                           1
    y4,30     E4,30                          -1
    y4,30     I4,30                           1
    y4,31     E4,31                          -1
    y4,31     I4,31                           1
    y4,32     E4,32                          -1
    y4,32     I4,32                           1
    y4,33     E4,33                          -1
    y4,33     I4,33                           1
    y4,34     E4,34                          -1
    y4,34     I4,34                           1
    y4,37     E4,37                          -1
    y4,37     I4,37                           1
    y4,38     E4,38                          -1
    y4,38     I4,38                           1
    y4,39     E4,39                          -1
    y4,39     I4,39                           1
    y4,40     E4,40                          -1
    y4,40     I4,40                           1
    y4,41     E4,41                          -1
    y4,41     I4,41                           1
    y4,43     E4,43                          -1
    y4,43     I4,43                           1
    y4,45     E4,45                          -1
    y4,45     I4,45                           1
    y4,46     E4,46                          -1
    y4,46     I4,46                           1
    y4,47     E4,47                          -1
    y4,47     I4,47                           1
    y4,49     E4,49                          -1
    y4,49     I4,49                           1
    y5,6      E5,6                           -1
    y5,6      I5,6                            1
    y5,7      E5,7                           -1
    y5,7      I5,7                            1
    y5,8      E5,8                           -1
    y5,8      I5,8                            1
    y5,10     E5,10                          -1
    y5,10     I5,10                           1
    y5,11     E5,11                          -1
    y5,11     I5,11                           1
    y5,12     E5,12                          -1
    y5,12     I5,12                           1
    y5,16     E5,16                          -1
    y5,16     I5,16                           1
    y5,18     E5,18                          -1
    y5,18     I5,18                           1
    y5,19     E5,19                          -1
    y5,19     I5,19                           1
    y5,20     E5,20                          -1
    y5,20     I5,20                           1
    y5,21     E5,21                          -1
    y5,21     I5,21                           1
    y5,22     E5,22                          -1
    y5,22     I5,22                           1
    y5,23     E5,23                          -1
    y5,23     I5,23                           1
    y5,24     E5,24                          -1
    y5,24     I5,24                           1
    y5,25     E5,25                          -1
    y5,25     I5,25                           1
    y5,26     E5,26                          -1
    y5,26     I5,26                           1
    y5,27     E5,27                          -1
    y5,27     I5,27                           1
    y5,28     E5,28                          -1
    y5,28     I5,28                           1
    y5,29     E5,29                          -1
    y5,29     I5,29                           1
    y5,30     E5,30                          -1
    y5,30     I5,30                           1
    y5,31     E5,31                          -1
    y5,31     I5,31                           1
    y5,32     E5,32                          -1
    y5,32     I5,32                           1
    y5,33     E5,33                          -1
    y5,33     I5,33                           1
    y5,34     E5,34                          -1
    y5,34     I5,34                           1
    y5,35     E5,35                          -1
    y5,35     I5,35                           1
    y5,36     E5,36                          -1
    y5,36     I5,36                           1
    y5,37     E5,37                          -1
    y5,37     I5,37                           1
    y5,39     E5,39                          -1
    y5,39     I5,39                           1
    y5,40     E5,40                          -1
    y5,40     I5,40                           1
    y5,41     E5,41                          -1
    y5,41     I5,41                           1
    y5,42     E5,42                          -1
    y5,42     I5,42                           1
    y5,43     E5,43                          -1
    y5,43     I5,43                           1
    y5,45     E5,45                          -1
    y5,45     I5,45                           1
    y5,47     E5,47                          -1
    y5,47     I5,47                           1
    y5,49     E5,49                          -1
    y5,49     I5,49                           1
    y6,8      E6,8                           -1
    y6,8      I6,8                            1
    y6,10     E6,10                          -1
    y6,10     I6,10                           1
    y6,12     E6,12                          -1
    y6,12     I6,12                           1
    y6,13     E6,13                          -1
    y6,13     I6,13                           1
    y6,15     E6,15                          -1
    y6,15     I6,15                           1
    y6,17     E6,17                          -1
    y6,17     I6,17                           1
    y6,18     E6,18                          -1
    y6,18     I6,18                           1
    y6,19     E6,19                          -1
    y6,19     I6,19                           1
    y6,20     E6,20                          -1
    y6,20     I6,20                           1
    y6,22     E6,22                          -1
    y6,22     I6,22                           1
    y6,23     E6,23                          -1
    y6,23     I6,23                           1
    y6,24     E6,24                          -1
    y6,24     I6,24                           1
    y6,25     E6,25                          -1
    y6,25     I6,25                           1
    y6,27     E6,27                          -1
    y6,27     I6,27                           1
    y6,28     E6,28                          -1
    y6,28     I6,28                           1
    y6,29     E6,29                          -1
    y6,29     I6,29                           1
    y6,30     E6,30                          -1
    y6,30     I6,30                           1
    y6,33     E6,33                          -1
    y6,33     I6,33                           1
    y6,34     E6,34                          -1
    y6,34     I6,34                           1
    y6,38     E6,38                          -1
    y6,38     I6,38                           1
    y6,39     E6,39                          -1
    y6,39     I6,39                           1
    y6,40     E6,40                          -1
    y6,40     I6,40                           1
    y6,41     E6,41                          -1
    y6,41     I6,41                           1
    y6,42     E6,42                          -1
    y6,42     I6,42                           1
    y6,43     E6,43                          -1
    y6,43     I6,43                           1
    y6,44     E6,44                          -1
    y6,44     I6,44                           1
    y6,45     E6,45                          -1
    y6,45     I6,45                           1
    y6,46     E6,46                          -1
    y6,46     I6,46                           1
    y6,47     E6,47                          -1
    y6,47     I6,47                           1
    y6,48     E6,48                          -1
    y6,48     I6,48                           1
    y6,49     E6,49                          -1
    y6,49     I6,49                           1
    y7,8      E7,8                           -1
    y7,8      I7,8                            1
    y7,10     E7,10                          -1
    y7,10     I7,10                           1
    y7,12     E7,12                          -1
    y7,12     I7,12                           1
    y7,14     E7,14                          -1
    y7,14     I7,14                           1
    y7,16     E7,16                          -1
    y7,16     I7,16                           1
    y7,17     E7,17                          -1
    y7,17     I7,17                           1
    y7,18     E7,18                          -1
    y7,18     I7,18                           1
    y7,19     E7,19                          -1
    y7,19     I7,19                           1
    y7,20     E7,20                          -1
    y7,20     I7,20                           1
    y7,21     E7,21                          -1
    y7,21     I7,21                           1
    y7,23     E7,23                          -1
    y7,23     I7,23                           1
    y7,24     E7,24                          -1
    y7,24     I7,24                           1
    y7,27     E7,27                          -1
    y7,27     I7,27                           1
    y7,28     E7,28                          -1
    y7,28     I7,28                           1
    y7,29     E7,29                          -1
    y7,29     I7,29                           1
    y7,30     E7,30                          -1
    y7,30     I7,30                           1
    y7,31     E7,31                          -1
    y7,31     I7,31                           1
    y7,32     E7,32                          -1
    y7,32     I7,32                           1
    y7,33     E7,33                          -1
    y7,33     I7,33                           1
    y7,35     E7,35                          -1
    y7,35     I7,35                           1
    y7,37     E7,37                          -1
    y7,37     I7,37                           1
    y7,39     E7,39                          -1
    y7,39     I7,39                           1
    y7,41     E7,41                          -1
    y7,41     I7,41                           1
    y7,42     E7,42                          -1
    y7,42     I7,42                           1
    y7,44     E7,44                          -1
    y7,44     I7,44                           1
    y7,45     E7,45                          -1
    y7,45     I7,45                           1
    y7,47     E7,47                          -1
    y7,47     I7,47                           1
    y7,48     E7,48                          -1
    y7,48     I7,48                           1
    y7,49     E7,49                          -1
    y7,49     I7,49                           1
    y8,9      E8,9                           -1
    y8,9      I8,9                            1
    y8,10     E8,10                          -1
    y8,10     I8,10                           1
    y8,12     E8,12                          -1
    y8,12     I8,12                           1
    y8,13     E8,13                          -1
    y8,13     I8,13                           1
    y8,15     E8,15                          -1
    y8,15     I8,15                           1
    y8,17     E8,17                          -1
    y8,17     I8,17                           1
    y8,18     E8,18                          -1
    y8,18     I8,18                           1
    y8,19     E8,19                          -1
    y8,19     I8,19                           1
    y8,20     E8,20                          -1
    y8,20     I8,20                           1
    y8,24     E8,24                          -1
    y8,24     I8,24                           1
    y8,26     E8,26                          -1
    y8,26     I8,26                           1
    y8,27     E8,27                          -1
    y8,27     I8,27                           1
    y8,31     E8,31                          -1
    y8,31     I8,31                           1
    y8,32     E8,32                          -1
    y8,32     I8,32                           1
    y8,33     E8,33                          -1
    y8,33     I8,33                           1
    y8,34     E8,34                          -1
    y8,34     I8,34                           1
    y8,35     E8,35                          -1
    y8,35     I8,35                           1
    y8,41     E8,41                          -1
    y8,41     I8,41                           1
    y8,42     E8,42                          -1
    y8,42     I8,42                           1
    y8,43     E8,43                          -1
    y8,43     I8,43                           1
    y8,44     E8,44                          -1
    y8,44     I8,44                           1
    y8,45     E8,45                          -1
    y8,45     I8,45                           1
    y8,46     E8,46                          -1
    y8,46     I8,46                           1
    y9,10     E9,10                          -1
    y9,10     I9,10                           1
    y9,11     E9,11                          -1
    y9,11     I9,11                           1
    y9,12     E9,12                          -1
    y9,12     I9,12                           1
    y9,13     E9,13                          -1
    y9,13     I9,13                           1
    y9,15     E9,15                          -1
    y9,15     I9,15                           1
    y9,16     E9,16                          -1
    y9,16     I9,16                           1
    y9,17     E9,17                          -1
    y9,17     I9,17                           1
    y9,18     E9,18                          -1
    y9,18     I9,18                           1
    y9,19     E9,19                          -1
    y9,19     I9,19                           1
    y9,21     E9,21                          -1
    y9,21     I9,21                           1
    y9,22     E9,22                          -1
    y9,22     I9,22                           1
    y9,23     E9,23                          -1
    y9,23     I9,23                           1
    y9,24     E9,24                          -1
    y9,24     I9,24                           1
    y9,26     E9,26                          -1
    y9,26     I9,26                           1
    y9,27     E9,27                          -1
    y9,27     I9,27                           1
    y9,29     E9,29                          -1
    y9,29     I9,29                           1
    y9,30     E9,30                          -1
    y9,30     I9,30                           1
    y9,32     E9,32                          -1
    y9,32     I9,32                           1
    y9,33     E9,33                          -1
    y9,33     I9,33                           1
    y9,34     E9,34                          -1
    y9,34     I9,34                           1
    y9,35     E9,35                          -1
    y9,35     I9,35                           1
    y9,36     E9,36                          -1
    y9,36     I9,36                           1
    y9,38     E9,38                          -1
    y9,38     I9,38                           1
    y9,40     E9,40                          -1
    y9,40     I9,40                           1
    y9,41     E9,41                          -1
    y9,41     I9,41                           1
    y9,42     E9,42                          -1
    y9,42     I9,42                           1
    y9,43     E9,43                          -1
    y9,43     I9,43                           1
    y9,44     E9,44                          -1
    y9,44     I9,44                           1
    y9,45     E9,45                          -1
    y9,45     I9,45                           1
    y9,46     E9,46                          -1
    y9,46     I9,46                           1
    y9,47     E9,47                          -1
    y9,47     I9,47                           1
    y9,48     E9,48                          -1
    y9,48     I9,48                           1
    y9,49     E9,49                          -1
    y9,49     I9,49                           1
    y10,11    E10,11                         -1
    y10,11    I10,11                          1
    y10,14    E10,14                         -1
    y10,14    I10,14                          1
    y10,15    E10,15                         -1
    y10,15    I10,15                          1
    y10,17    E10,17                         -1
    y10,17    I10,17                          1
    y10,18    E10,18                         -1
    y10,18    I10,18                          1
    y10,19    E10,19                         -1
    y10,19    I10,19                          1
    y10,20    E10,20                         -1
    y10,20    I10,20                          1
    y10,21    E10,21                         -1
    y10,21    I10,21                          1
    y10,22    E10,22                         -1
    y10,22    I10,22                          1
    y10,23    E10,23                         -1
    y10,23    I10,23                          1
    y10,24    E10,24                         -1
    y10,24    I10,24                          1
    y10,25    E10,25                         -1
    y10,25    I10,25                          1
    y10,26    E10,26                         -1
    y10,26    I10,26                          1
    y10,27    E10,27                         -1
    y10,27    I10,27                          1
    y10,29    E10,29                         -1
    y10,29    I10,29                          1
    y10,31    E10,31                         -1
    y10,31    I10,31                          1
    y10,32    E10,32                         -1
    y10,32    I10,32                          1
    y10,33    E10,33                         -1
    y10,33    I10,33                          1
    y10,35    E10,35                         -1
    y10,35    I10,35                          1
    y10,36    E10,36                         -1
    y10,36    I10,36                          1
    y10,37    E10,37                         -1
    y10,37    I10,37                          1
    y10,38    E10,38                         -1
    y10,38    I10,38                          1
    y10,39    E10,39                         -1
    y10,39    I10,39                          1
    y10,40    E10,40                         -1
    y10,40    I10,40                          1
    y10,41    E10,41                         -1
    y10,41    I10,41                          1
    y10,42    E10,42                         -1
    y10,42    I10,42                          1
    y10,43    E10,43                         -1
    y10,43    I10,43                          1
    y10,44    E10,44                         -1
    y10,44    I10,44                          1
    y10,47    E10,47                         -1
    y10,47    I10,47                          1
    y10,48    E10,48                         -1
    y10,48    I10,48                          1
    y11,12    E11,12                         -1
    y11,12    I11,12                          1
    y11,13    E11,13                         -1
    y11,13    I11,13                          1
    y11,14    E11,14                         -1
    y11,14    I11,14                          1
    y11,15    E11,15                         -1
    y11,15    I11,15                          1
    y11,16    E11,16                         -1
    y11,16    I11,16                          1
    y11,17    E11,17                         -1
    y11,17    I11,17                          1
    y11,18    E11,18                         -1
    y11,18    I11,18                          1
    y11,19    E11,19                         -1
    y11,19    I11,19                          1
    y11,21    E11,21                         -1
    y11,21    I11,21                          1
    y11,22    E11,22                         -1
    y11,22    I11,22                          1
    y11,25    E11,25                         -1
    y11,25    I11,25                          1
    y11,26    E11,26                         -1
    y11,26    I11,26                          1
    y11,27    E11,27                         -1
    y11,27    I11,27                          1
    y11,28    E11,28                         -1
    y11,28    I11,28                          1
    y11,29    E11,29                         -1
    y11,29    I11,29                          1
    y11,31    E11,31                         -1
    y11,31    I11,31                          1
    y11,33    E11,33                         -1
    y11,33    I11,33                          1
    y11,34    E11,34                         -1
    y11,34    I11,34                          1
    y11,38    E11,38                         -1
    y11,38    I11,38                          1
    y11,39    E11,39                         -1
    y11,39    I11,39                          1
    y11,40    E11,40                         -1
    y11,40    I11,40                          1
    y11,42    E11,42                         -1
    y11,42    I11,42                          1
    y11,44    E11,44                         -1
    y11,44    I11,44                          1
    y11,46    E11,46                         -1
    y11,46    I11,46                          1
    y11,47    E11,47                         -1
    y11,47    I11,47                          1
    y11,48    E11,48                         -1
    y11,48    I11,48                          1
    y11,49    E11,49                         -1
    y11,49    I11,49                          1
    y12,13    E12,13                         -1
    y12,13    I12,13                          1
    y12,15    E12,15                         -1
    y12,15    I12,15                          1
    y12,17    E12,17                         -1
    y12,17    I12,17                          1
    y12,18    E12,18                         -1
    y12,18    I12,18                          1
    y12,20    E12,20                         -1
    y12,20    I12,20                          1
    y12,21    E12,21                         -1
    y12,21    I12,21                          1
    y12,22    E12,22                         -1
    y12,22    I12,22                          1
    y12,23    E12,23                         -1
    y12,23    I12,23                          1
    y12,24    E12,24                         -1
    y12,24    I12,24                          1
    y12,26    E12,26                         -1
    y12,26    I12,26                          1
    y12,28    E12,28                         -1
    y12,28    I12,28                          1
    y12,29    E12,29                         -1
    y12,29    I12,29                          1
    y12,30    E12,30                         -1
    y12,30    I12,30                          1
    y12,31    E12,31                         -1
    y12,31    I12,31                          1
    y12,32    E12,32                         -1
    y12,32    I12,32                          1
    y12,36    E12,36                         -1
    y12,36    I12,36                          1
    y12,37    E12,37                         -1
    y12,37    I12,37                          1
    y12,39    E12,39                         -1
    y12,39    I12,39                          1
    y12,40    E12,40                         -1
    y12,40    I12,40                          1
    y12,41    E12,41                         -1
    y12,41    I12,41                          1
    y12,43    E12,43                         -1
    y12,43    I12,43                          1
    y12,44    E12,44                         -1
    y12,44    I12,44                          1
    y12,45    E12,45                         -1
    y12,45    I12,45                          1
    y12,48    E12,48                         -1
    y12,48    I12,48                          1
    y12,49    E12,49                         -1
    y12,49    I12,49                          1
    y13,14    E13,14                         -1
    y13,14    I13,14                          1
    y13,15    E13,15                         -1
    y13,15    I13,15                          1
    y13,18    E13,18                         -1
    y13,18    I13,18                          1
    y13,20    E13,20                         -1
    y13,20    I13,20                          1
    y13,23    E13,23                         -1
    y13,23    I13,23                          1
    y13,24    E13,24                         -1
    y13,24    I13,24                          1
    y13,25    E13,25                         -1
    y13,25    I13,25                          1
    y13,26    E13,26                         -1
    y13,26    I13,26                          1
    y13,28    E13,28                         -1
    y13,28    I13,28                          1
    y13,29    E13,29                         -1
    y13,29    I13,29                          1
    y13,30    E13,30                         -1
    y13,30    I13,30                          1
    y13,31    E13,31                         -1
    y13,31    I13,31                          1
    y13,32    E13,32                         -1
    y13,32    I13,32                          1
    y13,35    E13,35                         -1
    y13,35    I13,35                          1
    y13,36    E13,36                         -1
    y13,36    I13,36                          1
    y13,37    E13,37                         -1
    y13,37    I13,37                          1
    y13,38    E13,38                         -1
    y13,38    I13,38                          1
    y13,39    E13,39                         -1
    y13,39    I13,39                          1
    y13,40    E13,40                         -1
    y13,40    I13,40                          1
    y13,41    E13,41                         -1
    y13,41    I13,41                          1
    y13,42    E13,42                         -1
    y13,42    I13,42                          1
    y13,43    E13,43                         -1
    y13,43    I13,43                          1
    y13,45    E13,45                         -1
    y13,45    I13,45                          1
    y13,46    E13,46                         -1
    y13,46    I13,46                          1
    y13,47    E13,47                         -1
    y13,47    I13,47                          1
    y13,48    E13,48                         -1
    y13,48    I13,48                          1
    y13,49    E13,49                         -1
    y13,49    I13,49                          1
    y14,15    E14,15                         -1
    y14,15    I14,15                          1
    y14,16    E14,16                         -1
    y14,16    I14,16                          1
    y14,17    E14,17                         -1
    y14,17    I14,17                          1
    y14,18    E14,18                         -1
    y14,18    I14,18                          1
    y14,19    E14,19                         -1
    y14,19    I14,19                          1
    y14,20    E14,20                         -1
    y14,20    I14,20                          1
    y14,22    E14,22                         -1
    y14,22    I14,22                          1
    y14,23    E14,23                         -1
    y14,23    I14,23                          1
    y14,24    E14,24                         -1
    y14,24    I14,24                          1
    y14,25    E14,25                         -1
    y14,25    I14,25                          1
    y14,27    E14,27                         -1
    y14,27    I14,27                          1
    y14,30    E14,30                         -1
    y14,30    I14,30                          1
    y14,31    E14,31                         -1
    y14,31    I14,31                          1
    y14,32    E14,32                         -1
    y14,32    I14,32                          1
    y14,33    E14,33                         -1
    y14,33    I14,33                          1
    y14,34    E14,34                         -1
    y14,34    I14,34                          1
    y14,35    E14,35                         -1
    y14,35    I14,35                          1
    y14,37    E14,37                         -1
    y14,37    I14,37                          1
    y14,38    E14,38                         -1
    y14,38    I14,38                          1
    y14,42    E14,42                         -1
    y14,42    I14,42                          1
    y14,43    E14,43                         -1
    y14,43    I14,43                          1
    y14,44    E14,44                         -1
    y14,44    I14,44                          1
    y14,45    E14,45                         -1
    y14,45    I14,45                          1
    y14,46    E14,46                         -1
    y14,46    I14,46                          1
    y14,47    E14,47                         -1
    y14,47    I14,47                          1
    y14,48    E14,48                         -1
    y14,48    I14,48                          1
    y14,49    E14,49                         -1
    y14,49    I14,49                          1
    y15,16    E15,16                         -1
    y15,16    I15,16                          1
    y15,17    E15,17                         -1
    y15,17    I15,17                          1
    y15,18    E15,18                         -1
    y15,18    I15,18                          1
    y15,19    E15,19                         -1
    y15,19    I15,19                          1
    y15,21    E15,21                         -1
    y15,21    I15,21                          1
    y15,22    E15,22                         -1
    y15,22    I15,22                          1
    y15,23    E15,23                         -1
    y15,23    I15,23                          1
    y15,24    E15,24                         -1
    y15,24    I15,24                          1
    y15,26    E15,26                         -1
    y15,26    I15,26                          1
    y15,27    E15,27                         -1
    y15,27    I15,27                          1
    y15,29    E15,29                         -1
    y15,29    I15,29                          1
    y15,30    E15,30                         -1
    y15,30    I15,30                          1
    y15,31    E15,31                         -1
    y15,31    I15,31                          1
    y15,32    E15,32                         -1
    y15,32    I15,32                          1
    y15,33    E15,33                         -1
    y15,33    I15,33                          1
    y15,34    E15,34                         -1
    y15,34    I15,34                          1
    y15,36    E15,36                         -1
    y15,36    I15,36                          1
    y15,37    E15,37                         -1
    y15,37    I15,37                          1
    y15,39    E15,39                         -1
    y15,39    I15,39                          1
    y15,40    E15,40                         -1
    y15,40    I15,40                          1
    y15,41    E15,41                         -1
    y15,41    I15,41                          1
    y15,43    E15,43                         -1
    y15,43    I15,43                          1
    y15,44    E15,44                         -1
    y15,44    I15,44                          1
    y15,46    E15,46                         -1
    y15,46    I15,46                          1
    y15,47    E15,47                         -1
    y15,47    I15,47                          1
    y15,48    E15,48                         -1
    y15,48    I15,48                          1
    y15,49    E15,49                         -1
    y15,49    I15,49                          1
    y16,18    E16,18                         -1
    y16,18    I16,18                          1
    y16,20    E16,20                         -1
    y16,20    I16,20                          1
    y16,21    E16,21                         -1
    y16,21    I16,21                          1
    y16,22    E16,22                         -1
    y16,22    I16,22                          1
    y16,23    E16,23                         -1
    y16,23    I16,23                          1
    y16,24    E16,24                         -1
    y16,24    I16,24                          1
    y16,27    E16,27                         -1
    y16,27    I16,27                          1
    y16,28    E16,28                         -1
    y16,28    I16,28                          1
    y16,29    E16,29                         -1
    y16,29    I16,29                          1
    y16,30    E16,30                         -1
    y16,30    I16,30                          1
    y16,32    E16,32                         -1
    y16,32    I16,32                          1
    y16,33    E16,33                         -1
    y16,33    I16,33                          1
    y16,34    E16,34                         -1
    y16,34    I16,34                          1
    y16,35    E16,35                         -1
    y16,35    I16,35                          1
    y16,37    E16,37                         -1
    y16,37    I16,37                          1
    y16,38    E16,38                         -1
    y16,38    I16,38                          1
    y16,39    E16,39                         -1
    y16,39    I16,39                          1
    y16,40    E16,40                         -1
    y16,40    I16,40                          1
    y16,41    E16,41                         -1
    y16,41    I16,41                          1
    y16,42    E16,42                         -1
    y16,42    I16,42                          1
    y16,43    E16,43                         -1
    y16,43    I16,43                          1
    y16,44    E16,44                         -1
    y16,44    I16,44                          1
    y16,45    E16,45                         -1
    y16,45    I16,45                          1
    y16,46    E16,46                         -1
    y16,46    I16,46                          1
    y16,47    E16,47                         -1
    y16,47    I16,47                          1
    y16,48    E16,48                         -1
    y16,48    I16,48                          1
    y17,18    E17,18                         -1
    y17,18    I17,18                          1
    y17,20    E17,20                         -1
    y17,20    I17,20                          1
    y17,22    E17,22                         -1
    y17,22    I17,22                          1
    y17,25    E17,25                         -1
    y17,25    I17,25                          1
    y17,26    E17,26                         -1
    y17,26    I17,26                          1
    y17,27    E17,27                         -1
    y17,27    I17,27                          1
    y17,28    E17,28                         -1
    y17,28    I17,28                          1
    y17,30    E17,30                         -1
    y17,30    I17,30                          1
    y17,32    E17,32                         -1
    y17,32    I17,32                          1
    y17,33    E17,33                         -1
    y17,33    I17,33                          1
    y17,34    E17,34                         -1
    y17,34    I17,34                          1
    y17,38    E17,38                         -1
    y17,38    I17,38                          1
    y17,39    E17,39                         -1
    y17,39    I17,39                          1
    y17,43    E17,43                         -1
    y17,43    I17,43                          1
    y17,46    E17,46                         -1
    y17,46    I17,46                          1
    y17,47    E17,47                         -1
    y17,47    I17,47                          1
    y17,49    E17,49                         -1
    y17,49    I17,49                          1
    y18,19    E18,19                         -1
    y18,19    I18,19                          1
    y18,20    E18,20                         -1
    y18,20    I18,20                          1
    y18,21    E18,21                         -1
    y18,21    I18,21                          1
    y18,22    E18,22                         -1
    y18,22    I18,22                          1
    y18,23    E18,23                         -1
    y18,23    I18,23                          1
    y18,24    E18,24                         -1
    y18,24    I18,24                          1
    y18,25    E18,25                         -1
    y18,25    I18,25                          1
    y18,27    E18,27                         -1
    y18,27    I18,27                          1
    y18,28    E18,28                         -1
    y18,28    I18,28                          1
    y18,30    E18,30                         -1
    y18,30    I18,30                          1
    y18,31    E18,31                         -1
    y18,31    I18,31                          1
    y18,34    E18,34                         -1
    y18,34    I18,34                          1
    y18,35    E18,35                         -1
    y18,35    I18,35                          1
    y18,36    E18,36                         -1
    y18,36    I18,36                          1
    y18,37    E18,37                         -1
    y18,37    I18,37                          1
    y18,38    E18,38                         -1
    y18,38    I18,38                          1
    y18,40    E18,40                         -1
    y18,40    I18,40                          1
    y18,41    E18,41                         -1
    y18,41    I18,41                          1
    y18,42    E18,42                         -1
    y18,42    I18,42                          1
    y18,43    E18,43                         -1
    y18,43    I18,43                          1
    y18,45    E18,45                         -1
    y18,45    I18,45                          1
    y18,46    E18,46                         -1
    y18,46    I18,46                          1
    y18,47    E18,47                         -1
    y18,47    I18,47                          1
    y18,48    E18,48                         -1
    y18,48    I18,48                          1
    y19,20    E19,20                         -1
    y19,20    I19,20                          1
    y19,22    E19,22                         -1
    y19,22    I19,22                          1
    y19,23    E19,23                         -1
    y19,23    I19,23                          1
    y19,24    E19,24                         -1
    y19,24    I19,24                          1
    y19,25    E19,25                         -1
    y19,25    I19,25                          1
    y19,26    E19,26                         -1
    y19,26    I19,26                          1
    y19,28    E19,28                         -1
    y19,28    I19,28                          1
    y19,29    E19,29                         -1
    y19,29    I19,29                          1
    y19,31    E19,31                         -1
    y19,31    I19,31                          1
    y19,34    E19,34                         -1
    y19,34    I19,34                          1
    y19,37    E19,37                         -1
    y19,37    I19,37                          1
    y19,39    E19,39                         -1
    y19,39    I19,39                          1
    y19,40    E19,40                         -1
    y19,40    I19,40                          1
    y19,41    E19,41                         -1
    y19,41    I19,41                          1
    y19,45    E19,45                         -1
    y19,45    I19,45                          1
    y19,46    E19,46                         -1
    y19,46    I19,46                          1
    y19,47    E19,47                         -1
    y19,47    I19,47                          1
    y19,48    E19,48                         -1
    y19,48    I19,48                          1
    y19,49    E19,49                         -1
    y19,49    I19,49                          1
    y20,22    E20,22                         -1
    y20,22    I20,22                          1
    y20,23    E20,23                         -1
    y20,23    I20,23                          1
    y20,25    E20,25                         -1
    y20,25    I20,25                          1
    y20,28    E20,28                         -1
    y20,28    I20,28                          1
    y20,29    E20,29                         -1
    y20,29    I20,29                          1
    y20,30    E20,30                         -1
    y20,30    I20,30                          1
    y20,31    E20,31                         -1
    y20,31    I20,31                          1
    y20,32    E20,32                         -1
    y20,32    I20,32                          1
    y20,34    E20,34                         -1
    y20,34    I20,34                          1
    y20,35    E20,35                         -1
    y20,35    I20,35                          1
    y20,36    E20,36                         -1
    y20,36    I20,36                          1
    y20,37    E20,37                         -1
    y20,37    I20,37                          1
    y20,38    E20,38                         -1
    y20,38    I20,38                          1
    y20,40    E20,40                         -1
    y20,40    I20,40                          1
    y20,41    E20,41                         -1
    y20,41    I20,41                          1
    y20,42    E20,42                         -1
    y20,42    I20,42                          1
    y20,45    E20,45                         -1
    y20,45    I20,45                          1
    y20,46    E20,46                         -1
    y20,46    I20,46                          1
    y20,48    E20,48                         -1
    y20,48    I20,48                          1
    y20,49    E20,49                         -1
    y20,49    I20,49                          1
    y21,22    E21,22                         -1
    y21,22    I21,22                          1
    y21,24    E21,24                         -1
    y21,24    I21,24                          1
    y21,25    E21,25                         -1
    y21,25    I21,25                          1
    y21,26    E21,26                         -1
    y21,26    I21,26                          1
    y21,27    E21,27                         -1
    y21,27    I21,27                          1
    y21,28    E21,28                         -1
    y21,28    I21,28                          1
    y21,29    E21,29                         -1
    y21,29    I21,29                          1
    y21,30    E21,30                         -1
    y21,30    I21,30                          1
    y21,31    E21,31                         -1
    y21,31    I21,31                          1
    y21,32    E21,32                         -1
    y21,32    I21,32                          1
    y21,33    E21,33                         -1
    y21,33    I21,33                          1
    y21,37    E21,37                         -1
    y21,37    I21,37                          1
    y21,39    E21,39                         -1
    y21,39    I21,39                          1
    y21,41    E21,41                         -1
    y21,41    I21,41                          1
    y21,43    E21,43                         -1
    y21,43    I21,43                          1
    y21,45    E21,45                         -1
    y21,45    I21,45                          1
    y21,47    E21,47                         -1
    y21,47    I21,47                          1
    y21,48    E21,48                         -1
    y21,48    I21,48                          1
    y21,49    E21,49                         -1
    y21,49    I21,49                          1
    y22,23    E22,23                         -1
    y22,23    I22,23                          1
    y22,25    E22,25                         -1
    y22,25    I22,25                          1
    y22,27    E22,27                         -1
    y22,27    I22,27                          1
    y22,30    E22,30                         -1
    y22,30    I22,30                          1
    y22,33    E22,33                         -1
    y22,33    I22,33                          1
    y22,36    E22,36                         -1
    y22,36    I22,36                          1
    y22,38    E22,38                         -1
    y22,38    I22,38                          1
    y22,39    E22,39                         -1
    y22,39    I22,39                          1
    y22,40    E22,40                         -1
    y22,40    I22,40                          1
    y22,41    E22,41                         -1
    y22,41    I22,41                          1
    y22,42    E22,42                         -1
    y22,42    I22,42                          1
    y22,43    E22,43                         -1
    y22,43    I22,43                          1
    y22,44    E22,44                         -1
    y22,44    I22,44                          1
    y22,45    E22,45                         -1
    y22,45    I22,45                          1
    y22,46    E22,46                         -1
    y22,46    I22,46                          1
    y22,49    E22,49                         -1
    y22,49    I22,49                          1
    y23,24    E23,24                         -1
    y23,24    I23,24                          1
    y23,25    E23,25                         -1
    y23,25    I23,25                          1
    y23,26    E23,26                         -1
    y23,26    I23,26                          1
    y23,27    E23,27                         -1
    y23,27    I23,27                          1
    y23,28    E23,28                         -1
    y23,28    I23,28                          1
    y23,29    E23,29                         -1
    y23,29    I23,29                          1
    y23,32    E23,32                         -1
    y23,32    I23,32                          1
    y23,34    E23,34                         -1
    y23,34    I23,34                          1
    y23,35    E23,35                         -1
    y23,35    I23,35                          1
    y23,36    E23,36                         -1
    y23,36    I23,36                          1
    y23,37    E23,37                         -1
    y23,37    I23,37                          1
    y23,38    E23,38                         -1
    y23,38    I23,38                          1
    y23,39    E23,39                         -1
    y23,39    I23,39                          1
    y23,42    E23,42                         -1
    y23,42    I23,42                          1
    y23,44    E23,44                         -1
    y23,44    I23,44                          1
    y23,45    E23,45                         -1
    y23,45    I23,45                          1
    y23,46    E23,46                         -1
    y23,46    I23,46                          1
    y23,48    E23,48                         -1
    y23,48    I23,48                          1
    y23,49    E23,49                         -1
    y23,49    I23,49                          1
    y24,26    E24,26                         -1
    y24,26    I24,26                          1
    y24,28    E24,28                         -1
    y24,28    I24,28                          1
    y24,29    E24,29                         -1
    y24,29    I24,29                          1
    y24,30    E24,30                         -1
    y24,30    I24,30                          1
    y24,31    E24,31                         -1
    y24,31    I24,31                          1
    y24,32    E24,32                         -1
    y24,32    I24,32                          1
    y24,33    E24,33                         -1
    y24,33    I24,33                          1
    y24,36    E24,36                         -1
    y24,36    I24,36                          1
    y24,38    E24,38                         -1
    y24,38    I24,38                          1
    y24,39    E24,39                         -1
    y24,39    I24,39                          1
    y24,40    E24,40                         -1
    y24,40    I24,40                          1
    y24,42    E24,42                         -1
    y24,42    I24,42                          1
    y24,43    E24,43                         -1
    y24,43    I24,43                          1
    y24,44    E24,44                         -1
    y24,44    I24,44                          1
    y24,46    E24,46                         -1
    y24,46    I24,46                          1
    y24,47    E24,47                         -1
    y24,47    I24,47                          1
    y24,48    E24,48                         -1
    y24,48    I24,48                          1
    y25,26    E25,26                         -1
    y25,26    I25,26                          1
    y25,28    E25,28                         -1
    y25,28    I25,28                          1
    y25,29    E25,29                         -1
    y25,29    I25,29                          1
    y25,30    E25,30                         -1
    y25,30    I25,30                          1
    y25,31    E25,31                         -1
    y25,31    I25,31                          1
    y25,37    E25,37                         -1
    y25,37    I25,37                          1
    y25,38    E25,38                         -1
    y25,38    I25,38                          1
    y25,39    E25,39                         -1
    y25,39    I25,39                          1
    y25,43    E25,43                         -1
    y25,43    I25,43                          1
    y25,44    E25,44                         -1
    y25,44    I25,44                          1
    y25,45    E25,45                         -1
    y25,45    I25,45                          1
    y25,46    E25,46                         -1
    y25,46    I25,46                          1
    y25,47    E25,47                         -1
    y25,47    I25,47                          1
    y26,28    E26,28                         -1
    y26,28    I26,28                          1
    y26,29    E26,29                         -1
    y26,29    I26,29                          1
    y26,30    E26,30                         -1
    y26,30    I26,30                          1
    y26,31    E26,31                         -1
    y26,31    I26,31                          1
    y26,34    E26,34                         -1
    y26,34    I26,34                          1
    y26,37    E26,37                         -1
    y26,37    I26,37                          1
    y26,38    E26,38                         -1
    y26,38    I26,38                          1
    y26,42    E26,42                         -1
    y26,42    I26,42                          1
    y26,43    E26,43                         -1
    y26,43    I26,43                          1
    y26,44    E26,44                         -1
    y26,44    I26,44                          1
    y26,45    E26,45                         -1
    y26,45    I26,45                          1
    y26,47    E26,47                         -1
    y26,47    I26,47                          1
    y26,48    E26,48                         -1
    y26,48    I26,48                          1
    y26,49    E26,49                         -1
    y26,49    I26,49                          1
    y27,28    E27,28                         -1
    y27,28    I27,28                          1
    y27,29    E27,29                         -1
    y27,29    I27,29                          1
    y27,30    E27,30                         -1
    y27,30    I27,30                          1
    y27,32    E27,32                         -1
    y27,32    I27,32                          1
    y27,33    E27,33                         -1
    y27,33    I27,33                          1
    y27,34    E27,34                         -1
    y27,34    I27,34                          1
    y27,35    E27,35                         -1
    y27,35    I27,35                          1
    y27,40    E27,40                         -1
    y27,40    I27,40                          1
    y27,41    E27,41                         -1
    y27,41    I27,41                          1
    y27,42    E27,42                         -1
    y27,42    I27,42                          1
    y27,43    E27,43                         -1
    y27,43    I27,43                          1
    y27,44    E27,44                         -1
    y27,44    I27,44                          1
    y27,45    E27,45                         -1
    y27,45    I27,45                          1
    y27,47    E27,47                         -1
    y27,47    I27,47                          1
    y27,49    E27,49                         -1
    y27,49    I27,49                          1
    y28,29    E28,29                         -1
    y28,29    I28,29                          1
    y28,31    E28,31                         -1
    y28,31    I28,31                          1
    y28,32    E28,32                         -1
    y28,32    I28,32                          1
    y28,33    E28,33                         -1
    y28,33    I28,33                          1
    y28,34    E28,34                         -1
    y28,34    I28,34                          1
    y28,36    E28,36                         -1
    y28,36    I28,36                          1
    y28,39    E28,39                         -1
    y28,39    I28,39                          1
    y28,40    E28,40                         -1
    y28,40    I28,40                          1
    y28,41    E28,41                         -1
    y28,41    I28,41                          1
    y28,43    E28,43                         -1
    y28,43    I28,43                          1
    y28,44    E28,44                         -1
    y28,44    I28,44                          1
    y28,45    E28,45                         -1
    y28,45    I28,45                          1
    y28,46    E28,46                         -1
    y28,46    I28,46                          1
    y28,47    E28,47                         -1
    y28,47    I28,47                          1
    y28,49    E28,49                         -1
    y28,49    I28,49                          1
    y29,30    E29,30                         -1
    y29,30    I29,30                          1
    y29,31    E29,31                         -1
    y29,31    I29,31                          1
    y29,32    E29,32                         -1
    y29,32    I29,32                          1
    y29,34    E29,34                         -1
    y29,34    I29,34                          1
    y29,36    E29,36                         -1
    y29,36    I29,36                          1
    y29,37    E29,37                         -1
    y29,37    I29,37                          1
    y29,38    E29,38                         -1
    y29,38    I29,38                          1
    y29,39    E29,39                         -1
    y29,39    I29,39                          1
    y29,41    E29,41                         -1
    y29,41    I29,41                          1
    y29,42    E29,42                         -1
    y29,42    I29,42                          1
    y29,43    E29,43                         -1
    y29,43    I29,43                          1
    y29,46    E29,46                         -1
    y29,46    I29,46                          1
    y29,47    E29,47                         -1
    y29,47    I29,47                          1
    y29,48    E29,48                         -1
    y29,48    I29,48                          1
    y29,49    E29,49                         -1
    y29,49    I29,49                          1
    y30,31    E30,31                         -1
    y30,31    I30,31                          1
    y30,33    E30,33                         -1
    y30,33    I30,33                          1
    y30,34    E30,34                         -1
    y30,34    I30,34                          1
    y30,36    E30,36                         -1
    y30,36    I30,36                          1
    y30,37    E30,37                         -1
    y30,37    I30,37                          1
    y30,38    E30,38                         -1
    y30,38    I30,38                          1
    y30,40    E30,40                         -1
    y30,40    I30,40                          1
    y30,41    E30,41                         -1
    y30,41    I30,41                          1
    y30,42    E30,42                         -1
    y30,42    I30,42                          1
    y30,43    E30,43                         -1
    y30,43    I30,43                          1
    y30,46    E30,46                         -1
    y30,46    I30,46                          1
    y30,47    E30,47                         -1
    y30,47    I30,47                          1
    y30,48    E30,48                         -1
    y30,48    I30,48                          1
    y31,32    E31,32                         -1
    y31,32    I31,32                          1
    y31,33    E31,33                         -1
    y31,33    I31,33                          1
    y31,35    E31,35                         -1
    y31,35    I31,35                          1
    y31,38    E31,38                         -1
    y31,38    I31,38                          1
    y31,39    E31,39                         -1
    y31,39    I31,39                          1
    y31,41    E31,41                         -1
    y31,41    I31,41                          1
    y31,42    E31,42                         -1
    y31,42    I31,42                          1
    y31,43    E31,43                         -1
    y31,43    I31,43                          1
    y31,45    E31,45                         -1
    y31,45    I31,45                          1
    y31,48    E31,48                         -1
    y31,48    I31,48                          1
    y31,49    E31,49                         -1
    y31,49    I31,49                          1
    y32,33    E32,33                         -1
    y32,33    I32,33                          1
    y32,34    E32,34                         -1
    y32,34    I32,34                          1
    y32,35    E32,35                         -1
    y32,35    I32,35                          1
    y32,37    E32,37                         -1
    y32,37    I32,37                          1
    y32,38    E32,38                         -1
    y32,38    I32,38                          1
    y32,39    E32,39                         -1
    y32,39    I32,39                          1
    y32,40    E32,40                         -1
    y32,40    I32,40                          1
    y32,41    E32,41                         -1
    y32,41    I32,41                          1
    y32,42    E32,42                         -1
    y32,42    I32,42                          1
    y32,43    E32,43                         -1
    y32,43    I32,43                          1
    y32,44    E32,44                         -1
    y32,44    I32,44                          1
    y32,45    E32,45                         -1
    y32,45    I32,45                          1
    y32,46    E32,46                         -1
    y32,46    I32,46                          1
    y32,47    E32,47                         -1
    y32,47    I32,47                          1
    y32,48    E32,48                         -1
    y32,48    I32,48                          1
    y33,34    E33,34                         -1
    y33,34    I33,34                          1
    y33,35    E33,35                         -1
    y33,35    I33,35                          1
    y33,36    E33,36                         -1
    y33,36    I33,36                          1
    y33,37    E33,37                         -1
    y33,37    I33,37                          1
    y33,38    E33,38                         -1
    y33,38    I33,38                          1
    y33,40    E33,40                         -1
    y33,40    I33,40                          1
    y33,41    E33,41                         -1
    y33,41    I33,41                          1
    y33,43    E33,43                         -1
    y33,43    I33,43                          1
    y33,44    E33,44                         -1
    y33,44    I33,44                          1
    y33,45    E33,45                         -1
    y33,45    I33,45                          1
    y33,46    E33,46                         -1
    y33,46    I33,46                          1
    y33,47    E33,47                         -1
    y33,47    I33,47                          1
    y33,48    E33,48                         -1
    y33,48    I33,48                          1
    y33,49    E33,49                         -1
    y33,49    I33,49                          1
    y34,35    E34,35                         -1
    y34,35    I34,35                          1
    y34,37    E34,37                         -1
    y34,37    I34,37                          1
    y34,38    E34,38                         -1
    y34,38    I34,38                          1
    y34,39    E34,39                         -1
    y34,39    I34,39                          1
    y34,40    E34,40                         -1
    y34,40    I34,40                          1
    y34,41    E34,41                         -1
    y34,41    I34,41                          1
    y34,42    E34,42                         -1
    y34,42    I34,42                          1
    y34,43    E34,43                         -1
    y34,43    I34,43                          1
    y34,45    E34,45                         -1
    y34,45    I34,45                          1
    y34,47    E34,47                         -1
    y34,47    I34,47                          1
    y35,36    E35,36                         -1
    y35,36    I35,36                          1
    y35,38    E35,38                         -1
    y35,38    I35,38                          1
    y35,39    E35,39                         -1
    y35,39    I35,39                          1
    y35,41    E35,41                         -1
    y35,41    I35,41                          1
    y35,42    E35,42                         -1
    y35,42    I35,42                          1
    y35,44    E35,44                         -1
    y35,44    I35,44                          1
    y35,45    E35,45                         -1
    y35,45    I35,45                          1
    y35,46    E35,46                         -1
    y35,46    I35,46                          1
    y35,47    E35,47                         -1
    y35,47    I35,47                          1
    y35,48    E35,48                         -1
    y35,48    I35,48                          1
    y35,49    E35,49                         -1
    y35,49    I35,49                          1
    y36,38    E36,38                         -1
    y36,38    I36,38                          1
    y36,39    E36,39                         -1
    y36,39    I36,39                          1
    y36,41    E36,41                         -1
    y36,41    I36,41                          1
    y36,43    E36,43                         -1
    y36,43    I36,43                          1
    y36,44    E36,44                         -1
    y36,44    I36,44                          1
    y36,45    E36,45                         -1
    y36,45    I36,45                          1
    y36,47    E36,47                         -1
    y36,47    I36,47                          1
    y36,48    E36,48                         -1
    y36,48    I36,48                          1
    y37,38    E37,38                         -1
    y37,38    I37,38                          1
    y37,39    E37,39                         -1
    y37,39    I37,39                          1
    y37,41    E37,41                         -1
    y37,41    I37,41                          1
    y37,42    E37,42                         -1
    y37,42    I37,42                          1
    y37,43    E37,43                         -1
    y37,43    I37,43                          1
    y37,44    E37,44                         -1
    y37,44    I37,44                          1
    y37,45    E37,45                         -1
    y37,45    I37,45                          1
    y37,46    E37,46                         -1
    y37,46    I37,46                          1
    y37,47    E37,47                         -1
    y37,47    I37,47                          1
    y37,49    E37,49                         -1
    y37,49    I37,49                          1
    y38,41    E38,41                         -1
    y38,41    I38,41                          1
    y38,42    E38,42                         -1
    y38,42    I38,42                          1
    y38,43    E38,43                         -1
    y38,43    I38,43                          1
    y38,45    E38,45                         -1
    y38,45    I38,45                          1
    y38,46    E38,46                         -1
    y38,46    I38,46                          1
    y38,47    E38,47                         -1
    y38,47    I38,47                          1
    y38,48    E38,48                         -1
    y38,48    I38,48                          1
    y38,49    E38,49                         -1
    y38,49    I38,49                          1
    y39,40    E39,40                         -1
    y39,40    I39,40                          1
    y39,41    E39,41                         -1
    y39,41    I39,41                          1
    y39,42    E39,42                         -1
    y39,42    I39,42                          1
    y39,43    E39,43                         -1
    y39,43    I39,43                          1
    y39,44    E39,44                         -1
    y39,44    I39,44                          1
    y39,45    E39,45                         -1
    y39,45    I39,45                          1
    y39,46    E39,46                         -1
    y39,46    I39,46                          1
    y39,47    E39,47                         -1
    y39,47    I39,47                          1
    y40,44    E40,44                         -1
    y40,44    I40,44                          1
    y40,45    E40,45                         -1
    y40,45    I40,45                          1
    y40,47    E40,47                         -1
    y40,47    I40,47                          1
    y40,48    E40,48                         -1
    y40,48    I40,48                          1
    y40,49    E40,49                         -1
    y40,49    I40,49                          1
    y41,43    E41,43                         -1
    y41,43    I41,43                          1
    y41,45    E41,45                         -1
    y41,45    I41,45                          1
    y41,46    E41,46                         -1
    y41,46    I41,46                          1
    y41,47    E41,47                         -1
    y41,47    I41,47                          1
    y41,48    E41,48                         -1
    y41,48    I41,48                          1
    y41,49    E41,49                         -1
    y41,49    I41,49                          1
    y42,44    E42,44                         -1
    y42,44    I42,44                          1
    y42,47    E42,47                         -1
    y42,47    I42,47                          1
    y42,48    E42,48                         -1
    y42,48    I42,48                          1
    y42,49    E42,49                         -1
    y42,49    I42,49                          1
    y43,44    E43,44                         -1
    y43,44    I43,44                          1
    y43,45    E43,45                         -1
    y43,45    I43,45                          1
    y43,49    E43,49                         -1
    y43,49    I43,49                          1
    y44,45    E44,45                         -1
    y44,45    I44,45                          1
    y44,47    E44,47                         -1
    y44,47    I44,47                          1
    y44,48    E44,48                         -1
    y44,48    I44,48                          1
    y45,47    E45,47                         -1
    y45,47    I45,47                          1
    y45,49    E45,49                         -1
    y45,49    I45,49                          1
    y46,48    E46,48                         -1
    y46,48    I46,48                          1
    y46,49    E46,49                         -1
    y46,49    I46,49                          1
    y47,48    E47,48                         -1
    y47,48    I47,48                          1
    y48,49    E48,49                         -1
    y48,49    I48,49                          1
    x0        cost                            1
    x0        C0,4                            1
    x0        C0,12                           1
    x0        C0,21                           1
    x0        C0,24                           1
    x0        C0,27                           1
    x0        C0,28                           1
    x0        C0,29                           1
    x0        C0,30                           1
    x0        C0,35                           1
    x0        C0,36                           1
    x0        C0,37                           1
    x0        C0,39                           1
    x0        C0,41                           1
    x0        C0,42                           1
    x0        C0,49                           1
    x0        E0,1                            1
    x0        E0,2                            1
    x0        E0,3                            1
    x0        E0,5                            1
    x0        E0,6                            1
    x0        E0,7                            1
    x0        E0,8                            1
    x0        E0,9                            1
    x0        E0,10                           1
    x0        E0,11                           1
    x0        E0,13                           1
    x0        E0,14                           1
    x0        E0,15                           1
    x0        E0,16                           1
    x0        E0,17                           1
    x0        E0,18                           1
    x0        E0,19                           1
    x0        E0,20                           1
    x0        E0,22                           1
    x0        E0,23                           1
    x0        E0,25                           1
    x0        E0,26                           1
    x0        E0,31                           1
    x0        E0,32                           1
    x0        E0,33                           1
    x0        E0,34                           1
    x0        E0,38                           1
    x0        E0,40                           1
    x0        E0,43                           1
    x0        E0,44                           1
    x0        E0,45                           1
    x0        E0,46                           1
    x0        E0,47                           1
    x0        E0,48                           1
    x1        cost                            1
    x1        C1,4                            1
    x1        C1,7                            1
    x1        C1,13                           1
    x1        C1,23                           1
    x1        C1,25                           1
    x1        C1,28                           1
    x1        C1,30                           1
    x1        C1,33                           1
    x1        C1,36                           1
    x1        C1,39                           1
    x1        C1,47                           1
    x1        E0,1                            1
    x1        E1,2                            1
    x1        E1,3                            1
    x1        E1,5                            1
    x1        E1,6                            1
    x1        E1,8                            1
    x1        E1,9                            1
    x1        E1,10                           1
    x1        E1,11                           1
    x1        E1,12                           1
    x1        E1,14                           1
    x1        E1,15                           1
    x1        E1,16                           1
    x1        E1,17                           1
    x1        E1,18                           1
    x1        E1,19                           1
    x1        E1,20                           1
    x1        E1,21                           1
    x1        E1,22                           1
    x1        E1,24                           1
    x1        E1,26                           1
    x1        E1,27                           1
    x1        E1,29                           1
    x1        E1,31                           1
    x1        E1,32                           1
    x1        E1,34                           1
    x1        E1,35                           1
    x1        E1,37                           1
    x1        E1,38                           1
    x1        E1,40                           1
    x1        E1,41                           1
    x1        E1,42                           1
    x1        E1,43                           1
    x1        E1,44                           1
    x1        E1,45                           1
    x1        E1,46                           1
    x1        E1,48                           1
    x1        E1,49                           1
    x2        cost                            1
    x2        C2,3                            1
    x2        C2,6                            1
    x2        C2,8                            1
    x2        C2,13                           1
    x2        C2,15                           1
    x2        C2,16                           1
    x2        C2,17                           1
    x2        C2,23                           1
    x2        C2,24                           1
    x2        C2,25                           1
    x2        C2,26                           1
    x2        C2,29                           1
    x2        C2,36                           1
    x2        C2,37                           1
    x2        C2,38                           1
    x2        C2,43                           1
    x2        C2,46                           1
    x2        C2,48                           1
    x2        E0,2                            1
    x2        E1,2                            1
    x2        E2,4                            1
    x2        E2,5                            1
    x2        E2,7                            1
    x2        E2,9                            1
    x2        E2,10                           1
    x2        E2,11                           1
    x2        E2,12                           1
    x2        E2,14                           1
    x2        E2,18                           1
    x2        E2,19                           1
    x2        E2,20                           1
    x2        E2,21                           1
    x2        E2,22                           1
    x2        E2,27                           1
    x2        E2,28                           1
    x2        E2,30                           1
    x2        E2,31                           1
    x2        E2,32                           1
    x2        E2,33                           1
    x2        E2,34                           1
    x2        E2,35                           1
    x2        E2,39                           1
    x2        E2,40                           1
    x2        E2,41                           1
    x2        E2,42                           1
    x2        E2,44                           1
    x2        E2,45                           1
    x2        E2,47                           1
    x2        E2,49                           1
    x3        cost                            1
    x3        C2,3                            1
    x3        C3,4                            1
    x3        C3,7                            1
    x3        C3,10                           1
    x3        C3,11                           1
    x3        C3,12                           1
    x3        C3,13                           1
    x3        C3,15                           1
    x3        C3,16                           1
    x3        C3,18                           1
    x3        C3,28                           1
    x3        C3,29                           1
    x3        C3,30                           1
    x3        C3,31                           1
    x3        C3,32                           1
    x3        C3,36                           1
    x3        C3,46                           1
    x3        C3,48                           1
    x3        E0,3                            1
    x3        E1,3                            1
    x3        E3,5                            1
    x3        E3,6                            1
    x3        E3,8                            1
    x3        E3,9                            1
    x3        E3,14                           1
    x3        E3,17                           1
    x3        E3,19                           1
    x3        E3,20                           1
    x3        E3,21                           1
    x3        E3,22                           1
    x3        E3,23                           1
    x3        E3,24                           1
    x3        E3,25                           1
    x3        E3,26                           1
    x3        E3,27                           1
    x3        E3,33                           1
    x3        E3,34                           1
    x3        E3,35                           1
    x3        E3,37                           1
    x3        E3,38                           1
    x3        E3,39                           1
    x3        E3,40                           1
    x3        E3,41                           1
    x3        E3,42                           1
    x3        E3,43                           1
    x3        E3,44                           1
    x3        E3,45                           1
    x3        E3,47                           1
    x3        E3,49                           1
    x4        cost                            1
    x4        C0,4                            1
    x4        C1,4                            1
    x4        C3,4                            1
    x4        C4,7                            1
    x4        C4,10                           1
    x4        C4,12                           1
    x4        C4,14                           1
    x4        C4,17                           1
    x4        C4,19                           1
    x4        C4,21                           1
    x4        C4,23                           1
    x4        C4,24                           1
    x4        C4,27                           1
    x4        C4,35                           1
    x4        C4,36                           1
    x4        C4,42                           1
    x4        C4,44                           1
    x4        C4,48                           1
    x4        E2,4                            1
    x4        E4,5                            1
    x4        E4,6                            1
    x4        E4,8                            1
    x4        E4,9                            1
    x4        E4,11                           1
    x4        E4,13                           1
    x4        E4,15                           1
    x4        E4,16                           1
    x4        E4,18                           1
    x4        E4,20                           1
    x4        E4,22                           1
    x4        E4,25                           1
    x4        E4,26                           1
    x4        E4,28                           1
    x4        E4,29                           1
    x4        E4,30                           1
    x4        E4,31                           1
    x4        E4,32                           1
    x4        E4,33                           1
    x4        E4,34                           1
    x4        E4,37                           1
    x4        E4,38                           1
    x4        E4,39                           1
    x4        E4,40                           1
    x4        E4,41                           1
    x4        E4,43                           1
    x4        E4,45                           1
    x4        E4,46                           1
    x4        E4,47                           1
    x4        E4,49                           1
    x5        cost                            1
    x5        C5,9                            1
    x5        C5,13                           1
    x5        C5,14                           1
    x5        C5,15                           1
    x5        C5,17                           1
    x5        C5,38                           1
    x5        C5,44                           1
    x5        C5,46                           1
    x5        C5,48                           1
    x5        E0,5                            1
    x5        E1,5                            1
    x5        E2,5                            1
    x5        E3,5                            1
    x5        E4,5                            1
    x5        E5,6                            1
    x5        E5,7                            1
    x5        E5,8                            1
    x5        E5,10                           1
    x5        E5,11                           1
    x5        E5,12                           1
    x5        E5,16                           1
    x5        E5,18                           1
    x5        E5,19                           1
    x5        E5,20                           1
    x5        E5,21                           1
    x5        E5,22                           1
    x5        E5,23                           1
    x5        E5,24                           1
    x5        E5,25                           1
    x5        E5,26                           1
    x5        E5,27                           1
    x5        E5,28                           1
    x5        E5,29                           1
    x5        E5,30                           1
    x5        E5,31                           1
    x5        E5,32                           1
    x5        E5,33                           1
    x5        E5,34                           1
    x5        E5,35                           1
    x5        E5,36                           1
    x5        E5,37                           1
    x5        E5,39                           1
    x5        E5,40                           1
    x5        E5,41                           1
    x5        E5,42                           1
    x5        E5,43                           1
    x5        E5,45                           1
    x5        E5,47                           1
    x5        E5,49                           1
    x6        cost                            1
    x6        C2,6                            1
    x6        C6,7                            1
    x6        C6,9                            1
    x6        C6,11                           1
    x6        C6,14                           1
    x6        C6,16                           1
    x6        C6,21                           1
    x6        C6,26                           1
    x6        C6,31                           1
    x6        C6,32                           1
    x6        C6,35                           1
    x6        C6,36                           1
    x6        C6,37                           1
    x6        E0,6                            1
    x6        E1,6                            1
    x6        E3,6                            1
    x6        E4,6                            1
    x6        E5,6                            1
    x6        E6,8                            1
    x6        E6,10                           1
    x6        E6,12                           1
    x6        E6,13                           1
    x6        E6,15                           1
    x6        E6,17                           1
    x6        E6,18                           1
    x6        E6,19                           1
    x6        E6,20                           1
    x6        E6,22                           1
    x6        E6,23                           1
    x6        E6,24                           1
    x6        E6,25                           1
    x6        E6,27                           1
    x6        E6,28                           1
    x6        E6,29                           1
    x6        E6,30                           1
    x6        E6,33                           1
    x6        E6,34                           1
    x6        E6,38                           1
    x6        E6,39                           1
    x6        E6,40                           1
    x6        E6,41                           1
    x6        E6,42                           1
    x6        E6,43                           1
    x6        E6,44                           1
    x6        E6,45                           1
    x6        E6,46                           1
    x6        E6,47                           1
    x6        E6,48                           1
    x6        E6,49                           1
    x7        cost                            1
    x7        C1,7                            1
    x7        C3,7                            1
    x7        C4,7                            1
    x7        C6,7                            1
    x7        C7,9                            1
    x7        C7,11                           1
    x7        C7,13                           1
    x7        C7,15                           1
    x7        C7,22                           1
    x7        C7,25                           1
    x7        C7,26                           1
    x7        C7,34                           1
    x7        C7,36                           1
    x7        C7,38                           1
    x7        C7,40                           1
    x7        C7,43                           1
    x7        C7,46                           1
    x7        E0,7                            1
    x7        E2,7                            1
    x7        E5,7                            1
    x7        E7,8                            1
    x7        E7,10                           1
    x7        E7,12                           1
    x7        E7,14                           1
    x7        E7,16                           1
    x7        E7,17                           1
    x7        E7,18                           1
    x7        E7,19                           1
    x7        E7,20                           1
    x7        E7,21                           1
    x7        E7,23                           1
    x7        E7,24                           1
    x7        E7,27                           1
    x7        E7,28                           1
    x7        E7,29                           1
    x7        E7,30                           1
    x7        E7,31                           1
    x7        E7,32                           1
    x7        E7,33                           1
    x7        E7,35                           1
    x7        E7,37                           1
    x7        E7,39                           1
    x7        E7,41                           1
    x7        E7,42                           1
    x7        E7,44                           1
    x7        E7,45                           1
    x7        E7,47                           1
    x7        E7,48                           1
    x7        E7,49                           1
    x8        cost                            1
    x8        C2,8                            1
    x8        C8,11                           1
    x8        C8,14                           1
    x8        C8,16                           1
    x8        C8,21                           1
    x8        C8,22                           1
    x8        C8,23                           1
    x8        C8,25                           1
    x8        C8,28                           1
    x8        C8,29                           1
    x8        C8,30                           1
    x8        C8,36                           1
    x8        C8,37                           1
    x8        C8,38                           1
    x8        C8,39                           1
    x8        C8,40                           1
    x8        C8,47                           1
    x8        C8,48                           1
    x8        C8,49                           1
    x8        E0,8                            1
    x8        E1,8                            1
    x8        E3,8                            1
    x8        E4,8                            1
    x8        E5,8                            1
    x8        E6,8                            1
    x8        E7,8                            1
    x8        E8,9                            1
    x8        E8,10                           1
    x8        E8,12                           1
    x8        E8,13                           1
    x8        E8,15                           1
    x8        E8,17                           1
    x8        E8,18                           1
    x8        E8,19                           1
    x8        E8,20                           1
    x8        E8,24                           1
    x8        E8,26                           1
    x8        E8,27                           1
    x8        E8,31                           1
    x8        E8,32                           1
    x8        E8,33                           1
    x8        E8,34                           1
    x8        E8,35                           1
    x8        E8,41                           1
    x8        E8,42                           1
    x8        E8,43                           1
    x8        E8,44                           1
    x8        E8,45                           1
    x8        E8,46                           1
    x9        cost                            1
    x9        C5,9                            1
    x9        C6,9                            1
    x9        C7,9                            1
    x9        C9,14                           1
    x9        C9,20                           1
    x9        C9,25                           1
    x9        C9,28                           1
    x9        C9,31                           1
    x9        C9,37                           1
    x9        C9,39                           1
    x9        E0,9                            1
    x9        E1,9                            1
    x9        E2,9                            1
    x9        E3,9                            1
    x9        E4,9                            1
    x9        E8,9                            1
    x9        E9,10                           1
    x9        E9,11                           1
    x9        E9,12                           1
    x9        E9,13                           1
    x9        E9,15                           1
    x9        E9,16                           1
    x9        E9,17                           1
    x9        E9,18                           1
    x9        E9,19                           1
    x9        E9,21                           1
    x9        E9,22                           1
    x9        E9,23                           1
    x9        E9,24                           1
    x9        E9,26                           1
    x9        E9,27                           1
    x9        E9,29                           1
    x9        E9,30                           1
    x9        E9,32                           1
    x9        E9,33                           1
    x9        E9,34                           1
    x9        E9,35                           1
    x9        E9,36                           1
    x9        E9,38                           1
    x9        E9,40                           1
    x9        E9,41                           1
    x9        E9,42                           1
    x9        E9,43                           1
    x9        E9,44                           1
    x9        E9,45                           1
    x9        E9,46                           1
    x9        E9,47                           1
    x9        E9,48                           1
    x9        E9,49                           1
    x10       cost                            1
    x10       C3,10                           1
    x10       C4,10                           1
    x10       C10,12                          1
    x10       C10,13                          1
    x10       C10,16                          1
    x10       C10,28                          1
    x10       C10,30                          1
    x10       C10,34                          1
    x10       C10,45                          1
    x10       C10,46                          1
    x10       C10,49                          1
    x10       E0,10                           1
    x10       E1,10                           1
    x10       E2,10                           1
    x10       E5,10                           1
    x10       E6,10                           1
    x10       E7,10                           1
    x10       E8,10                           1
    x10       E9,10                           1
    x10       E10,11                          1
    x10       E10,14                          1
    x10       E10,15                          1
    x10       E10,17                          1
    x10       E10,18                          1
    x10       E10,19                          1
    x10       E10,20                          1
    x10       E10,21                          1
    x10       E10,22                          1
    x10       E10,23                          1
    x10       E10,24                          1
    x10       E10,25                          1
    x10       E10,26                          1
    x10       E10,27                          1
    x10       E10,29                          1
    x10       E10,31                          1
    x10       E10,32                          1
    x10       E10,33                          1
    x10       E10,35                          1
    x10       E10,36                          1
    x10       E10,37                          1
    x10       E10,38                          1
    x10       E10,39                          1
    x10       E10,40                          1
    x10       E10,41                          1
    x10       E10,42                          1
    x10       E10,43                          1
    x10       E10,44                          1
    x10       E10,47                          1
    x10       E10,48                          1
    x11       cost                            1
    x11       C3,11                           1
    x11       C6,11                           1
    x11       C7,11                           1
    x11       C8,11                           1
    x11       C11,20                          1
    x11       C11,23                          1
    x11       C11,24                          1
    x11       C11,30                          1
    x11       C11,32                          1
    x11       C11,35                          1
    x11       C11,36                          1
    x11       C11,37                          1
    x11       C11,41                          1
    x11       C11,43                          1
    x11       C11,45                          1
    x11       E0,11                           1
    x11       E1,11                           1
    x11       E2,11                           1
    x11       E4,11                           1
    x11       E5,11                           1
    x11       E9,11                           1
    x11       E10,11                          1
    x11       E11,12                          1
    x11       E11,13                          1
    x11       E11,14                          1
    x11       E11,15                          1
    x11       E11,16                          1
    x11       E11,17                          1
    x11       E11,18                          1
    x11       E11,19                          1
    x11       E11,21                          1
    x11       E11,22                          1
    x11       E11,25                          1
    x11       E11,26                          1
    x11       E11,27                          1
    x11       E11,28                          1
    x11       E11,29                          1
    x11       E11,31                          1
    x11       E11,33                          1
    x11       E11,34                          1
    x11       E11,38                          1
    x11       E11,39                          1
    x11       E11,40                          1
    x11       E11,42                          1
    x11       E11,44                          1
    x11       E11,46                          1
    x11       E11,47                          1
    x11       E11,48                          1
    x11       E11,49                          1
    x12       cost                            1
    x12       C0,12                           1
    x12       C3,12                           1
    x12       C4,12                           1
    x12       C10,12                          1
    x12       C12,14                          1
    x12       C12,16                          1
    x12       C12,19                          1
    x12       C12,25                          1
    x12       C12,27                          1
    x12       C12,33                          1
    x12       C12,34                          1
    x12       C12,35                          1
    x12       C12,38                          1
    x12       C12,42                          1
    x12       C12,46                          1
    x12       C12,47                          1
    x12       E1,12                           1
    x12       E2,12                           1
    x12       E5,12                           1
    x12       E6,12                           1
    x12       E7,12                           1
    x12       E8,12                           1
    x12       E9,12                           1
    x12       E11,12                          1
    x12       E12,13                          1
    x12       E12,15                          1
    x12       E12,17                          1
    x12       E12,18                          1
    x12       E12,20                          1
    x12       E12,21                          1
    x12       E12,22                          1
    x12       E12,23                          1
    x12       E12,24                          1
    x12       E12,26                          1
    x12       E12,28                          1
    x12       E12,29                          1
    x12       E12,30                          1
    x12       E12,31                          1
    x12       E12,32                          1
    x12       E12,36                          1
    x12       E12,37                          1
    x12       E12,39                          1
    x12       E12,40                          1
    x12       E12,41                          1
    x12       E12,43                          1
    x12       E12,44                          1
    x12       E12,45                          1
    x12       E12,48                          1
    x12       E12,49                          1
    x13       cost                            1
    x13       C1,13                           1
    x13       C2,13                           1
    x13       C3,13                           1
    x13       C5,13                           1
    x13       C7,13                           1
    x13       C10,13                          1
    x13       C13,16                          1
    x13       C13,17                          1
    x13       C13,19                          1
    x13       C13,21                          1
    x13       C13,22                          1
    x13       C13,27                          1
    x13       C13,33                          1
    x13       C13,34                          1
    x13       C13,44                          1
    x13       E0,13                           1
    x13       E4,13                           1
    x13       E6,13                           1
    x13       E8,13                           1
    x13       E9,13                           1
    x13       E11,13                          1
    x13       E12,13                          1
    x13       E13,14                          1
    x13       E13,15                          1
    x13       E13,18                          1
    x13       E13,20                          1
    x13       E13,23                          1
    x13       E13,24                          1
    x13       E13,25                          1
    x13       E13,26                          1
    x13       E13,28                          1
    x13       E13,29                          1
    x13       E13,30                          1
    x13       E13,31                          1
    x13       E13,32                          1
    x13       E13,35                          1
    x13       E13,36                          1
    x13       E13,37                          1
    x13       E13,38                          1
    x13       E13,39                          1
    x13       E13,40                          1
    x13       E13,41                          1
    x13       E13,42                          1
    x13       E13,43                          1
    x13       E13,45                          1
    x13       E13,46                          1
    x13       E13,47                          1
    x13       E13,48                          1
    x13       E13,49                          1
    x14       cost                            1
    x14       C4,14                           1
    x14       C5,14                           1
    x14       C6,14                           1
    x14       C8,14                           1
    x14       C9,14                           1
    x14       C12,14                          1
    x14       C14,21                          1
    x14       C14,26                          1
    x14       C14,28                          1
    x14       C14,29                          1
    x14       C14,36                          1
    x14       C14,39                          1
    x14       C14,40                          1
    x14       C14,41                          1
    x14       E0,14                           1
    x14       E1,14                           1
    x14       E2,14                           1
    x14       E3,14                           1
    x14       E7,14                           1
    x14       E10,14                          1
    x14       E11,14                          1
    x14       E13,14                          1
    x14       E14,15                          1
    x14       E14,16                          1
    x14       E14,17                          1
    x14       E14,18                          1
    x14       E14,19                          1
    x14       E14,20                          1
    x14       E14,22                          1
    x14       E14,23                          1
    x14       E14,24                          1
    x14       E14,25                          1
    x14       E14,27                          1
    x14       E14,30                          1
    x14       E14,31                          1
    x14       E14,32                          1
    x14       E14,33                          1
    x14       E14,34                          1
    x14       E14,35                          1
    x14       E14,37                          1
    x14       E14,38                          1
    x14       E14,42                          1
    x14       E14,43                          1
    x14       E14,44                          1
    x14       E14,45                          1
    x14       E14,46                          1
    x14       E14,47                          1
    x14       E14,48                          1
    x14       E14,49                          1
    x15       cost                            1
    x15       C2,15                           1
    x15       C3,15                           1
    x15       C5,15                           1
    x15       C7,15                           1
    x15       C15,20                          1
    x15       C15,25                          1
    x15       C15,28                          1
    x15       C15,35                          1
    x15       C15,38                          1
    x15       C15,42                          1
    x15       C15,45                          1
    x15       E0,15                           1
    x15       E1,15                           1
    x15       E4,15                           1
    x15       E6,15                           1
    x15       E8,15                           1
    x15       E9,15                           1
    x15       E10,15                          1
    x15       E11,15                          1
    x15       E12,15                          1
    x15       E13,15                          1
    x15       E14,15                          1
    x15       E15,16                          1
    x15       E15,17                          1
    x15       E15,18                          1
    x15       E15,19                          1
    x15       E15,21                          1
    x15       E15,22                          1
    x15       E15,23                          1
    x15       E15,24                          1
    x15       E15,26                          1
    x15       E15,27                          1
    x15       E15,29                          1
    x15       E15,30                          1
    x15       E15,31                          1
    x15       E15,32                          1
    x15       E15,33                          1
    x15       E15,34                          1
    x15       E15,36                          1
    x15       E15,37                          1
    x15       E15,39                          1
    x15       E15,40                          1
    x15       E15,41                          1
    x15       E15,43                          1
    x15       E15,44                          1
    x15       E15,46                          1
    x15       E15,47                          1
    x15       E15,48                          1
    x15       E15,49                          1
    x16       cost                            1
    x16       C2,16                           1
    x16       C3,16                           1
    x16       C6,16                           1
    x16       C8,16                           1
    x16       C10,16                          1
    x16       C12,16                          1
    x16       C13,16                          1
    x16       C16,17                          1
    x16       C16,19                          1
    x16       C16,25                          1
    x16       C16,26                          1
    x16       C16,31                          1
    x16       C16,36                          1
    x16       C16,49                          1
    x16       E0,16                           1
    x16       E1,16                           1
    x16       E4,16                           1
    x16       E5,16                           1
    x16       E7,16                           1
    x16       E9,16                           1
    x16       E11,16                          1
    x16       E14,16                          1
    x16       E15,16                          1
    x16       E16,18                          1
    x16       E16,20                          1
    x16       E16,21                          1
    x16       E16,22                          1
    x16       E16,23                          1
    x16       E16,24                          1
    x16       E16,27                          1
    x16       E16,28                          1
    x16       E16,29                          1
    x16       E16,30                          1
    x16       E16,32                          1
    x16       E16,33                          1
    x16       E16,34                          1
    x16       E16,35                          1
    x16       E16,37                          1
    x16       E16,38                          1
    x16       E16,39                          1
    x16       E16,40                          1
    x16       E16,41                          1
    x16       E16,42                          1
    x16       E16,43                          1
    x16       E16,44                          1
    x16       E16,45                          1
    x16       E16,46                          1
    x16       E16,47                          1
    x16       E16,48                          1
    x17       cost                            1
    x17       C2,17                           1
    x17       C4,17                           1
    x17       C5,17                           1
    x17       C13,17                          1
    x17       C16,17                          1
    x17       C17,19                          1
    x17       C17,21                          1
    x17       C17,23                          1
    x17       C17,24                          1
    x17       C17,29                          1
    x17       C17,31                          1
    x17       C17,35                          1
    x17       C17,36                          1
    x17       C17,37                          1
    x17       C17,40                          1
    x17       C17,41                          1
    x17       C17,42                          1
    x17       C17,44                          1
    x17       C17,45                          1
    x17       C17,48                          1
    x17       E0,17                           1
    x17       E1,17                           1
    x17       E3,17                           1
    x17       E6,17                           1
    x17       E7,17                           1
    x17       E8,17                           1
    x17       E9,17                           1
    x17       E10,17                          1
    x17       E11,17                          1
    x17       E12,17                          1
    x17       E14,17                          1
    x17       E15,17                          1
    x17       E17,18                          1
    x17       E17,20                          1
    x17       E17,22                          1
    x17       E17,25                          1
    x17       E17,26                          1
    x17       E17,27                          1
    x17       E17,28                          1
    x17       E17,30                          1
    x17       E17,32                          1
    x17       E17,33                          1
    x17       E17,34                          1
    x17       E17,38                          1
    x17       E17,39                          1
    x17       E17,43                          1
    x17       E17,46                          1
    x17       E17,47                          1
    x17       E17,49                          1
    x18       cost                            1
    x18       C3,18                           1
    x18       C18,26                          1
    x18       C18,29                          1
    x18       C18,32                          1
    x18       C18,33                          1
    x18       C18,39                          1
    x18       C18,44                          1
    x18       C18,49                          1
    x18       E0,18                           1
    x18       E1,18                           1
    x18       E2,18                           1
    x18       E4,18                           1
    x18       E5,18                           1
    x18       E6,18                           1
    x18       E7,18                           1
    x18       E8,18                           1
    x18       E9,18                           1
    x18       E10,18                          1
    x18       E11,18                          1
    x18       E12,18                          1
    x18       E13,18                          1
    x18       E14,18                          1
    x18       E15,18                          1
    x18       E16,18                          1
    x18       E17,18                          1
    x18       E18,19                          1
    x18       E18,20                          1
    x18       E18,21                          1
    x18       E18,22                          1
    x18       E18,23                          1
    x18       E18,24                          1
    x18       E18,25                          1
    x18       E18,27                          1
    x18       E18,28                          1
    x18       E18,30                          1
    x18       E18,31                          1
    x18       E18,34                          1
    x18       E18,35                          1
    x18       E18,36                          1
    x18       E18,37                          1
    x18       E18,38                          1
    x18       E18,40                          1
    x18       E18,41                          1
    x18       E18,42                          1
    x18       E18,43                          1
    x18       E18,45                          1
    x18       E18,46                          1
    x18       E18,47                          1
    x18       E18,48                          1
    x19       cost                            1
    x19       C4,19                           1
    x19       C12,19                          1
    x19       C13,19                          1
    x19       C16,19                          1
    x19       C17,19                          1
    x19       C19,21                          1
    x19       C19,27                          1
    x19       C19,30                          1
    x19       C19,32                          1
    x19       C19,33                          1
    x19       C19,35                          1
    x19       C19,36                          1
    x19       C19,38                          1
    x19       C19,42                          1
    x19       C19,43                          1
    x19       C19,44                          1
    x19       E0,19                           1
    x19       E1,19                           1
    x19       E2,19                           1
    x19       E3,19                           1
    x19       E5,19                           1
    x19       E6,19                           1
    x19       E7,19                           1
    x19       E8,19                           1
    x19       E9,19                           1
    x19       E10,19                          1
    x19       E11,19                          1
    x19       E14,19                          1
    x19       E15,19                          1
    x19       E18,19                          1
    x19       E19,20                          1
    x19       E19,22                          1
    x19       E19,23                          1
    x19       E19,24                          1
    x19       E19,25                          1
    x19       E19,26                          1
    x19       E19,28                          1
    x19       E19,29                          1
    x19       E19,31                          1
    x19       E19,34                          1
    x19       E19,37                          1
    x19       E19,39                          1
    x19       E19,40                          1
    x19       E19,41                          1
    x19       E19,45                          1
    x19       E19,46                          1
    x19       E19,47                          1
    x19       E19,48                          1
    x19       E19,49                          1
    x20       cost                            1
    x20       C9,20                           1
    x20       C11,20                          1
    x20       C15,20                          1
    x20       C20,21                          1
    x20       C20,24                          1
    x20       C20,26                          1
    x20       C20,27                          1
    x20       C20,33                          1
    x20       C20,39                          1
    x20       C20,43                          1
    x20       C20,44                          1
    x20       C20,47                          1
    x20       E0,20                           1
    x20       E1,20                           1
    x20       E2,20                           1
    x20       E3,20                           1
    x20       E4,20                           1
    x20       E5,20                           1
    x20       E6,20                           1
    x20       E7,20                           1
    x20       E8,20                           1
    x20       E10,20                          1
    x20       E12,20                          1
    x20       E13,20                          1
    x20       E14,20                          1
    x20       E16,20                          1
    x20       E17,20                          1
    x20       E18,20                          1
    x20       E19,20                          1
    x20       E20,22                          1
    x20       E20,23                          1
    x20       E20,25                          1
    x20       E20,28                          1
    x20       E20,29                          1
    x20       E20,30                          1
    x20       E20,31                          1
    x20       E20,32                          1
    x20       E20,34                          1
    x20       E20,35                          1
    x20       E20,36                          1
    x20       E20,37                          1
    x20       E20,38                          1
    x20       E20,40                          1
    x20       E20,41                          1
    x20       E20,42                          1
    x20       E20,45                          1
    x20       E20,46                          1
    x20       E20,48                          1
    x20       E20,49                          1
    x21       cost                            1
    x21       C0,21                           1
    x21       C4,21                           1
    x21       C6,21                           1
    x21       C8,21                           1
    x21       C13,21                          1
    x21       C14,21                          1
    x21       C17,21                          1
    x21       C19,21                          1
    x21       C20,21                          1
    x21       C21,23                          1
    x21       C21,34                          1
    x21       C21,35                          1
    x21       C21,36                          1
    x21       C21,38                          1
    x21       C21,40                          1
    x21       C21,42                          1
    x21       C21,44                          1
    x21       C21,46                          1
    x21       E1,21                           1
    x21       E2,21                           1
    x21       E3,21                           1
    x21       E5,21                           1
    x21       E7,21                           1
    x21       E9,21                           1
    x21       E10,21                          1
    x21       E11,21                          1
    x21       E12,21                          1
    x21       E15,21                          1
    x21       E16,21                          1
    x21       E18,21                          1
    x21       E21,22                          1
    x21       E21,24                          1
    x21       E21,25                          1
    x21       E21,26                          1
    x21       E21,27                          1
    x21       E21,28                          1
    x21       E21,29                          1
    x21       E21,30                          1
    x21       E21,31                          1
    x21       E21,32                          1
    x21       E21,33                          1
    x21       E21,37                          1
    x21       E21,39                          1
    x21       E21,41                          1
    x21       E21,43                          1
    x21       E21,45                          1
    x21       E21,47                          1
    x21       E21,48                          1
    x21       E21,49                          1
    x22       cost                            1
    x22       C7,22                           1
    x22       C8,22                           1
    x22       C13,22                          1
    x22       C22,24                          1
    x22       C22,26                          1
    x22       C22,28                          1
    x22       C22,29                          1
    x22       C22,31                          1
    x22       C22,32                          1
    x22       C22,34                          1
    x22       C22,35                          1
    x22       C22,37                          1
    x22       C22,47                          1
    x22       C22,48                          1
    x22       E0,22                           1
    x22       E1,22                           1
    x22       E2,22                           1
    x22       E3,22                           1
    x22       E4,22                           1
    x22       E5,22                           1
    x22       E6,22                           1
    x22       E9,22                           1
    x22       E10,22                          1
    x22       E11,22                          1
    x22       E12,22                          1
    x22       E14,22                          1
    x22       E15,22                          1
    x22       E16,22                          1
    x22       E17,22                          1
    x22       E18,22                          1
    x22       E19,22                          1
    x22       E20,22                          1
    x22       E21,22                          1
    x22       E22,23                          1
    x22       E22,25                          1
    x22       E22,27                          1
    x22       E22,30                          1
    x22       E22,33                          1
    x22       E22,36                          1
    x22       E22,38                          1
    x22       E22,39                          1
    x22       E22,40                          1
    x22       E22,41                          1
    x22       E22,42                          1
    x22       E22,43                          1
    x22       E22,44                          1
    x22       E22,45                          1
    x22       E22,46                          1
    x22       E22,49                          1
    x23       cost                            1
    x23       C1,23                           1
    x23       C2,23                           1
    x23       C4,23                           1
    x23       C8,23                           1
    x23       C11,23                          1
    x23       C17,23                          1
    x23       C21,23                          1
    x23       C23,30                          1
    x23       C23,31                          1
    x23       C23,33                          1
    x23       C23,40                          1
    x23       C23,41                          1
    x23       C23,43                          1
    x23       C23,47                          1
    x23       E0,23                           1
    x23       E3,23                           1
    x23       E5,23                           1
    x23       E6,23                           1
    x23       E7,23                           1
    x23       E9,23                           1
    x23       E10,23                          1
    x23       E12,23                          1
    x23       E13,23                          1
    x23       E14,23                          1
    x23       E15,23                          1
    x23       E16,23                          1
    x23       E18,23                          1
    x23       E19,23                          1
    x23       E20,23                          1
    x23       E22,23                          1
    x23       E23,24                          1
    x23       E23,25                          1
    x23       E23,26                          1
    x23       E23,27                          1
    x23       E23,28                          1
    x23       E23,29                          1
    x23       E23,32                          1
    x23       E23,34                          1
    x23       E23,35                          1
    x23       E23,36                          1
    x23       E23,37                          1
    x23       E23,38                          1
    x23       E23,39                          1
    x23       E23,42                          1
    x23       E23,44                          1
    x23       E23,45                          1
    x23       E23,46                          1
    x23       E23,48                          1
    x23       E23,49                          1
    x24       cost                            1
    x24       C0,24                           1
    x24       C2,24                           1
    x24       C4,24                           1
    x24       C11,24                          1
    x24       C17,24                          1
    x24       C20,24                          1
    x24       C22,24                          1
    x24       C24,25                          1
    x24       C24,27                          1
    x24       C24,34                          1
    x24       C24,35                          1
    x24       C24,37                          1
    x24       C24,41                          1
    x24       C24,45                          1
    x24       C24,49                          1
    x24       E1,24                           1
    x24       E3,24                           1
    x24       E5,24                           1
    x24       E6,24                           1
    x24       E7,24                           1
    x24       E8,24                           1
    x24       E9,24                           1
    x24       E10,24                          1
    x24       E12,24                          1
    x24       E13,24                          1
    x24       E14,24                          1
    x24       E15,24                          1
    x24       E16,24                          1
    x24       E18,24                          1
    x24       E19,24                          1
    x24       E21,24                          1
    x24       E23,24                          1
    x24       E24,26                          1
    x24       E24,28                          1
    x24       E24,29                          1
    x24       E24,30                          1
    x24       E24,31                          1
    x24       E24,32                          1
    x24       E24,33                          1
    x24       E24,36                          1
    x24       E24,38                          1
    x24       E24,39                          1
    x24       E24,40                          1
    x24       E24,42                          1
    x24       E24,43                          1
    x24       E24,44                          1
    x24       E24,46                          1
    x24       E24,47                          1
    x24       E24,48                          1
    x25       cost                            1
    x25       C1,25                           1
    x25       C2,25                           1
    x25       C7,25                           1
    x25       C8,25                           1
    x25       C9,25                           1
    x25       C12,25                          1
    x25       C15,25                          1
    x25       C16,25                          1
    x25       C24,25                          1
    x25       C25,27                          1
    x25       C25,32                          1
    x25       C25,33                          1
    x25       C25,34                          1
    x25       C25,35                          1
    x25       C25,36                          1
    x25       C25,40                          1
    x25       C25,41                          1
    x25       C25,42                          1
    x25       C25,48                          1
    x25       C25,49                          1
    x25       E0,25                           1
    x25       E3,25                           1
    x25       E4,25                           1
    x25       E5,25                           1
    x25       E6,25                           1
    x25       E10,25                          1
    x25       E11,25                          1
    x25       E13,25                          1
    x25       E14,25                          1
    x25       E17,25                          1
    x25       E18,25                          1
    x25       E19,25                          1
    x25       E20,25                          1
    x25       E21,25                          1
    x25       E22,25                          1
    x25       E23,25                          1
    x25       E25,26                          1
    x25       E25,28                          1
    x25       E25,29                          1
    x25       E25,30                          1
    x25       E25,31                          1
    x25       E25,37                          1
    x25       E25,38                          1
    x25       E25,39                          1
    x25       E25,43                          1
    x25       E25,44                          1
    x25       E25,45                          1
    x25       E25,46                          1
    x25       E25,47                          1
    x26       cost                            1
    x26       C2,26                           1
    x26       C6,26                           1
    x26       C7,26                           1
    x26       C14,26                          1
    x26       C16,26                          1
    x26       C18,26                          1
    x26       C20,26                          1
    x26       C22,26                          1
    x26       C26,27                          1
    x26       C26,32                          1
    x26       C26,33                          1
    x26       C26,35                          1
    x26       C26,36                          1
    x26       C26,39                          1
    x26       C26,40                          1
    x26       C26,41                          1
    x26       C26,46                          1
    x26       E0,26                           1
    x26       E1,26                           1
    x26       E3,26                           1
    x26       E4,26                           1
    x26       E5,26                           1
    x26       E8,26                           1
    x26       E9,26                           1
    x26       E10,26                          1
    x26       E11,26                          1
    x26       E12,26                          1
    x26       E13,26                          1
    x26       E15,26                          1
    x26       E17,26                          1
    x26       E19,26                          1
    x26       E21,26                          1
    x26       E23,26                          1
    x26       E24,26                          1
    x26       E25,26                          1
    x26       E26,28                          1
    x26       E26,29                          1
    x26       E26,30                          1
    x26       E26,31                          1
    x26       E26,34                          1
    x26       E26,37                          1
    x26       E26,38                          1
    x26       E26,42                          1
    x26       E26,43                          1
    x26       E26,44                          1
    x26       E26,45                          1
    x26       E26,47                          1
    x26       E26,48                          1
    x26       E26,49                          1
    x27       cost                            1
    x27       C0,27                           1
    x27       C4,27                           1
    x27       C12,27                          1
    x27       C13,27                          1
    x27       C19,27                          1
    x27       C20,27                          1
    x27       C24,27                          1
    x27       C25,27                          1
    x27       C26,27                          1
    x27       C27,31                          1
    x27       C27,36                          1
    x27       C27,37                          1
    x27       C27,38                          1
    x27       C27,39                          1
    x27       C27,46                          1
    x27       C27,48                          1
    x27       E1,27                           1
    x27       E2,27                           1
    x27       E3,27                           1
    x27       E5,27                           1
    x27       E6,27                           1
    x27       E7,27                           1
    x27       E8,27                           1
    x27       E9,27                           1
    x27       E10,27                          1
    x27       E11,27                          1
    x27       E14,27                          1
    x27       E15,27                          1
    x27       E16,27                          1
    x27       E17,27                          1
    x27       E18,27                          1
    x27       E21,27                          1
    x27       E22,27                          1
    x27       E23,27                          1
    x27       E27,28                          1
    x27       E27,29                          1
    x27       E27,30                          1
    x27       E27,32                          1
    x27       E27,33                          1
    x27       E27,34                          1
    x27       E27,35                          1
    x27       E27,40                          1
    x27       E27,41                          1
    x27       E27,42                          1
    x27       E27,43                          1
    x27       E27,44                          1
    x27       E27,45                          1
    x27       E27,47                          1
    x27       E27,49                          1
    x28       cost                            1
    x28       C0,28                           1
    x28       C1,28                           1
    x28       C3,28                           1
    x28       C8,28                           1
    x28       C9,28                           1
    x28       C10,28                          1
    x28       C14,28                          1
    x28       C15,28                          1
    x28       C22,28                          1
    x28       C28,30                          1
    x28       C28,35                          1
    x28       C28,37                          1
    x28       C28,38                          1
    x28       C28,42                          1
    x28       C28,48                          1
    x28       E2,28                           1
    x28       E4,28                           1
    x28       E5,28                           1
    x28       E6,28                           1
    x28       E7,28                           1
    x28       E11,28                          1
    x28       E12,28                          1
    x28       E13,28                          1
    x28       E16,28                          1
    x28       E17,28                          1
    x28       E18,28                          1
    x28       E19,28                          1
    x28       E20,28                          1
    x28       E21,28                          1
    x28       E23,28                          1
    x28       E24,28                          1
    x28       E25,28                          1
    x28       E26,28                          1
    x28       E27,28                          1
    x28       E28,29                          1
    x28       E28,31                          1
    x28       E28,32                          1
    x28       E28,33                          1
    x28       E28,34                          1
    x28       E28,36                          1
    x28       E28,39                          1
    x28       E28,40                          1
    x28       E28,41                          1
    x28       E28,43                          1
    x28       E28,44                          1
    x28       E28,45                          1
    x28       E28,46                          1
    x28       E28,47                          1
    x28       E28,49                          1
    x29       cost                            1
    x29       C0,29                           1
    x29       C2,29                           1
    x29       C3,29                           1
    x29       C8,29                           1
    x29       C14,29                          1
    x29       C17,29                          1
    x29       C18,29                          1
    x29       C22,29                          1
    x29       C29,33                          1
    x29       C29,35                          1
    x29       C29,40                          1
    x29       C29,44                          1
    x29       C29,45                          1
    x29       E1,29                           1
    x29       E4,29                           1
    x29       E5,29                           1
    x29       E6,29                           1
    x29       E7,29                           1
    x29       E9,29                           1
    x29       E10,29                          1
    x29       E11,29                          1
    x29       E12,29                          1
    x29       E13,29                          1
    x29       E15,29                          1
    x29       E16,29                          1
    x29       E19,29                          1
    x29       E20,29                          1
    x29       E21,29                          1
    x29       E23,29                          1
    x29       E24,29                          1
    x29       E25,29                          1
    x29       E26,29                          1
    x29       E27,29                          1
    x29       E28,29                          1
    x29       E29,30                          1
    x29       E29,31                          1
    x29       E29,32                          1
    x29       E29,34                          1
    x29       E29,36                          1
    x29       E29,37                          1
    x29       E29,38                          1
    x29       E29,39                          1
    x29       E29,41                          1
    x29       E29,42                          1
    x29       E29,43                          1
    x29       E29,46                          1
    x29       E29,47                          1
    x29       E29,48                          1
    x29       E29,49                          1
    x30       cost                            1
    x30       C0,30                           1
    x30       C1,30                           1
    x30       C3,30                           1
    x30       C8,30                           1
    x30       C10,30                          1
    x30       C11,30                          1
    x30       C19,30                          1
    x30       C23,30                          1
    x30       C28,30                          1
    x30       C30,32                          1
    x30       C30,35                          1
    x30       C30,39                          1
    x30       C30,44                          1
    x30       C30,45                          1
    x30       C30,49                          1
    x30       E2,30                           1
    x30       E4,30                           1
    x30       E5,30                           1
    x30       E6,30                           1
    x30       E7,30                           1
    x30       E9,30                           1
    x30       E12,30                          1
    x30       E13,30                          1
    x30       E14,30                          1
    x30       E15,30                          1
    x30       E16,30                          1
    x30       E17,30                          1
    x30       E18,30                          1
    x30       E20,30                          1
    x30       E21,30                          1
    x30       E22,30                          1
    x30       E24,30                          1
    x30       E25,30                          1
    x30       E26,30                          1
    x30       E27,30                          1
    x30       E29,30                          1
    x30       E30,31                          1
    x30       E30,33                          1
    x30       E30,34                          1
    x30       E30,36                          1
    x30       E30,37                          1
    x30       E30,38                          1
    x30       E30,40                          1
    x30       E30,41                          1
    x30       E30,42                          1
    x30       E30,43                          1
    x30       E30,46                          1
    x30       E30,47                          1
    x30       E30,48                          1
    x31       cost                            1
    x31       C3,31                           1
    x31       C6,31                           1
    x31       C9,31                           1
    x31       C16,31                          1
    x31       C17,31                          1
    x31       C22,31                          1
    x31       C23,31                          1
    x31       C27,31                          1
    x31       C31,34                          1
    x31       C31,36                          1
    x31       C31,37                          1
    x31       C31,40                          1
    x31       C31,44                          1
    x31       C31,46                          1
    x31       C31,47                          1
    x31       E0,31                           1
    x31       E1,31                           1
    x31       E2,31                           1
    x31       E4,31                           1
    x31       E5,31                           1
    x31       E7,31                           1
    x31       E8,31                           1
    x31       E10,31                          1
    x31       E11,31                          1
    x31       E12,31                          1
    x31       E13,31                          1
    x31       E14,31                          1
    x31       E15,31                          1
    x31       E18,31                          1
    x31       E19,31                          1
    x31       E20,31                          1
    x31       E21,31                          1
    x31       E24,31                          1
    x31       E25,31                          1
    x31       E26,31                          1
    x31       E28,31                          1
    x31       E29,31                          1
    x31       E30,31                          1
    x31       E31,32                          1
    x31       E31,33                          1
    x31       E31,35                          1
    x31       E31,38                          1
    x31       E31,39                          1
    x31       E31,41                          1
    x31       E31,42                          1
    x31       E31,43                          1
    x31       E31,45                          1
    x31       E31,48                          1
    x31       E31,49                          1
    x32       cost                            1
    x32       C3,32                           1
    x32       C6,32                           1
    x32       C11,32                          1
    x32       C18,32                          1
    x32       C19,32                          1
    x32       C22,32                          1
    x32       C25,32                          1
    x32       C26,32                          1
    x32       C30,32                          1
    x32       C32,36                          1
    x32       C32,49                          1
    x32       E0,32                           1
    x32       E1,32                           1
    x32       E2,32                           1
    x32       E4,32                           1
    x32       E5,32                           1
    x32       E7,32                           1
    x32       E8,32                           1
    x32       E9,32                           1
    x32       E10,32                          1
    x32       E12,32                          1
    x32       E13,32                          1
    x32       E14,32                          1
    x32       E15,32                          1
    x32       E16,32                          1
    x32       E17,32                          1
    x32       E20,32                          1
    x32       E21,32                          1
    x32       E23,32                          1
    x32       E24,32                          1
    x32       E27,32                          1
    x32       E28,32                          1
    x32       E29,32                          1
    x32       E31,32                          1
    x32       E32,33                          1
    x32       E32,34                          1
    x32       E32,35                          1
    x32       E32,37                          1
    x32       E32,38                          1
    x32       E32,39                          1
    x32       E32,40                          1
    x32       E32,41                          1
    x32       E32,42                          1
    x32       E32,43                          1
    x32       E32,44                          1
    x32       E32,45                          1
    x32       E32,46                          1
    x32       E32,47                          1
    x32       E32,48                          1
    x33       cost                            1
    x33       C1,33                           1
    x33       C12,33                          1
    x33       C13,33                          1
    x33       C18,33                          1
    x33       C19,33                          1
    x33       C20,33                          1
    x33       C23,33                          1
    x33       C25,33                          1
    x33       C26,33                          1
    x33       C29,33                          1
    x33       C33,39                          1
    x33       C33,42                          1
    x33       E0,33                           1
    x33       E2,33                           1
    x33       E3,33                           1
    x33       E4,33                           1
    x33       E5,33                           1
    x33       E6,33                           1
    x33       E7,33                           1
    x33       E8,33                           1
    x33       E9,33                           1
    x33       E10,33                          1
    x33       E11,33                          1
    x33       E14,33                          1
    x33       E15,33                          1
    x33       E16,33                          1
    x33       E17,33                          1
    x33       E21,33                          1
    x33       E22,33                          1
    x33       E24,33                          1
    x33       E27,33                          1
    x33       E28,33                          1
    x33       E30,33                          1
    x33       E31,33                          1
    x33       E32,33                          1
    x33       E33,34                          1
    x33       E33,35                          1
    x33       E33,36                          1
    x33       E33,37                          1
    x33       E33,38                          1
    x33       E33,40                          1
    x33       E33,41                          1
    x33       E33,43                          1
    x33       E33,44                          1
    x33       E33,45                          1
    x33       E33,46                          1
    x33       E33,47                          1
    x33       E33,48                          1
    x33       E33,49                          1
    x34       cost                            1
    x34       C7,34                           1
    x34       C10,34                          1
    x34       C12,34                          1
    x34       C13,34                          1
    x34       C21,34                          1
    x34       C22,34                          1
    x34       C24,34                          1
    x34       C25,34                          1
    x34       C31,34                          1
    x34       C34,36                          1
    x34       C34,44                          1
    x34       C34,46                          1
    x34       C34,48                          1
    x34       C34,49                          1
    x34       E0,34                           1
    x34       E1,34                           1
    x34       E2,34                           1
    x34       E3,34                           1
    x34       E4,34                           1
    x34       E5,34                           1
    x34       E6,34                           1
    x34       E8,34                           1
    x34       E9,34                           1
    x34       E11,34                          1
    x34       E14,34                          1
    x34       E15,34                          1
    x34       E16,34                          1
    x34       E17,34                          1
    x34       E18,34                          1
    x34       E19,34                          1
    x34       E20,34                          1
    x34       E23,34                          1
    x34       E26,34                          1
    x34       E27,34                          1
    x34       E28,34                          1
    x34       E29,34                          1
    x34       E30,34                          1
    x34       E32,34                          1
    x34       E33,34                          1
    x34       E34,35                          1
    x34       E34,37                          1
    x34       E34,38                          1
    x34       E34,39                          1
    x34       E34,40                          1
    x34       E34,41                          1
    x34       E34,42                          1
    x34       E34,43                          1
    x34       E34,45                          1
    x34       E34,47                          1
    x35       cost                            1
    x35       C0,35                           1
    x35       C4,35                           1
    x35       C6,35                           1
    x35       C11,35                          1
    x35       C12,35                          1
    x35       C15,35                          1
    x35       C17,35                          1
    x35       C19,35                          1
    x35       C21,35                          1
    x35       C22,35                          1
    x35       C24,35                          1
    x35       C25,35                          1
    x35       C26,35                          1
    x35       C28,35                          1
    x35       C29,35                          1
    x35       C30,35                          1
    x35       C35,37                          1
    x35       C35,40                          1
    x35       C35,43                          1
    x35       E1,35                           1
    x35       E2,35                           1
    x35       E3,35                           1
    x35       E5,35                           1
    x35       E7,35                           1
    x35       E8,35                           1
    x35       E9,35                           1
    x35       E10,35                          1
    x35       E13,35                          1
    x35       E14,35                          1
    x35       E16,35                          1
    x35       E18,35                          1
    x35       E20,35                          1
    x35       E23,35                          1
    x35       E27,35                          1
    x35       E31,35                          1
    x35       E32,35                          1
    x35       E33,35                          1
    x35       E34,35                          1
    x35       E35,36                          1
    x35       E35,38                          1
    x35       E35,39                          1
    x35       E35,41                          1
    x35       E35,42                          1
    x35       E35,44                          1
    x35       E35,45                          1
    x35       E35,46                          1
    x35       E35,47                          1
    x35       E35,48                          1
    x35       E35,49                          1
    x36       cost                            1
    x36       C0,36                           1
    x36       C1,36                           1
    x36       C2,36                           1
    x36       C3,36                           1
    x36       C4,36                           1
    x36       C6,36                           1
    x36       C7,36                           1
    x36       C8,36                           1
    x36       C11,36                          1
    x36       C14,36                          1
    x36       C16,36                          1
    x36       C17,36                          1
    x36       C19,36                          1
    x36       C21,36                          1
    x36       C25,36                          1
    x36       C26,36                          1
    x36       C27,36                          1
    x36       C31,36                          1
    x36       C32,36                          1
    x36       C34,36                          1
    x36       C36,37                          1
    x36       C36,40                          1
    x36       C36,42                          1
    x36       C36,46                          1
    x36       C36,49                          1
    x36       E5,36                           1
    x36       E9,36                           1
    x36       E10,36                          1
    x36       E12,36                          1
    x36       E13,36                          1
    x36       E15,36                          1
    x36       E18,36                          1
    x36       E20,36                          1
    x36       E22,36                          1
    x36       E23,36                          1
    x36       E24,36                          1
    x36       E28,36                          1
    x36       E29,36                          1
    x36       E30,36                          1
    x36       E33,36                          1
    x36       E35,36                          1
    x36       E36,38                          1
    x36       E36,39                          1
    x36       E36,41                          1
    x36       E36,43                          1
    x36       E36,44                          1
    x36       E36,45                          1
    x36       E36,47                          1
    x36       E36,48                          1
    x37       cost                            1
    x37       C0,37                           1
    x37       C2,37                           1
    x37       C6,37                           1
    x37       C8,37                           1
    x37       C9,37                           1
    x37       C11,37                          1
    x37       C17,37                          1
    x37       C22,37                          1
    x37       C24,37                          1
    x37       C27,37                          1
    x37       C28,37                          1
    x37       C31,37                          1
    x37       C35,37                          1
    x37       C36,37                          1
    x37       C37,40                          1
    x37       C37,48                          1
    x37       E1,37                           1
    x37       E3,37                           1
    x37       E4,37                           1
    x37       E5,37                           1
    x37       E7,37                           1
    x37       E10,37                          1
    x37       E12,37                          1
    x37       E13,37                          1
    x37       E14,37                          1
    x37       E15,37                          1
    x37       E16,37                          1
    x37       E18,37                          1
    x37       E19,37                          1
    x37       E20,37                          1
    x37       E21,37                          1
    x37       E23,37                          1
    x37       E25,37                          1
    x37       E26,37                          1
    x37       E29,37                          1
    x37       E30,37                          1
    x37       E32,37                          1
    x37       E33,37                          1
    x37       E34,37                          1
    x37       E37,38                          1
    x37       E37,39                          1
    x37       E37,41                          1
    x37       E37,42                          1
    x37       E37,43                          1
    x37       E37,44                          1
    x37       E37,45                          1
    x37       E37,46                          1
    x37       E37,47                          1
    x37       E37,49                          1
    x38       cost                            1
    x38       C2,38                           1
    x38       C5,38                           1
    x38       C7,38                           1
    x38       C8,38                           1
    x38       C12,38                          1
    x38       C15,38                          1
    x38       C19,38                          1
    x38       C21,38                          1
    x38       C27,38                          1
    x38       C28,38                          1
    x38       C38,39                          1
    x38       C38,40                          1
    x38       C38,44                          1
    x38       E0,38                           1
    x38       E1,38                           1
    x38       E3,38                           1
    x38       E4,38                           1
    x38       E6,38                           1
    x38       E9,38                           1
    x38       E10,38                          1
    x38       E11,38                          1
    x38       E13,38                          1
    x38       E14,38                          1
    x38       E16,38                          1
    x38       E17,38                          1
    x38       E18,38                          1
    x38       E20,38                          1
    x38       E22,38                          1
    x38       E23,38                          1
    x38       E24,38                          1
    x38       E25,38                          1
    x38       E26,38                          1
    x38       E29,38                          1
    x38       E30,38                          1
    x38       E31,38                          1
    x38       E32,38                          1
    x38       E33,38                          1
    x38       E34,38                          1
    x38       E35,38                          1
    x38       E36,38                          1
    x38       E37,38                          1
    x38       E38,41                          1
    x38       E38,42                          1
    x38       E38,43                          1
    x38       E38,45                          1
    x38       E38,46                          1
    x38       E38,47                          1
    x38       E38,48                          1
    x38       E38,49                          1
    x39       cost                            1
    x39       C0,39                           1
    x39       C1,39                           1
    x39       C8,39                           1
    x39       C9,39                           1
    x39       C14,39                          1
    x39       C18,39                          1
    x39       C20,39                          1
    x39       C26,39                          1
    x39       C27,39                          1
    x39       C30,39                          1
    x39       C33,39                          1
    x39       C38,39                          1
    x39       C39,48                          1
    x39       C39,49                          1
    x39       E2,39                           1
    x39       E3,39                           1
    x39       E4,39                           1
    x39       E5,39                           1
    x39       E6,39                           1
    x39       E7,39                           1
    x39       E10,39                          1
    x39       E11,39                          1
    x39       E12,39                          1
    x39       E13,39                          1
    x39       E15,39                          1
    x39       E16,39                          1
    x39       E17,39                          1
    x39       E19,39                          1
    x39       E21,39                          1
    x39       E22,39                          1
    x39       E23,39                          1
    x39       E24,39                          1
    x39       E25,39                          1
    x39       E28,39                          1
    x39       E29,39                          1
    x39       E31,39                          1
    x39       E32,39                          1
    x39       E34,39                          1
    x39       E35,39                          1
    x39       E36,39                          1
    x39       E37,39                          1
    x39       E39,40                          1
    x39       E39,41                          1
    x39       E39,42                          1
    x39       E39,43                          1
    x39       E39,44                          1
    x39       E39,45                          1
    x39       E39,46                          1
    x39       E39,47                          1
    x40       cost                            1
    x40       C7,40                           1
    x40       C8,40                           1
    x40       C14,40                          1
    x40       C17,40                          1
    x40       C21,40                          1
    x40       C23,40                          1
    x40       C25,40                          1
    x40       C26,40                          1
    x40       C29,40                          1
    x40       C31,40                          1
    x40       C35,40                          1
    x40       C36,40                          1
    x40       C37,40                          1
    x40       C38,40                          1
    x40       C40,41                          1
    x40       C40,42                          1
    x40       C40,43                          1
    x40       C40,46                          1
    x40       E0,40                           1
    x40       E1,40                           1
    x40       E2,40                           1
    x40       E3,40                           1
    x40       E4,40                           1
    x40       E5,40                           1
    x40       E6,40                           1
    x40       E9,40                           1
    x40       E10,40                          1
    x40       E11,40                          1
    x40       E12,40                          1
    x40       E13,40                          1
    x40       E15,40                          1
    x40       E16,40                          1
    x40       E18,40                          1
    x40       E19,40                          1
    x40       E20,40                          1
    x40       E22,40                          1
    x40       E24,40                          1
    x40       E27,40                          1
    x40       E28,40                          1
    x40       E30,40                          1
    x40       E32,40                          1
    x40       E33,40                          1
    x40       E34,40                          1
    x40       E39,40                          1
    x40       E40,44                          1
    x40       E40,45                          1
    x40       E40,47                          1
    x40       E40,48                          1
    x40       E40,49                          1
    x41       cost                            1
    x41       C0,41                           1
    x41       C11,41                          1
    x41       C14,41                          1
    x41       C17,41                          1
    x41       C23,41                          1
    x41       C24,41                          1
    x41       C25,41                          1
    x41       C26,41                          1
    x41       C40,41                          1
    x41       C41,42                          1
    x41       C41,44                          1
    x41       E1,41                           1
    x41       E2,41                           1
    x41       E3,41                           1
    x41       E4,41                           1
    x41       E5,41                           1
    x41       E6,41                           1
    x41       E7,41                           1
    x41       E8,41                           1
    x41       E9,41                           1
    x41       E10,41                          1
    x41       E12,41                          1
    x41       E13,41                          1
    x41       E15,41                          1
    x41       E16,41                          1
    x41       E18,41                          1
    x41       E19,41                          1
    x41       E20,41                          1
    x41       E21,41                          1
    x41       E22,41                          1
    x41       E27,41                          1
    x41       E28,41                          1
    x41       E29,41                          1
    x41       E30,41                          1
    x41       E31,41                          1
    x41       E32,41                          1
    x41       E33,41                          1
    x41       E34,41                          1
    x41       E35,41                          1
    x41       E36,41                          1
    x41       E37,41                          1
    x41       E38,41                          1
    x41       E39,41                          1
    x41       E41,43                          1
    x41       E41,45                          1
    x41       E41,46                          1
    x41       E41,47                          1
    x41       E41,48                          1
    x41       E41,49                          1
    x42       cost                            1
    x42       C0,42                           1
    x42       C4,42                           1
    x42       C12,42                          1
    x42       C15,42                          1
    x42       C17,42                          1
    x42       C19,42                          1
    x42       C21,42                          1
    x42       C25,42                          1
    x42       C28,42                          1
    x42       C33,42                          1
    x42       C36,42                          1
    x42       C40,42                          1
    x42       C41,42                          1
    x42       C42,43                          1
    x42       C42,45                          1
    x42       C42,46                          1
    x42       E1,42                           1
    x42       E2,42                           1
    x42       E3,42                           1
    x42       E5,42                           1
    x42       E6,42                           1
    x42       E7,42                           1
    x42       E8,42                           1
    x42       E9,42                           1
    x42       E10,42                          1
    x42       E11,42                          1
    x42       E13,42                          1
    x42       E14,42                          1
    x42       E16,42                          1
    x42       E18,42                          1
    x42       E20,42                          1
    x42       E22,42                          1
    x42       E23,42                          1
    x42       E24,42                          1
    x42       E26,42                          1
    x42       E27,42                          1
    x42       E29,42                          1
    x42       E30,42                          1
    x42       E31,42                          1
    x42       E32,42                          1
    x42       E34,42                          1
    x42       E35,42                          1
    x42       E37,42                          1
    x42       E38,42                          1
    x42       E39,42                          1
    x42       E42,44                          1
    x42       E42,47                          1
    x42       E42,48                          1
    x42       E42,49                          1
    x43       cost                            1
    x43       C2,43                           1
    x43       C7,43                           1
    x43       C11,43                          1
    x43       C19,43                          1
    x43       C20,43                          1
    x43       C23,43                          1
    x43       C35,43                          1
    x43       C40,43                          1
    x43       C42,43                          1
    x43       C43,46                          1
    x43       C43,47                          1
    x43       C43,48                          1
    x43       E0,43                           1
    x43       E1,43                           1
    x43       E3,43                           1
    x43       E4,43                           1
    x43       E5,43                           1
    x43       E6,43                           1
    x43       E8,43                           1
    x43       E9,43                           1
    x43       E10,43                          1
    x43       E12,43                          1
    x43       E13,43                          1
    x43       E14,43                          1
    x43       E15,43                          1
    x43       E16,43                          1
    x43       E17,43                          1
    x43       E18,43                          1
    x43       E21,43                          1
    x43       E22,43                          1
    x43       E24,43                          1
    x43       E25,43                          1
    x43       E26,43                          1
    x43       E27,43                          1
    x43       E28,43                          1
    x43       E29,43                          1
    x43       E30,43                          1
    x43       E31,43                          1
    x43       E32,43                          1
    x43       E33,43                          1
    x43       E34,43                          1
    x43       E36,43                          1
    x43       E37,43                          1
    x43       E38,43                          1
    x43       E39,43                          1
    x43       E41,43                          1
    x43       E43,44                          1
    x43       E43,45                          1
    x43       E43,49                          1
    x44       cost                            1
    x44       C4,44                           1
    x44       C5,44                           1
    x44       C13,44                          1
    x44       C17,44                          1
    x44       C18,44                          1
    x44       C19,44                          1
    x44       C20,44                          1
    x44       C21,44                          1
    x44       C29,44                          1
    x44       C30,44                          1
    x44       C31,44                          1
    x44       C34,44                          1
    x44       C38,44                          1
    x44       C41,44                          1
    x44       C44,46                          1
    x44       C44,49                          1
    x44       E0,44                           1
    x44       E1,44                           1
    x44       E2,44                           1
    x44       E3,44                           1
    x44       E6,44                           1
    x44       E7,44                           1
    x44       E8,44                           1
    x44       E9,44                           1
    x44       E10,44                          1
    x44       E11,44                          1
    x44       E12,44                          1
    x44       E14,44                          1
    x44       E15,44                          1
    x44       E16,44                          1
    x44       E22,44                          1
    x44       E23,44                          1
    x44       E24,44                          1
    x44       E25,44                          1
    x44       E26,44                          1
    x44       E27,44                          1
    x44       E28,44                          1
    x44       E32,44                          1
    x44       E33,44                          1
    x44       E35,44                          1
    x44       E36,44                          1
    x44       E37,44                          1
    x44       E39,44                          1
    x44       E40,44                          1
    x44       E42,44                          1
    x44       E43,44                          1
    x44       E44,45                          1
    x44       E44,47                          1
    x44       E44,48                          1
    x45       cost                            1
    x45       C10,45                          1
    x45       C11,45                          1
    x45       C15,45                          1
    x45       C17,45                          1
    x45       C24,45                          1
    x45       C29,45                          1
    x45       C30,45                          1
    x45       C42,45                          1
    x45       C45,46                          1
    x45       C45,48                          1
    x45       E0,45                           1
    x45       E1,45                           1
    x45       E2,45                           1
    x45       E3,45                           1
    x45       E4,45                           1
    x45       E5,45                           1
    x45       E6,45                           1
    x45       E7,45                           1
    x45       E8,45                           1
    x45       E9,45                           1
    x45       E12,45                          1
    x45       E13,45                          1
    x45       E14,45                          1
    x45       E16,45                          1
    x45       E18,45                          1
    x45       E19,45                          1
    x45       E20,45                          1
    x45       E21,45                          1
    x45       E22,45                          1
    x45       E23,45                          1
    x45       E25,45                          1
    x45       E26,45                          1
    x45       E27,45                          1
    x45       E28,45                          1
    x45       E31,45                          1
    x45       E32,45                          1
    x45       E33,45                          1
    x45       E34,45                          1
    x45       E35,45                          1
    x45       E36,45                          1
    x45       E37,45                          1
    x45       E38,45                          1
    x45       E39,45                          1
    x45       E40,45                          1
    x45       E41,45                          1
    x45       E43,45                          1
    x45       E44,45                          1
    x45       E45,47                          1
    x45       E45,49                          1
    x46       cost                            1
    x46       C2,46                           1
    x46       C3,46                           1
    x46       C5,46                           1
    x46       C7,46                           1
    x46       C10,46                          1
    x46       C12,46                          1
    x46       C21,46                          1
    x46       C26,46                          1
    x46       C27,46                          1
    x46       C31,46                          1
    x46       C34,46                          1
    x46       C36,46                          1
    x46       C40,46                          1
    x46       C42,46                          1
    x46       C43,46                          1
    x46       C44,46                          1
    x46       C45,46                          1
    x46       C46,47                          1
    x46       E0,46                           1
    x46       E1,46                           1
    x46       E4,46                           1
    x46       E6,46                           1
    x46       E8,46                           1
    x46       E9,46                           1
    x46       E11,46                          1
    x46       E13,46                          1
    x46       E14,46                          1
    x46       E15,46                          1
    x46       E16,46                          1
    x46       E17,46                          1
    x46       E18,46                          1
    x46       E19,46                          1
    x46       E20,46                          1
    x46       E22,46                          1
    x46       E23,46                          1
    x46       E24,46                          1
    x46       E25,46                          1
    x46       E28,46                          1
    x46       E29,46                          1
    x46       E30,46                          1
    x46       E32,46                          1
    x46       E33,46                          1
    x46       E35,46                          1
    x46       E37,46                          1
    x46       E38,46                          1
    x46       E39,46                          1
    x46       E41,46                          1
    x46       E46,48                          1
    x46       E46,49                          1
    x47       cost                            1
    x47       C1,47                           1
    x47       C8,47                           1
    x47       C12,47                          1
    x47       C20,47                          1
    x47       C22,47                          1
    x47       C23,47                          1
    x47       C31,47                          1
    x47       C43,47                          1
    x47       C46,47                          1
    x47       C47,49                          1
    x47       E0,47                           1
    x47       E2,47                           1
    x47       E3,47                           1
    x47       E4,47                           1
    x47       E5,47                           1
    x47       E6,47                           1
    x47       E7,47                           1
    x47       E9,47                           1
    x47       E10,47                          1
    x47       E11,47                          1
    x47       E13,47                          1
    x47       E14,47                          1
    x47       E15,47                          1
    x47       E16,47                          1
    x47       E17,47                          1
    x47       E18,47                          1
    x47       E19,47                          1
    x47       E21,47                          1
    x47       E24,47                          1
    x47       E25,47                          1
    x47       E26,47                          1
    x47       E27,47                          1
    x47       E28,47                          1
    x47       E29,47                          1
    x47       E30,47                          1
    x47       E32,47                          1
    x47       E33,47                          1
    x47       E34,47                          1
    x47       E35,47                          1
    x47       E36,47                          1
    x47       E37,47                          1
    x47       E38,47                          1
    x47       E39,47                          1
    x47       E40,47                          1
    x47       E41,47                          1
    x47       E42,47                          1
    x47       E44,47                          1
    x47       E45,47                          1
    x47       E47,48                          1
    x48       cost                            1
    x48       C2,48                           1
    x48       C3,48                           1
    x48       C4,48                           1
    x48       C5,48                           1
    x48       C8,48                           1
    x48       C17,48                          1
    x48       C22,48                          1
    x48       C25,48                          1
    x48       C27,48                          1
    x48       C28,48                          1
    x48       C34,48                          1
    x48       C37,48                          1
    x48       C39,48                          1
    x48       C43,48                          1
    x48       C45,48                          1
    x48       E0,48                           1
    x48       E1,48                           1
    x48       E6,48                           1
    x48       E7,48                           1
    x48       E9,48                           1
    x48       E10,48                          1
    x48       E11,48                          1
    x48       E12,48                          1
    x48       E13,48                          1
    x48       E14,48                          1
    x48       E15,48                          1
    x48       E16,48                          1
    x48       E18,48                          1
    x48       E19,48                          1
    x48       E20,48                          1
    x48       E21,48                          1
    x48       E23,48                          1
    x48       E24,48                          1
    x48       E26,48                          1
    x48       E29,48                          1
    x48       E30,48                          1
    x48       E31,48                          1
    x48       E32,48                          1
    x48       E33,48                          1
    x48       E35,48                          1
    x48       E36,48                          1
    x48       E38,48                          1
    x48       E40,48                          1
    x48       E41,48                          1
    x48       E42,48                          1
    x48       E44,48                          1
    x48       E46,48                          1
    x48       E47,48                          1
    x48       E48,49                          1
    x49       cost                            1
    x49       C0,49                           1
    x49       C8,49                           1
    x49       C10,49                          1
    x49       C16,49                          1
    x49       C18,49                          1
    x49       C24,49                          1
    x49       C25,49                          1
    x49       C30,49                          1
    x49       C32,49                          1
    x49       C34,49                          1
    x49       C36,49                          1
    x49       C39,49                          1
    x49       C44,49                          1
    x49       C47,49                          1
    x49       E1,49                           1
    x49       E2,49                           1
    x49       E3,49                           1
    x49       E4,49                           1
    x49       E5,49                           1
    x49       E6,49                           1
    x49       E7,49                           1
    x49       E9,49                           1
    x49       E11,49                          1
    x49       E12,49                          1
    x49       E13,49                          1
    x49       E14,49                          1
    x49       E15,49                          1
    x49       E17,49                          1
    x49       E19,49                          1
    x49       E20,49                          1
    x49       E21,49                          1
    x49       E22,49                          1
    x49       E23,49                          1
    x49       E26,49                          1
    x49       E27,49                          1
    x49       E28,49                          1
    x49       E29,49                          1
    x49       E31,49                          1
    x49       E33,49                          1
    x49       E35,49                          1
    x49       E37,49                          1
    x49       E38,49                          1
    x49       E40,49                          1
    x49       E41,49                          1
    x49       E42,49                          1
    x49       E43,49                          1
    x49       E45,49                          1
    x49       E46,49                          1
    x49       E48,49                          1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       KL                            214
    rhs       C0,4                            1
    rhs       C0,12                           1
    rhs       C0,21                           1
    rhs       C0,24                           1
    rhs       C0,27                           1
    rhs       C0,28                           1
    rhs       C0,29                           1
    rhs       C0,30                           1
    rhs       C0,35                           1
    rhs       C0,36                           1
    rhs       C0,37                           1
    rhs       C0,39                           1
    rhs       C0,41                           1
    rhs       C0,42                           1
    rhs       C0,49                           1
    rhs       C1,4                            1
    rhs       C1,7                            1
    rhs       C1,13                           1
    rhs       C1,23                           1
    rhs       C1,25                           1
    rhs       C1,28                           1
    rhs       C1,30                           1
    rhs       C1,33                           1
    rhs       C1,36                           1
    rhs       C1,39                           1
    rhs       C1,47                           1
    rhs       C2,3                            1
    rhs       C2,6                            1
    rhs       C2,8                            1
    rhs       C2,13                           1
    rhs       C2,15                           1
    rhs       C2,16                           1
    rhs       C2,17                           1
    rhs       C2,23                           1
    rhs       C2,24                           1
    rhs       C2,25                           1
    rhs       C2,26                           1
    rhs       C2,29                           1
    rhs       C2,36                           1
    rhs       C2,37                           1
    rhs       C2,38                           1
    rhs       C2,43                           1
    rhs       C2,46                           1
    rhs       C2,48                           1
    rhs       C3,4                            1
    rhs       C3,7                            1
    rhs       C3,10                           1
    rhs       C3,11                           1
    rhs       C3,12                           1
    rhs       C3,13                           1
    rhs       C3,15                           1
    rhs       C3,16                           1
    rhs       C3,18                           1
    rhs       C3,28                           1
    rhs       C3,29                           1
    rhs       C3,30                           1
    rhs       C3,31                           1
    rhs       C3,32                           1
    rhs       C3,36                           1
    rhs       C3,46                           1
    rhs       C3,48                           1
    rhs       C4,7                            1
    rhs       C4,10                           1
    rhs       C4,12                           1
    rhs       C4,14                           1
    rhs       C4,17                           1
    rhs       C4,19                           1
    rhs       C4,21                           1
    rhs       C4,23                           1
    rhs       C4,24                           1
    rhs       C4,27                           1
    rhs       C4,35                           1
    rhs       C4,36                           1
    rhs       C4,42                           1
    rhs       C4,44                           1
    rhs       C4,48                           1
    rhs       C5,9                            1
    rhs       C5,13                           1
    rhs       C5,14                           1
    rhs       C5,15                           1
    rhs       C5,17                           1
    rhs       C5,38                           1
    rhs       C5,44                           1
    rhs       C5,46                           1
    rhs       C5,48                           1
    rhs       C6,7                            1
    rhs       C6,9                            1
    rhs       C6,11                           1
    rhs       C6,14                           1
    rhs       C6,16                           1
    rhs       C6,21                           1
    rhs       C6,26                           1
    rhs       C6,31                           1
    rhs       C6,32                           1
    rhs       C6,35                           1
    rhs       C6,36                           1
    rhs       C6,37                           1
    rhs       C7,9                            1
    rhs       C7,11                           1
    rhs       C7,13                           1
    rhs       C7,15                           1
    rhs       C7,22                           1
    rhs       C7,25                           1
    rhs       C7,26                           1
    rhs       C7,34                           1
    rhs       C7,36                           1
    rhs       C7,38                           1
    rhs       C7,40                           1
    rhs       C7,43                           1
    rhs       C7,46                           1
    rhs       C8,11                           1
    rhs       C8,14                           1
    rhs       C8,16                           1
    rhs       C8,21                           1
    rhs       C8,22                           1
    rhs       C8,23                           1
    rhs       C8,25                           1
    rhs       C8,28                           1
    rhs       C8,29                           1
    rhs       C8,30                           1
    rhs       C8,36                           1
    rhs       C8,37                           1
    rhs       C8,38                           1
    rhs       C8,39                           1
    rhs       C8,40                           1
    rhs       C8,47                           1
    rhs       C8,48                           1
    rhs       C8,49                           1
    rhs       C9,14                           1
    rhs       C9,20                           1
    rhs       C9,25                           1
    rhs       C9,28                           1
    rhs       C9,31                           1
    rhs       C9,37                           1
    rhs       C9,39                           1
    rhs       C10,12                          1
    rhs       C10,13                          1
    rhs       C10,16                          1
    rhs       C10,28                          1
    rhs       C10,30                          1
    rhs       C10,34                          1
    rhs       C10,45                          1
    rhs       C10,46                          1
    rhs       C10,49                          1
    rhs       C11,20                          1
    rhs       C11,23                          1
    rhs       C11,24                          1
    rhs       C11,30                          1
    rhs       C11,32                          1
    rhs       C11,35                          1
    rhs       C11,36                          1
    rhs       C11,37                          1
    rhs       C11,41                          1
    rhs       C11,43                          1
    rhs       C11,45                          1
    rhs       C12,14                          1
    rhs       C12,16                          1
    rhs       C12,19                          1
    rhs       C12,25                          1
    rhs       C12,27                          1
    rhs       C12,33                          1
    rhs       C12,34                          1
    rhs       C12,35                          1
    rhs       C12,38                          1
    rhs       C12,42                          1
    rhs       C12,46                          1
    rhs       C12,47                          1
    rhs       C13,16                          1
    rhs       C13,17                          1
    rhs       C13,19                          1
    rhs       C13,21                          1
    rhs       C13,22                          1
    rhs       C13,27                          1
    rhs       C13,33                          1
    rhs       C13,34                          1
    rhs       C13,44                          1
    rhs       C14,21                          1
    rhs       C14,26                          1
    rhs       C14,28                          1
    rhs       C14,29                          1
    rhs       C14,36                          1
    rhs       C14,39                          1
    rhs       C14,40                          1
    rhs       C14,41                          1
    rhs       C15,20                          1
    rhs       C15,25                          1
    rhs       C15,28                          1
    rhs       C15,35                          1
    rhs       C15,38                          1
    rhs       C15,42                          1
    rhs       C15,45                          1
    rhs       C16,17                          1
    rhs       C16,19                          1
    rhs       C16,25                          1
    rhs       C16,26                          1
    rhs       C16,31                          1
    rhs       C16,36                          1
    rhs       C16,49                          1
    rhs       C17,19                          1
    rhs       C17,21                          1
    rhs       C17,23                          1
    rhs       C17,24                          1
    rhs       C17,29                          1
    rhs       C17,31                          1
    rhs       C17,35                          1
    rhs       C17,36                          1
    rhs       C17,37                          1
    rhs       C17,40                          1
    rhs       C17,41                          1
    rhs       C17,42                          1
    rhs       C17,44                          1
    rhs       C17,45                          1
    rhs       C17,48                          1
    rhs       C18,26                          1
    rhs       C18,29                          1
    rhs       C18,32                          1
    rhs       C18,33                          1
    rhs       C18,39                          1
    rhs       C18,44                          1
    rhs       C18,49                          1
    rhs       C19,21                          1
    rhs       C19,27                          1
    rhs       C19,30                          1
    rhs       C19,32                          1
    rhs       C19,33                          1
    rhs       C19,35                          1
    rhs       C19,36                          1
    rhs       C19,38                          1
    rhs       C19,42                          1
    rhs       C19,43                          1
    rhs       C19,44                          1
    rhs       C20,21                          1
    rhs       C20,24                          1
    rhs       C20,26                          1
    rhs       C20,27                          1
    rhs       C20,33                          1
    rhs       C20,39                          1
    rhs       C20,43                          1
    rhs       C20,44                          1
    rhs       C20,47                          1
    rhs       C21,23                          1
    rhs       C21,34                          1
    rhs       C21,35                          1
    rhs       C21,36                          1
    rhs       C21,38                          1
    rhs       C21,40                          1
    rhs       C21,42                          1
    rhs       C21,44                          1
    rhs       C21,46                          1
    rhs       C22,24                          1
    rhs       C22,26                          1
    rhs       C22,28                          1
    rhs       C22,29                          1
    rhs       C22,31                          1
    rhs       C22,32                          1
    rhs       C22,34                          1
    rhs       C22,35                          1
    rhs       C22,37                          1
    rhs       C22,47                          1
    rhs       C22,48                          1
    rhs       C23,30                          1
    rhs       C23,31                          1
    rhs       C23,33                          1
    rhs       C23,40                          1
    rhs       C23,41                          1
    rhs       C23,43                          1
    rhs       C23,47                          1
    rhs       C24,25                          1
    rhs       C24,27                          1
    rhs       C24,34                          1
    rhs       C24,35                          1
    rhs       C24,37                          1
    rhs       C24,41                          1
    rhs       C24,45                          1
    rhs       C24,49                          1
    rhs       C25,27                          1
    rhs       C25,32                          1
    rhs       C25,33                          1
    rhs       C25,34                          1
    rhs       C25,35                          1
    rhs       C25,36                          1
    rhs       C25,40                          1
    rhs       C25,41                          1
    rhs       C25,42                          1
    rhs       C25,48                          1
    rhs       C25,49                          1
    rhs       C26,27                          1
    rhs       C26,32                          1
    rhs       C26,33                          1
    rhs       C26,35                          1
    rhs       C26,36                          1
    rhs       C26,39                          1
    rhs       C26,40                          1
    rhs       C26,41                          1
    rhs       C26,46                          1
    rhs       C27,31                          1
    rhs       C27,36                          1
    rhs       C27,37                          1
    rhs       C27,38                          1
    rhs       C27,39                          1
    rhs       C27,46                          1
    rhs       C27,48                          1
    rhs       C28,30                          1
    rhs       C28,35                          1
    rhs       C28,37                          1
    rhs       C28,38                          1
    rhs       C28,42                          1
    rhs       C28,48                          1
    rhs       C29,33                          1
    rhs       C29,35                          1
    rhs       C29,40                          1
    rhs       C29,44                          1
    rhs       C29,45                          1
    rhs       C30,32                          1
    rhs       C30,35                          1
    rhs       C30,39                          1
    rhs       C30,44                          1
    rhs       C30,45                          1
    rhs       C30,49                          1
    rhs       C31,34                          1
    rhs       C31,36                          1
    rhs       C31,37                          1
    rhs       C31,40                          1
    rhs       C31,44                          1
    rhs       C31,46                          1
    rhs       C31,47                          1
    rhs       C32,36                          1
    rhs       C32,49                          1
    rhs       C33,39                          1
    rhs       C33,42                          1
    rhs       C34,36                          1
    rhs       C34,44                          1
    rhs       C34,46                          1
    rhs       C34,48                          1
    rhs       C34,49                          1
    rhs       C35,37                          1
    rhs       C35,40                          1
    rhs       C35,43                          1
    rhs       C36,37                          1
    rhs       C36,40                          1
    rhs       C36,42                          1
    rhs       C36,46                          1
    rhs       C36,49                          1
    rhs       C37,40                          1
    rhs       C37,48                          1
    rhs       C38,39                          1
    rhs       C38,40                          1
    rhs       C38,44                          1
    rhs       C39,48                          1
    rhs       C39,49                          1
    rhs       C40,41                          1
    rhs       C40,42                          1
    rhs       C40,43                          1
    rhs       C40,46                          1
    rhs       C41,42                          1
    rhs       C41,44                          1
    rhs       C42,43                          1
    rhs       C42,45                          1
    rhs       C42,46                          1
    rhs       C43,46                          1
    rhs       C43,47                          1
    rhs       C43,48                          1
    rhs       C44,46                          1
    rhs       C44,49                          1
    rhs       C45,46                          1
    rhs       C45,48                          1
    rhs       C46,47                          1
    rhs       C47,49                          1
    rhs       E0,1                            1
    rhs       E0,2                            1
    rhs       E0,3                            1
    rhs       E0,5                            1
    rhs       E0,6                            1
    rhs       E0,7                            1
    rhs       E0,8                            1
    rhs       E0,9                            1
    rhs       E0,10                           1
    rhs       E0,11                           1
    rhs       E0,13                           1
    rhs       E0,14                           1
    rhs       E0,15                           1
    rhs       E0,16                           1
    rhs       E0,17                           1
    rhs       E0,18                           1
    rhs       E0,19                           1
    rhs       E0,20                           1
    rhs       E0,22                           1
    rhs       E0,23                           1
    rhs       E0,25                           1
    rhs       E0,26                           1
    rhs       E0,31                           1
    rhs       E0,32                           1
    rhs       E0,33                           1
    rhs       E0,34                           1
    rhs       E0,38                           1
    rhs       E0,40                           1
    rhs       E0,43                           1
    rhs       E0,44                           1
    rhs       E0,45                           1
    rhs       E0,46                           1
    rhs       E0,47                           1
    rhs       E0,48                           1
    rhs       E1,2                            1
    rhs       E1,3                            1
    rhs       E1,5                            1
    rhs       E1,6                            1
    rhs       E1,8                            1
    rhs       E1,9                            1
    rhs       E1,10                           1
    rhs       E1,11                           1
    rhs       E1,12                           1
    rhs       E1,14                           1
    rhs       E1,15                           1
    rhs       E1,16                           1
    rhs       E1,17                           1
    rhs       E1,18                           1
    rhs       E1,19                           1
    rhs       E1,20                           1
    rhs       E1,21                           1
    rhs       E1,22                           1
    rhs       E1,24                           1
    rhs       E1,26                           1
    rhs       E1,27                           1
    rhs       E1,29                           1
    rhs       E1,31                           1
    rhs       E1,32                           1
    rhs       E1,34                           1
    rhs       E1,35                           1
    rhs       E1,37                           1
    rhs       E1,38                           1
    rhs       E1,40                           1
    rhs       E1,41                           1
    rhs       E1,42                           1
    rhs       E1,43                           1
    rhs       E1,44                           1
    rhs       E1,45                           1
    rhs       E1,46                           1
    rhs       E1,48                           1
    rhs       E1,49                           1
    rhs       E2,4                            1
    rhs       E2,5                            1
    rhs       E2,7                            1
    rhs       E2,9                            1
    rhs       E2,10                           1
    rhs       E2,11                           1
    rhs       E2,12                           1
    rhs       E2,14                           1
    rhs       E2,18                           1
    rhs       E2,19                           1
    rhs       E2,20                           1
    rhs       E2,21                           1
    rhs       E2,22                           1
    rhs       E2,27                           1
    rhs       E2,28                           1
    rhs       E2,30                           1
    rhs       E2,31                           1
    rhs       E2,32                           1
    rhs       E2,33                           1
    rhs       E2,34                           1
    rhs       E2,35                           1
    rhs       E2,39                           1
    rhs       E2,40                           1
    rhs       E2,41                           1
    rhs       E2,42                           1
    rhs       E2,44                           1
    rhs       E2,45                           1
    rhs       E2,47                           1
    rhs       E2,49                           1
    rhs       E3,5                            1
    rhs       E3,6                            1
    rhs       E3,8                            1
    rhs       E3,9                            1
    rhs       E3,14                           1
    rhs       E3,17                           1
    rhs       E3,19                           1
    rhs       E3,20                           1
    rhs       E3,21                           1
    rhs       E3,22                           1
    rhs       E3,23                           1
    rhs       E3,24                           1
    rhs       E3,25                           1
    rhs       E3,26                           1
    rhs       E3,27                           1
    rhs       E3,33                           1
    rhs       E3,34                           1
    rhs       E3,35                           1
    rhs       E3,37                           1
    rhs       E3,38                           1
    rhs       E3,39                           1
    rhs       E3,40                           1
    rhs       E3,41                           1
    rhs       E3,42                           1
    rhs       E3,43                           1
    rhs       E3,44                           1
    rhs       E3,45                           1
    rhs       E3,47                           1
    rhs       E3,49                           1
    rhs       E4,5                            1
    rhs       E4,6                            1
    rhs       E4,8                            1
    rhs       E4,9                            1
    rhs       E4,11                           1
    rhs       E4,13                           1
    rhs       E4,15                           1
    rhs       E4,16                           1
    rhs       E4,18                           1
    rhs       E4,20                           1
    rhs       E4,22                           1
    rhs       E4,25                           1
    rhs       E4,26                           1
    rhs       E4,28                           1
    rhs       E4,29                           1
    rhs       E4,30                           1
    rhs       E4,31                           1
    rhs       E4,32                           1
    rhs       E4,33                           1
    rhs       E4,34                           1
    rhs       E4,37                           1
    rhs       E4,38                           1
    rhs       E4,39                           1
    rhs       E4,40                           1
    rhs       E4,41                           1
    rhs       E4,43                           1
    rhs       E4,45                           1
    rhs       E4,46                           1
    rhs       E4,47                           1
    rhs       E4,49                           1
    rhs       E5,6                            1
    rhs       E5,7                            1
    rhs       E5,8                            1
    rhs       E5,10                           1
    rhs       E5,11                           1
    rhs       E5,12                           1
    rhs       E5,16                           1
    rhs       E5,18                           1
    rhs       E5,19                           1
    rhs       E5,20                           1
    rhs       E5,21                           1
    rhs       E5,22                           1
    rhs       E5,23                           1
    rhs       E5,24                           1
    rhs       E5,25                           1
    rhs       E5,26                           1
    rhs       E5,27                           1
    rhs       E5,28                           1
    rhs       E5,29                           1
    rhs       E5,30                           1
    rhs       E5,31                           1
    rhs       E5,32                           1
    rhs       E5,33                           1
    rhs       E5,34                           1
    rhs       E5,35                           1
    rhs       E5,36                           1
    rhs       E5,37                           1
    rhs       E5,39                           1
    rhs       E5,40                           1
    rhs       E5,41                           1
    rhs       E5,42                           1
    rhs       E5,43                           1
    rhs       E5,45                           1
    rhs       E5,47                           1
    rhs       E5,49                           1
    rhs       E6,8                            1
    rhs       E6,10                           1
    rhs       E6,12                           1
    rhs       E6,13                           1
    rhs       E6,15                           1
    rhs       E6,17                           1
    rhs       E6,18                           1
    rhs       E6,19                           1
    rhs       E6,20                           1
    rhs       E6,22                           1
    rhs       E6,23                           1
    rhs       E6,24                           1
    rhs       E6,25                           1
    rhs       E6,27                           1
    rhs       E6,28                           1
    rhs       E6,29                           1
    rhs       E6,30                           1
    rhs       E6,33                           1
    rhs       E6,34                           1
    rhs       E6,38                           1
    rhs       E6,39                           1
    rhs       E6,40                           1
    rhs       E6,41                           1
    rhs       E6,42                           1
    rhs       E6,43                           1
    rhs       E6,44                           1
    rhs       E6,45                           1
    rhs       E6,46                           1
    rhs       E6,47                           1
    rhs       E6,48                           1
    rhs       E6,49                           1
    rhs       E7,8                            1
    rhs       E7,10                           1
    rhs       E7,12                           1
    rhs       E7,14                           1
    rhs       E7,16                           1
    rhs       E7,17                           1
    rhs       E7,18                           1
    rhs       E7,19                           1
    rhs       E7,20                           1
    rhs       E7,21                           1
    rhs       E7,23                           1
    rhs       E7,24                           1
    rhs       E7,27                           1
    rhs       E7,28                           1
    rhs       E7,29                           1
    rhs       E7,30                           1
    rhs       E7,31                           1
    rhs       E7,32                           1
    rhs       E7,33                           1
    rhs       E7,35                           1
    rhs       E7,37                           1
    rhs       E7,39                           1
    rhs       E7,41                           1
    rhs       E7,42                           1
    rhs       E7,44                           1
    rhs       E7,45                           1
    rhs       E7,47                           1
    rhs       E7,48                           1
    rhs       E7,49                           1
    rhs       E8,9                            1
    rhs       E8,10                           1
    rhs       E8,12                           1
    rhs       E8,13                           1
    rhs       E8,15                           1
    rhs       E8,17                           1
    rhs       E8,18                           1
    rhs       E8,19                           1
    rhs       E8,20                           1
    rhs       E8,24                           1
    rhs       E8,26                           1
    rhs       E8,27                           1
    rhs       E8,31                           1
    rhs       E8,32                           1
    rhs       E8,33                           1
    rhs       E8,34                           1
    rhs       E8,35                           1
    rhs       E8,41                           1
    rhs       E8,42                           1
    rhs       E8,43                           1
    rhs       E8,44                           1
    rhs       E8,45                           1
    rhs       E8,46                           1
    rhs       E9,10                           1
    rhs       E9,11                           1
    rhs       E9,12                           1
    rhs       E9,13                           1
    rhs       E9,15                           1
    rhs       E9,16                           1
    rhs       E9,17                           1
    rhs       E9,18                           1
    rhs       E9,19                           1
    rhs       E9,21                           1
    rhs       E9,22                           1
    rhs       E9,23                           1
    rhs       E9,24                           1
    rhs       E9,26                           1
    rhs       E9,27                           1
    rhs       E9,29                           1
    rhs       E9,30                           1
    rhs       E9,32                           1
    rhs       E9,33                           1
    rhs       E9,34                           1
    rhs       E9,35                           1
    rhs       E9,36                           1
    rhs       E9,38                           1
    rhs       E9,40                           1
    rhs       E9,41                           1
    rhs       E9,42                           1
    rhs       E9,43                           1
    rhs       E9,44                           1
    rhs       E9,45                           1
    rhs       E9,46                           1
    rhs       E9,47                           1
    rhs       E9,48                           1
    rhs       E9,49                           1
    rhs       E10,11                          1
    rhs       E10,14                          1
    rhs       E10,15                          1
    rhs       E10,17                          1
    rhs       E10,18                          1
    rhs       E10,19                          1
    rhs       E10,20                          1
    rhs       E10,21                          1
    rhs       E10,22                          1
    rhs       E10,23                          1
    rhs       E10,24                          1
    rhs       E10,25                          1
    rhs       E10,26                          1
    rhs       E10,27                          1
    rhs       E10,29                          1
    rhs       E10,31                          1
    rhs       E10,32                          1
    rhs       E10,33                          1
    rhs       E10,35                          1
    rhs       E10,36                          1
    rhs       E10,37                          1
    rhs       E10,38                          1
    rhs       E10,39                          1
    rhs       E10,40                          1
    rhs       E10,41                          1
    rhs       E10,42                          1
    rhs       E10,43                          1
    rhs       E10,44                          1
    rhs       E10,47                          1
    rhs       E10,48                          1
    rhs       E11,12                          1
    rhs       E11,13                          1
    rhs       E11,14                          1
    rhs       E11,15                          1
    rhs       E11,16                          1
    rhs       E11,17                          1
    rhs       E11,18                          1
    rhs       E11,19                          1
    rhs       E11,21                          1
    rhs       E11,22                          1
    rhs       E11,25                          1
    rhs       E11,26                          1
    rhs       E11,27                          1
    rhs       E11,28                          1
    rhs       E11,29                          1
    rhs       E11,31                          1
    rhs       E11,33                          1
    rhs       E11,34                          1
    rhs       E11,38                          1
    rhs       E11,39                          1
    rhs       E11,40                          1
    rhs       E11,42                          1
    rhs       E11,44                          1
    rhs       E11,46                          1
    rhs       E11,47                          1
    rhs       E11,48                          1
    rhs       E11,49                          1
    rhs       E12,13                          1
    rhs       E12,15                          1
    rhs       E12,17                          1
    rhs       E12,18                          1
    rhs       E12,20                          1
    rhs       E12,21                          1
    rhs       E12,22                          1
    rhs       E12,23                          1
    rhs       E12,24                          1
    rhs       E12,26                          1
    rhs       E12,28                          1
    rhs       E12,29                          1
    rhs       E12,30                          1
    rhs       E12,31                          1
    rhs       E12,32                          1
    rhs       E12,36                          1
    rhs       E12,37                          1
    rhs       E12,39                          1
    rhs       E12,40                          1
    rhs       E12,41                          1
    rhs       E12,43                          1
    rhs       E12,44                          1
    rhs       E12,45                          1
    rhs       E12,48                          1
    rhs       E12,49                          1
    rhs       E13,14                          1
    rhs       E13,15                          1
    rhs       E13,18                          1
    rhs       E13,20                          1
    rhs       E13,23                          1
    rhs       E13,24                          1
    rhs       E13,25                          1
    rhs       E13,26                          1
    rhs       E13,28                          1
    rhs       E13,29                          1
    rhs       E13,30                          1
    rhs       E13,31                          1
    rhs       E13,32                          1
    rhs       E13,35                          1
    rhs       E13,36                          1
    rhs       E13,37                          1
    rhs       E13,38                          1
    rhs       E13,39                          1
    rhs       E13,40                          1
    rhs       E13,41                          1
    rhs       E13,42                          1
    rhs       E13,43                          1
    rhs       E13,45                          1
    rhs       E13,46                          1
    rhs       E13,47                          1
    rhs       E13,48                          1
    rhs       E13,49                          1
    rhs       E14,15                          1
    rhs       E14,16                          1
    rhs       E14,17                          1
    rhs       E14,18                          1
    rhs       E14,19                          1
    rhs       E14,20                          1
    rhs       E14,22                          1
    rhs       E14,23                          1
    rhs       E14,24                          1
    rhs       E14,25                          1
    rhs       E14,27                          1
    rhs       E14,30                          1
    rhs       E14,31                          1
    rhs       E14,32                          1
    rhs       E14,33                          1
    rhs       E14,34                          1
    rhs       E14,35                          1
    rhs       E14,37                          1
    rhs       E14,38                          1
    rhs       E14,42                          1
    rhs       E14,43                          1
    rhs       E14,44                          1
    rhs       E14,45                          1
    rhs       E14,46                          1
    rhs       E14,47                          1
    rhs       E14,48                          1
    rhs       E14,49                          1
    rhs       E15,16                          1
    rhs       E15,17                          1
    rhs       E15,18                          1
    rhs       E15,19                          1
    rhs       E15,21                          1
    rhs       E15,22                          1
    rhs       E15,23                          1
    rhs       E15,24                          1
    rhs       E15,26                          1
    rhs       E15,27                          1
    rhs       E15,29                          1
    rhs       E15,30                          1
    rhs       E15,31                          1
    rhs       E15,32                          1
    rhs       E15,33                          1
    rhs       E15,34                          1
    rhs       E15,36                          1
    rhs       E15,37                          1
    rhs       E15,39                          1
    rhs       E15,40                          1
    rhs       E15,41                          1
    rhs       E15,43                          1
    rhs       E15,44                          1
    rhs       E15,46                          1
    rhs       E15,47                          1
    rhs       E15,48                          1
    rhs       E15,49                          1
    rhs       E16,18                          1
    rhs       E16,20                          1
    rhs       E16,21                          1
    rhs       E16,22                          1
    rhs       E16,23                          1
    rhs       E16,24                          1
    rhs       E16,27                          1
    rhs       E16,28                          1
    rhs       E16,29                          1
    rhs       E16,30                          1
    rhs       E16,32                          1
    rhs       E16,33                          1
    rhs       E16,34                          1
    rhs       E16,35                          1
    rhs       E16,37                          1
    rhs       E16,38                          1
    rhs       E16,39                          1
    rhs       E16,40                          1
    rhs       E16,41                          1
    rhs       E16,42                          1
    rhs       E16,43                          1
    rhs       E16,44                          1
    rhs       E16,45                          1
    rhs       E16,46                          1
    rhs       E16,47                          1
    rhs       E16,48                          1
    rhs       E17,18                          1
    rhs       E17,20                          1
    rhs       E17,22                          1
    rhs       E17,25                          1
    rhs       E17,26                          1
    rhs       E17,27                          1
    rhs       E17,28                          1
    rhs       E17,30                          1
    rhs       E17,32                          1
    rhs       E17,33                          1
    rhs       E17,34                          1
    rhs       E17,38                          1
    rhs       E17,39                          1
    rhs       E17,43                          1
    rhs       E17,46                          1
    rhs       E17,47                          1
    rhs       E17,49                          1
    rhs       E18,19                          1
    rhs       E18,20                          1
    rhs       E18,21                          1
    rhs       E18,22                          1
    rhs       E18,23                          1
    rhs       E18,24                          1
    rhs       E18,25                          1
    rhs       E18,27                          1
    rhs       E18,28                          1
    rhs       E18,30                          1
    rhs       E18,31                          1
    rhs       E18,34                          1
    rhs       E18,35                          1
    rhs       E18,36                          1
    rhs       E18,37                          1
    rhs       E18,38                          1
    rhs       E18,40                          1
    rhs       E18,41                          1
    rhs       E18,42                          1
    rhs       E18,43                          1
    rhs       E18,45                          1
    rhs       E18,46                          1
    rhs       E18,47                          1
    rhs       E18,48                          1
    rhs       E19,20                          1
    rhs       E19,22                          1
    rhs       E19,23                          1
    rhs       E19,24                          1
    rhs       E19,25                          1
    rhs       E19,26                          1
    rhs       E19,28                          1
    rhs       E19,29                          1
    rhs       E19,31                          1
    rhs       E19,34                          1
    rhs       E19,37                          1
    rhs       E19,39                          1
    rhs       E19,40                          1
    rhs       E19,41                          1
    rhs       E19,45                          1
    rhs       E19,46                          1
    rhs       E19,47                          1
    rhs       E19,48                          1
    rhs       E19,49                          1
    rhs       E20,22                          1
    rhs       E20,23                          1
    rhs       E20,25                          1
    rhs       E20,28                          1
    rhs       E20,29                          1
    rhs       E20,30                          1
    rhs       E20,31                          1
    rhs       E20,32                          1
    rhs       E20,34                          1
    rhs       E20,35                          1
    rhs       E20,36                          1
    rhs       E20,37                          1
    rhs       E20,38                          1
    rhs       E20,40                          1
    rhs       E20,41                          1
    rhs       E20,42                          1
    rhs       E20,45                          1
    rhs       E20,46                          1
    rhs       E20,48                          1
    rhs       E20,49                          1
    rhs       E21,22                          1
    rhs       E21,24                          1
    rhs       E21,25                          1
    rhs       E21,26                          1
    rhs       E21,27                          1
    rhs       E21,28                          1
    rhs       E21,29                          1
    rhs       E21,30                          1
    rhs       E21,31                          1
    rhs       E21,32                          1
    rhs       E21,33                          1
    rhs       E21,37                          1
    rhs       E21,39                          1
    rhs       E21,41                          1
    rhs       E21,43                          1
    rhs       E21,45                          1
    rhs       E21,47                          1
    rhs       E21,48                          1
    rhs       E21,49                          1
    rhs       E22,23                          1
    rhs       E22,25                          1
    rhs       E22,27                          1
    rhs       E22,30                          1
    rhs       E22,33                          1
    rhs       E22,36                          1
    rhs       E22,38                          1
    rhs       E22,39                          1
    rhs       E22,40                          1
    rhs       E22,41                          1
    rhs       E22,42                          1
    rhs       E22,43                          1
    rhs       E22,44                          1
    rhs       E22,45                          1
    rhs       E22,46                          1
    rhs       E22,49                          1
    rhs       E23,24                          1
    rhs       E23,25                          1
    rhs       E23,26                          1
    rhs       E23,27                          1
    rhs       E23,28                          1
    rhs       E23,29                          1
    rhs       E23,32                          1
    rhs       E23,34                          1
    rhs       E23,35                          1
    rhs       E23,36                          1
    rhs       E23,37                          1
    rhs       E23,38                          1
    rhs       E23,39                          1
    rhs       E23,42                          1
    rhs       E23,44                          1
    rhs       E23,45                          1
    rhs       E23,46                          1
    rhs       E23,48                          1
    rhs       E23,49                          1
    rhs       E24,26                          1
    rhs       E24,28                          1
    rhs       E24,29                          1
    rhs       E24,30                          1
    rhs       E24,31                          1
    rhs       E24,32                          1
    rhs       E24,33                          1
    rhs       E24,36                          1
    rhs       E24,38                          1
    rhs       E24,39                          1
    rhs       E24,40                          1
    rhs       E24,42                          1
    rhs       E24,43                          1
    rhs       E24,44                          1
    rhs       E24,46                          1
    rhs       E24,47                          1
    rhs       E24,48                          1
    rhs       E25,26                          1
    rhs       E25,28                          1
    rhs       E25,29                          1
    rhs       E25,30                          1
    rhs       E25,31                          1
    rhs       E25,37                          1
    rhs       E25,38                          1
    rhs       E25,39                          1
    rhs       E25,43                          1
    rhs       E25,44                          1
    rhs       E25,45                          1
    rhs       E25,46                          1
    rhs       E25,47                          1
    rhs       E26,28                          1
    rhs       E26,29                          1
    rhs       E26,30                          1
    rhs       E26,31                          1
    rhs       E26,34                          1
    rhs       E26,37                          1
    rhs       E26,38                          1
    rhs       E26,42                          1
    rhs       E26,43                          1
    rhs       E26,44                          1
    rhs       E26,45                          1
    rhs       E26,47                          1
    rhs       E26,48                          1
    rhs       E26,49                          1
    rhs       E27,28                          1
    rhs       E27,29                          1
    rhs       E27,30                          1
    rhs       E27,32                          1
    rhs       E27,33                          1
    rhs       E27,34                          1
    rhs       E27,35                          1
    rhs       E27,40                          1
    rhs       E27,41                          1
    rhs       E27,42                          1
    rhs       E27,43                          1
    rhs       E27,44                          1
    rhs       E27,45                          1
    rhs       E27,47                          1
    rhs       E27,49                          1
    rhs       E28,29                          1
    rhs       E28,31                          1
    rhs       E28,32                          1
    rhs       E28,33                          1
    rhs       E28,34                          1
    rhs       E28,36                          1
    rhs       E28,39                          1
    rhs       E28,40                          1
    rhs       E28,41                          1
    rhs       E28,43                          1
    rhs       E28,44                          1
    rhs       E28,45                          1
    rhs       E28,46                          1
    rhs       E28,47                          1
    rhs       E28,49                          1
    rhs       E29,30                          1
    rhs       E29,31                          1
    rhs       E29,32                          1
    rhs       E29,34                          1
    rhs       E29,36                          1
    rhs       E29,37                          1
    rhs       E29,38                          1
    rhs       E29,39                          1
    rhs       E29,41                          1
    rhs       E29,42                          1
    rhs       E29,43                          1
    rhs       E29,46                          1
    rhs       E29,47                          1
    rhs       E29,48                          1
    rhs       E29,49                          1
    rhs       E30,31                          1
    rhs       E30,33                          1
    rhs       E30,34                          1
    rhs       E30,36                          1
    rhs       E30,37                          1
    rhs       E30,38                          1
    rhs       E30,40                          1
    rhs       E30,41                          1
    rhs       E30,42                          1
    rhs       E30,43                          1
    rhs       E30,46                          1
    rhs       E30,47                          1
    rhs       E30,48                          1
    rhs       E31,32                          1
    rhs       E31,33                          1
    rhs       E31,35                          1
    rhs       E31,38                          1
    rhs       E31,39                          1
    rhs       E31,41                          1
    rhs       E31,42                          1
    rhs       E31,43                          1
    rhs       E31,45                          1
    rhs       E31,48                          1
    rhs       E31,49                          1
    rhs       E32,33                          1
    rhs       E32,34                          1
    rhs       E32,35                          1
    rhs       E32,37                          1
    rhs       E32,38                          1
    rhs       E32,39                          1
    rhs       E32,40                          1
    rhs       E32,41                          1
    rhs       E32,42                          1
    rhs       E32,43                          1
    rhs       E32,44                          1
    rhs       E32,45                          1
    rhs       E32,46                          1
    rhs       E32,47                          1
    rhs       E32,48                          1
    rhs       E33,34                          1
    rhs       E33,35                          1
    rhs       E33,36                          1
    rhs       E33,37                          1
    rhs       E33,38                          1
    rhs       E33,40                          1
    rhs       E33,41                          1
    rhs       E33,43                          1
    rhs       E33,44                          1
    rhs       E33,45                          1
    rhs       E33,46                          1
    rhs       E33,47                          1
    rhs       E33,48                          1
    rhs       E33,49                          1
    rhs       E34,35                          1
    rhs       E34,37                          1
    rhs       E34,38                          1
    rhs       E34,39                          1
    rhs       E34,40                          1
    rhs       E34,41                          1
    rhs       E34,42                          1
    rhs       E34,43                          1
    rhs       E34,45                          1
    rhs       E34,47                          1
    rhs       E35,36                          1
    rhs       E35,38                          1
    rhs       E35,39                          1
    rhs       E35,41                          1
    rhs       E35,42                          1
    rhs       E35,44                          1
    rhs       E35,45                          1
    rhs       E35,46                          1
    rhs       E35,47                          1
    rhs       E35,48                          1
    rhs       E35,49                          1
    rhs       E36,38                          1
    rhs       E36,39                          1
    rhs       E36,41                          1
    rhs       E36,43                          1
    rhs       E36,44                          1
    rhs       E36,45                          1
    rhs       E36,47                          1
    rhs       E36,48                          1
    rhs       E37,38                          1
    rhs       E37,39                          1
    rhs       E37,41                          1
    rhs       E37,42                          1
    rhs       E37,43                          1
    rhs       E37,44                          1
    rhs       E37,45                          1
    rhs       E37,46                          1
    rhs       E37,47                          1
    rhs       E37,49                          1
    rhs       E38,41                          1
    rhs       E38,42                          1
    rhs       E38,43                          1
    rhs       E38,45                          1
    rhs       E38,46                          1
    rhs       E38,47                          1
    rhs       E38,48                          1
    rhs       E38,49                          1
    rhs       E39,40                          1
    rhs       E39,41                          1
    rhs       E39,42                          1
    rhs       E39,43                          1
    rhs       E39,44                          1
    rhs       E39,45                          1
    rhs       E39,46                          1
    rhs       E39,47                          1
    rhs       E40,44                          1
    rhs       E40,45                          1
    rhs       E40,47                          1
    rhs       E40,48                          1
    rhs       E40,49                          1
    rhs       E41,43                          1
    rhs       E41,45                          1
    rhs       E41,46                          1
    rhs       E41,47                          1
    rhs       E41,48                          1
    rhs       E41,49                          1
    rhs       E42,44                          1
    rhs       E42,47                          1
    rhs       E42,48                          1
    rhs       E42,49                          1
    rhs       E43,44                          1
    rhs       E43,45                          1
    rhs       E43,49                          1
    rhs       E44,45                          1
    rhs       E44,47                          1
    rhs       E44,48                          1
    rhs       E45,47                          1
    rhs       E45,49                          1
    rhs       E46,48                          1
    rhs       E46,49                          1
    rhs       E47,48                          1
    rhs       E48,49                          1
    rhs       I0,1                            1
    rhs       I0,2                            1
    rhs       I0,3                            1
    rhs       I0,5                            1
    rhs       I0,6                            1
    rhs       I0,7                            1
    rhs       I0,8                            1
    rhs       I0,9                            1
    rhs       I0,10                           1
    rhs       I0,11                           1
    rhs       I0,13                           1
    rhs       I0,14                           1
    rhs       I0,15                           1
    rhs       I0,16                           1
    rhs       I0,17                           1
    rhs       I0,18                           1
    rhs       I0,19                           1
    rhs       I0,20                           1
    rhs       I0,22                           1
    rhs       I0,23                           1
    rhs       I0,25                           1
    rhs       I0,26                           1
    rhs       I0,31                           1
    rhs       I0,32                           1
    rhs       I0,33                           1
    rhs       I0,34                           1
    rhs       I0,38                           1
    rhs       I0,40                           1
    rhs       I0,43                           1
    rhs       I0,44                           1
    rhs       I0,45                           1
    rhs       I0,46                           1
    rhs       I0,47                           1
    rhs       I0,48                           1
    rhs       I1,2                            1
    rhs       I1,3                            1
    rhs       I1,5                            1
    rhs       I1,6                            1
    rhs       I1,8                            1
    rhs       I1,9                            1
    rhs       I1,10                           1
    rhs       I1,11                           1
    rhs       I1,12                           1
    rhs       I1,14                           1
    rhs       I1,15                           1
    rhs       I1,16                           1
    rhs       I1,17                           1
    rhs       I1,18                           1
    rhs       I1,19                           1
    rhs       I1,20                           1
    rhs       I1,21                           1
    rhs       I1,22                           1
    rhs       I1,24                           1
    rhs       I1,26                           1
    rhs       I1,27                           1
    rhs       I1,29                           1
    rhs       I1,31                           1
    rhs       I1,32                           1
    rhs       I1,34                           1
    rhs       I1,35                           1
    rhs       I1,37                           1
    rhs       I1,38                           1
    rhs       I1,40                           1
    rhs       I1,41                           1
    rhs       I1,42                           1
    rhs       I1,43                           1
    rhs       I1,44                           1
    rhs       I1,45                           1
    rhs       I1,46                           1
    rhs       I1,48                           1
    rhs       I1,49                           1
    rhs       I2,4                            1
    rhs       I2,5                            1
    rhs       I2,7                            1
    rhs       I2,9                            1
    rhs       I2,10                           1
    rhs       I2,11                           1
    rhs       I2,12                           1
    rhs       I2,14                           1
    rhs       I2,18                           1
    rhs       I2,19                           1
    rhs       I2,20                           1
    rhs       I2,21                           1
    rhs       I2,22                           1
    rhs       I2,27                           1
    rhs       I2,28                           1
    rhs       I2,30                           1
    rhs       I2,31                           1
    rhs       I2,32                           1
    rhs       I2,33                           1
    rhs       I2,34                           1
    rhs       I2,35                           1
    rhs       I2,39                           1
    rhs       I2,40                           1
    rhs       I2,41                           1
    rhs       I2,42                           1
    rhs       I2,44                           1
    rhs       I2,45                           1
    rhs       I2,47                           1
    rhs       I2,49                           1
    rhs       I3,5                            1
    rhs       I3,6                            1
    rhs       I3,8                            1
    rhs       I3,9                            1
    rhs       I3,14                           1
    rhs       I3,17                           1
    rhs       I3,19                           1
    rhs       I3,20                           1
    rhs       I3,21                           1
    rhs       I3,22                           1
    rhs       I3,23                           1
    rhs       I3,24                           1
    rhs       I3,25                           1
    rhs       I3,26                           1
    rhs       I3,27                           1
    rhs       I3,33                           1
    rhs       I3,34                           1
    rhs       I3,35                           1
    rhs       I3,37                           1
    rhs       I3,38                           1
    rhs       I3,39                           1
    rhs       I3,40                           1
    rhs       I3,41                           1
    rhs       I3,42                           1
    rhs       I3,43                           1
    rhs       I3,44                           1
    rhs       I3,45                           1
    rhs       I3,47                           1
    rhs       I3,49                           1
    rhs       I4,5                            1
    rhs       I4,6                            1
    rhs       I4,8                            1
    rhs       I4,9                            1
    rhs       I4,11                           1
    rhs       I4,13                           1
    rhs       I4,15                           1
    rhs       I4,16                           1
    rhs       I4,18                           1
    rhs       I4,20                           1
    rhs       I4,22                           1
    rhs       I4,25                           1
    rhs       I4,26                           1
    rhs       I4,28                           1
    rhs       I4,29                           1
    rhs       I4,30                           1
    rhs       I4,31                           1
    rhs       I4,32                           1
    rhs       I4,33                           1
    rhs       I4,34                           1
    rhs       I4,37                           1
    rhs       I4,38                           1
    rhs       I4,39                           1
    rhs       I4,40                           1
    rhs       I4,41                           1
    rhs       I4,43                           1
    rhs       I4,45                           1
    rhs       I4,46                           1
    rhs       I4,47                           1
    rhs       I4,49                           1
    rhs       I5,6                            1
    rhs       I5,7                            1
    rhs       I5,8                            1
    rhs       I5,10                           1
    rhs       I5,11                           1
    rhs       I5,12                           1
    rhs       I5,16                           1
    rhs       I5,18                           1
    rhs       I5,19                           1
    rhs       I5,20                           1
    rhs       I5,21                           1
    rhs       I5,22                           1
    rhs       I5,23                           1
    rhs       I5,24                           1
    rhs       I5,25                           1
    rhs       I5,26                           1
    rhs       I5,27                           1
    rhs       I5,28                           1
    rhs       I5,29                           1
    rhs       I5,30                           1
    rhs       I5,31                           1
    rhs       I5,32                           1
    rhs       I5,33                           1
    rhs       I5,34                           1
    rhs       I5,35                           1
    rhs       I5,36                           1
    rhs       I5,37                           1
    rhs       I5,39                           1
    rhs       I5,40                           1
    rhs       I5,41                           1
    rhs       I5,42                           1
    rhs       I5,43                           1
    rhs       I5,45                           1
    rhs       I5,47                           1
    rhs       I5,49                           1
    rhs       I6,8                            1
    rhs       I6,10                           1
    rhs       I6,12                           1
    rhs       I6,13                           1
    rhs       I6,15                           1
    rhs       I6,17                           1
    rhs       I6,18                           1
    rhs       I6,19                           1
    rhs       I6,20                           1
    rhs       I6,22                           1
    rhs       I6,23                           1
    rhs       I6,24                           1
    rhs       I6,25                           1
    rhs       I6,27                           1
    rhs       I6,28                           1
    rhs       I6,29                           1
    rhs       I6,30                           1
    rhs       I6,33                           1
    rhs       I6,34                           1
    rhs       I6,38                           1
    rhs       I6,39                           1
    rhs       I6,40                           1
    rhs       I6,41                           1
    rhs       I6,42                           1
    rhs       I6,43                           1
    rhs       I6,44                           1
    rhs       I6,45                           1
    rhs       I6,46                           1
    rhs       I6,47                           1
    rhs       I6,48                           1
    rhs       I6,49                           1
    rhs       I7,8                            1
    rhs       I7,10                           1
    rhs       I7,12                           1
    rhs       I7,14                           1
    rhs       I7,16                           1
    rhs       I7,17                           1
    rhs       I7,18                           1
    rhs       I7,19                           1
    rhs       I7,20                           1
    rhs       I7,21                           1
    rhs       I7,23                           1
    rhs       I7,24                           1
    rhs       I7,27                           1
    rhs       I7,28                           1
    rhs       I7,29                           1
    rhs       I7,30                           1
    rhs       I7,31                           1
    rhs       I7,32                           1
    rhs       I7,33                           1
    rhs       I7,35                           1
    rhs       I7,37                           1
    rhs       I7,39                           1
    rhs       I7,41                           1
    rhs       I7,42                           1
    rhs       I7,44                           1
    rhs       I7,45                           1
    rhs       I7,47                           1
    rhs       I7,48                           1
    rhs       I7,49                           1
    rhs       I8,9                            1
    rhs       I8,10                           1
    rhs       I8,12                           1
    rhs       I8,13                           1
    rhs       I8,15                           1
    rhs       I8,17                           1
    rhs       I8,18                           1
    rhs       I8,19                           1
    rhs       I8,20                           1
    rhs       I8,24                           1
    rhs       I8,26                           1
    rhs       I8,27                           1
    rhs       I8,31                           1
    rhs       I8,32                           1
    rhs       I8,33                           1
    rhs       I8,34                           1
    rhs       I8,35                           1
    rhs       I8,41                           1
    rhs       I8,42                           1
    rhs       I8,43                           1
    rhs       I8,44                           1
    rhs       I8,45                           1
    rhs       I8,46                           1
    rhs       I9,10                           1
    rhs       I9,11                           1
    rhs       I9,12                           1
    rhs       I9,13                           1
    rhs       I9,15                           1
    rhs       I9,16                           1
    rhs       I9,17                           1
    rhs       I9,18                           1
    rhs       I9,19                           1
    rhs       I9,21                           1
    rhs       I9,22                           1
    rhs       I9,23                           1
    rhs       I9,24                           1
    rhs       I9,26                           1
    rhs       I9,27                           1
    rhs       I9,29                           1
    rhs       I9,30                           1
    rhs       I9,32                           1
    rhs       I9,33                           1
    rhs       I9,34                           1
    rhs       I9,35                           1
    rhs       I9,36                           1
    rhs       I9,38                           1
    rhs       I9,40                           1
    rhs       I9,41                           1
    rhs       I9,42                           1
    rhs       I9,43                           1
    rhs       I9,44                           1
    rhs       I9,45                           1
    rhs       I9,46                           1
    rhs       I9,47                           1
    rhs       I9,48                           1
    rhs       I9,49                           1
    rhs       I10,11                          1
    rhs       I10,14                          1
    rhs       I10,15                          1
    rhs       I10,17                          1
    rhs       I10,18                          1
    rhs       I10,19                          1
    rhs       I10,20                          1
    rhs       I10,21                          1
    rhs       I10,22                          1
    rhs       I10,23                          1
    rhs       I10,24                          1
    rhs       I10,25                          1
    rhs       I10,26                          1
    rhs       I10,27                          1
    rhs       I10,29                          1
    rhs       I10,31                          1
    rhs       I10,32                          1
    rhs       I10,33                          1
    rhs       I10,35                          1
    rhs       I10,36                          1
    rhs       I10,37                          1
    rhs       I10,38                          1
    rhs       I10,39                          1
    rhs       I10,40                          1
    rhs       I10,41                          1
    rhs       I10,42                          1
    rhs       I10,43                          1
    rhs       I10,44                          1
    rhs       I10,47                          1
    rhs       I10,48                          1
    rhs       I11,12                          1
    rhs       I11,13                          1
    rhs       I11,14                          1
    rhs       I11,15                          1
    rhs       I11,16                          1
    rhs       I11,17                          1
    rhs       I11,18                          1
    rhs       I11,19                          1
    rhs       I11,21                          1
    rhs       I11,22                          1
    rhs       I11,25                          1
    rhs       I11,26                          1
    rhs       I11,27                          1
    rhs       I11,28                          1
    rhs       I11,29                          1
    rhs       I11,31                          1
    rhs       I11,33                          1
    rhs       I11,34                          1
    rhs       I11,38                          1
    rhs       I11,39                          1
    rhs       I11,40                          1
    rhs       I11,42                          1
    rhs       I11,44                          1
    rhs       I11,46                          1
    rhs       I11,47                          1
    rhs       I11,48                          1
    rhs       I11,49                          1
    rhs       I12,13                          1
    rhs       I12,15                          1
    rhs       I12,17                          1
    rhs       I12,18                          1
    rhs       I12,20                          1
    rhs       I12,21                          1
    rhs       I12,22                          1
    rhs       I12,23                          1
    rhs       I12,24                          1
    rhs       I12,26                          1
    rhs       I12,28                          1
    rhs       I12,29                          1
    rhs       I12,30                          1
    rhs       I12,31                          1
    rhs       I12,32                          1
    rhs       I12,36                          1
    rhs       I12,37                          1
    rhs       I12,39                          1
    rhs       I12,40                          1
    rhs       I12,41                          1
    rhs       I12,43                          1
    rhs       I12,44                          1
    rhs       I12,45                          1
    rhs       I12,48                          1
    rhs       I12,49                          1
    rhs       I13,14                          1
    rhs       I13,15                          1
    rhs       I13,18                          1
    rhs       I13,20                          1
    rhs       I13,23                          1
    rhs       I13,24                          1
    rhs       I13,25                          1
    rhs       I13,26                          1
    rhs       I13,28                          1
    rhs       I13,29                          1
    rhs       I13,30                          1
    rhs       I13,31                          1
    rhs       I13,32                          1
    rhs       I13,35                          1
    rhs       I13,36                          1
    rhs       I13,37                          1
    rhs       I13,38                          1
    rhs       I13,39                          1
    rhs       I13,40                          1
    rhs       I13,41                          1
    rhs       I13,42                          1
    rhs       I13,43                          1
    rhs       I13,45                          1
    rhs       I13,46                          1
    rhs       I13,47                          1
    rhs       I13,48                          1
    rhs       I13,49                          1
    rhs       I14,15                          1
    rhs       I14,16                          1
    rhs       I14,17                          1
    rhs       I14,18                          1
    rhs       I14,19                          1
    rhs       I14,20                          1
    rhs       I14,22                          1
    rhs       I14,23                          1
    rhs       I14,24                          1
    rhs       I14,25                          1
    rhs       I14,27                          1
    rhs       I14,30                          1
    rhs       I14,31                          1
    rhs       I14,32                          1
    rhs       I14,33                          1
    rhs       I14,34                          1
    rhs       I14,35                          1
    rhs       I14,37                          1
    rhs       I14,38                          1
    rhs       I14,42                          1
    rhs       I14,43                          1
    rhs       I14,44                          1
    rhs       I14,45                          1
    rhs       I14,46                          1
    rhs       I14,47                          1
    rhs       I14,48                          1
    rhs       I14,49                          1
    rhs       I15,16                          1
    rhs       I15,17                          1
    rhs       I15,18                          1
    rhs       I15,19                          1
    rhs       I15,21                          1
    rhs       I15,22                          1
    rhs       I15,23                          1
    rhs       I15,24                          1
    rhs       I15,26                          1
    rhs       I15,27                          1
    rhs       I15,29                          1
    rhs       I15,30                          1
    rhs       I15,31                          1
    rhs       I15,32                          1
    rhs       I15,33                          1
    rhs       I15,34                          1
    rhs       I15,36                          1
    rhs       I15,37                          1
    rhs       I15,39                          1
    rhs       I15,40                          1
    rhs       I15,41                          1
    rhs       I15,43                          1
    rhs       I15,44                          1
    rhs       I15,46                          1
    rhs       I15,47                          1
    rhs       I15,48                          1
    rhs       I15,49                          1
    rhs       I16,18                          1
    rhs       I16,20                          1
    rhs       I16,21                          1
    rhs       I16,22                          1
    rhs       I16,23                          1
    rhs       I16,24                          1
    rhs       I16,27                          1
    rhs       I16,28                          1
    rhs       I16,29                          1
    rhs       I16,30                          1
    rhs       I16,32                          1
    rhs       I16,33                          1
    rhs       I16,34                          1
    rhs       I16,35                          1
    rhs       I16,37                          1
    rhs       I16,38                          1
    rhs       I16,39                          1
    rhs       I16,40                          1
    rhs       I16,41                          1
    rhs       I16,42                          1
    rhs       I16,43                          1
    rhs       I16,44                          1
    rhs       I16,45                          1
    rhs       I16,46                          1
    rhs       I16,47                          1
    rhs       I16,48                          1
    rhs       I17,18                          1
    rhs       I17,20                          1
    rhs       I17,22                          1
    rhs       I17,25                          1
    rhs       I17,26                          1
    rhs       I17,27                          1
    rhs       I17,28                          1
    rhs       I17,30                          1
    rhs       I17,32                          1
    rhs       I17,33                          1
    rhs       I17,34                          1
    rhs       I17,38                          1
    rhs       I17,39                          1
    rhs       I17,43                          1
    rhs       I17,46                          1
    rhs       I17,47                          1
    rhs       I17,49                          1
    rhs       I18,19                          1
    rhs       I18,20                          1
    rhs       I18,21                          1
    rhs       I18,22                          1
    rhs       I18,23                          1
    rhs       I18,24                          1
    rhs       I18,25                          1
    rhs       I18,27                          1
    rhs       I18,28                          1
    rhs       I18,30                          1
    rhs       I18,31                          1
    rhs       I18,34                          1
    rhs       I18,35                          1
    rhs       I18,36                          1
    rhs       I18,37                          1
    rhs       I18,38                          1
    rhs       I18,40                          1
    rhs       I18,41                          1
    rhs       I18,42                          1
    rhs       I18,43                          1
    rhs       I18,45                          1
    rhs       I18,46                          1
    rhs       I18,47                          1
    rhs       I18,48                          1
    rhs       I19,20                          1
    rhs       I19,22                          1
    rhs       I19,23                          1
    rhs       I19,24                          1
    rhs       I19,25                          1
    rhs       I19,26                          1
    rhs       I19,28                          1
    rhs       I19,29                          1
    rhs       I19,31                          1
    rhs       I19,34                          1
    rhs       I19,37                          1
    rhs       I19,39                          1
    rhs       I19,40                          1
    rhs       I19,41                          1
    rhs       I19,45                          1
    rhs       I19,46                          1
    rhs       I19,47                          1
    rhs       I19,48                          1
    rhs       I19,49                          1
    rhs       I20,22                          1
    rhs       I20,23                          1
    rhs       I20,25                          1
    rhs       I20,28                          1
    rhs       I20,29                          1
    rhs       I20,30                          1
    rhs       I20,31                          1
    rhs       I20,32                          1
    rhs       I20,34                          1
    rhs       I20,35                          1
    rhs       I20,36                          1
    rhs       I20,37                          1
    rhs       I20,38                          1
    rhs       I20,40                          1
    rhs       I20,41                          1
    rhs       I20,42                          1
    rhs       I20,45                          1
    rhs       I20,46                          1
    rhs       I20,48                          1
    rhs       I20,49                          1
    rhs       I21,22                          1
    rhs       I21,24                          1
    rhs       I21,25                          1
    rhs       I21,26                          1
    rhs       I21,27                          1
    rhs       I21,28                          1
    rhs       I21,29                          1
    rhs       I21,30                          1
    rhs       I21,31                          1
    rhs       I21,32                          1
    rhs       I21,33                          1
    rhs       I21,37                          1
    rhs       I21,39                          1
    rhs       I21,41                          1
    rhs       I21,43                          1
    rhs       I21,45                          1
    rhs       I21,47                          1
    rhs       I21,48                          1
    rhs       I21,49                          1
    rhs       I22,23                          1
    rhs       I22,25                          1
    rhs       I22,27                          1
    rhs       I22,30                          1
    rhs       I22,33                          1
    rhs       I22,36                          1
    rhs       I22,38                          1
    rhs       I22,39                          1
    rhs       I22,40                          1
    rhs       I22,41                          1
    rhs       I22,42                          1
    rhs       I22,43                          1
    rhs       I22,44                          1
    rhs       I22,45                          1
    rhs       I22,46                          1
    rhs       I22,49                          1
    rhs       I23,24                          1
    rhs       I23,25                          1
    rhs       I23,26                          1
    rhs       I23,27                          1
    rhs       I23,28                          1
    rhs       I23,29                          1
    rhs       I23,32                          1
    rhs       I23,34                          1
    rhs       I23,35                          1
    rhs       I23,36                          1
    rhs       I23,37                          1
    rhs       I23,38                          1
    rhs       I23,39                          1
    rhs       I23,42                          1
    rhs       I23,44                          1
    rhs       I23,45                          1
    rhs       I23,46                          1
    rhs       I23,48                          1
    rhs       I23,49                          1
    rhs       I24,26                          1
    rhs       I24,28                          1
    rhs       I24,29                          1
    rhs       I24,30                          1
    rhs       I24,31                          1
    rhs       I24,32                          1
    rhs       I24,33                          1
    rhs       I24,36                          1
    rhs       I24,38                          1
    rhs       I24,39                          1
    rhs       I24,40                          1
    rhs       I24,42                          1
    rhs       I24,43                          1
    rhs       I24,44                          1
    rhs       I24,46                          1
    rhs       I24,47                          1
    rhs       I24,48                          1
    rhs       I25,26                          1
    rhs       I25,28                          1
    rhs       I25,29                          1
    rhs       I25,30                          1
    rhs       I25,31                          1
    rhs       I25,37                          1
    rhs       I25,38                          1
    rhs       I25,39                          1
    rhs       I25,43                          1
    rhs       I25,44                          1
    rhs       I25,45                          1
    rhs       I25,46                          1
    rhs       I25,47                          1
    rhs       I26,28                          1
    rhs       I26,29                          1
    rhs       I26,30                          1
    rhs       I26,31                          1
    rhs       I26,34                          1
    rhs       I26,37                          1
    rhs       I26,38                          1
    rhs       I26,42                          1
    rhs       I26,43                          1
    rhs       I26,44                          1
    rhs       I26,45                          1
    rhs       I26,47                          1
    rhs       I26,48                          1
    rhs       I26,49                          1
    rhs       I27,28                          1
    rhs       I27,29                          1
    rhs       I27,30                          1
    rhs       I27,32                          1
    rhs       I27,33                          1
    rhs       I27,34                          1
    rhs       I27,35                          1
    rhs       I27,40                          1
    rhs       I27,41                          1
    rhs       I27,42                          1
    rhs       I27,43                          1
    rhs       I27,44                          1
    rhs       I27,45                          1
    rhs       I27,47                          1
    rhs       I27,49                          1
    rhs       I28,29                          1
    rhs       I28,31                          1
    rhs       I28,32                          1
    rhs       I28,33                          1
    rhs       I28,34                          1
    rhs       I28,36                          1
    rhs       I28,39                          1
    rhs       I28,40                          1
    rhs       I28,41                          1
    rhs       I28,43                          1
    rhs       I28,44                          1
    rhs       I28,45                          1
    rhs       I28,46                          1
    rhs       I28,47                          1
    rhs       I28,49                          1
    rhs       I29,30                          1
    rhs       I29,31                          1
    rhs       I29,32                          1
    rhs       I29,34                          1
    rhs       I29,36                          1
    rhs       I29,37                          1
    rhs       I29,38                          1
    rhs       I29,39                          1
    rhs       I29,41                          1
    rhs       I29,42                          1
    rhs       I29,43                          1
    rhs       I29,46                          1
    rhs       I29,47                          1
    rhs       I29,48                          1
    rhs       I29,49                          1
    rhs       I30,31                          1
    rhs       I30,33                          1
    rhs       I30,34                          1
    rhs       I30,36                          1
    rhs       I30,37                          1
    rhs       I30,38                          1
    rhs       I30,40                          1
    rhs       I30,41                          1
    rhs       I30,42                          1
    rhs       I30,43                          1
    rhs       I30,46                          1
    rhs       I30,47                          1
    rhs       I30,48                          1
    rhs       I31,32                          1
    rhs       I31,33                          1
    rhs       I31,35                          1
    rhs       I31,38                          1
    rhs       I31,39                          1
    rhs       I31,41                          1
    rhs       I31,42                          1
    rhs       I31,43                          1
    rhs       I31,45                          1
    rhs       I31,48                          1
    rhs       I31,49                          1
    rhs       I32,33                          1
    rhs       I32,34                          1
    rhs       I32,35                          1
    rhs       I32,37                          1
    rhs       I32,38                          1
    rhs       I32,39                          1
    rhs       I32,40                          1
    rhs       I32,41                          1
    rhs       I32,42                          1
    rhs       I32,43                          1
    rhs       I32,44                          1
    rhs       I32,45                          1
    rhs       I32,46                          1
    rhs       I32,47                          1
    rhs       I32,48                          1
    rhs       I33,34                          1
    rhs       I33,35                          1
    rhs       I33,36                          1
    rhs       I33,37                          1
    rhs       I33,38                          1
    rhs       I33,40                          1
    rhs       I33,41                          1
    rhs       I33,43                          1
    rhs       I33,44                          1
    rhs       I33,45                          1
    rhs       I33,46                          1
    rhs       I33,47                          1
    rhs       I33,48                          1
    rhs       I33,49                          1
    rhs       I34,35                          1
    rhs       I34,37                          1
    rhs       I34,38                          1
    rhs       I34,39                          1
    rhs       I34,40                          1
    rhs       I34,41                          1
    rhs       I34,42                          1
    rhs       I34,43                          1
    rhs       I34,45                          1
    rhs       I34,47                          1
    rhs       I35,36                          1
    rhs       I35,38                          1
    rhs       I35,39                          1
    rhs       I35,41                          1
    rhs       I35,42                          1
    rhs       I35,44                          1
    rhs       I35,45                          1
    rhs       I35,46                          1
    rhs       I35,47                          1
    rhs       I35,48                          1
    rhs       I35,49                          1
    rhs       I36,38                          1
    rhs       I36,39                          1
    rhs       I36,41                          1
    rhs       I36,43                          1
    rhs       I36,44                          1
    rhs       I36,45                          1
    rhs       I36,47                          1
    rhs       I36,48                          1
    rhs       I37,38                          1
    rhs       I37,39                          1
    rhs       I37,41                          1
    rhs       I37,42                          1
    rhs       I37,43                          1
    rhs       I37,44                          1
    rhs       I37,45                          1
    rhs       I37,46                          1
    rhs       I37,47                          1
    rhs       I37,49                          1
    rhs       I38,41                          1
    rhs       I38,42                          1
    rhs       I38,43                          1
    rhs       I38,45                          1
    rhs       I38,46                          1
    rhs       I38,47                          1
    rhs       I38,48                          1
    rhs       I38,49                          1
    rhs       I39,40                          1
    rhs       I39,41                          1
    rhs       I39,42                          1
    rhs       I39,43                          1
    rhs       I39,44                          1
    rhs       I39,45                          1
    rhs       I39,46                          1
    rhs       I39,47                          1
    rhs       I40,44                          1
    rhs       I40,45                          1
    rhs       I40,47                          1
    rhs       I40,48                          1
    rhs       I40,49                          1
    rhs       I41,43                          1
    rhs       I41,45                          1
    rhs       I41,46                          1
    rhs       I41,47                          1
    rhs       I41,48                          1
    rhs       I41,49                          1
    rhs       I42,44                          1
    rhs       I42,47                          1
    rhs       I42,48                          1
    rhs       I42,49                          1
    rhs       I43,44                          1
    rhs       I43,45                          1
    rhs       I43,49                          1
    rhs       I44,45                          1
    rhs       I44,47                          1
    rhs       I44,48                          1
    rhs       I45,47                          1
    rhs       I45,49                          1
    rhs       I46,48                          1
    rhs       I46,49                          1
    rhs       I47,48                          1
    rhs       I48,49                          1
BOUNDS
 BV bnd       w0,1    
 BV bnd       w0,2    
 BV bnd       w0,3    
 BV bnd       w0,5    
 BV bnd       w0,6    
 BV bnd       w0,7    
 BV bnd       w0,8    
 BV bnd       w0,9    
 BV bnd       w0,10   
 BV bnd       w0,11   
 BV bnd       w0,13   
 BV bnd       w0,14   
 BV bnd       w0,15   
 BV bnd       w0,16   
 BV bnd       w0,17   
 BV bnd       w0,18   
 BV bnd       w0,19   
 BV bnd       w0,20   
 BV bnd       w0,22   
 BV bnd       w0,23   
 BV bnd       w0,25   
 BV bnd       w0,26   
 BV bnd       w0,31   
 BV bnd       w0,32   
 BV bnd       w0,33   
 BV bnd       w0,34   
 BV bnd       w0,38   
 BV bnd       w0,40   
 BV bnd       w0,43   
 BV bnd       w0,44   
 BV bnd       w0,45   
 BV bnd       w0,46   
 BV bnd       w0,47   
 BV bnd       w0,48   
 BV bnd       w1,2    
 BV bnd       w1,3    
 BV bnd       w1,5    
 BV bnd       w1,6    
 BV bnd       w1,8    
 BV bnd       w1,9    
 BV bnd       w1,10   
 BV bnd       w1,11   
 BV bnd       w1,12   
 BV bnd       w1,14   
 BV bnd       w1,15   
 BV bnd       w1,16   
 BV bnd       w1,17   
 BV bnd       w1,18   
 BV bnd       w1,19   
 BV bnd       w1,20   
 BV bnd       w1,21   
 BV bnd       w1,22   
 BV bnd       w1,24   
 BV bnd       w1,26   
 BV bnd       w1,27   
 BV bnd       w1,29   
 BV bnd       w1,31   
 BV bnd       w1,32   
 BV bnd       w1,34   
 BV bnd       w1,35   
 BV bnd       w1,37   
 BV bnd       w1,38   
 BV bnd       w1,40   
 BV bnd       w1,41   
 BV bnd       w1,42   
 BV bnd       w1,43   
 BV bnd       w1,44   
 BV bnd       w1,45   
 BV bnd       w1,46   
 BV bnd       w1,48   
 BV bnd       w1,49   
 BV bnd       w2,4    
 BV bnd       w2,5    
 BV bnd       w2,7    
 BV bnd       w2,9    
 BV bnd       w2,10   
 BV bnd       w2,11   
 BV bnd       w2,12   
 BV bnd       w2,14   
 BV bnd       w2,18   
 BV bnd       w2,19   
 BV bnd       w2,20   
 BV bnd       w2,21   
 BV bnd       w2,22   
 BV bnd       w2,27   
 BV bnd       w2,28   
 BV bnd       w2,30   
 BV bnd       w2,31   
 BV bnd       w2,32   
 BV bnd       w2,33   
 BV bnd       w2,34   
 BV bnd       w2,35   
 BV bnd       w2,39   
 BV bnd       w2,40   
 BV bnd       w2,41   
 BV bnd       w2,42   
 BV bnd       w2,44   
 BV bnd       w2,45   
 BV bnd       w2,47   
 BV bnd       w2,49   
 BV bnd       w3,5    
 BV bnd       w3,6    
 BV bnd       w3,8    
 BV bnd       w3,9    
 BV bnd       w3,14   
 BV bnd       w3,17   
 BV bnd       w3,19   
 BV bnd       w3,20   
 BV bnd       w3,21   
 BV bnd       w3,22   
 BV bnd       w3,23   
 BV bnd       w3,24   
 BV bnd       w3,25   
 BV bnd       w3,26   
 BV bnd       w3,27   
 BV bnd       w3,33   
 BV bnd       w3,34   
 BV bnd       w3,35   
 BV bnd       w3,37   
 BV bnd       w3,38   
 BV bnd       w3,39   
 BV bnd       w3,40   
 BV bnd       w3,41   
 BV bnd       w3,42   
 BV bnd       w3,43   
 BV bnd       w3,44   
 BV bnd       w3,45   
 BV bnd       w3,47   
 BV bnd       w3,49   
 BV bnd       w4,5    
 BV bnd       w4,6    
 BV bnd       w4,8    
 BV bnd       w4,9    
 BV bnd       w4,11   
 BV bnd       w4,13   
 BV bnd       w4,15   
 BV bnd       w4,16   
 BV bnd       w4,18   
 BV bnd       w4,20   
 BV bnd       w4,22   
 BV bnd       w4,25   
 BV bnd       w4,26   
 BV bnd       w4,28   
 BV bnd       w4,29   
 BV bnd       w4,30   
 BV bnd       w4,31   
 BV bnd       w4,32   
 BV bnd       w4,33   
 BV bnd       w4,34   
 BV bnd       w4,37   
 BV bnd       w4,38   
 BV bnd       w4,39   
 BV bnd       w4,40   
 BV bnd       w4,41   
 BV bnd       w4,43   
 BV bnd       w4,45   
 BV bnd       w4,46   
 BV bnd       w4,47   
 BV bnd       w4,49   
 BV bnd       w5,6    
 BV bnd       w5,7    
 BV bnd       w5,8    
 BV bnd       w5,10   
 BV bnd       w5,11   
 BV bnd       w5,12   
 BV bnd       w5,16   
 BV bnd       w5,18   
 BV bnd       w5,19   
 BV bnd       w5,20   
 BV bnd       w5,21   
 BV bnd       w5,22   
 BV bnd       w5,23   
 BV bnd       w5,24   
 BV bnd       w5,25   
 BV bnd       w5,26   
 BV bnd       w5,27   
 BV bnd       w5,28   
 BV bnd       w5,29   
 BV bnd       w5,30   
 BV bnd       w5,31   
 BV bnd       w5,32   
 BV bnd       w5,33   
 BV bnd       w5,34   
 BV bnd       w5,35   
 BV bnd       w5,36   
 BV bnd       w5,37   
 BV bnd       w5,39   
 BV bnd       w5,40   
 BV bnd       w5,41   
 BV bnd       w5,42   
 BV bnd       w5,43   
 BV bnd       w5,45   
 BV bnd       w5,47   
 BV bnd       w5,49   
 BV bnd       w6,8    
 BV bnd       w6,10   
 BV bnd       w6,12   
 BV bnd       w6,13   
 BV bnd       w6,15   
 BV bnd       w6,17   
 BV bnd       w6,18   
 BV bnd       w6,19   
 BV bnd       w6,20   
 BV bnd       w6,22   
 BV bnd       w6,23   
 BV bnd       w6,24   
 BV bnd       w6,25   
 BV bnd       w6,27   
 BV bnd       w6,28   
 BV bnd       w6,29   
 BV bnd       w6,30   
 BV bnd       w6,33   
 BV bnd       w6,34   
 BV bnd       w6,38   
 BV bnd       w6,39   
 BV bnd       w6,40   
 BV bnd       w6,41   
 BV bnd       w6,42   
 BV bnd       w6,43   
 BV bnd       w6,44   
 BV bnd       w6,45   
 BV bnd       w6,46   
 BV bnd       w6,47   
 BV bnd       w6,48   
 BV bnd       w6,49   
 BV bnd       w7,8    
 BV bnd       w7,10   
 BV bnd       w7,12   
 BV bnd       w7,14   
 BV bnd       w7,16   
 BV bnd       w7,17   
 BV bnd       w7,18   
 BV bnd       w7,19   
 BV bnd       w7,20   
 BV bnd       w7,21   
 BV bnd       w7,23   
 BV bnd       w7,24   
 BV bnd       w7,27   
 BV bnd       w7,28   
 BV bnd       w7,29   
 BV bnd       w7,30   
 BV bnd       w7,31   
 BV bnd       w7,32   
 BV bnd       w7,33   
 BV bnd       w7,35   
 BV bnd       w7,37   
 BV bnd       w7,39   
 BV bnd       w7,41   
 BV bnd       w7,42   
 BV bnd       w7,44   
 BV bnd       w7,45   
 BV bnd       w7,47   
 BV bnd       w7,48   
 BV bnd       w7,49   
 BV bnd       w8,9    
 BV bnd       w8,10   
 BV bnd       w8,12   
 BV bnd       w8,13   
 BV bnd       w8,15   
 BV bnd       w8,17   
 BV bnd       w8,18   
 BV bnd       w8,19   
 BV bnd       w8,20   
 BV bnd       w8,24   
 BV bnd       w8,26   
 BV bnd       w8,27   
 BV bnd       w8,31   
 BV bnd       w8,32   
 BV bnd       w8,33   
 BV bnd       w8,34   
 BV bnd       w8,35   
 BV bnd       w8,41   
 BV bnd       w8,42   
 BV bnd       w8,43   
 BV bnd       w8,44   
 BV bnd       w8,45   
 BV bnd       w8,46   
 BV bnd       w9,10   
 BV bnd       w9,11   
 BV bnd       w9,12   
 BV bnd       w9,13   
 BV bnd       w9,15   
 BV bnd       w9,16   
 BV bnd       w9,17   
 BV bnd       w9,18   
 BV bnd       w9,19   
 BV bnd       w9,21   
 BV bnd       w9,22   
 BV bnd       w9,23   
 BV bnd       w9,24   
 BV bnd       w9,26   
 BV bnd       w9,27   
 BV bnd       w9,29   
 BV bnd       w9,30   
 BV bnd       w9,32   
 BV bnd       w9,33   
 BV bnd       w9,34   
 BV bnd       w9,35   
 BV bnd       w9,36   
 BV bnd       w9,38   
 BV bnd       w9,40   
 BV bnd       w9,41   
 BV bnd       w9,42   
 BV bnd       w9,43   
 BV bnd       w9,44   
 BV bnd       w9,45   
 BV bnd       w9,46   
 BV bnd       w9,47   
 BV bnd       w9,48   
 BV bnd       w9,49   
 BV bnd       w10,11  
 BV bnd       w10,14  
 BV bnd       w10,15  
 BV bnd       w10,17  
 BV bnd       w10,18  
 BV bnd       w10,19  
 BV bnd       w10,20  
 BV bnd       w10,21  
 BV bnd       w10,22  
 BV bnd       w10,23  
 BV bnd       w10,24  
 BV bnd       w10,25  
 BV bnd       w10,26  
 BV bnd       w10,27  
 BV bnd       w10,29  
 BV bnd       w10,31  
 BV bnd       w10,32  
 BV bnd       w10,33  
 BV bnd       w10,35  
 BV bnd       w10,36  
 BV bnd       w10,37  
 BV bnd       w10,38  
 BV bnd       w10,39  
 BV bnd       w10,40  
 BV bnd       w10,41  
 BV bnd       w10,42  
 BV bnd       w10,43  
 BV bnd       w10,44  
 BV bnd       w10,47  
 BV bnd       w10,48  
 BV bnd       w11,12  
 BV bnd       w11,13  
 BV bnd       w11,14  
 BV bnd       w11,15  
 BV bnd       w11,16  
 BV bnd       w11,17  
 BV bnd       w11,18  
 BV bnd       w11,19  
 BV bnd       w11,21  
 BV bnd       w11,22  
 BV bnd       w11,25  
 BV bnd       w11,26  
 BV bnd       w11,27  
 BV bnd       w11,28  
 BV bnd       w11,29  
 BV bnd       w11,31  
 BV bnd       w11,33  
 BV bnd       w11,34  
 BV bnd       w11,38  
 BV bnd       w11,39  
 BV bnd       w11,40  
 BV bnd       w11,42  
 BV bnd       w11,44  
 BV bnd       w11,46  
 BV bnd       w11,47  
 BV bnd       w11,48  
 BV bnd       w11,49  
 BV bnd       w12,13  
 BV bnd       w12,15  
 BV bnd       w12,17  
 BV bnd       w12,18  
 BV bnd       w12,20  
 BV bnd       w12,21  
 BV bnd       w12,22  
 BV bnd       w12,23  
 BV bnd       w12,24  
 BV bnd       w12,26  
 BV bnd       w12,28  
 BV bnd       w12,29  
 BV bnd       w12,30  
 BV bnd       w12,31  
 BV bnd       w12,32  
 BV bnd       w12,36  
 BV bnd       w12,37  
 BV bnd       w12,39  
 BV bnd       w12,40  
 BV bnd       w12,41  
 BV bnd       w12,43  
 BV bnd       w12,44  
 BV bnd       w12,45  
 BV bnd       w12,48  
 BV bnd       w12,49  
 BV bnd       w13,14  
 BV bnd       w13,15  
 BV bnd       w13,18  
 BV bnd       w13,20  
 BV bnd       w13,23  
 BV bnd       w13,24  
 BV bnd       w13,25  
 BV bnd       w13,26  
 BV bnd       w13,28  
 BV bnd       w13,29  
 BV bnd       w13,30  
 BV bnd       w13,31  
 BV bnd       w13,32  
 BV bnd       w13,35  
 BV bnd       w13,36  
 BV bnd       w13,37  
 BV bnd       w13,38  
 BV bnd       w13,39  
 BV bnd       w13,40  
 BV bnd       w13,41  
 BV bnd       w13,42  
 BV bnd       w13,43  
 BV bnd       w13,45  
 BV bnd       w13,46  
 BV bnd       w13,47  
 BV bnd       w13,48  
 BV bnd       w13,49  
 BV bnd       w14,15  
 BV bnd       w14,16  
 BV bnd       w14,17  
 BV bnd       w14,18  
 BV bnd       w14,19  
 BV bnd       w14,20  
 BV bnd       w14,22  
 BV bnd       w14,23  
 BV bnd       w14,24  
 BV bnd       w14,25  
 BV bnd       w14,27  
 BV bnd       w14,30  
 BV bnd       w14,31  
 BV bnd       w14,32  
 BV bnd       w14,33  
 BV bnd       w14,34  
 BV bnd       w14,35  
 BV bnd       w14,37  
 BV bnd       w14,38  
 BV bnd       w14,42  
 BV bnd       w14,43  
 BV bnd       w14,44  
 BV bnd       w14,45  
 BV bnd       w14,46  
 BV bnd       w14,47  
 BV bnd       w14,48  
 BV bnd       w14,49  
 BV bnd       w15,16  
 BV bnd       w15,17  
 BV bnd       w15,18  
 BV bnd       w15,19  
 BV bnd       w15,21  
 BV bnd       w15,22  
 BV bnd       w15,23  
 BV bnd       w15,24  
 BV bnd       w15,26  
 BV bnd       w15,27  
 BV bnd       w15,29  
 BV bnd       w15,30  
 BV bnd       w15,31  
 BV bnd       w15,32  
 BV bnd       w15,33  
 BV bnd       w15,34  
 BV bnd       w15,36  
 BV bnd       w15,37  
 BV bnd       w15,39  
 BV bnd       w15,40  
 BV bnd       w15,41  
 BV bnd       w15,43  
 BV bnd       w15,44  
 BV bnd       w15,46  
 BV bnd       w15,47  
 BV bnd       w15,48  
 BV bnd       w15,49  
 BV bnd       w16,18  
 BV bnd       w16,20  
 BV bnd       w16,21  
 BV bnd       w16,22  
 BV bnd       w16,23  
 BV bnd       w16,24  
 BV bnd       w16,27  
 BV bnd       w16,28  
 BV bnd       w16,29  
 BV bnd       w16,30  
 BV bnd       w16,32  
 BV bnd       w16,33  
 BV bnd       w16,34  
 BV bnd       w16,35  
 BV bnd       w16,37  
 BV bnd       w16,38  
 BV bnd       w16,39  
 BV bnd       w16,40  
 BV bnd       w16,41  
 BV bnd       w16,42  
 BV bnd       w16,43  
 BV bnd       w16,44  
 BV bnd       w16,45  
 BV bnd       w16,46  
 BV bnd       w16,47  
 BV bnd       w16,48  
 BV bnd       w17,18  
 BV bnd       w17,20  
 BV bnd       w17,22  
 BV bnd       w17,25  
 BV bnd       w17,26  
 BV bnd       w17,27  
 BV bnd       w17,28  
 BV bnd       w17,30  
 BV bnd       w17,32  
 BV bnd       w17,33  
 BV bnd       w17,34  
 BV bnd       w17,38  
 BV bnd       w17,39  
 BV bnd       w17,43  
 BV bnd       w17,46  
 BV bnd       w17,47  
 BV bnd       w17,49  
 BV bnd       w18,19  
 BV bnd       w18,20  
 BV bnd       w18,21  
 BV bnd       w18,22  
 BV bnd       w18,23  
 BV bnd       w18,24  
 BV bnd       w18,25  
 BV bnd       w18,27  
 BV bnd       w18,28  
 BV bnd       w18,30  
 BV bnd       w18,31  
 BV bnd       w18,34  
 BV bnd       w18,35  
 BV bnd       w18,36  
 BV bnd       w18,37  
 BV bnd       w18,38  
 BV bnd       w18,40  
 BV bnd       w18,41  
 BV bnd       w18,42  
 BV bnd       w18,43  
 BV bnd       w18,45  
 BV bnd       w18,46  
 BV bnd       w18,47  
 BV bnd       w18,48  
 BV bnd       w19,20  
 BV bnd       w19,22  
 BV bnd       w19,23  
 BV bnd       w19,24  
 BV bnd       w19,25  
 BV bnd       w19,26  
 BV bnd       w19,28  
 BV bnd       w19,29  
 BV bnd       w19,31  
 BV bnd       w19,34  
 BV bnd       w19,37  
 BV bnd       w19,39  
 BV bnd       w19,40  
 BV bnd       w19,41  
 BV bnd       w19,45  
 BV bnd       w19,46  
 BV bnd       w19,47  
 BV bnd       w19,48  
 BV bnd       w19,49  
 BV bnd       w20,22  
 BV bnd       w20,23  
 BV bnd       w20,25  
 BV bnd       w20,28  
 BV bnd       w20,29  
 BV bnd       w20,30  
 BV bnd       w20,31  
 BV bnd       w20,32  
 BV bnd       w20,34  
 BV bnd       w20,35  
 BV bnd       w20,36  
 BV bnd       w20,37  
 BV bnd       w20,38  
 BV bnd       w20,40  
 BV bnd       w20,41  
 BV bnd       w20,42  
 BV bnd       w20,45  
 BV bnd       w20,46  
 BV bnd       w20,48  
 BV bnd       w20,49  
 BV bnd       w21,22  
 BV bnd       w21,24  
 BV bnd       w21,25  
 BV bnd       w21,26  
 BV bnd       w21,27  
 BV bnd       w21,28  
 BV bnd       w21,29  
 BV bnd       w21,30  
 BV bnd       w21,31  
 BV bnd       w21,32  
 BV bnd       w21,33  
 BV bnd       w21,37  
 BV bnd       w21,39  
 BV bnd       w21,41  
 BV bnd       w21,43  
 BV bnd       w21,45  
 BV bnd       w21,47  
 BV bnd       w21,48  
 BV bnd       w21,49  
 BV bnd       w22,23  
 BV bnd       w22,25  
 BV bnd       w22,27  
 BV bnd       w22,30  
 BV bnd       w22,33  
 BV bnd       w22,36  
 BV bnd       w22,38  
 BV bnd       w22,39  
 BV bnd       w22,40  
 BV bnd       w22,41  
 BV bnd       w22,42  
 BV bnd       w22,43  
 BV bnd       w22,44  
 BV bnd       w22,45  
 BV bnd       w22,46  
 BV bnd       w22,49  
 BV bnd       w23,24  
 BV bnd       w23,25  
 BV bnd       w23,26  
 BV bnd       w23,27  
 BV bnd       w23,28  
 BV bnd       w23,29  
 BV bnd       w23,32  
 BV bnd       w23,34  
 BV bnd       w23,35  
 BV bnd       w23,36  
 BV bnd       w23,37  
 BV bnd       w23,38  
 BV bnd       w23,39  
 BV bnd       w23,42  
 BV bnd       w23,44  
 BV bnd       w23,45  
 BV bnd       w23,46  
 BV bnd       w23,48  
 BV bnd       w23,49  
 BV bnd       w24,26  
 BV bnd       w24,28  
 BV bnd       w24,29  
 BV bnd       w24,30  
 BV bnd       w24,31  
 BV bnd       w24,32  
 BV bnd       w24,33  
 BV bnd       w24,36  
 BV bnd       w24,38  
 BV bnd       w24,39  
 BV bnd       w24,40  
 BV bnd       w24,42  
 BV bnd       w24,43  
 BV bnd       w24,44  
 BV bnd       w24,46  
 BV bnd       w24,47  
 BV bnd       w24,48  
 BV bnd       w25,26  
 BV bnd       w25,28  
 BV bnd       w25,29  
 BV bnd       w25,30  
 BV bnd       w25,31  
 BV bnd       w25,37  
 BV bnd       w25,38  
 BV bnd       w25,39  
 BV bnd       w25,43  
 BV bnd       w25,44  
 BV bnd       w25,45  
 BV bnd       w25,46  
 BV bnd       w25,47  
 BV bnd       w26,28  
 BV bnd       w26,29  
 BV bnd       w26,30  
 BV bnd       w26,31  
 BV bnd       w26,34  
 BV bnd       w26,37  
 BV bnd       w26,38  
 BV bnd       w26,42  
 BV bnd       w26,43  
 BV bnd       w26,44  
 BV bnd       w26,45  
 BV bnd       w26,47  
 BV bnd       w26,48  
 BV bnd       w26,49  
 BV bnd       w27,28  
 BV bnd       w27,29  
 BV bnd       w27,30  
 BV bnd       w27,32  
 BV bnd       w27,33  
 BV bnd       w27,34  
 BV bnd       w27,35  
 BV bnd       w27,40  
 BV bnd       w27,41  
 BV bnd       w27,42  
 BV bnd       w27,43  
 BV bnd       w27,44  
 BV bnd       w27,45  
 BV bnd       w27,47  
 BV bnd       w27,49  
 BV bnd       w28,29  
 BV bnd       w28,31  
 BV bnd       w28,32  
 BV bnd       w28,33  
 BV bnd       w28,34  
 BV bnd       w28,36  
 BV bnd       w28,39  
 BV bnd       w28,40  
 BV bnd       w28,41  
 BV bnd       w28,43  
 BV bnd       w28,44  
 BV bnd       w28,45  
 BV bnd       w28,46  
 BV bnd       w28,47  
 BV bnd       w28,49  
 BV bnd       w29,30  
 BV bnd       w29,31  
 BV bnd       w29,32  
 BV bnd       w29,34  
 BV bnd       w29,36  
 BV bnd       w29,37  
 BV bnd       w29,38  
 BV bnd       w29,39  
 BV bnd       w29,41  
 BV bnd       w29,42  
 BV bnd       w29,43  
 BV bnd       w29,46  
 BV bnd       w29,47  
 BV bnd       w29,48  
 BV bnd       w29,49  
 BV bnd       w30,31  
 BV bnd       w30,33  
 BV bnd       w30,34  
 BV bnd       w30,36  
 BV bnd       w30,37  
 BV bnd       w30,38  
 BV bnd       w30,40  
 BV bnd       w30,41  
 BV bnd       w30,42  
 BV bnd       w30,43  
 BV bnd       w30,46  
 BV bnd       w30,47  
 BV bnd       w30,48  
 BV bnd       w31,32  
 BV bnd       w31,33  
 BV bnd       w31,35  
 BV bnd       w31,38  
 BV bnd       w31,39  
 BV bnd       w31,41  
 BV bnd       w31,42  
 BV bnd       w31,43  
 BV bnd       w31,45  
 BV bnd       w31,48  
 BV bnd       w31,49  
 BV bnd       w32,33  
 BV bnd       w32,34  
 BV bnd       w32,35  
 BV bnd       w32,37  
 BV bnd       w32,38  
 BV bnd       w32,39  
 BV bnd       w32,40  
 BV bnd       w32,41  
 BV bnd       w32,42  
 BV bnd       w32,43  
 BV bnd       w32,44  
 BV bnd       w32,45  
 BV bnd       w32,46  
 BV bnd       w32,47  
 BV bnd       w32,48  
 BV bnd       w33,34  
 BV bnd       w33,35  
 BV bnd       w33,36  
 BV bnd       w33,37  
 BV bnd       w33,38  
 BV bnd       w33,40  
 BV bnd       w33,41  
 BV bnd       w33,43  
 BV bnd       w33,44  
 BV bnd       w33,45  
 BV bnd       w33,46  
 BV bnd       w33,47  
 BV bnd       w33,48  
 BV bnd       w33,49  
 BV bnd       w34,35  
 BV bnd       w34,37  
 BV bnd       w34,38  
 BV bnd       w34,39  
 BV bnd       w34,40  
 BV bnd       w34,41  
 BV bnd       w34,42  
 BV bnd       w34,43  
 BV bnd       w34,45  
 BV bnd       w34,47  
 BV bnd       w35,36  
 BV bnd       w35,38  
 BV bnd       w35,39  
 BV bnd       w35,41  
 BV bnd       w35,42  
 BV bnd       w35,44  
 BV bnd       w35,45  
 BV bnd       w35,46  
 BV bnd       w35,47  
 BV bnd       w35,48  
 BV bnd       w35,49  
 BV bnd       w36,38  
 BV bnd       w36,39  
 BV bnd       w36,41  
 BV bnd       w36,43  
 BV bnd       w36,44  
 BV bnd       w36,45  
 BV bnd       w36,47  
 BV bnd       w36,48  
 BV bnd       w37,38  
 BV bnd       w37,39  
 BV bnd       w37,41  
 BV bnd       w37,42  
 BV bnd       w37,43  
 BV bnd       w37,44  
 BV bnd       w37,45  
 BV bnd       w37,46  
 BV bnd       w37,47  
 BV bnd       w37,49  
 BV bnd       w38,41  
 BV bnd       w38,42  
 BV bnd       w38,43  
 BV bnd       w38,45  
 BV bnd       w38,46  
 BV bnd       w38,47  
 BV bnd       w38,48  
 BV bnd       w38,49  
 BV bnd       w39,40  
 BV bnd       w39,41  
 BV bnd       w39,42  
 BV bnd       w39,43  
 BV bnd       w39,44  
 BV bnd       w39,45  
 BV bnd       w39,46  
 BV bnd       w39,47  
 BV bnd       w40,44  
 BV bnd       w40,45  
 BV bnd       w40,47  
 BV bnd       w40,48  
 BV bnd       w40,49  
 BV bnd       w41,43  
 BV bnd       w41,45  
 BV bnd       w41,46  
 BV bnd       w41,47  
 BV bnd       w41,48  
 BV bnd       w41,49  
 BV bnd       w42,44  
 BV bnd       w42,47  
 BV bnd       w42,48  
 BV bnd       w42,49  
 BV bnd       w43,44  
 BV bnd       w43,45  
 BV bnd       w43,49  
 BV bnd       w44,45  
 BV bnd       w44,47  
 BV bnd       w44,48  
 BV bnd       w45,47  
 BV bnd       w45,49  
 BV bnd       w46,48  
 BV bnd       w46,49  
 BV bnd       w47,48  
 BV bnd       w48,49  
 BV bnd       y0,1    
 BV bnd       y0,2    
 BV bnd       y0,3    
 BV bnd       y0,5    
 BV bnd       y0,6    
 BV bnd       y0,7    
 BV bnd       y0,8    
 BV bnd       y0,9    
 BV bnd       y0,10   
 BV bnd       y0,11   
 BV bnd       y0,13   
 BV bnd       y0,14   
 BV bnd       y0,15   
 BV bnd       y0,16   
 BV bnd       y0,17   
 BV bnd       y0,18   
 BV bnd       y0,19   
 BV bnd       y0,20   
 BV bnd       y0,22   
 BV bnd       y0,23   
 BV bnd       y0,25   
 BV bnd       y0,26   
 BV bnd       y0,31   
 BV bnd       y0,32   
 BV bnd       y0,33   
 BV bnd       y0,34   
 BV bnd       y0,38   
 BV bnd       y0,40   
 BV bnd       y0,43   
 BV bnd       y0,44   
 BV bnd       y0,45   
 BV bnd       y0,46   
 BV bnd       y0,47   
 BV bnd       y0,48   
 BV bnd       y1,2    
 BV bnd       y1,3    
 BV bnd       y1,5    
 BV bnd       y1,6    
 BV bnd       y1,8    
 BV bnd       y1,9    
 BV bnd       y1,10   
 BV bnd       y1,11   
 BV bnd       y1,12   
 BV bnd       y1,14   
 BV bnd       y1,15   
 BV bnd       y1,16   
 BV bnd       y1,17   
 BV bnd       y1,18   
 BV bnd       y1,19   
 BV bnd       y1,20   
 BV bnd       y1,21   
 BV bnd       y1,22   
 BV bnd       y1,24   
 BV bnd       y1,26   
 BV bnd       y1,27   
 BV bnd       y1,29   
 BV bnd       y1,31   
 BV bnd       y1,32   
 BV bnd       y1,34   
 BV bnd       y1,35   
 BV bnd       y1,37   
 BV bnd       y1,38   
 BV bnd       y1,40   
 BV bnd       y1,41   
 BV bnd       y1,42   
 BV bnd       y1,43   
 BV bnd       y1,44   
 BV bnd       y1,45   
 BV bnd       y1,46   
 BV bnd       y1,48   
 BV bnd       y1,49   
 BV bnd       y2,4    
 BV bnd       y2,5    
 BV bnd       y2,7    
 BV bnd       y2,9    
 BV bnd       y2,10   
 BV bnd       y2,11   
 BV bnd       y2,12   
 BV bnd       y2,14   
 BV bnd       y2,18   
 BV bnd       y2,19   
 BV bnd       y2,20   
 BV bnd       y2,21   
 BV bnd       y2,22   
 BV bnd       y2,27   
 BV bnd       y2,28   
 BV bnd       y2,30   
 BV bnd       y2,31   
 BV bnd       y2,32   
 BV bnd       y2,33   
 BV bnd       y2,34   
 BV bnd       y2,35   
 BV bnd       y2,39   
 BV bnd       y2,40   
 BV bnd       y2,41   
 BV bnd       y2,42   
 BV bnd       y2,44   
 BV bnd       y2,45   
 BV bnd       y2,47   
 BV bnd       y2,49   
 BV bnd       y3,5    
 BV bnd       y3,6    
 BV bnd       y3,8    
 BV bnd       y3,9    
 BV bnd       y3,14   
 BV bnd       y3,17   
 BV bnd       y3,19   
 BV bnd       y3,20   
 BV bnd       y3,21   
 BV bnd       y3,22   
 BV bnd       y3,23   
 BV bnd       y3,24   
 BV bnd       y3,25   
 BV bnd       y3,26   
 BV bnd       y3,27   
 BV bnd       y3,33   
 BV bnd       y3,34   
 BV bnd       y3,35   
 BV bnd       y3,37   
 BV bnd       y3,38   
 BV bnd       y3,39   
 BV bnd       y3,40   
 BV bnd       y3,41   
 BV bnd       y3,42   
 BV bnd       y3,43   
 BV bnd       y3,44   
 BV bnd       y3,45   
 BV bnd       y3,47   
 BV bnd       y3,49   
 BV bnd       y4,5    
 BV bnd       y4,6    
 BV bnd       y4,8    
 BV bnd       y4,9    
 BV bnd       y4,11   
 BV bnd       y4,13   
 BV bnd       y4,15   
 BV bnd       y4,16   
 BV bnd       y4,18   
 BV bnd       y4,20   
 BV bnd       y4,22   
 BV bnd       y4,25   
 BV bnd       y4,26   
 BV bnd       y4,28   
 BV bnd       y4,29   
 BV bnd       y4,30   
 BV bnd       y4,31   
 BV bnd       y4,32   
 BV bnd       y4,33   
 BV bnd       y4,34   
 BV bnd       y4,37   
 BV bnd       y4,38   
 BV bnd       y4,39   
 BV bnd       y4,40   
 BV bnd       y4,41   
 BV bnd       y4,43   
 BV bnd       y4,45   
 BV bnd       y4,46   
 BV bnd       y4,47   
 BV bnd       y4,49   
 BV bnd       y5,6    
 BV bnd       y5,7    
 BV bnd       y5,8    
 BV bnd       y5,10   
 BV bnd       y5,11   
 BV bnd       y5,12   
 BV bnd       y5,16   
 BV bnd       y5,18   
 BV bnd       y5,19   
 BV bnd       y5,20   
 BV bnd       y5,21   
 BV bnd       y5,22   
 BV bnd       y5,23   
 BV bnd       y5,24   
 BV bnd       y5,25   
 BV bnd       y5,26   
 BV bnd       y5,27   
 BV bnd       y5,28   
 BV bnd       y5,29   
 BV bnd       y5,30   
 BV bnd       y5,31   
 BV bnd       y5,32   
 BV bnd       y5,33   
 BV bnd       y5,34   
 BV bnd       y5,35   
 BV bnd       y5,36   
 BV bnd       y5,37   
 BV bnd       y5,39   
 BV bnd       y5,40   
 BV bnd       y5,41   
 BV bnd       y5,42   
 BV bnd       y5,43   
 BV bnd       y5,45   
 BV bnd       y5,47   
 BV bnd       y5,49   
 BV bnd       y6,8    
 BV bnd       y6,10   
 BV bnd       y6,12   
 BV bnd       y6,13   
 BV bnd       y6,15   
 BV bnd       y6,17   
 BV bnd       y6,18   
 BV bnd       y6,19   
 BV bnd       y6,20   
 BV bnd       y6,22   
 BV bnd       y6,23   
 BV bnd       y6,24   
 BV bnd       y6,25   
 BV bnd       y6,27   
 BV bnd       y6,28   
 BV bnd       y6,29   
 BV bnd       y6,30   
 BV bnd       y6,33   
 BV bnd       y6,34   
 BV bnd       y6,38   
 BV bnd       y6,39   
 BV bnd       y6,40   
 BV bnd       y6,41   
 BV bnd       y6,42   
 BV bnd       y6,43   
 BV bnd       y6,44   
 BV bnd       y6,45   
 BV bnd       y6,46   
 BV bnd       y6,47   
 BV bnd       y6,48   
 BV bnd       y6,49   
 BV bnd       y7,8    
 BV bnd       y7,10   
 BV bnd       y7,12   
 BV bnd       y7,14   
 BV bnd       y7,16   
 BV bnd       y7,17   
 BV bnd       y7,18   
 BV bnd       y7,19   
 BV bnd       y7,20   
 BV bnd       y7,21   
 BV bnd       y7,23   
 BV bnd       y7,24   
 BV bnd       y7,27   
 BV bnd       y7,28   
 BV bnd       y7,29   
 BV bnd       y7,30   
 BV bnd       y7,31   
 BV bnd       y7,32   
 BV bnd       y7,33   
 BV bnd       y7,35   
 BV bnd       y7,37   
 BV bnd       y7,39   
 BV bnd       y7,41   
 BV bnd       y7,42   
 BV bnd       y7,44   
 BV bnd       y7,45   
 BV bnd       y7,47   
 BV bnd       y7,48   
 BV bnd       y7,49   
 BV bnd       y8,9    
 BV bnd       y8,10   
 BV bnd       y8,12   
 BV bnd       y8,13   
 BV bnd       y8,15   
 BV bnd       y8,17   
 BV bnd       y8,18   
 BV bnd       y8,19   
 BV bnd       y8,20   
 BV bnd       y8,24   
 BV bnd       y8,26   
 BV bnd       y8,27   
 BV bnd       y8,31   
 BV bnd       y8,32   
 BV bnd       y8,33   
 BV bnd       y8,34   
 BV bnd       y8,35   
 BV bnd       y8,41   
 BV bnd       y8,42   
 BV bnd       y8,43   
 BV bnd       y8,44   
 BV bnd       y8,45   
 BV bnd       y8,46   
 BV bnd       y9,10   
 BV bnd       y9,11   
 BV bnd       y9,12   
 BV bnd       y9,13   
 BV bnd       y9,15   
 BV bnd       y9,16   
 BV bnd       y9,17   
 BV bnd       y9,18   
 BV bnd       y9,19   
 BV bnd       y9,21   
 BV bnd       y9,22   
 BV bnd       y9,23   
 BV bnd       y9,24   
 BV bnd       y9,26   
 BV bnd       y9,27   
 BV bnd       y9,29   
 BV bnd       y9,30   
 BV bnd       y9,32   
 BV bnd       y9,33   
 BV bnd       y9,34   
 BV bnd       y9,35   
 BV bnd       y9,36   
 BV bnd       y9,38   
 BV bnd       y9,40   
 BV bnd       y9,41   
 BV bnd       y9,42   
 BV bnd       y9,43   
 BV bnd       y9,44   
 BV bnd       y9,45   
 BV bnd       y9,46   
 BV bnd       y9,47   
 BV bnd       y9,48   
 BV bnd       y9,49   
 BV bnd       y10,11  
 BV bnd       y10,14  
 BV bnd       y10,15  
 BV bnd       y10,17  
 BV bnd       y10,18  
 BV bnd       y10,19  
 BV bnd       y10,20  
 BV bnd       y10,21  
 BV bnd       y10,22  
 BV bnd       y10,23  
 BV bnd       y10,24  
 BV bnd       y10,25  
 BV bnd       y10,26  
 BV bnd       y10,27  
 BV bnd       y10,29  
 BV bnd       y10,31  
 BV bnd       y10,32  
 BV bnd       y10,33  
 BV bnd       y10,35  
 BV bnd       y10,36  
 BV bnd       y10,37  
 BV bnd       y10,38  
 BV bnd       y10,39  
 BV bnd       y10,40  
 BV bnd       y10,41  
 BV bnd       y10,42  
 BV bnd       y10,43  
 BV bnd       y10,44  
 BV bnd       y10,47  
 BV bnd       y10,48  
 BV bnd       y11,12  
 BV bnd       y11,13  
 BV bnd       y11,14  
 BV bnd       y11,15  
 BV bnd       y11,16  
 BV bnd       y11,17  
 BV bnd       y11,18  
 BV bnd       y11,19  
 BV bnd       y11,21  
 BV bnd       y11,22  
 BV bnd       y11,25  
 BV bnd       y11,26  
 BV bnd       y11,27  
 BV bnd       y11,28  
 BV bnd       y11,29  
 BV bnd       y11,31  
 BV bnd       y11,33  
 BV bnd       y11,34  
 BV bnd       y11,38  
 BV bnd       y11,39  
 BV bnd       y11,40  
 BV bnd       y11,42  
 BV bnd       y11,44  
 BV bnd       y11,46  
 BV bnd       y11,47  
 BV bnd       y11,48  
 BV bnd       y11,49  
 BV bnd       y12,13  
 BV bnd       y12,15  
 BV bnd       y12,17  
 BV bnd       y12,18  
 BV bnd       y12,20  
 BV bnd       y12,21  
 BV bnd       y12,22  
 BV bnd       y12,23  
 BV bnd       y12,24  
 BV bnd       y12,26  
 BV bnd       y12,28  
 BV bnd       y12,29  
 BV bnd       y12,30  
 BV bnd       y12,31  
 BV bnd       y12,32  
 BV bnd       y12,36  
 BV bnd       y12,37  
 BV bnd       y12,39  
 BV bnd       y12,40  
 BV bnd       y12,41  
 BV bnd       y12,43  
 BV bnd       y12,44  
 BV bnd       y12,45  
 BV bnd       y12,48  
 BV bnd       y12,49  
 BV bnd       y13,14  
 BV bnd       y13,15  
 BV bnd       y13,18  
 BV bnd       y13,20  
 BV bnd       y13,23  
 BV bnd       y13,24  
 BV bnd       y13,25  
 BV bnd       y13,26  
 BV bnd       y13,28  
 BV bnd       y13,29  
 BV bnd       y13,30  
 BV bnd       y13,31  
 BV bnd       y13,32  
 BV bnd       y13,35  
 BV bnd       y13,36  
 BV bnd       y13,37  
 BV bnd       y13,38  
 BV bnd       y13,39  
 BV bnd       y13,40  
 BV bnd       y13,41  
 BV bnd       y13,42  
 BV bnd       y13,43  
 BV bnd       y13,45  
 BV bnd       y13,46  
 BV bnd       y13,47  
 BV bnd       y13,48  
 BV bnd       y13,49  
 BV bnd       y14,15  
 BV bnd       y14,16  
 BV bnd       y14,17  
 BV bnd       y14,18  
 BV bnd       y14,19  
 BV bnd       y14,20  
 BV bnd       y14,22  
 BV bnd       y14,23  
 BV bnd       y14,24  
 BV bnd       y14,25  
 BV bnd       y14,27  
 BV bnd       y14,30  
 BV bnd       y14,31  
 BV bnd       y14,32  
 BV bnd       y14,33  
 BV bnd       y14,34  
 BV bnd       y14,35  
 BV bnd       y14,37  
 BV bnd       y14,38  
 BV bnd       y14,42  
 BV bnd       y14,43  
 BV bnd       y14,44  
 BV bnd       y14,45  
 BV bnd       y14,46  
 BV bnd       y14,47  
 BV bnd       y14,48  
 BV bnd       y14,49  
 BV bnd       y15,16  
 BV bnd       y15,17  
 BV bnd       y15,18  
 BV bnd       y15,19  
 BV bnd       y15,21  
 BV bnd       y15,22  
 BV bnd       y15,23  
 BV bnd       y15,24  
 BV bnd       y15,26  
 BV bnd       y15,27  
 BV bnd       y15,29  
 BV bnd       y15,30  
 BV bnd       y15,31  
 BV bnd       y15,32  
 BV bnd       y15,33  
 BV bnd       y15,34  
 BV bnd       y15,36  
 BV bnd       y15,37  
 BV bnd       y15,39  
 BV bnd       y15,40  
 BV bnd       y15,41  
 BV bnd       y15,43  
 BV bnd       y15,44  
 BV bnd       y15,46  
 BV bnd       y15,47  
 BV bnd       y15,48  
 BV bnd       y15,49  
 BV bnd       y16,18  
 BV bnd       y16,20  
 BV bnd       y16,21  
 BV bnd       y16,22  
 BV bnd       y16,23  
 BV bnd       y16,24  
 BV bnd       y16,27  
 BV bnd       y16,28  
 BV bnd       y16,29  
 BV bnd       y16,30  
 BV bnd       y16,32  
 BV bnd       y16,33  
 BV bnd       y16,34  
 BV bnd       y16,35  
 BV bnd       y16,37  
 BV bnd       y16,38  
 BV bnd       y16,39  
 BV bnd       y16,40  
 BV bnd       y16,41  
 BV bnd       y16,42  
 BV bnd       y16,43  
 BV bnd       y16,44  
 BV bnd       y16,45  
 BV bnd       y16,46  
 BV bnd       y16,47  
 BV bnd       y16,48  
 BV bnd       y17,18  
 BV bnd       y17,20  
 BV bnd       y17,22  
 BV bnd       y17,25  
 BV bnd       y17,26  
 BV bnd       y17,27  
 BV bnd       y17,28  
 BV bnd       y17,30  
 BV bnd       y17,32  
 BV bnd       y17,33  
 BV bnd       y17,34  
 BV bnd       y17,38  
 BV bnd       y17,39  
 BV bnd       y17,43  
 BV bnd       y17,46  
 BV bnd       y17,47  
 BV bnd       y17,49  
 BV bnd       y18,19  
 BV bnd       y18,20  
 BV bnd       y18,21  
 BV bnd       y18,22  
 BV bnd       y18,23  
 BV bnd       y18,24  
 BV bnd       y18,25  
 BV bnd       y18,27  
 BV bnd       y18,28  
 BV bnd       y18,30  
 BV bnd       y18,31  
 BV bnd       y18,34  
 BV bnd       y18,35  
 BV bnd       y18,36  
 BV bnd       y18,37  
 BV bnd       y18,38  
 BV bnd       y18,40  
 BV bnd       y18,41  
 BV bnd       y18,42  
 BV bnd       y18,43  
 BV bnd       y18,45  
 BV bnd       y18,46  
 BV bnd       y18,47  
 BV bnd       y18,48  
 BV bnd       y19,20  
 BV bnd       y19,22  
 BV bnd       y19,23  
 BV bnd       y19,24  
 BV bnd       y19,25  
 BV bnd       y19,26  
 BV bnd       y19,28  
 BV bnd       y19,29  
 BV bnd       y19,31  
 BV bnd       y19,34  
 BV bnd       y19,37  
 BV bnd       y19,39  
 BV bnd       y19,40  
 BV bnd       y19,41  
 BV bnd       y19,45  
 BV bnd       y19,46  
 BV bnd       y19,47  
 BV bnd       y19,48  
 BV bnd       y19,49  
 BV bnd       y20,22  
 BV bnd       y20,23  
 BV bnd       y20,25  
 BV bnd       y20,28  
 BV bnd       y20,29  
 BV bnd       y20,30  
 BV bnd       y20,31  
 BV bnd       y20,32  
 BV bnd       y20,34  
 BV bnd       y20,35  
 BV bnd       y20,36  
 BV bnd       y20,37  
 BV bnd       y20,38  
 BV bnd       y20,40  
 BV bnd       y20,41  
 BV bnd       y20,42  
 BV bnd       y20,45  
 BV bnd       y20,46  
 BV bnd       y20,48  
 BV bnd       y20,49  
 BV bnd       y21,22  
 BV bnd       y21,24  
 BV bnd       y21,25  
 BV bnd       y21,26  
 BV bnd       y21,27  
 BV bnd       y21,28  
 BV bnd       y21,29  
 BV bnd       y21,30  
 BV bnd       y21,31  
 BV bnd       y21,32  
 BV bnd       y21,33  
 BV bnd       y21,37  
 BV bnd       y21,39  
 BV bnd       y21,41  
 BV bnd       y21,43  
 BV bnd       y21,45  
 BV bnd       y21,47  
 BV bnd       y21,48  
 BV bnd       y21,49  
 BV bnd       y22,23  
 BV bnd       y22,25  
 BV bnd       y22,27  
 BV bnd       y22,30  
 BV bnd       y22,33  
 BV bnd       y22,36  
 BV bnd       y22,38  
 BV bnd       y22,39  
 BV bnd       y22,40  
 BV bnd       y22,41  
 BV bnd       y22,42  
 BV bnd       y22,43  
 BV bnd       y22,44  
 BV bnd       y22,45  
 BV bnd       y22,46  
 BV bnd       y22,49  
 BV bnd       y23,24  
 BV bnd       y23,25  
 BV bnd       y23,26  
 BV bnd       y23,27  
 BV bnd       y23,28  
 BV bnd       y23,29  
 BV bnd       y23,32  
 BV bnd       y23,34  
 BV bnd       y23,35  
 BV bnd       y23,36  
 BV bnd       y23,37  
 BV bnd       y23,38  
 BV bnd       y23,39  
 BV bnd       y23,42  
 BV bnd       y23,44  
 BV bnd       y23,45  
 BV bnd       y23,46  
 BV bnd       y23,48  
 BV bnd       y23,49  
 BV bnd       y24,26  
 BV bnd       y24,28  
 BV bnd       y24,29  
 BV bnd       y24,30  
 BV bnd       y24,31  
 BV bnd       y24,32  
 BV bnd       y24,33  
 BV bnd       y24,36  
 BV bnd       y24,38  
 BV bnd       y24,39  
 BV bnd       y24,40  
 BV bnd       y24,42  
 BV bnd       y24,43  
 BV bnd       y24,44  
 BV bnd       y24,46  
 BV bnd       y24,47  
 BV bnd       y24,48  
 BV bnd       y25,26  
 BV bnd       y25,28  
 BV bnd       y25,29  
 BV bnd       y25,30  
 BV bnd       y25,31  
 BV bnd       y25,37  
 BV bnd       y25,38  
 BV bnd       y25,39  
 BV bnd       y25,43  
 BV bnd       y25,44  
 BV bnd       y25,45  
 BV bnd       y25,46  
 BV bnd       y25,47  
 BV bnd       y26,28  
 BV bnd       y26,29  
 BV bnd       y26,30  
 BV bnd       y26,31  
 BV bnd       y26,34  
 BV bnd       y26,37  
 BV bnd       y26,38  
 BV bnd       y26,42  
 BV bnd       y26,43  
 BV bnd       y26,44  
 BV bnd       y26,45  
 BV bnd       y26,47  
 BV bnd       y26,48  
 BV bnd       y26,49  
 BV bnd       y27,28  
 BV bnd       y27,29  
 BV bnd       y27,30  
 BV bnd       y27,32  
 BV bnd       y27,33  
 BV bnd       y27,34  
 BV bnd       y27,35  
 BV bnd       y27,40  
 BV bnd       y27,41  
 BV bnd       y27,42  
 BV bnd       y27,43  
 BV bnd       y27,44  
 BV bnd       y27,45  
 BV bnd       y27,47  
 BV bnd       y27,49  
 BV bnd       y28,29  
 BV bnd       y28,31  
 BV bnd       y28,32  
 BV bnd       y28,33  
 BV bnd       y28,34  
 BV bnd       y28,36  
 BV bnd       y28,39  
 BV bnd       y28,40  
 BV bnd       y28,41  
 BV bnd       y28,43  
 BV bnd       y28,44  
 BV bnd       y28,45  
 BV bnd       y28,46  
 BV bnd       y28,47  
 BV bnd       y28,49  
 BV bnd       y29,30  
 BV bnd       y29,31  
 BV bnd       y29,32  
 BV bnd       y29,34  
 BV bnd       y29,36  
 BV bnd       y29,37  
 BV bnd       y29,38  
 BV bnd       y29,39  
 BV bnd       y29,41  
 BV bnd       y29,42  
 BV bnd       y29,43  
 BV bnd       y29,46  
 BV bnd       y29,47  
 BV bnd       y29,48  
 BV bnd       y29,49  
 BV bnd       y30,31  
 BV bnd       y30,33  
 BV bnd       y30,34  
 BV bnd       y30,36  
 BV bnd       y30,37  
 BV bnd       y30,38  
 BV bnd       y30,40  
 BV bnd       y30,41  
 BV bnd       y30,42  
 BV bnd       y30,43  
 BV bnd       y30,46  
 BV bnd       y30,47  
 BV bnd       y30,48  
 BV bnd       y31,32  
 BV bnd       y31,33  
 BV bnd       y31,35  
 BV bnd       y31,38  
 BV bnd       y31,39  
 BV bnd       y31,41  
 BV bnd       y31,42  
 BV bnd       y31,43  
 BV bnd       y31,45  
 BV bnd       y31,48  
 BV bnd       y31,49  
 BV bnd       y32,33  
 BV bnd       y32,34  
 BV bnd       y32,35  
 BV bnd       y32,37  
 BV bnd       y32,38  
 BV bnd       y32,39  
 BV bnd       y32,40  
 BV bnd       y32,41  
 BV bnd       y32,42  
 BV bnd       y32,43  
 BV bnd       y32,44  
 BV bnd       y32,45  
 BV bnd       y32,46  
 BV bnd       y32,47  
 BV bnd       y32,48  
 BV bnd       y33,34  
 BV bnd       y33,35  
 BV bnd       y33,36  
 BV bnd       y33,37  
 BV bnd       y33,38  
 BV bnd       y33,40  
 BV bnd       y33,41  
 BV bnd       y33,43  
 BV bnd       y33,44  
 BV bnd       y33,45  
 BV bnd       y33,46  
 BV bnd       y33,47  
 BV bnd       y33,48  
 BV bnd       y33,49  
 BV bnd       y34,35  
 BV bnd       y34,37  
 BV bnd       y34,38  
 BV bnd       y34,39  
 BV bnd       y34,40  
 BV bnd       y34,41  
 BV bnd       y34,42  
 BV bnd       y34,43  
 BV bnd       y34,45  
 BV bnd       y34,47  
 BV bnd       y35,36  
 BV bnd       y35,38  
 BV bnd       y35,39  
 BV bnd       y35,41  
 BV bnd       y35,42  
 BV bnd       y35,44  
 BV bnd       y35,45  
 BV bnd       y35,46  
 BV bnd       y35,47  
 BV bnd       y35,48  
 BV bnd       y35,49  
 BV bnd       y36,38  
 BV bnd       y36,39  
 BV bnd       y36,41  
 BV bnd       y36,43  
 BV bnd       y36,44  
 BV bnd       y36,45  
 BV bnd       y36,47  
 BV bnd       y36,48  
 BV bnd       y37,38  
 BV bnd       y37,39  
 BV bnd       y37,41  
 BV bnd       y37,42  
 BV bnd       y37,43  
 BV bnd       y37,44  
 BV bnd       y37,45  
 BV bnd       y37,46  
 BV bnd       y37,47  
 BV bnd       y37,49  
 BV bnd       y38,41  
 BV bnd       y38,42  
 BV bnd       y38,43  
 BV bnd       y38,45  
 BV bnd       y38,46  
 BV bnd       y38,47  
 BV bnd       y38,48  
 BV bnd       y38,49  
 BV bnd       y39,40  
 BV bnd       y39,41  
 BV bnd       y39,42  
 BV bnd       y39,43  
 BV bnd       y39,44  
 BV bnd       y39,45  
 BV bnd       y39,46  
 BV bnd       y39,47  
 BV bnd       y40,44  
 BV bnd       y40,45  
 BV bnd       y40,47  
 BV bnd       y40,48  
 BV bnd       y40,49  
 BV bnd       y41,43  
 BV bnd       y41,45  
 BV bnd       y41,46  
 BV bnd       y41,47  
 BV bnd       y41,48  
 BV bnd       y41,49  
 BV bnd       y42,44  
 BV bnd       y42,47  
 BV bnd       y42,48  
 BV bnd       y42,49  
 BV bnd       y43,44  
 BV bnd       y43,45  
 BV bnd       y43,49  
 BV bnd       y44,45  
 BV bnd       y44,47  
 BV bnd       y44,48  
 BV bnd       y45,47  
 BV bnd       y45,49  
 BV bnd       y46,48  
 BV bnd       y46,49  
 BV bnd       y47,48  
 BV bnd       y48,49  
 BV bnd       x0      
 BV bnd       x1      
 BV bnd       x2      
 BV bnd       x3      
 BV bnd       x4      
 BV bnd       x5      
 BV bnd       x6      
 BV bnd       x7      
 BV bnd       x8      
 BV bnd       x9      
 BV bnd       x10     
 BV bnd       x11     
 BV bnd       x12     
 BV bnd       x13     
 BV bnd       x14     
 BV bnd       x15     
 BV bnd       x16     
 BV bnd       x17     
 BV bnd       x18     
 BV bnd       x19     
 BV bnd       x20     
 BV bnd       x21     
 BV bnd       x22     
 BV bnd       x23     
 BV bnd       x24     
 BV bnd       x25     
 BV bnd       x26     
 BV bnd       x27     
 BV bnd       x28     
 BV bnd       x29     
 BV bnd       x30     
 BV bnd       x31     
 BV bnd       x32     
 BV bnd       x33     
 BV bnd       x34     
 BV bnd       x35     
 BV bnd       x36     
 BV bnd       x37     
 BV bnd       x38     
 BV bnd       x39     
 BV bnd       x40     
 BV bnd       x41     
 BV bnd       x42     
 BV bnd       x43     
 BV bnd       x44     
 BV bnd       x45     
 BV bnd       x46     
 BV bnd       x47     
 BV bnd       x48     
 BV bnd       x49     
ENDATA
