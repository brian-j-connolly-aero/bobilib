* ENCODING=ISO-8859-1
NAME          normalClique50-70-2
ROWS
 N  cost    
 L  KL      
 L  C0,9    
 L  C0,11   
 L  C0,13   
 L  C0,18   
 L  C0,25   
 L  C0,28   
 L  C0,30   
 L  C0,31   
 L  C0,36   
 L  C0,44   
 L  C0,48   
 L  C0,49   
 L  C1,2    
 L  C1,10   
 L  C1,14   
 L  C1,15   
 L  C1,19   
 L  C1,28   
 L  C1,32   
 L  C1,38   
 L  C1,39   
 L  C1,42   
 L  C1,43   
 L  C1,45   
 L  C1,46   
 L  C1,47   
 L  C1,49   
 L  C2,6    
 L  C2,8    
 L  C2,9    
 L  C2,11   
 L  C2,13   
 L  C2,15   
 L  C2,17   
 L  C2,22   
 L  C2,23   
 L  C2,24   
 L  C2,25   
 L  C2,27   
 L  C2,30   
 L  C2,41   
 L  C2,42   
 L  C2,43   
 L  C2,47   
 L  C3,5    
 L  C3,19   
 L  C3,20   
 L  C3,23   
 L  C3,27   
 L  C3,28   
 L  C3,32   
 L  C3,34   
 L  C3,39   
 L  C3,40   
 L  C3,41   
 L  C3,42   
 L  C3,44   
 L  C3,46   
 L  C3,48   
 L  C3,49   
 L  C4,6    
 L  C4,7    
 L  C4,8    
 L  C4,10   
 L  C4,18   
 L  C4,20   
 L  C4,21   
 L  C4,28   
 L  C4,29   
 L  C4,30   
 L  C4,39   
 L  C4,43   
 L  C4,49   
 L  C5,18   
 L  C5,21   
 L  C5,29   
 L  C5,32   
 L  C5,34   
 L  C5,36   
 L  C5,37   
 L  C5,43   
 L  C5,44   
 L  C5,46   
 L  C6,7    
 L  C6,8    
 L  C6,12   
 L  C6,14   
 L  C6,15   
 L  C6,18   
 L  C6,19   
 L  C6,20   
 L  C6,22   
 L  C6,25   
 L  C6,33   
 L  C6,37   
 L  C6,39   
 L  C6,40   
 L  C6,41   
 L  C6,42   
 L  C6,44   
 L  C6,45   
 L  C6,48   
 L  C7,11   
 L  C7,12   
 L  C7,17   
 L  C7,18   
 L  C7,19   
 L  C7,22   
 L  C7,23   
 L  C7,24   
 L  C7,34   
 L  C7,35   
 L  C7,36   
 L  C7,37   
 L  C7,41   
 L  C7,42   
 L  C7,43   
 L  C7,44   
 L  C7,45   
 L  C7,47   
 L  C7,48   
 L  C8,10   
 L  C8,11   
 L  C8,15   
 L  C8,17   
 L  C8,23   
 L  C8,24   
 L  C8,26   
 L  C8,27   
 L  C8,28   
 L  C8,31   
 L  C8,32   
 L  C8,36   
 L  C8,38   
 L  C8,46   
 L  C9,16   
 L  C9,18   
 L  C9,22   
 L  C9,31   
 L  C9,32   
 L  C9,36   
 L  C9,43   
 L  C9,44   
 L  C9,46   
 L  C10,17  
 L  C10,18  
 L  C10,19  
 L  C10,22  
 L  C10,25  
 L  C10,26  
 L  C10,38  
 L  C10,39  
 L  C10,47  
 L  C11,13  
 L  C11,17  
 L  C11,19  
 L  C11,24  
 L  C11,26  
 L  C11,32  
 L  C11,41  
 L  C11,45  
 L  C11,49  
 L  C12,16  
 L  C12,18  
 L  C12,19  
 L  C12,22  
 L  C12,31  
 L  C12,43  
 L  C12,45  
 L  C12,48  
 L  C13,14  
 L  C13,17  
 L  C13,19  
 L  C13,20  
 L  C13,25  
 L  C13,28  
 L  C13,29  
 L  C13,30  
 L  C13,33  
 L  C13,36  
 L  C13,37  
 L  C13,46  
 L  C13,48  
 L  C14,21  
 L  C14,28  
 L  C14,29  
 L  C14,34  
 L  C14,35  
 L  C14,38  
 L  C14,42  
 L  C14,43  
 L  C14,44  
 L  C14,45  
 L  C14,49  
 L  C15,18  
 L  C15,25  
 L  C15,31  
 L  C15,35  
 L  C15,36  
 L  C15,39  
 L  C15,42  
 L  C15,43  
 L  C15,47  
 L  C15,49  
 L  C16,20  
 L  C16,21  
 L  C16,24  
 L  C16,25  
 L  C16,32  
 L  C16,33  
 L  C16,34  
 L  C16,35  
 L  C16,36  
 L  C16,42  
 L  C16,43  
 L  C16,45  
 L  C17,24  
 L  C17,25  
 L  C17,26  
 L  C17,28  
 L  C17,34  
 L  C17,37  
 L  C17,38  
 L  C17,45  
 L  C17,48  
 L  C18,19  
 L  C18,20  
 L  C18,25  
 L  C18,28  
 L  C18,29  
 L  C18,30  
 L  C18,39  
 L  C18,41  
 L  C18,44  
 L  C19,20  
 L  C19,22  
 L  C19,27  
 L  C19,33  
 L  C19,35  
 L  C19,36  
 L  C19,42  
 L  C19,43  
 L  C20,25  
 L  C20,28  
 L  C20,31  
 L  C20,34  
 L  C20,36  
 L  C20,38  
 L  C20,42  
 L  C20,46  
 L  C21,23  
 L  C21,24  
 L  C21,28  
 L  C21,30  
 L  C21,31  
 L  C21,32  
 L  C21,37  
 L  C21,40  
 L  C21,41  
 L  C21,43  
 L  C21,46  
 L  C21,48  
 L  C22,28  
 L  C22,32  
 L  C22,33  
 L  C22,34  
 L  C22,37  
 L  C22,41  
 L  C22,44  
 L  C22,46  
 L  C22,49  
 L  C23,24  
 L  C23,36  
 L  C23,38  
 L  C23,41  
 L  C23,43  
 L  C23,45  
 L  C23,49  
 L  C24,28  
 L  C24,31  
 L  C24,34  
 L  C24,37  
 L  C24,39  
 L  C24,40  
 L  C24,45  
 L  C24,47  
 L  C24,48  
 L  C25,29  
 L  C25,32  
 L  C25,37  
 L  C25,38  
 L  C25,39  
 L  C25,43  
 L  C25,45  
 L  C26,33  
 L  C26,36  
 L  C26,39  
 L  C26,43  
 L  C26,47  
 L  C27,32  
 L  C27,33  
 L  C27,37  
 L  C27,38  
 L  C27,39  
 L  C27,41  
 L  C27,46  
 L  C28,29  
 L  C28,30  
 L  C28,47  
 L  C29,33  
 L  C29,41  
 L  C29,46  
 L  C30,31  
 L  C30,41  
 L  C30,42  
 L  C30,48  
 L  C31,32  
 L  C31,33  
 L  C31,38  
 L  C31,42  
 L  C31,44  
 L  C31,47  
 L  C32,35  
 L  C32,36  
 L  C32,44  
 L  C32,45  
 L  C33,35  
 L  C33,40  
 L  C33,41  
 L  C33,43  
 L  C33,47  
 L  C34,35  
 L  C34,37  
 L  C34,39  
 L  C34,41  
 L  C34,42  
 L  C34,48  
 L  C35,41  
 L  C35,42  
 L  C35,45  
 L  C35,48  
 L  C36,39  
 L  C36,42  
 L  C36,43  
 L  C37,38  
 L  C37,41  
 L  C38,41  
 L  C38,47  
 L  C39,40  
 L  C39,43  
 L  C39,46  
 L  C39,47  
 L  C39,48  
 L  C40,41  
 L  C40,42  
 L  C40,44  
 L  C40,46  
 L  C40,49  
 L  C41,49  
 L  C42,44  
 L  C42,47  
 L  C43,44  
 L  C43,48  
 L  C44,47  
 L  C45,46  
 L  C45,48  
 L  C45,49  
 L  C48,49  
 L  E0,1    
 L  E0,2    
 L  E0,3    
 L  E0,4    
 L  E0,5    
 L  E0,6    
 L  E0,7    
 L  E0,8    
 L  E0,10   
 L  E0,12   
 L  E0,14   
 L  E0,15   
 L  E0,16   
 L  E0,17   
 L  E0,19   
 L  E0,20   
 L  E0,21   
 L  E0,22   
 L  E0,23   
 L  E0,24   
 L  E0,26   
 L  E0,27   
 L  E0,29   
 L  E0,32   
 L  E0,33   
 L  E0,34   
 L  E0,35   
 L  E0,37   
 L  E0,38   
 L  E0,39   
 L  E0,40   
 L  E0,41   
 L  E0,42   
 L  E0,43   
 L  E0,45   
 L  E0,46   
 L  E0,47   
 L  E1,3    
 L  E1,4    
 L  E1,5    
 L  E1,6    
 L  E1,7    
 L  E1,8    
 L  E1,9    
 L  E1,11   
 L  E1,12   
 L  E1,13   
 L  E1,16   
 L  E1,17   
 L  E1,18   
 L  E1,20   
 L  E1,21   
 L  E1,22   
 L  E1,23   
 L  E1,24   
 L  E1,25   
 L  E1,26   
 L  E1,27   
 L  E1,29   
 L  E1,30   
 L  E1,31   
 L  E1,33   
 L  E1,34   
 L  E1,35   
 L  E1,36   
 L  E1,37   
 L  E1,40   
 L  E1,41   
 L  E1,44   
 L  E1,48   
 L  E2,3    
 L  E2,4    
 L  E2,5    
 L  E2,7    
 L  E2,10   
 L  E2,12   
 L  E2,14   
 L  E2,16   
 L  E2,18   
 L  E2,19   
 L  E2,20   
 L  E2,21   
 L  E2,26   
 L  E2,28   
 L  E2,29   
 L  E2,31   
 L  E2,32   
 L  E2,33   
 L  E2,34   
 L  E2,35   
 L  E2,36   
 L  E2,37   
 L  E2,38   
 L  E2,39   
 L  E2,40   
 L  E2,44   
 L  E2,45   
 L  E2,46   
 L  E2,48   
 L  E2,49   
 L  E3,4    
 L  E3,6    
 L  E3,7    
 L  E3,8    
 L  E3,9    
 L  E3,10   
 L  E3,11   
 L  E3,12   
 L  E3,13   
 L  E3,14   
 L  E3,15   
 L  E3,16   
 L  E3,17   
 L  E3,18   
 L  E3,21   
 L  E3,22   
 L  E3,24   
 L  E3,25   
 L  E3,26   
 L  E3,29   
 L  E3,30   
 L  E3,31   
 L  E3,33   
 L  E3,35   
 L  E3,36   
 L  E3,37   
 L  E3,38   
 L  E3,43   
 L  E3,45   
 L  E3,47   
 L  E4,5    
 L  E4,9    
 L  E4,11   
 L  E4,12   
 L  E4,13   
 L  E4,14   
 L  E4,15   
 L  E4,16   
 L  E4,17   
 L  E4,19   
 L  E4,22   
 L  E4,23   
 L  E4,24   
 L  E4,25   
 L  E4,26   
 L  E4,27   
 L  E4,31   
 L  E4,32   
 L  E4,33   
 L  E4,34   
 L  E4,35   
 L  E4,36   
 L  E4,37   
 L  E4,38   
 L  E4,40   
 L  E4,41   
 L  E4,42   
 L  E4,44   
 L  E4,45   
 L  E4,46   
 L  E4,47   
 L  E4,48   
 L  E5,6    
 L  E5,7    
 L  E5,8    
 L  E5,9    
 L  E5,10   
 L  E5,11   
 L  E5,12   
 L  E5,13   
 L  E5,14   
 L  E5,15   
 L  E5,16   
 L  E5,17   
 L  E5,19   
 L  E5,20   
 L  E5,22   
 L  E5,23   
 L  E5,24   
 L  E5,25   
 L  E5,26   
 L  E5,27   
 L  E5,28   
 L  E5,30   
 L  E5,31   
 L  E5,33   
 L  E5,35   
 L  E5,38   
 L  E5,39   
 L  E5,40   
 L  E5,41   
 L  E5,42   
 L  E5,45   
 L  E5,47   
 L  E5,48   
 L  E5,49   
 L  E6,9    
 L  E6,10   
 L  E6,11   
 L  E6,13   
 L  E6,16   
 L  E6,17   
 L  E6,21   
 L  E6,23   
 L  E6,24   
 L  E6,26   
 L  E6,27   
 L  E6,28   
 L  E6,29   
 L  E6,30   
 L  E6,31   
 L  E6,32   
 L  E6,34   
 L  E6,35   
 L  E6,36   
 L  E6,38   
 L  E6,43   
 L  E6,46   
 L  E6,47   
 L  E6,49   
 L  E7,8    
 L  E7,9    
 L  E7,10   
 L  E7,13   
 L  E7,14   
 L  E7,15   
 L  E7,16   
 L  E7,20   
 L  E7,21   
 L  E7,25   
 L  E7,26   
 L  E7,27   
 L  E7,28   
 L  E7,29   
 L  E7,30   
 L  E7,31   
 L  E7,32   
 L  E7,33   
 L  E7,38   
 L  E7,39   
 L  E7,40   
 L  E7,46   
 L  E7,49   
 L  E8,9    
 L  E8,12   
 L  E8,13   
 L  E8,14   
 L  E8,16   
 L  E8,18   
 L  E8,19   
 L  E8,20   
 L  E8,21   
 L  E8,22   
 L  E8,25   
 L  E8,29   
 L  E8,30   
 L  E8,33   
 L  E8,34   
 L  E8,35   
 L  E8,37   
 L  E8,39   
 L  E8,40   
 L  E8,41   
 L  E8,42   
 L  E8,43   
 L  E8,44   
 L  E8,45   
 L  E8,47   
 L  E8,48   
 L  E8,49   
 L  E9,10   
 L  E9,11   
 L  E9,12   
 L  E9,13   
 L  E9,14   
 L  E9,15   
 L  E9,17   
 L  E9,19   
 L  E9,20   
 L  E9,21   
 L  E9,23   
 L  E9,24   
 L  E9,25   
 L  E9,26   
 L  E9,27   
 L  E9,28   
 L  E9,29   
 L  E9,30   
 L  E9,33   
 L  E9,34   
 L  E9,35   
 L  E9,37   
 L  E9,38   
 L  E9,39   
 L  E9,40   
 L  E9,41   
 L  E9,42   
 L  E9,45   
 L  E9,47   
 L  E9,48   
 L  E9,49   
 L  E10,11  
 L  E10,12  
 L  E10,13  
 L  E10,14  
 L  E10,15  
 L  E10,16  
 L  E10,20  
 L  E10,21  
 L  E10,23  
 L  E10,24  
 L  E10,27  
 L  E10,28  
 L  E10,29  
 L  E10,30  
 L  E10,31  
 L  E10,32  
 L  E10,33  
 L  E10,34  
 L  E10,35  
 L  E10,36  
 L  E10,37  
 L  E10,40  
 L  E10,41  
 L  E10,42  
 L  E10,43  
 L  E10,44  
 L  E10,45  
 L  E10,46  
 L  E10,48  
 L  E10,49  
 L  E11,12  
 L  E11,14  
 L  E11,15  
 L  E11,16  
 L  E11,18  
 L  E11,20  
 L  E11,21  
 L  E11,22  
 L  E11,23  
 L  E11,25  
 L  E11,27  
 L  E11,28  
 L  E11,29  
 L  E11,30  
 L  E11,31  
 L  E11,33  
 L  E11,34  
 L  E11,35  
 L  E11,36  
 L  E11,37  
 L  E11,38  
 L  E11,39  
 L  E11,40  
 L  E11,42  
 L  E11,43  
 L  E11,44  
 L  E11,46  
 L  E11,47  
 L  E11,48  
 L  E12,13  
 L  E12,14  
 L  E12,15  
 L  E12,17  
 L  E12,20  
 L  E12,21  
 L  E12,23  
 L  E12,24  
 L  E12,25  
 L  E12,26  
 L  E12,27  
 L  E12,28  
 L  E12,29  
 L  E12,30  
 L  E12,32  
 L  E12,33  
 L  E12,34  
 L  E12,35  
 L  E12,36  
 L  E12,37  
 L  E12,38  
 L  E12,39  
 L  E12,40  
 L  E12,41  
 L  E12,42  
 L  E12,44  
 L  E12,46  
 L  E12,47  
 L  E12,49  
 L  E13,15  
 L  E13,16  
 L  E13,18  
 L  E13,21  
 L  E13,22  
 L  E13,23  
 L  E13,24  
 L  E13,26  
 L  E13,27  
 L  E13,31  
 L  E13,32  
 L  E13,34  
 L  E13,35  
 L  E13,38  
 L  E13,39  
 L  E13,40  
 L  E13,41  
 L  E13,42  
 L  E13,43  
 L  E13,44  
 L  E13,45  
 L  E13,47  
 L  E13,49  
 L  E14,15  
 L  E14,16  
 L  E14,17  
 L  E14,18  
 L  E14,19  
 L  E14,20  
 L  E14,22  
 L  E14,23  
 L  E14,24  
 L  E14,25  
 L  E14,26  
 L  E14,27  
 L  E14,30  
 L  E14,31  
 L  E14,32  
 L  E14,33  
 L  E14,36  
 L  E14,37  
 L  E14,39  
 L  E14,40  
 L  E14,41  
 L  E14,46  
 L  E14,47  
 L  E14,48  
 L  E15,16  
 L  E15,17  
 L  E15,19  
 L  E15,20  
 L  E15,21  
 L  E15,22  
 L  E15,23  
 L  E15,24  
 L  E15,26  
 L  E15,27  
 L  E15,28  
 L  E15,29  
 L  E15,30  
 L  E15,32  
 L  E15,33  
 L  E15,34  
 L  E15,37  
 L  E15,38  
 L  E15,40  
 L  E15,41  
 L  E15,44  
 L  E15,45  
 L  E15,46  
 L  E15,48  
 L  E16,17  
 L  E16,18  
 L  E16,19  
 L  E16,22  
 L  E16,23  
 L  E16,26  
 L  E16,27  
 L  E16,28  
 L  E16,29  
 L  E16,30  
 L  E16,31  
 L  E16,37  
 L  E16,38  
 L  E16,39  
 L  E16,40  
 L  E16,41  
 L  E16,44  
 L  E16,46  
 L  E16,47  
 L  E16,48  
 L  E16,49  
 L  E17,18  
 L  E17,19  
 L  E17,20  
 L  E17,21  
 L  E17,22  
 L  E17,23  
 L  E17,27  
 L  E17,29  
 L  E17,30  
 L  E17,31  
 L  E17,32  
 L  E17,33  
 L  E17,35  
 L  E17,36  
 L  E17,39  
 L  E17,40  
 L  E17,41  
 L  E17,42  
 L  E17,43  
 L  E17,44  
 L  E17,46  
 L  E17,47  
 L  E17,49  
 L  E18,21  
 L  E18,22  
 L  E18,23  
 L  E18,24  
 L  E18,26  
 L  E18,27  
 L  E18,31  
 L  E18,32  
 L  E18,33  
 L  E18,34  
 L  E18,35  
 L  E18,36  
 L  E18,37  
 L  E18,38  
 L  E18,40  
 L  E18,42  
 L  E18,43  
 L  E18,45  
 L  E18,46  
 L  E18,47  
 L  E18,48  
 L  E18,49  
 L  E19,21  
 L  E19,23  
 L  E19,24  
 L  E19,25  
 L  E19,26  
 L  E19,28  
 L  E19,29  
 L  E19,30  
 L  E19,31  
 L  E19,32  
 L  E19,34  
 L  E19,37  
 L  E19,38  
 L  E19,39  
 L  E19,40  
 L  E19,41  
 L  E19,44  
 L  E19,45  
 L  E19,46  
 L  E19,47  
 L  E19,48  
 L  E19,49  
 L  E20,21  
 L  E20,22  
 L  E20,23  
 L  E20,24  
 L  E20,26  
 L  E20,27  
 L  E20,29  
 L  E20,30  
 L  E20,32  
 L  E20,33  
 L  E20,35  
 L  E20,37  
 L  E20,39  
 L  E20,40  
 L  E20,41  
 L  E20,43  
 L  E20,44  
 L  E20,45  
 L  E20,47  
 L  E20,48  
 L  E20,49  
 L  E21,22  
 L  E21,25  
 L  E21,26  
 L  E21,27  
 L  E21,29  
 L  E21,33  
 L  E21,34  
 L  E21,35  
 L  E21,36  
 L  E21,38  
 L  E21,39  
 L  E21,42  
 L  E21,44  
 L  E21,45  
 L  E21,47  
 L  E21,49  
 L  E22,23  
 L  E22,24  
 L  E22,25  
 L  E22,26  
 L  E22,27  
 L  E22,29  
 L  E22,30  
 L  E22,31  
 L  E22,35  
 L  E22,36  
 L  E22,38  
 L  E22,39  
 L  E22,40  
 L  E22,42  
 L  E22,43  
 L  E22,45  
 L  E22,47  
 L  E22,48  
 L  E23,25  
 L  E23,26  
 L  E23,27  
 L  E23,28  
 L  E23,29  
 L  E23,30  
 L  E23,31  
 L  E23,32  
 L  E23,33  
 L  E23,34  
 L  E23,35  
 L  E23,37  
 L  E23,39  
 L  E23,40  
 L  E23,42  
 L  E23,44  
 L  E23,46  
 L  E23,47  
 L  E23,48  
 L  E24,25  
 L  E24,26  
 L  E24,27  
 L  E24,29  
 L  E24,30  
 L  E24,32  
 L  E24,33  
 L  E24,35  
 L  E24,36  
 L  E24,38  
 L  E24,41  
 L  E24,42  
 L  E24,43  
 L  E24,44  
 L  E24,46  
 L  E24,49  
 L  E25,26  
 L  E25,27  
 L  E25,28  
 L  E25,30  
 L  E25,31  
 L  E25,33  
 L  E25,34  
 L  E25,35  
 L  E25,36  
 L  E25,40  
 L  E25,41  
 L  E25,42  
 L  E25,44  
 L  E25,46  
 L  E25,47  
 L  E25,48  
 L  E25,49  
 L  E26,27  
 L  E26,28  
 L  E26,29  
 L  E26,30  
 L  E26,31  
 L  E26,32  
 L  E26,34  
 L  E26,35  
 L  E26,37  
 L  E26,38  
 L  E26,40  
 L  E26,41  
 L  E26,42  
 L  E26,44  
 L  E26,45  
 L  E26,46  
 L  E26,48  
 L  E26,49  
 L  E27,28  
 L  E27,29  
 L  E27,30  
 L  E27,31  
 L  E27,34  
 L  E27,35  
 L  E27,36  
 L  E27,40  
 L  E27,42  
 L  E27,43  
 L  E27,44  
 L  E27,45  
 L  E27,47  
 L  E27,48  
 L  E27,49  
 L  E28,31  
 L  E28,32  
 L  E28,33  
 L  E28,34  
 L  E28,35  
 L  E28,36  
 L  E28,37  
 L  E28,38  
 L  E28,39  
 L  E28,40  
 L  E28,41  
 L  E28,42  
 L  E28,43  
 L  E28,44  
 L  E28,45  
 L  E28,46  
 L  E28,48  
 L  E28,49  
 L  E29,30  
 L  E29,31  
 L  E29,32  
 L  E29,34  
 L  E29,35  
 L  E29,36  
 L  E29,37  
 L  E29,38  
 L  E29,39  
 L  E29,40  
 L  E29,42  
 L  E29,43  
 L  E29,44  
 L  E29,45  
 L  E29,47  
 L  E29,48  
 L  E29,49  
 L  E30,32  
 L  E30,33  
 L  E30,34  
 L  E30,35  
 L  E30,36  
 L  E30,37  
 L  E30,38  
 L  E30,39  
 L  E30,40  
 L  E30,43  
 L  E30,44  
 L  E30,45  
 L  E30,46  
 L  E30,47  
 L  E30,49  
 L  E31,34  
 L  E31,35  
 L  E31,36  
 L  E31,37  
 L  E31,39  
 L  E31,40  
 L  E31,41  
 L  E31,43  
 L  E31,45  
 L  E31,46  
 L  E31,48  
 L  E31,49  
 L  E32,33  
 L  E32,34  
 L  E32,37  
 L  E32,38  
 L  E32,39  
 L  E32,40  
 L  E32,41  
 L  E32,42  
 L  E32,43  
 L  E32,46  
 L  E32,47  
 L  E32,48  
 L  E32,49  
 L  E33,34  
 L  E33,36  
 L  E33,37  
 L  E33,38  
 L  E33,39  
 L  E33,42  
 L  E33,44  
 L  E33,45  
 L  E33,46  
 L  E33,48  
 L  E33,49  
 L  E34,36  
 L  E34,38  
 L  E34,40  
 L  E34,43  
 L  E34,44  
 L  E34,45  
 L  E34,46  
 L  E34,47  
 L  E34,49  
 L  E35,36  
 L  E35,37  
 L  E35,38  
 L  E35,39  
 L  E35,40  
 L  E35,43  
 L  E35,44  
 L  E35,46  
 L  E35,47  
 L  E35,49  
 L  E36,37  
 L  E36,38  
 L  E36,40  
 L  E36,41  
 L  E36,44  
 L  E36,45  
 L  E36,46  
 L  E36,47  
 L  E36,48  
 L  E36,49  
 L  E37,39  
 L  E37,40  
 L  E37,42  
 L  E37,43  
 L  E37,44  
 L  E37,45  
 L  E37,46  
 L  E37,47  
 L  E37,48  
 L  E37,49  
 L  E38,39  
 L  E38,40  
 L  E38,42  
 L  E38,43  
 L  E38,44  
 L  E38,45  
 L  E38,46  
 L  E38,48  
 L  E38,49  
 L  E39,41  
 L  E39,42  
 L  E39,44  
 L  E39,45  
 L  E39,49  
 L  E40,43  
 L  E40,45  
 L  E40,47  
 L  E40,48  
 L  E41,42  
 L  E41,43  
 L  E41,44  
 L  E41,45  
 L  E41,46  
 L  E41,47  
 L  E41,48  
 L  E42,43  
 L  E42,45  
 L  E42,46  
 L  E42,48  
 L  E42,49  
 L  E43,45  
 L  E43,46  
 L  E43,47  
 L  E43,49  
 L  E44,45  
 L  E44,46  
 L  E44,48  
 L  E44,49  
 L  E45,47  
 L  E46,47  
 L  E46,48  
 L  E46,49  
 L  E47,48  
 L  E47,49  
 L  I0,1    
 L  I0,2    
 L  I0,3    
 L  I0,4    
 L  I0,5    
 L  I0,6    
 L  I0,7    
 L  I0,8    
 L  I0,10   
 L  I0,12   
 L  I0,14   
 L  I0,15   
 L  I0,16   
 L  I0,17   
 L  I0,19   
 L  I0,20   
 L  I0,21   
 L  I0,22   
 L  I0,23   
 L  I0,24   
 L  I0,26   
 L  I0,27   
 L  I0,29   
 L  I0,32   
 L  I0,33   
 L  I0,34   
 L  I0,35   
 L  I0,37   
 L  I0,38   
 L  I0,39   
 L  I0,40   
 L  I0,41   
 L  I0,42   
 L  I0,43   
 L  I0,45   
 L  I0,46   
 L  I0,47   
 L  I1,3    
 L  I1,4    
 L  I1,5    
 L  I1,6    
 L  I1,7    
 L  I1,8    
 L  I1,9    
 L  I1,11   
 L  I1,12   
 L  I1,13   
 L  I1,16   
 L  I1,17   
 L  I1,18   
 L  I1,20   
 L  I1,21   
 L  I1,22   
 L  I1,23   
 L  I1,24   
 L  I1,25   
 L  I1,26   
 L  I1,27   
 L  I1,29   
 L  I1,30   
 L  I1,31   
 L  I1,33   
 L  I1,34   
 L  I1,35   
 L  I1,36   
 L  I1,37   
 L  I1,40   
 L  I1,41   
 L  I1,44   
 L  I1,48   
 L  I2,3    
 L  I2,4    
 L  I2,5    
 L  I2,7    
 L  I2,10   
 L  I2,12   
 L  I2,14   
 L  I2,16   
 L  I2,18   
 L  I2,19   
 L  I2,20   
 L  I2,21   
 L  I2,26   
 L  I2,28   
 L  I2,29   
 L  I2,31   
 L  I2,32   
 L  I2,33   
 L  I2,34   
 L  I2,35   
 L  I2,36   
 L  I2,37   
 L  I2,38   
 L  I2,39   
 L  I2,40   
 L  I2,44   
 L  I2,45   
 L  I2,46   
 L  I2,48   
 L  I2,49   
 L  I3,4    
 L  I3,6    
 L  I3,7    
 L  I3,8    
 L  I3,9    
 L  I3,10   
 L  I3,11   
 L  I3,12   
 L  I3,13   
 L  I3,14   
 L  I3,15   
 L  I3,16   
 L  I3,17   
 L  I3,18   
 L  I3,21   
 L  I3,22   
 L  I3,24   
 L  I3,25   
 L  I3,26   
 L  I3,29   
 L  I3,30   
 L  I3,31   
 L  I3,33   
 L  I3,35   
 L  I3,36   
 L  I3,37   
 L  I3,38   
 L  I3,43   
 L  I3,45   
 L  I3,47   
 L  I4,5    
 L  I4,9    
 L  I4,11   
 L  I4,12   
 L  I4,13   
 L  I4,14   
 L  I4,15   
 L  I4,16   
 L  I4,17   
 L  I4,19   
 L  I4,22   
 L  I4,23   
 L  I4,24   
 L  I4,25   
 L  I4,26   
 L  I4,27   
 L  I4,31   
 L  I4,32   
 L  I4,33   
 L  I4,34   
 L  I4,35   
 L  I4,36   
 L  I4,37   
 L  I4,38   
 L  I4,40   
 L  I4,41   
 L  I4,42   
 L  I4,44   
 L  I4,45   
 L  I4,46   
 L  I4,47   
 L  I4,48   
 L  I5,6    
 L  I5,7    
 L  I5,8    
 L  I5,9    
 L  I5,10   
 L  I5,11   
 L  I5,12   
 L  I5,13   
 L  I5,14   
 L  I5,15   
 L  I5,16   
 L  I5,17   
 L  I5,19   
 L  I5,20   
 L  I5,22   
 L  I5,23   
 L  I5,24   
 L  I5,25   
 L  I5,26   
 L  I5,27   
 L  I5,28   
 L  I5,30   
 L  I5,31   
 L  I5,33   
 L  I5,35   
 L  I5,38   
 L  I5,39   
 L  I5,40   
 L  I5,41   
 L  I5,42   
 L  I5,45   
 L  I5,47   
 L  I5,48   
 L  I5,49   
 L  I6,9    
 L  I6,10   
 L  I6,11   
 L  I6,13   
 L  I6,16   
 L  I6,17   
 L  I6,21   
 L  I6,23   
 L  I6,24   
 L  I6,26   
 L  I6,27   
 L  I6,28   
 L  I6,29   
 L  I6,30   
 L  I6,31   
 L  I6,32   
 L  I6,34   
 L  I6,35   
 L  I6,36   
 L  I6,38   
 L  I6,43   
 L  I6,46   
 L  I6,47   
 L  I6,49   
 L  I7,8    
 L  I7,9    
 L  I7,10   
 L  I7,13   
 L  I7,14   
 L  I7,15   
 L  I7,16   
 L  I7,20   
 L  I7,21   
 L  I7,25   
 L  I7,26   
 L  I7,27   
 L  I7,28   
 L  I7,29   
 L  I7,30   
 L  I7,31   
 L  I7,32   
 L  I7,33   
 L  I7,38   
 L  I7,39   
 L  I7,40   
 L  I7,46   
 L  I7,49   
 L  I8,9    
 L  I8,12   
 L  I8,13   
 L  I8,14   
 L  I8,16   
 L  I8,18   
 L  I8,19   
 L  I8,20   
 L  I8,21   
 L  I8,22   
 L  I8,25   
 L  I8,29   
 L  I8,30   
 L  I8,33   
 L  I8,34   
 L  I8,35   
 L  I8,37   
 L  I8,39   
 L  I8,40   
 L  I8,41   
 L  I8,42   
 L  I8,43   
 L  I8,44   
 L  I8,45   
 L  I8,47   
 L  I8,48   
 L  I8,49   
 L  I9,10   
 L  I9,11   
 L  I9,12   
 L  I9,13   
 L  I9,14   
 L  I9,15   
 L  I9,17   
 L  I9,19   
 L  I9,20   
 L  I9,21   
 L  I9,23   
 L  I9,24   
 L  I9,25   
 L  I9,26   
 L  I9,27   
 L  I9,28   
 L  I9,29   
 L  I9,30   
 L  I9,33   
 L  I9,34   
 L  I9,35   
 L  I9,37   
 L  I9,38   
 L  I9,39   
 L  I9,40   
 L  I9,41   
 L  I9,42   
 L  I9,45   
 L  I9,47   
 L  I9,48   
 L  I9,49   
 L  I10,11  
 L  I10,12  
 L  I10,13  
 L  I10,14  
 L  I10,15  
 L  I10,16  
 L  I10,20  
 L  I10,21  
 L  I10,23  
 L  I10,24  
 L  I10,27  
 L  I10,28  
 L  I10,29  
 L  I10,30  
 L  I10,31  
 L  I10,32  
 L  I10,33  
 L  I10,34  
 L  I10,35  
 L  I10,36  
 L  I10,37  
 L  I10,40  
 L  I10,41  
 L  I10,42  
 L  I10,43  
 L  I10,44  
 L  I10,45  
 L  I10,46  
 L  I10,48  
 L  I10,49  
 L  I11,12  
 L  I11,14  
 L  I11,15  
 L  I11,16  
 L  I11,18  
 L  I11,20  
 L  I11,21  
 L  I11,22  
 L  I11,23  
 L  I11,25  
 L  I11,27  
 L  I11,28  
 L  I11,29  
 L  I11,30  
 L  I11,31  
 L  I11,33  
 L  I11,34  
 L  I11,35  
 L  I11,36  
 L  I11,37  
 L  I11,38  
 L  I11,39  
 L  I11,40  
 L  I11,42  
 L  I11,43  
 L  I11,44  
 L  I11,46  
 L  I11,47  
 L  I11,48  
 L  I12,13  
 L  I12,14  
 L  I12,15  
 L  I12,17  
 L  I12,20  
 L  I12,21  
 L  I12,23  
 L  I12,24  
 L  I12,25  
 L  I12,26  
 L  I12,27  
 L  I12,28  
 L  I12,29  
 L  I12,30  
 L  I12,32  
 L  I12,33  
 L  I12,34  
 L  I12,35  
 L  I12,36  
 L  I12,37  
 L  I12,38  
 L  I12,39  
 L  I12,40  
 L  I12,41  
 L  I12,42  
 L  I12,44  
 L  I12,46  
 L  I12,47  
 L  I12,49  
 L  I13,15  
 L  I13,16  
 L  I13,18  
 L  I13,21  
 L  I13,22  
 L  I13,23  
 L  I13,24  
 L  I13,26  
 L  I13,27  
 L  I13,31  
 L  I13,32  
 L  I13,34  
 L  I13,35  
 L  I13,38  
 L  I13,39  
 L  I13,40  
 L  I13,41  
 L  I13,42  
 L  I13,43  
 L  I13,44  
 L  I13,45  
 L  I13,47  
 L  I13,49  
 L  I14,15  
 L  I14,16  
 L  I14,17  
 L  I14,18  
 L  I14,19  
 L  I14,20  
 L  I14,22  
 L  I14,23  
 L  I14,24  
 L  I14,25  
 L  I14,26  
 L  I14,27  
 L  I14,30  
 L  I14,31  
 L  I14,32  
 L  I14,33  
 L  I14,36  
 L  I14,37  
 L  I14,39  
 L  I14,40  
 L  I14,41  
 L  I14,46  
 L  I14,47  
 L  I14,48  
 L  I15,16  
 L  I15,17  
 L  I15,19  
 L  I15,20  
 L  I15,21  
 L  I15,22  
 L  I15,23  
 L  I15,24  
 L  I15,26  
 L  I15,27  
 L  I15,28  
 L  I15,29  
 L  I15,30  
 L  I15,32  
 L  I15,33  
 L  I15,34  
 L  I15,37  
 L  I15,38  
 L  I15,40  
 L  I15,41  
 L  I15,44  
 L  I15,45  
 L  I15,46  
 L  I15,48  
 L  I16,17  
 L  I16,18  
 L  I16,19  
 L  I16,22  
 L  I16,23  
 L  I16,26  
 L  I16,27  
 L  I16,28  
 L  I16,29  
 L  I16,30  
 L  I16,31  
 L  I16,37  
 L  I16,38  
 L  I16,39  
 L  I16,40  
 L  I16,41  
 L  I16,44  
 L  I16,46  
 L  I16,47  
 L  I16,48  
 L  I16,49  
 L  I17,18  
 L  I17,19  
 L  I17,20  
 L  I17,21  
 L  I17,22  
 L  I17,23  
 L  I17,27  
 L  I17,29  
 L  I17,30  
 L  I17,31  
 L  I17,32  
 L  I17,33  
 L  I17,35  
 L  I17,36  
 L  I17,39  
 L  I17,40  
 L  I17,41  
 L  I17,42  
 L  I17,43  
 L  I17,44  
 L  I17,46  
 L  I17,47  
 L  I17,49  
 L  I18,21  
 L  I18,22  
 L  I18,23  
 L  I18,24  
 L  I18,26  
 L  I18,27  
 L  I18,31  
 L  I18,32  
 L  I18,33  
 L  I18,34  
 L  I18,35  
 L  I18,36  
 L  I18,37  
 L  I18,38  
 L  I18,40  
 L  I18,42  
 L  I18,43  
 L  I18,45  
 L  I18,46  
 L  I18,47  
 L  I18,48  
 L  I18,49  
 L  I19,21  
 L  I19,23  
 L  I19,24  
 L  I19,25  
 L  I19,26  
 L  I19,28  
 L  I19,29  
 L  I19,30  
 L  I19,31  
 L  I19,32  
 L  I19,34  
 L  I19,37  
 L  I19,38  
 L  I19,39  
 L  I19,40  
 L  I19,41  
 L  I19,44  
 L  I19,45  
 L  I19,46  
 L  I19,47  
 L  I19,48  
 L  I19,49  
 L  I20,21  
 L  I20,22  
 L  I20,23  
 L  I20,24  
 L  I20,26  
 L  I20,27  
 L  I20,29  
 L  I20,30  
 L  I20,32  
 L  I20,33  
 L  I20,35  
 L  I20,37  
 L  I20,39  
 L  I20,40  
 L  I20,41  
 L  I20,43  
 L  I20,44  
 L  I20,45  
 L  I20,47  
 L  I20,48  
 L  I20,49  
 L  I21,22  
 L  I21,25  
 L  I21,26  
 L  I21,27  
 L  I21,29  
 L  I21,33  
 L  I21,34  
 L  I21,35  
 L  I21,36  
 L  I21,38  
 L  I21,39  
 L  I21,42  
 L  I21,44  
 L  I21,45  
 L  I21,47  
 L  I21,49  
 L  I22,23  
 L  I22,24  
 L  I22,25  
 L  I22,26  
 L  I22,27  
 L  I22,29  
 L  I22,30  
 L  I22,31  
 L  I22,35  
 L  I22,36  
 L  I22,38  
 L  I22,39  
 L  I22,40  
 L  I22,42  
 L  I22,43  
 L  I22,45  
 L  I22,47  
 L  I22,48  
 L  I23,25  
 L  I23,26  
 L  I23,27  
 L  I23,28  
 L  I23,29  
 L  I23,30  
 L  I23,31  
 L  I23,32  
 L  I23,33  
 L  I23,34  
 L  I23,35  
 L  I23,37  
 L  I23,39  
 L  I23,40  
 L  I23,42  
 L  I23,44  
 L  I23,46  
 L  I23,47  
 L  I23,48  
 L  I24,25  
 L  I24,26  
 L  I24,27  
 L  I24,29  
 L  I24,30  
 L  I24,32  
 L  I24,33  
 L  I24,35  
 L  I24,36  
 L  I24,38  
 L  I24,41  
 L  I24,42  
 L  I24,43  
 L  I24,44  
 L  I24,46  
 L  I24,49  
 L  I25,26  
 L  I25,27  
 L  I25,28  
 L  I25,30  
 L  I25,31  
 L  I25,33  
 L  I25,34  
 L  I25,35  
 L  I25,36  
 L  I25,40  
 L  I25,41  
 L  I25,42  
 L  I25,44  
 L  I25,46  
 L  I25,47  
 L  I25,48  
 L  I25,49  
 L  I26,27  
 L  I26,28  
 L  I26,29  
 L  I26,30  
 L  I26,31  
 L  I26,32  
 L  I26,34  
 L  I26,35  
 L  I26,37  
 L  I26,38  
 L  I26,40  
 L  I26,41  
 L  I26,42  
 L  I26,44  
 L  I26,45  
 L  I26,46  
 L  I26,48  
 L  I26,49  
 L  I27,28  
 L  I27,29  
 L  I27,30  
 L  I27,31  
 L  I27,34  
 L  I27,35  
 L  I27,36  
 L  I27,40  
 L  I27,42  
 L  I27,43  
 L  I27,44  
 L  I27,45  
 L  I27,47  
 L  I27,48  
 L  I27,49  
 L  I28,31  
 L  I28,32  
 L  I28,33  
 L  I28,34  
 L  I28,35  
 L  I28,36  
 L  I28,37  
 L  I28,38  
 L  I28,39  
 L  I28,40  
 L  I28,41  
 L  I28,42  
 L  I28,43  
 L  I28,44  
 L  I28,45  
 L  I28,46  
 L  I28,48  
 L  I28,49  
 L  I29,30  
 L  I29,31  
 L  I29,32  
 L  I29,34  
 L  I29,35  
 L  I29,36  
 L  I29,37  
 L  I29,38  
 L  I29,39  
 L  I29,40  
 L  I29,42  
 L  I29,43  
 L  I29,44  
 L  I29,45  
 L  I29,47  
 L  I29,48  
 L  I29,49  
 L  I30,32  
 L  I30,33  
 L  I30,34  
 L  I30,35  
 L  I30,36  
 L  I30,37  
 L  I30,38  
 L  I30,39  
 L  I30,40  
 L  I30,43  
 L  I30,44  
 L  I30,45  
 L  I30,46  
 L  I30,47  
 L  I30,49  
 L  I31,34  
 L  I31,35  
 L  I31,36  
 L  I31,37  
 L  I31,39  
 L  I31,40  
 L  I31,41  
 L  I31,43  
 L  I31,45  
 L  I31,46  
 L  I31,48  
 L  I31,49  
 L  I32,33  
 L  I32,34  
 L  I32,37  
 L  I32,38  
 L  I32,39  
 L  I32,40  
 L  I32,41  
 L  I32,42  
 L  I32,43  
 L  I32,46  
 L  I32,47  
 L  I32,48  
 L  I32,49  
 L  I33,34  
 L  I33,36  
 L  I33,37  
 L  I33,38  
 L  I33,39  
 L  I33,42  
 L  I33,44  
 L  I33,45  
 L  I33,46  
 L  I33,48  
 L  I33,49  
 L  I34,36  
 L  I34,38  
 L  I34,40  
 L  I34,43  
 L  I34,44  
 L  I34,45  
 L  I34,46  
 L  I34,47  
 L  I34,49  
 L  I35,36  
 L  I35,37  
 L  I35,38  
 L  I35,39  
 L  I35,40  
 L  I35,43  
 L  I35,44  
 L  I35,46  
 L  I35,47  
 L  I35,49  
 L  I36,37  
 L  I36,38  
 L  I36,40  
 L  I36,41  
 L  I36,44  
 L  I36,45  
 L  I36,46  
 L  I36,47  
 L  I36,48  
 L  I36,49  
 L  I37,39  
 L  I37,40  
 L  I37,42  
 L  I37,43  
 L  I37,44  
 L  I37,45  
 L  I37,46  
 L  I37,47  
 L  I37,48  
 L  I37,49  
 L  I38,39  
 L  I38,40  
 L  I38,42  
 L  I38,43  
 L  I38,44  
 L  I38,45  
 L  I38,46  
 L  I38,48  
 L  I38,49  
 L  I39,41  
 L  I39,42  
 L  I39,44  
 L  I39,45  
 L  I39,49  
 L  I40,43  
 L  I40,45  
 L  I40,47  
 L  I40,48  
 L  I41,42  
 L  I41,43  
 L  I41,44  
 L  I41,45  
 L  I41,46  
 L  I41,47  
 L  I41,48  
 L  I42,43  
 L  I42,45  
 L  I42,46  
 L  I42,48  
 L  I42,49  
 L  I43,45  
 L  I43,46  
 L  I43,47  
 L  I43,49  
 L  I44,45  
 L  I44,46  
 L  I44,48  
 L  I44,49  
 L  I45,47  
 L  I46,47  
 L  I46,48  
 L  I46,49  
 L  I47,48  
 L  I47,49  
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    w0,1      KL                              1
    w0,1      I0,1                            1
    w0,2      KL                              1
    w0,2      I0,2                            1
    w0,3      KL                              1
    w0,3      I0,3                            1
    w0,4      KL                              1
    w0,4      I0,4                            1
    w0,5      KL                              1
    w0,5      I0,5                            1
    w0,6      KL                              1
    w0,6      I0,6                            1
    w0,7      KL                              1
    w0,7      I0,7                            1
    w0,8      KL                              1
    w0,8      I0,8                            1
    w0,10     KL                              1
    w0,10     I0,10                           1
    w0,12     KL                              1
    w0,12     I0,12                           1
    w0,14     KL                              1
    w0,14     I0,14                           1
    w0,15     KL                              1
    w0,15     I0,15                           1
    w0,16     KL                              1
    w0,16     I0,16                           1
    w0,17     KL                              1
    w0,17     I0,17                           1
    w0,19     KL                              1
    w0,19     I0,19                           1
    w0,20     KL                              1
    w0,20     I0,20                           1
    w0,21     KL                              1
    w0,21     I0,21                           1
    w0,22     KL                              1
    w0,22     I0,22                           1
    w0,23     KL                              1
    w0,23     I0,23                           1
    w0,24     KL                              1
    w0,24     I0,24                           1
    w0,26     KL                              1
    w0,26     I0,26                           1
    w0,27     KL                              1
    w0,27     I0,27                           1
    w0,29     KL                              1
    w0,29     I0,29                           1
    w0,32     KL                              1
    w0,32     I0,32                           1
    w0,33     KL                              1
    w0,33     I0,33                           1
    w0,34     KL                              1
    w0,34     I0,34                           1
    w0,35     KL                              1
    w0,35     I0,35                           1
    w0,37     KL                              1
    w0,37     I0,37                           1
    w0,38     KL                              1
    w0,38     I0,38                           1
    w0,39     KL                              1
    w0,39     I0,39                           1
    w0,40     KL                              1
    w0,40     I0,40                           1
    w0,41     KL                              1
    w0,41     I0,41                           1
    w0,42     KL                              1
    w0,42     I0,42                           1
    w0,43     KL                              1
    w0,43     I0,43                           1
    w0,45     KL                              1
    w0,45     I0,45                           1
    w0,46     KL                              1
    w0,46     I0,46                           1
    w0,47     KL                              1
    w0,47     I0,47                           1
    w1,3      KL                              1
    w1,3      I1,3                            1
    w1,4      KL                              1
    w1,4      I1,4                            1
    w1,5      KL                              1
    w1,5      I1,5                            1
    w1,6      KL                              1
    w1,6      I1,6                            1
    w1,7      KL                              1
    w1,7      I1,7                            1
    w1,8      KL                              1
    w1,8      I1,8                            1
    w1,9      KL                              1
    w1,9      I1,9                            1
    w1,11     KL                              1
    w1,11     I1,11                           1
    w1,12     KL                              1
    w1,12     I1,12                           1
    w1,13     KL                              1
    w1,13     I1,13                           1
    w1,16     KL                              1
    w1,16     I1,16                           1
    w1,17     KL                              1
    w1,17     I1,17                           1
    w1,18     KL                              1
    w1,18     I1,18                           1
    w1,20     KL                              1
    w1,20     I1,20                           1
    w1,21     KL                              1
    w1,21     I1,21                           1
    w1,22     KL                              1
    w1,22     I1,22                           1
    w1,23     KL                              1
    w1,23     I1,23                           1
    w1,24     KL                              1
    w1,24     I1,24                           1
    w1,25     KL                              1
    w1,25     I1,25                           1
    w1,26     KL                              1
    w1,26     I1,26                           1
    w1,27     KL                              1
    w1,27     I1,27                           1
    w1,29     KL                              1
    w1,29     I1,29                           1
    w1,30     KL                              1
    w1,30     I1,30                           1
    w1,31     KL                              1
    w1,31     I1,31                           1
    w1,33     KL                              1
    w1,33     I1,33                           1
    w1,34     KL                              1
    w1,34     I1,34                           1
    w1,35     KL                              1
    w1,35     I1,35                           1
    w1,36     KL                              1
    w1,36     I1,36                           1
    w1,37     KL                              1
    w1,37     I1,37                           1
    w1,40     KL                              1
    w1,40     I1,40                           1
    w1,41     KL                              1
    w1,41     I1,41                           1
    w1,44     KL                              1
    w1,44     I1,44                           1
    w1,48     KL                              1
    w1,48     I1,48                           1
    w2,3      KL                              1
    w2,3      I2,3                            1
    w2,4      KL                              1
    w2,4      I2,4                            1
    w2,5      KL                              1
    w2,5      I2,5                            1
    w2,7      KL                              1
    w2,7      I2,7                            1
    w2,10     KL                              1
    w2,10     I2,10                           1
    w2,12     KL                              1
    w2,12     I2,12                           1
    w2,14     KL                              1
    w2,14     I2,14                           1
    w2,16     KL                              1
    w2,16     I2,16                           1
    w2,18     KL                              1
    w2,18     I2,18                           1
    w2,19     KL                              1
    w2,19     I2,19                           1
    w2,20     KL                              1
    w2,20     I2,20                           1
    w2,21     KL                              1
    w2,21     I2,21                           1
    w2,26     KL                              1
    w2,26     I2,26                           1
    w2,28     KL                              1
    w2,28     I2,28                           1
    w2,29     KL                              1
    w2,29     I2,29                           1
    w2,31     KL                              1
    w2,31     I2,31                           1
    w2,32     KL                              1
    w2,32     I2,32                           1
    w2,33     KL                              1
    w2,33     I2,33                           1
    w2,34     KL                              1
    w2,34     I2,34                           1
    w2,35     KL                              1
    w2,35     I2,35                           1
    w2,36     KL                              1
    w2,36     I2,36                           1
    w2,37     KL                              1
    w2,37     I2,37                           1
    w2,38     KL                              1
    w2,38     I2,38                           1
    w2,39     KL                              1
    w2,39     I2,39                           1
    w2,40     KL                              1
    w2,40     I2,40                           1
    w2,44     KL                              1
    w2,44     I2,44                           1
    w2,45     KL                              1
    w2,45     I2,45                           1
    w2,46     KL                              1
    w2,46     I2,46                           1
    w2,48     KL                              1
    w2,48     I2,48                           1
    w2,49     KL                              1
    w2,49     I2,49                           1
    w3,4      KL                              1
    w3,4      I3,4                            1
    w3,6      KL                              1
    w3,6      I3,6                            1
    w3,7      KL                              1
    w3,7      I3,7                            1
    w3,8      KL                              1
    w3,8      I3,8                            1
    w3,9      KL                              1
    w3,9      I3,9                            1
    w3,10     KL                              1
    w3,10     I3,10                           1
    w3,11     KL                              1
    w3,11     I3,11                           1
    w3,12     KL                              1
    w3,12     I3,12                           1
    w3,13     KL                              1
    w3,13     I3,13                           1
    w3,14     KL                              1
    w3,14     I3,14                           1
    w3,15     KL                              1
    w3,15     I3,15                           1
    w3,16     KL                              1
    w3,16     I3,16                           1
    w3,17     KL                              1
    w3,17     I3,17                           1
    w3,18     KL                              1
    w3,18     I3,18                           1
    w3,21     KL                              1
    w3,21     I3,21                           1
    w3,22     KL                              1
    w3,22     I3,22                           1
    w3,24     KL                              1
    w3,24     I3,24                           1
    w3,25     KL                              1
    w3,25     I3,25                           1
    w3,26     KL                              1
    w3,26     I3,26                           1
    w3,29     KL                              1
    w3,29     I3,29                           1
    w3,30     KL                              1
    w3,30     I3,30                           1
    w3,31     KL                              1
    w3,31     I3,31                           1
    w3,33     KL                              1
    w3,33     I3,33                           1
    w3,35     KL                              1
    w3,35     I3,35                           1
    w3,36     KL                              1
    w3,36     I3,36                           1
    w3,37     KL                              1
    w3,37     I3,37                           1
    w3,38     KL                              1
    w3,38     I3,38                           1
    w3,43     KL                              1
    w3,43     I3,43                           1
    w3,45     KL                              1
    w3,45     I3,45                           1
    w3,47     KL                              1
    w3,47     I3,47                           1
    w4,5      KL                              1
    w4,5      I4,5                            1
    w4,9      KL                              1
    w4,9      I4,9                            1
    w4,11     KL                              1
    w4,11     I4,11                           1
    w4,12     KL                              1
    w4,12     I4,12                           1
    w4,13     KL                              1
    w4,13     I4,13                           1
    w4,14     KL                              1
    w4,14     I4,14                           1
    w4,15     KL                              1
    w4,15     I4,15                           1
    w4,16     KL                              1
    w4,16     I4,16                           1
    w4,17     KL                              1
    w4,17     I4,17                           1
    w4,19     KL                              1
    w4,19     I4,19                           1
    w4,22     KL                              1
    w4,22     I4,22                           1
    w4,23     KL                              1
    w4,23     I4,23                           1
    w4,24     KL                              1
    w4,24     I4,24                           1
    w4,25     KL                              1
    w4,25     I4,25                           1
    w4,26     KL                              1
    w4,26     I4,26                           1
    w4,27     KL                              1
    w4,27     I4,27                           1
    w4,31     KL                              1
    w4,31     I4,31                           1
    w4,32     KL                              1
    w4,32     I4,32                           1
    w4,33     KL                              1
    w4,33     I4,33                           1
    w4,34     KL                              1
    w4,34     I4,34                           1
    w4,35     KL                              1
    w4,35     I4,35                           1
    w4,36     KL                              1
    w4,36     I4,36                           1
    w4,37     KL                              1
    w4,37     I4,37                           1
    w4,38     KL                              1
    w4,38     I4,38                           1
    w4,40     KL                              1
    w4,40     I4,40                           1
    w4,41     KL                              1
    w4,41     I4,41                           1
    w4,42     KL                              1
    w4,42     I4,42                           1
    w4,44     KL                              1
    w4,44     I4,44                           1
    w4,45     KL                              1
    w4,45     I4,45                           1
    w4,46     KL                              1
    w4,46     I4,46                           1
    w4,47     KL                              1
    w4,47     I4,47                           1
    w4,48     KL                              1
    w4,48     I4,48                           1
    w5,6      KL                              1
    w5,6      I5,6                            1
    w5,7      KL                              1
    w5,7      I5,7                            1
    w5,8      KL                              1
    w5,8      I5,8                            1
    w5,9      KL                              1
    w5,9      I5,9                            1
    w5,10     KL                              1
    w5,10     I5,10                           1
    w5,11     KL                              1
    w5,11     I5,11                           1
    w5,12     KL                              1
    w5,12     I5,12                           1
    w5,13     KL                              1
    w5,13     I5,13                           1
    w5,14     KL                              1
    w5,14     I5,14                           1
    w5,15     KL                              1
    w5,15     I5,15                           1
    w5,16     KL                              1
    w5,16     I5,16                           1
    w5,17     KL                              1
    w5,17     I5,17                           1
    w5,19     KL                              1
    w5,19     I5,19                           1
    w5,20     KL                              1
    w5,20     I5,20                           1
    w5,22     KL                              1
    w5,22     I5,22                           1
    w5,23     KL                              1
    w5,23     I5,23                           1
    w5,24     KL                              1
    w5,24     I5,24                           1
    w5,25     KL                              1
    w5,25     I5,25                           1
    w5,26     KL                              1
    w5,26     I5,26                           1
    w5,27     KL                              1
    w5,27     I5,27                           1
    w5,28     KL                              1
    w5,28     I5,28                           1
    w5,30     KL                              1
    w5,30     I5,30                           1
    w5,31     KL                              1
    w5,31     I5,31                           1
    w5,33     KL                              1
    w5,33     I5,33                           1
    w5,35     KL                              1
    w5,35     I5,35                           1
    w5,38     KL                              1
    w5,38     I5,38                           1
    w5,39     KL                              1
    w5,39     I5,39                           1
    w5,40     KL                              1
    w5,40     I5,40                           1
    w5,41     KL                              1
    w5,41     I5,41                           1
    w5,42     KL                              1
    w5,42     I5,42                           1
    w5,45     KL                              1
    w5,45     I5,45                           1
    w5,47     KL                              1
    w5,47     I5,47                           1
    w5,48     KL                              1
    w5,48     I5,48                           1
    w5,49     KL                              1
    w5,49     I5,49                           1
    w6,9      KL                              1
    w6,9      I6,9                            1
    w6,10     KL                              1
    w6,10     I6,10                           1
    w6,11     KL                              1
    w6,11     I6,11                           1
    w6,13     KL                              1
    w6,13     I6,13                           1
    w6,16     KL                              1
    w6,16     I6,16                           1
    w6,17     KL                              1
    w6,17     I6,17                           1
    w6,21     KL                              1
    w6,21     I6,21                           1
    w6,23     KL                              1
    w6,23     I6,23                           1
    w6,24     KL                              1
    w6,24     I6,24                           1
    w6,26     KL                              1
    w6,26     I6,26                           1
    w6,27     KL                              1
    w6,27     I6,27                           1
    w6,28     KL                              1
    w6,28     I6,28                           1
    w6,29     KL                              1
    w6,29     I6,29                           1
    w6,30     KL                              1
    w6,30     I6,30                           1
    w6,31     KL                              1
    w6,31     I6,31                           1
    w6,32     KL                              1
    w6,32     I6,32                           1
    w6,34     KL                              1
    w6,34     I6,34                           1
    w6,35     KL                              1
    w6,35     I6,35                           1
    w6,36     KL                              1
    w6,36     I6,36                           1
    w6,38     KL                              1
    w6,38     I6,38                           1
    w6,43     KL                              1
    w6,43     I6,43                           1
    w6,46     KL                              1
    w6,46     I6,46                           1
    w6,47     KL                              1
    w6,47     I6,47                           1
    w6,49     KL                              1
    w6,49     I6,49                           1
    w7,8      KL                              1
    w7,8      I7,8                            1
    w7,9      KL                              1
    w7,9      I7,9                            1
    w7,10     KL                              1
    w7,10     I7,10                           1
    w7,13     KL                              1
    w7,13     I7,13                           1
    w7,14     KL                              1
    w7,14     I7,14                           1
    w7,15     KL                              1
    w7,15     I7,15                           1
    w7,16     KL                              1
    w7,16     I7,16                           1
    w7,20     KL                              1
    w7,20     I7,20                           1
    w7,21     KL                              1
    w7,21     I7,21                           1
    w7,25     KL                              1
    w7,25     I7,25                           1
    w7,26     KL                              1
    w7,26     I7,26                           1
    w7,27     KL                              1
    w7,27     I7,27                           1
    w7,28     KL                              1
    w7,28     I7,28                           1
    w7,29     KL                              1
    w7,29     I7,29                           1
    w7,30     KL                              1
    w7,30     I7,30                           1
    w7,31     KL                              1
    w7,31     I7,31                           1
    w7,32     KL                              1
    w7,32     I7,32                           1
    w7,33     KL                              1
    w7,33     I7,33                           1
    w7,38     KL                              1
    w7,38     I7,38                           1
    w7,39     KL                              1
    w7,39     I7,39                           1
    w7,40     KL                              1
    w7,40     I7,40                           1
    w7,46     KL                              1
    w7,46     I7,46                           1
    w7,49     KL                              1
    w7,49     I7,49                           1
    w8,9      KL                              1
    w8,9      I8,9                            1
    w8,12     KL                              1
    w8,12     I8,12                           1
    w8,13     KL                              1
    w8,13     I8,13                           1
    w8,14     KL                              1
    w8,14     I8,14                           1
    w8,16     KL                              1
    w8,16     I8,16                           1
    w8,18     KL                              1
    w8,18     I8,18                           1
    w8,19     KL                              1
    w8,19     I8,19                           1
    w8,20     KL                              1
    w8,20     I8,20                           1
    w8,21     KL                              1
    w8,21     I8,21                           1
    w8,22     KL                              1
    w8,22     I8,22                           1
    w8,25     KL                              1
    w8,25     I8,25                           1
    w8,29     KL                              1
    w8,29     I8,29                           1
    w8,30     KL                              1
    w8,30     I8,30                           1
    w8,33     KL                              1
    w8,33     I8,33                           1
    w8,34     KL                              1
    w8,34     I8,34                           1
    w8,35     KL                              1
    w8,35     I8,35                           1
    w8,37     KL                              1
    w8,37     I8,37                           1
    w8,39     KL                              1
    w8,39     I8,39                           1
    w8,40     KL                              1
    w8,40     I8,40                           1
    w8,41     KL                              1
    w8,41     I8,41                           1
    w8,42     KL                              1
    w8,42     I8,42                           1
    w8,43     KL                              1
    w8,43     I8,43                           1
    w8,44     KL                              1
    w8,44     I8,44                           1
    w8,45     KL                              1
    w8,45     I8,45                           1
    w8,47     KL                              1
    w8,47     I8,47                           1
    w8,48     KL                              1
    w8,48     I8,48                           1
    w8,49     KL                              1
    w8,49     I8,49                           1
    w9,10     KL                              1
    w9,10     I9,10                           1
    w9,11     KL                              1
    w9,11     I9,11                           1
    w9,12     KL                              1
    w9,12     I9,12                           1
    w9,13     KL                              1
    w9,13     I9,13                           1
    w9,14     KL                              1
    w9,14     I9,14                           1
    w9,15     KL                              1
    w9,15     I9,15                           1
    w9,17     KL                              1
    w9,17     I9,17                           1
    w9,19     KL                              1
    w9,19     I9,19                           1
    w9,20     KL                              1
    w9,20     I9,20                           1
    w9,21     KL                              1
    w9,21     I9,21                           1
    w9,23     KL                              1
    w9,23     I9,23                           1
    w9,24     KL                              1
    w9,24     I9,24                           1
    w9,25     KL                              1
    w9,25     I9,25                           1
    w9,26     KL                              1
    w9,26     I9,26                           1
    w9,27     KL                              1
    w9,27     I9,27                           1
    w9,28     KL                              1
    w9,28     I9,28                           1
    w9,29     KL                              1
    w9,29     I9,29                           1
    w9,30     KL                              1
    w9,30     I9,30                           1
    w9,33     KL                              1
    w9,33     I9,33                           1
    w9,34     KL                              1
    w9,34     I9,34                           1
    w9,35     KL                              1
    w9,35     I9,35                           1
    w9,37     KL                              1
    w9,37     I9,37                           1
    w9,38     KL                              1
    w9,38     I9,38                           1
    w9,39     KL                              1
    w9,39     I9,39                           1
    w9,40     KL                              1
    w9,40     I9,40                           1
    w9,41     KL                              1
    w9,41     I9,41                           1
    w9,42     KL                              1
    w9,42     I9,42                           1
    w9,45     KL                              1
    w9,45     I9,45                           1
    w9,47     KL                              1
    w9,47     I9,47                           1
    w9,48     KL                              1
    w9,48     I9,48                           1
    w9,49     KL                              1
    w9,49     I9,49                           1
    w10,11    KL                              1
    w10,11    I10,11                          1
    w10,12    KL                              1
    w10,12    I10,12                          1
    w10,13    KL                              1
    w10,13    I10,13                          1
    w10,14    KL                              1
    w10,14    I10,14                          1
    w10,15    KL                              1
    w10,15    I10,15                          1
    w10,16    KL                              1
    w10,16    I10,16                          1
    w10,20    KL                              1
    w10,20    I10,20                          1
    w10,21    KL                              1
    w10,21    I10,21                          1
    w10,23    KL                              1
    w10,23    I10,23                          1
    w10,24    KL                              1
    w10,24    I10,24                          1
    w10,27    KL                              1
    w10,27    I10,27                          1
    w10,28    KL                              1
    w10,28    I10,28                          1
    w10,29    KL                              1
    w10,29    I10,29                          1
    w10,30    KL                              1
    w10,30    I10,30                          1
    w10,31    KL                              1
    w10,31    I10,31                          1
    w10,32    KL                              1
    w10,32    I10,32                          1
    w10,33    KL                              1
    w10,33    I10,33                          1
    w10,34    KL                              1
    w10,34    I10,34                          1
    w10,35    KL                              1
    w10,35    I10,35                          1
    w10,36    KL                              1
    w10,36    I10,36                          1
    w10,37    KL                              1
    w10,37    I10,37                          1
    w10,40    KL                              1
    w10,40    I10,40                          1
    w10,41    KL                              1
    w10,41    I10,41                          1
    w10,42    KL                              1
    w10,42    I10,42                          1
    w10,43    KL                              1
    w10,43    I10,43                          1
    w10,44    KL                              1
    w10,44    I10,44                          1
    w10,45    KL                              1
    w10,45    I10,45                          1
    w10,46    KL                              1
    w10,46    I10,46                          1
    w10,48    KL                              1
    w10,48    I10,48                          1
    w10,49    KL                              1
    w10,49    I10,49                          1
    w11,12    KL                              1
    w11,12    I11,12                          1
    w11,14    KL                              1
    w11,14    I11,14                          1
    w11,15    KL                              1
    w11,15    I11,15                          1
    w11,16    KL                              1
    w11,16    I11,16                          1
    w11,18    KL                              1
    w11,18    I11,18                          1
    w11,20    KL                              1
    w11,20    I11,20                          1
    w11,21    KL                              1
    w11,21    I11,21                          1
    w11,22    KL                              1
    w11,22    I11,22                          1
    w11,23    KL                              1
    w11,23    I11,23                          1
    w11,25    KL                              1
    w11,25    I11,25                          1
    w11,27    KL                              1
    w11,27    I11,27                          1
    w11,28    KL                              1
    w11,28    I11,28                          1
    w11,29    KL                              1
    w11,29    I11,29                          1
    w11,30    KL                              1
    w11,30    I11,30                          1
    w11,31    KL                              1
    w11,31    I11,31                          1
    w11,33    KL                              1
    w11,33    I11,33                          1
    w11,34    KL                              1
    w11,34    I11,34                          1
    w11,35    KL                              1
    w11,35    I11,35                          1
    w11,36    KL                              1
    w11,36    I11,36                          1
    w11,37    KL                              1
    w11,37    I11,37                          1
    w11,38    KL                              1
    w11,38    I11,38                          1
    w11,39    KL                              1
    w11,39    I11,39                          1
    w11,40    KL                              1
    w11,40    I11,40                          1
    w11,42    KL                              1
    w11,42    I11,42                          1
    w11,43    KL                              1
    w11,43    I11,43                          1
    w11,44    KL                              1
    w11,44    I11,44                          1
    w11,46    KL                              1
    w11,46    I11,46                          1
    w11,47    KL                              1
    w11,47    I11,47                          1
    w11,48    KL                              1
    w11,48    I11,48                          1
    w12,13    KL                              1
    w12,13    I12,13                          1
    w12,14    KL                              1
    w12,14    I12,14                          1
    w12,15    KL                              1
    w12,15    I12,15                          1
    w12,17    KL                              1
    w12,17    I12,17                          1
    w12,20    KL                              1
    w12,20    I12,20                          1
    w12,21    KL                              1
    w12,21    I12,21                          1
    w12,23    KL                              1
    w12,23    I12,23                          1
    w12,24    KL                              1
    w12,24    I12,24                          1
    w12,25    KL                              1
    w12,25    I12,25                          1
    w12,26    KL                              1
    w12,26    I12,26                          1
    w12,27    KL                              1
    w12,27    I12,27                          1
    w12,28    KL                              1
    w12,28    I12,28                          1
    w12,29    KL                              1
    w12,29    I12,29                          1
    w12,30    KL                              1
    w12,30    I12,30                          1
    w12,32    KL                              1
    w12,32    I12,32                          1
    w12,33    KL                              1
    w12,33    I12,33                          1
    w12,34    KL                              1
    w12,34    I12,34                          1
    w12,35    KL                              1
    w12,35    I12,35                          1
    w12,36    KL                              1
    w12,36    I12,36                          1
    w12,37    KL                              1
    w12,37    I12,37                          1
    w12,38    KL                              1
    w12,38    I12,38                          1
    w12,39    KL                              1
    w12,39    I12,39                          1
    w12,40    KL                              1
    w12,40    I12,40                          1
    w12,41    KL                              1
    w12,41    I12,41                          1
    w12,42    KL                              1
    w12,42    I12,42                          1
    w12,44    KL                              1
    w12,44    I12,44                          1
    w12,46    KL                              1
    w12,46    I12,46                          1
    w12,47    KL                              1
    w12,47    I12,47                          1
    w12,49    KL                              1
    w12,49    I12,49                          1
    w13,15    KL                              1
    w13,15    I13,15                          1
    w13,16    KL                              1
    w13,16    I13,16                          1
    w13,18    KL                              1
    w13,18    I13,18                          1
    w13,21    KL                              1
    w13,21    I13,21                          1
    w13,22    KL                              1
    w13,22    I13,22                          1
    w13,23    KL                              1
    w13,23    I13,23                          1
    w13,24    KL                              1
    w13,24    I13,24                          1
    w13,26    KL                              1
    w13,26    I13,26                          1
    w13,27    KL                              1
    w13,27    I13,27                          1
    w13,31    KL                              1
    w13,31    I13,31                          1
    w13,32    KL                              1
    w13,32    I13,32                          1
    w13,34    KL                              1
    w13,34    I13,34                          1
    w13,35    KL                              1
    w13,35    I13,35                          1
    w13,38    KL                              1
    w13,38    I13,38                          1
    w13,39    KL                              1
    w13,39    I13,39                          1
    w13,40    KL                              1
    w13,40    I13,40                          1
    w13,41    KL                              1
    w13,41    I13,41                          1
    w13,42    KL                              1
    w13,42    I13,42                          1
    w13,43    KL                              1
    w13,43    I13,43                          1
    w13,44    KL                              1
    w13,44    I13,44                          1
    w13,45    KL                              1
    w13,45    I13,45                          1
    w13,47    KL                              1
    w13,47    I13,47                          1
    w13,49    KL                              1
    w13,49    I13,49                          1
    w14,15    KL                              1
    w14,15    I14,15                          1
    w14,16    KL                              1
    w14,16    I14,16                          1
    w14,17    KL                              1
    w14,17    I14,17                          1
    w14,18    KL                              1
    w14,18    I14,18                          1
    w14,19    KL                              1
    w14,19    I14,19                          1
    w14,20    KL                              1
    w14,20    I14,20                          1
    w14,22    KL                              1
    w14,22    I14,22                          1
    w14,23    KL                              1
    w14,23    I14,23                          1
    w14,24    KL                              1
    w14,24    I14,24                          1
    w14,25    KL                              1
    w14,25    I14,25                          1
    w14,26    KL                              1
    w14,26    I14,26                          1
    w14,27    KL                              1
    w14,27    I14,27                          1
    w14,30    KL                              1
    w14,30    I14,30                          1
    w14,31    KL                              1
    w14,31    I14,31                          1
    w14,32    KL                              1
    w14,32    I14,32                          1
    w14,33    KL                              1
    w14,33    I14,33                          1
    w14,36    KL                              1
    w14,36    I14,36                          1
    w14,37    KL                              1
    w14,37    I14,37                          1
    w14,39    KL                              1
    w14,39    I14,39                          1
    w14,40    KL                              1
    w14,40    I14,40                          1
    w14,41    KL                              1
    w14,41    I14,41                          1
    w14,46    KL                              1
    w14,46    I14,46                          1
    w14,47    KL                              1
    w14,47    I14,47                          1
    w14,48    KL                              1
    w14,48    I14,48                          1
    w15,16    KL                              1
    w15,16    I15,16                          1
    w15,17    KL                              1
    w15,17    I15,17                          1
    w15,19    KL                              1
    w15,19    I15,19                          1
    w15,20    KL                              1
    w15,20    I15,20                          1
    w15,21    KL                              1
    w15,21    I15,21                          1
    w15,22    KL                              1
    w15,22    I15,22                          1
    w15,23    KL                              1
    w15,23    I15,23                          1
    w15,24    KL                              1
    w15,24    I15,24                          1
    w15,26    KL                              1
    w15,26    I15,26                          1
    w15,27    KL                              1
    w15,27    I15,27                          1
    w15,28    KL                              1
    w15,28    I15,28                          1
    w15,29    KL                              1
    w15,29    I15,29                          1
    w15,30    KL                              1
    w15,30    I15,30                          1
    w15,32    KL                              1
    w15,32    I15,32                          1
    w15,33    KL                              1
    w15,33    I15,33                          1
    w15,34    KL                              1
    w15,34    I15,34                          1
    w15,37    KL                              1
    w15,37    I15,37                          1
    w15,38    KL                              1
    w15,38    I15,38                          1
    w15,40    KL                              1
    w15,40    I15,40                          1
    w15,41    KL                              1
    w15,41    I15,41                          1
    w15,44    KL                              1
    w15,44    I15,44                          1
    w15,45    KL                              1
    w15,45    I15,45                          1
    w15,46    KL                              1
    w15,46    I15,46                          1
    w15,48    KL                              1
    w15,48    I15,48                          1
    w16,17    KL                              1
    w16,17    I16,17                          1
    w16,18    KL                              1
    w16,18    I16,18                          1
    w16,19    KL                              1
    w16,19    I16,19                          1
    w16,22    KL                              1
    w16,22    I16,22                          1
    w16,23    KL                              1
    w16,23    I16,23                          1
    w16,26    KL                              1
    w16,26    I16,26                          1
    w16,27    KL                              1
    w16,27    I16,27                          1
    w16,28    KL                              1
    w16,28    I16,28                          1
    w16,29    KL                              1
    w16,29    I16,29                          1
    w16,30    KL                              1
    w16,30    I16,30                          1
    w16,31    KL                              1
    w16,31    I16,31                          1
    w16,37    KL                              1
    w16,37    I16,37                          1
    w16,38    KL                              1
    w16,38    I16,38                          1
    w16,39    KL                              1
    w16,39    I16,39                          1
    w16,40    KL                              1
    w16,40    I16,40                          1
    w16,41    KL                              1
    w16,41    I16,41                          1
    w16,44    KL                              1
    w16,44    I16,44                          1
    w16,46    KL                              1
    w16,46    I16,46                          1
    w16,47    KL                              1
    w16,47    I16,47                          1
    w16,48    KL                              1
    w16,48    I16,48                          1
    w16,49    KL                              1
    w16,49    I16,49                          1
    w17,18    KL                              1
    w17,18    I17,18                          1
    w17,19    KL                              1
    w17,19    I17,19                          1
    w17,20    KL                              1
    w17,20    I17,20                          1
    w17,21    KL                              1
    w17,21    I17,21                          1
    w17,22    KL                              1
    w17,22    I17,22                          1
    w17,23    KL                              1
    w17,23    I17,23                          1
    w17,27    KL                              1
    w17,27    I17,27                          1
    w17,29    KL                              1
    w17,29    I17,29                          1
    w17,30    KL                              1
    w17,30    I17,30                          1
    w17,31    KL                              1
    w17,31    I17,31                          1
    w17,32    KL                              1
    w17,32    I17,32                          1
    w17,33    KL                              1
    w17,33    I17,33                          1
    w17,35    KL                              1
    w17,35    I17,35                          1
    w17,36    KL                              1
    w17,36    I17,36                          1
    w17,39    KL                              1
    w17,39    I17,39                          1
    w17,40    KL                              1
    w17,40    I17,40                          1
    w17,41    KL                              1
    w17,41    I17,41                          1
    w17,42    KL                              1
    w17,42    I17,42                          1
    w17,43    KL                              1
    w17,43    I17,43                          1
    w17,44    KL                              1
    w17,44    I17,44                          1
    w17,46    KL                              1
    w17,46    I17,46                          1
    w17,47    KL                              1
    w17,47    I17,47                          1
    w17,49    KL                              1
    w17,49    I17,49                          1
    w18,21    KL                              1
    w18,21    I18,21                          1
    w18,22    KL                              1
    w18,22    I18,22                          1
    w18,23    KL                              1
    w18,23    I18,23                          1
    w18,24    KL                              1
    w18,24    I18,24                          1
    w18,26    KL                              1
    w18,26    I18,26                          1
    w18,27    KL                              1
    w18,27    I18,27                          1
    w18,31    KL                              1
    w18,31    I18,31                          1
    w18,32    KL                              1
    w18,32    I18,32                          1
    w18,33    KL                              1
    w18,33    I18,33                          1
    w18,34    KL                              1
    w18,34    I18,34                          1
    w18,35    KL                              1
    w18,35    I18,35                          1
    w18,36    KL                              1
    w18,36    I18,36                          1
    w18,37    KL                              1
    w18,37    I18,37                          1
    w18,38    KL                              1
    w18,38    I18,38                          1
    w18,40    KL                              1
    w18,40    I18,40                          1
    w18,42    KL                              1
    w18,42    I18,42                          1
    w18,43    KL                              1
    w18,43    I18,43                          1
    w18,45    KL                              1
    w18,45    I18,45                          1
    w18,46    KL                              1
    w18,46    I18,46                          1
    w18,47    KL                              1
    w18,47    I18,47                          1
    w18,48    KL                              1
    w18,48    I18,48                          1
    w18,49    KL                              1
    w18,49    I18,49                          1
    w19,21    KL                              1
    w19,21    I19,21                          1
    w19,23    KL                              1
    w19,23    I19,23                          1
    w19,24    KL                              1
    w19,24    I19,24                          1
    w19,25    KL                              1
    w19,25    I19,25                          1
    w19,26    KL                              1
    w19,26    I19,26                          1
    w19,28    KL                              1
    w19,28    I19,28                          1
    w19,29    KL                              1
    w19,29    I19,29                          1
    w19,30    KL                              1
    w19,30    I19,30                          1
    w19,31    KL                              1
    w19,31    I19,31                          1
    w19,32    KL                              1
    w19,32    I19,32                          1
    w19,34    KL                              1
    w19,34    I19,34                          1
    w19,37    KL                              1
    w19,37    I19,37                          1
    w19,38    KL                              1
    w19,38    I19,38                          1
    w19,39    KL                              1
    w19,39    I19,39                          1
    w19,40    KL                              1
    w19,40    I19,40                          1
    w19,41    KL                              1
    w19,41    I19,41                          1
    w19,44    KL                              1
    w19,44    I19,44                          1
    w19,45    KL                              1
    w19,45    I19,45                          1
    w19,46    KL                              1
    w19,46    I19,46                          1
    w19,47    KL                              1
    w19,47    I19,47                          1
    w19,48    KL                              1
    w19,48    I19,48                          1
    w19,49    KL                              1
    w19,49    I19,49                          1
    w20,21    KL                              1
    w20,21    I20,21                          1
    w20,22    KL                              1
    w20,22    I20,22                          1
    w20,23    KL                              1
    w20,23    I20,23                          1
    w20,24    KL                              1
    w20,24    I20,24                          1
    w20,26    KL                              1
    w20,26    I20,26                          1
    w20,27    KL                              1
    w20,27    I20,27                          1
    w20,29    KL                              1
    w20,29    I20,29                          1
    w20,30    KL                              1
    w20,30    I20,30                          1
    w20,32    KL                              1
    w20,32    I20,32                          1
    w20,33    KL                              1
    w20,33    I20,33                          1
    w20,35    KL                              1
    w20,35    I20,35                          1
    w20,37    KL                              1
    w20,37    I20,37                          1
    w20,39    KL                              1
    w20,39    I20,39                          1
    w20,40    KL                              1
    w20,40    I20,40                          1
    w20,41    KL                              1
    w20,41    I20,41                          1
    w20,43    KL                              1
    w20,43    I20,43                          1
    w20,44    KL                              1
    w20,44    I20,44                          1
    w20,45    KL                              1
    w20,45    I20,45                          1
    w20,47    KL                              1
    w20,47    I20,47                          1
    w20,48    KL                              1
    w20,48    I20,48                          1
    w20,49    KL                              1
    w20,49    I20,49                          1
    w21,22    KL                              1
    w21,22    I21,22                          1
    w21,25    KL                              1
    w21,25    I21,25                          1
    w21,26    KL                              1
    w21,26    I21,26                          1
    w21,27    KL                              1
    w21,27    I21,27                          1
    w21,29    KL                              1
    w21,29    I21,29                          1
    w21,33    KL                              1
    w21,33    I21,33                          1
    w21,34    KL                              1
    w21,34    I21,34                          1
    w21,35    KL                              1
    w21,35    I21,35                          1
    w21,36    KL                              1
    w21,36    I21,36                          1
    w21,38    KL                              1
    w21,38    I21,38                          1
    w21,39    KL                              1
    w21,39    I21,39                          1
    w21,42    KL                              1
    w21,42    I21,42                          1
    w21,44    KL                              1
    w21,44    I21,44                          1
    w21,45    KL                              1
    w21,45    I21,45                          1
    w21,47    KL                              1
    w21,47    I21,47                          1
    w21,49    KL                              1
    w21,49    I21,49                          1
    w22,23    KL                              1
    w22,23    I22,23                          1
    w22,24    KL                              1
    w22,24    I22,24                          1
    w22,25    KL                              1
    w22,25    I22,25                          1
    w22,26    KL                              1
    w22,26    I22,26                          1
    w22,27    KL                              1
    w22,27    I22,27                          1
    w22,29    KL                              1
    w22,29    I22,29                          1
    w22,30    KL                              1
    w22,30    I22,30                          1
    w22,31    KL                              1
    w22,31    I22,31                          1
    w22,35    KL                              1
    w22,35    I22,35                          1
    w22,36    KL                              1
    w22,36    I22,36                          1
    w22,38    KL                              1
    w22,38    I22,38                          1
    w22,39    KL                              1
    w22,39    I22,39                          1
    w22,40    KL                              1
    w22,40    I22,40                          1
    w22,42    KL                              1
    w22,42    I22,42                          1
    w22,43    KL                              1
    w22,43    I22,43                          1
    w22,45    KL                              1
    w22,45    I22,45                          1
    w22,47    KL                              1
    w22,47    I22,47                          1
    w22,48    KL                              1
    w22,48    I22,48                          1
    w23,25    KL                              1
    w23,25    I23,25                          1
    w23,26    KL                              1
    w23,26    I23,26                          1
    w23,27    KL                              1
    w23,27    I23,27                          1
    w23,28    KL                              1
    w23,28    I23,28                          1
    w23,29    KL                              1
    w23,29    I23,29                          1
    w23,30    KL                              1
    w23,30    I23,30                          1
    w23,31    KL                              1
    w23,31    I23,31                          1
    w23,32    KL                              1
    w23,32    I23,32                          1
    w23,33    KL                              1
    w23,33    I23,33                          1
    w23,34    KL                              1
    w23,34    I23,34                          1
    w23,35    KL                              1
    w23,35    I23,35                          1
    w23,37    KL                              1
    w23,37    I23,37                          1
    w23,39    KL                              1
    w23,39    I23,39                          1
    w23,40    KL                              1
    w23,40    I23,40                          1
    w23,42    KL                              1
    w23,42    I23,42                          1
    w23,44    KL                              1
    w23,44    I23,44                          1
    w23,46    KL                              1
    w23,46    I23,46                          1
    w23,47    KL                              1
    w23,47    I23,47                          1
    w23,48    KL                              1
    w23,48    I23,48                          1
    w24,25    KL                              1
    w24,25    I24,25                          1
    w24,26    KL                              1
    w24,26    I24,26                          1
    w24,27    KL                              1
    w24,27    I24,27                          1
    w24,29    KL                              1
    w24,29    I24,29                          1
    w24,30    KL                              1
    w24,30    I24,30                          1
    w24,32    KL                              1
    w24,32    I24,32                          1
    w24,33    KL                              1
    w24,33    I24,33                          1
    w24,35    KL                              1
    w24,35    I24,35                          1
    w24,36    KL                              1
    w24,36    I24,36                          1
    w24,38    KL                              1
    w24,38    I24,38                          1
    w24,41    KL                              1
    w24,41    I24,41                          1
    w24,42    KL                              1
    w24,42    I24,42                          1
    w24,43    KL                              1
    w24,43    I24,43                          1
    w24,44    KL                              1
    w24,44    I24,44                          1
    w24,46    KL                              1
    w24,46    I24,46                          1
    w24,49    KL                              1
    w24,49    I24,49                          1
    w25,26    KL                              1
    w25,26    I25,26                          1
    w25,27    KL                              1
    w25,27    I25,27                          1
    w25,28    KL                              1
    w25,28    I25,28                          1
    w25,30    KL                              1
    w25,30    I25,30                          1
    w25,31    KL                              1
    w25,31    I25,31                          1
    w25,33    KL                              1
    w25,33    I25,33                          1
    w25,34    KL                              1
    w25,34    I25,34                          1
    w25,35    KL                              1
    w25,35    I25,35                          1
    w25,36    KL                              1
    w25,36    I25,36                          1
    w25,40    KL                              1
    w25,40    I25,40                          1
    w25,41    KL                              1
    w25,41    I25,41                          1
    w25,42    KL                              1
    w25,42    I25,42                          1
    w25,44    KL                              1
    w25,44    I25,44                          1
    w25,46    KL                              1
    w25,46    I25,46                          1
    w25,47    KL                              1
    w25,47    I25,47                          1
    w25,48    KL                              1
    w25,48    I25,48                          1
    w25,49    KL                              1
    w25,49    I25,49                          1
    w26,27    KL                              1
    w26,27    I26,27                          1
    w26,28    KL                              1
    w26,28    I26,28                          1
    w26,29    KL                              1
    w26,29    I26,29                          1
    w26,30    KL                              1
    w26,30    I26,30                          1
    w26,31    KL                              1
    w26,31    I26,31                          1
    w26,32    KL                              1
    w26,32    I26,32                          1
    w26,34    KL                              1
    w26,34    I26,34                          1
    w26,35    KL                              1
    w26,35    I26,35                          1
    w26,37    KL                              1
    w26,37    I26,37                          1
    w26,38    KL                              1
    w26,38    I26,38                          1
    w26,40    KL                              1
    w26,40    I26,40                          1
    w26,41    KL                              1
    w26,41    I26,41                          1
    w26,42    KL                              1
    w26,42    I26,42                          1
    w26,44    KL                              1
    w26,44    I26,44                          1
    w26,45    KL                              1
    w26,45    I26,45                          1
    w26,46    KL                              1
    w26,46    I26,46                          1
    w26,48    KL                              1
    w26,48    I26,48                          1
    w26,49    KL                              1
    w26,49    I26,49                          1
    w27,28    KL                              1
    w27,28    I27,28                          1
    w27,29    KL                              1
    w27,29    I27,29                          1
    w27,30    KL                              1
    w27,30    I27,30                          1
    w27,31    KL                              1
    w27,31    I27,31                          1
    w27,34    KL                              1
    w27,34    I27,34                          1
    w27,35    KL                              1
    w27,35    I27,35                          1
    w27,36    KL                              1
    w27,36    I27,36                          1
    w27,40    KL                              1
    w27,40    I27,40                          1
    w27,42    KL                              1
    w27,42    I27,42                          1
    w27,43    KL                              1
    w27,43    I27,43                          1
    w27,44    KL                              1
    w27,44    I27,44                          1
    w27,45    KL                              1
    w27,45    I27,45                          1
    w27,47    KL                              1
    w27,47    I27,47                          1
    w27,48    KL                              1
    w27,48    I27,48                          1
    w27,49    KL                              1
    w27,49    I27,49                          1
    w28,31    KL                              1
    w28,31    I28,31                          1
    w28,32    KL                              1
    w28,32    I28,32                          1
    w28,33    KL                              1
    w28,33    I28,33                          1
    w28,34    KL                              1
    w28,34    I28,34                          1
    w28,35    KL                              1
    w28,35    I28,35                          1
    w28,36    KL                              1
    w28,36    I28,36                          1
    w28,37    KL                              1
    w28,37    I28,37                          1
    w28,38    KL                              1
    w28,38    I28,38                          1
    w28,39    KL                              1
    w28,39    I28,39                          1
    w28,40    KL                              1
    w28,40    I28,40                          1
    w28,41    KL                              1
    w28,41    I28,41                          1
    w28,42    KL                              1
    w28,42    I28,42                          1
    w28,43    KL                              1
    w28,43    I28,43                          1
    w28,44    KL                              1
    w28,44    I28,44                          1
    w28,45    KL                              1
    w28,45    I28,45                          1
    w28,46    KL                              1
    w28,46    I28,46                          1
    w28,48    KL                              1
    w28,48    I28,48                          1
    w28,49    KL                              1
    w28,49    I28,49                          1
    w29,30    KL                              1
    w29,30    I29,30                          1
    w29,31    KL                              1
    w29,31    I29,31                          1
    w29,32    KL                              1
    w29,32    I29,32                          1
    w29,34    KL                              1
    w29,34    I29,34                          1
    w29,35    KL                              1
    w29,35    I29,35                          1
    w29,36    KL                              1
    w29,36    I29,36                          1
    w29,37    KL                              1
    w29,37    I29,37                          1
    w29,38    KL                              1
    w29,38    I29,38                          1
    w29,39    KL                              1
    w29,39    I29,39                          1
    w29,40    KL                              1
    w29,40    I29,40                          1
    w29,42    KL                              1
    w29,42    I29,42                          1
    w29,43    KL                              1
    w29,43    I29,43                          1
    w29,44    KL                              1
    w29,44    I29,44                          1
    w29,45    KL                              1
    w29,45    I29,45                          1
    w29,47    KL                              1
    w29,47    I29,47                          1
    w29,48    KL                              1
    w29,48    I29,48                          1
    w29,49    KL                              1
    w29,49    I29,49                          1
    w30,32    KL                              1
    w30,32    I30,32                          1
    w30,33    KL                              1
    w30,33    I30,33                          1
    w30,34    KL                              1
    w30,34    I30,34                          1
    w30,35    KL                              1
    w30,35    I30,35                          1
    w30,36    KL                              1
    w30,36    I30,36                          1
    w30,37    KL                              1
    w30,37    I30,37                          1
    w30,38    KL                              1
    w30,38    I30,38                          1
    w30,39    KL                              1
    w30,39    I30,39                          1
    w30,40    KL                              1
    w30,40    I30,40                          1
    w30,43    KL                              1
    w30,43    I30,43                          1
    w30,44    KL                              1
    w30,44    I30,44                          1
    w30,45    KL                              1
    w30,45    I30,45                          1
    w30,46    KL                              1
    w30,46    I30,46                          1
    w30,47    KL                              1
    w30,47    I30,47                          1
    w30,49    KL                              1
    w30,49    I30,49                          1
    w31,34    KL                              1
    w31,34    I31,34                          1
    w31,35    KL                              1
    w31,35    I31,35                          1
    w31,36    KL                              1
    w31,36    I31,36                          1
    w31,37    KL                              1
    w31,37    I31,37                          1
    w31,39    KL                              1
    w31,39    I31,39                          1
    w31,40    KL                              1
    w31,40    I31,40                          1
    w31,41    KL                              1
    w31,41    I31,41                          1
    w31,43    KL                              1
    w31,43    I31,43                          1
    w31,45    KL                              1
    w31,45    I31,45                          1
    w31,46    KL                              1
    w31,46    I31,46                          1
    w31,48    KL                              1
    w31,48    I31,48                          1
    w31,49    KL                              1
    w31,49    I31,49                          1
    w32,33    KL                              1
    w32,33    I32,33                          1
    w32,34    KL                              1
    w32,34    I32,34                          1
    w32,37    KL                              1
    w32,37    I32,37                          1
    w32,38    KL                              1
    w32,38    I32,38                          1
    w32,39    KL                              1
    w32,39    I32,39                          1
    w32,40    KL                              1
    w32,40    I32,40                          1
    w32,41    KL                              1
    w32,41    I32,41                          1
    w32,42    KL                              1
    w32,42    I32,42                          1
    w32,43    KL                              1
    w32,43    I32,43                          1
    w32,46    KL                              1
    w32,46    I32,46                          1
    w32,47    KL                              1
    w32,47    I32,47                          1
    w32,48    KL                              1
    w32,48    I32,48                          1
    w32,49    KL                              1
    w32,49    I32,49                          1
    w33,34    KL                              1
    w33,34    I33,34                          1
    w33,36    KL                              1
    w33,36    I33,36                          1
    w33,37    KL                              1
    w33,37    I33,37                          1
    w33,38    KL                              1
    w33,38    I33,38                          1
    w33,39    KL                              1
    w33,39    I33,39                          1
    w33,42    KL                              1
    w33,42    I33,42                          1
    w33,44    KL                              1
    w33,44    I33,44                          1
    w33,45    KL                              1
    w33,45    I33,45                          1
    w33,46    KL                              1
    w33,46    I33,46                          1
    w33,48    KL                              1
    w33,48    I33,48                          1
    w33,49    KL                              1
    w33,49    I33,49                          1
    w34,36    KL                              1
    w34,36    I34,36                          1
    w34,38    KL                              1
    w34,38    I34,38                          1
    w34,40    KL                              1
    w34,40    I34,40                          1
    w34,43    KL                              1
    w34,43    I34,43                          1
    w34,44    KL                              1
    w34,44    I34,44                          1
    w34,45    KL                              1
    w34,45    I34,45                          1
    w34,46    KL                              1
    w34,46    I34,46                          1
    w34,47    KL                              1
    w34,47    I34,47                          1
    w34,49    KL                              1
    w34,49    I34,49                          1
    w35,36    KL                              1
    w35,36    I35,36                          1
    w35,37    KL                              1
    w35,37    I35,37                          1
    w35,38    KL                              1
    w35,38    I35,38                          1
    w35,39    KL                              1
    w35,39    I35,39                          1
    w35,40    KL                              1
    w35,40    I35,40                          1
    w35,43    KL                              1
    w35,43    I35,43                          1
    w35,44    KL                              1
    w35,44    I35,44                          1
    w35,46    KL                              1
    w35,46    I35,46                          1
    w35,47    KL                              1
    w35,47    I35,47                          1
    w35,49    KL                              1
    w35,49    I35,49                          1
    w36,37    KL                              1
    w36,37    I36,37                          1
    w36,38    KL                              1
    w36,38    I36,38                          1
    w36,40    KL                              1
    w36,40    I36,40                          1
    w36,41    KL                              1
    w36,41    I36,41                          1
    w36,44    KL                              1
    w36,44    I36,44                          1
    w36,45    KL                              1
    w36,45    I36,45                          1
    w36,46    KL                              1
    w36,46    I36,46                          1
    w36,47    KL                              1
    w36,47    I36,47                          1
    w36,48    KL                              1
    w36,48    I36,48                          1
    w36,49    KL                              1
    w36,49    I36,49                          1
    w37,39    KL                              1
    w37,39    I37,39                          1
    w37,40    KL                              1
    w37,40    I37,40                          1
    w37,42    KL                              1
    w37,42    I37,42                          1
    w37,43    KL                              1
    w37,43    I37,43                          1
    w37,44    KL                              1
    w37,44    I37,44                          1
    w37,45    KL                              1
    w37,45    I37,45                          1
    w37,46    KL                              1
    w37,46    I37,46                          1
    w37,47    KL                              1
    w37,47    I37,47                          1
    w37,48    KL                              1
    w37,48    I37,48                          1
    w37,49    KL                              1
    w37,49    I37,49                          1
    w38,39    KL                              1
    w38,39    I38,39                          1
    w38,40    KL                              1
    w38,40    I38,40                          1
    w38,42    KL                              1
    w38,42    I38,42                          1
    w38,43    KL                              1
    w38,43    I38,43                          1
    w38,44    KL                              1
    w38,44    I38,44                          1
    w38,45    KL                              1
    w38,45    I38,45                          1
    w38,46    KL                              1
    w38,46    I38,46                          1
    w38,48    KL                              1
    w38,48    I38,48                          1
    w38,49    KL                              1
    w38,49    I38,49                          1
    w39,41    KL                              1
    w39,41    I39,41                          1
    w39,42    KL                              1
    w39,42    I39,42                          1
    w39,44    KL                              1
    w39,44    I39,44                          1
    w39,45    KL                              1
    w39,45    I39,45                          1
    w39,49    KL                              1
    w39,49    I39,49                          1
    w40,43    KL                              1
    w40,43    I40,43                          1
    w40,45    KL                              1
    w40,45    I40,45                          1
    w40,47    KL                              1
    w40,47    I40,47                          1
    w40,48    KL                              1
    w40,48    I40,48                          1
    w41,42    KL                              1
    w41,42    I41,42                          1
    w41,43    KL                              1
    w41,43    I41,43                          1
    w41,44    KL                              1
    w41,44    I41,44                          1
    w41,45    KL                              1
    w41,45    I41,45                          1
    w41,46    KL                              1
    w41,46    I41,46                          1
    w41,47    KL                              1
    w41,47    I41,47                          1
    w41,48    KL                              1
    w41,48    I41,48                          1
    w42,43    KL                              1
    w42,43    I42,43                          1
    w42,45    KL                              1
    w42,45    I42,45                          1
    w42,46    KL                              1
    w42,46    I42,46                          1
    w42,48    KL                              1
    w42,48    I42,48                          1
    w42,49    KL                              1
    w42,49    I42,49                          1
    w43,45    KL                              1
    w43,45    I43,45                          1
    w43,46    KL                              1
    w43,46    I43,46                          1
    w43,47    KL                              1
    w43,47    I43,47                          1
    w43,49    KL                              1
    w43,49    I43,49                          1
    w44,45    KL                              1
    w44,45    I44,45                          1
    w44,46    KL                              1
    w44,46    I44,46                          1
    w44,48    KL                              1
    w44,48    I44,48                          1
    w44,49    KL                              1
    w44,49    I44,49                          1
    w45,47    KL                              1
    w45,47    I45,47                          1
    w46,47    KL                              1
    w46,47    I46,47                          1
    w46,48    KL                              1
    w46,48    I46,48                          1
    w46,49    KL                              1
    w46,49    I46,49                          1
    w47,48    KL                              1
    w47,48    I47,48                          1
    w47,49    KL                              1
    w47,49    I47,49                          1
    y0,1      E0,1                           -1
    y0,1      I0,1                            1
    y0,2      E0,2                           -1
    y0,2      I0,2                            1
    y0,3      E0,3                           -1
    y0,3      I0,3                            1
    y0,4      E0,4                           -1
    y0,4      I0,4                            1
    y0,5      E0,5                           -1
    y0,5      I0,5                            1
    y0,6      E0,6                           -1
    y0,6      I0,6                            1
    y0,7      E0,7                           -1
    y0,7      I0,7                            1
    y0,8      E0,8                           -1
    y0,8      I0,8                            1
    y0,10     E0,10                          -1
    y0,10     I0,10                           1
    y0,12     E0,12                          -1
    y0,12     I0,12                           1
    y0,14     E0,14                          -1
    y0,14     I0,14                           1
    y0,15     E0,15                          -1
    y0,15     I0,15                           1
    y0,16     E0,16                          -1
    y0,16     I0,16                           1
    y0,17     E0,17                          -1
    y0,17     I0,17                           1
    y0,19     E0,19                          -1
    y0,19     I0,19                           1
    y0,20     E0,20                          -1
    y0,20     I0,20                           1
    y0,21     E0,21                          -1
    y0,21     I0,21                           1
    y0,22     E0,22                          -1
    y0,22     I0,22                           1
    y0,23     E0,23                          -1
    y0,23     I0,23                           1
    y0,24     E0,24                          -1
    y0,24     I0,24                           1
    y0,26     E0,26                          -1
    y0,26     I0,26                           1
    y0,27     E0,27                          -1
    y0,27     I0,27                           1
    y0,29     E0,29                          -1
    y0,29     I0,29                           1
    y0,32     E0,32                          -1
    y0,32     I0,32                           1
    y0,33     E0,33                          -1
    y0,33     I0,33                           1
    y0,34     E0,34                          -1
    y0,34     I0,34                           1
    y0,35     E0,35                          -1
    y0,35     I0,35                           1
    y0,37     E0,37                          -1
    y0,37     I0,37                           1
    y0,38     E0,38                          -1
    y0,38     I0,38                           1
    y0,39     E0,39                          -1
    y0,39     I0,39                           1
    y0,40     E0,40                          -1
    y0,40     I0,40                           1
    y0,41     E0,41                          -1
    y0,41     I0,41                           1
    y0,42     E0,42                          -1
    y0,42     I0,42                           1
    y0,43     E0,43                          -1
    y0,43     I0,43                           1
    y0,45     E0,45                          -1
    y0,45     I0,45                           1
    y0,46     E0,46                          -1
    y0,46     I0,46                           1
    y0,47     E0,47                          -1
    y0,47     I0,47                           1
    y1,3      E1,3                           -1
    y1,3      I1,3                            1
    y1,4      E1,4                           -1
    y1,4      I1,4                            1
    y1,5      E1,5                           -1
    y1,5      I1,5                            1
    y1,6      E1,6                           -1
    y1,6      I1,6                            1
    y1,7      E1,7                           -1
    y1,7      I1,7                            1
    y1,8      E1,8                           -1
    y1,8      I1,8                            1
    y1,9      E1,9                           -1
    y1,9      I1,9                            1
    y1,11     E1,11                          -1
    y1,11     I1,11                           1
    y1,12     E1,12                          -1
    y1,12     I1,12                           1
    y1,13     E1,13                          -1
    y1,13     I1,13                           1
    y1,16     E1,16                          -1
    y1,16     I1,16                           1
    y1,17     E1,17                          -1
    y1,17     I1,17                           1
    y1,18     E1,18                          -1
    y1,18     I1,18                           1
    y1,20     E1,20                          -1
    y1,20     I1,20                           1
    y1,21     E1,21                          -1
    y1,21     I1,21                           1
    y1,22     E1,22                          -1
    y1,22     I1,22                           1
    y1,23     E1,23                          -1
    y1,23     I1,23                           1
    y1,24     E1,24                          -1
    y1,24     I1,24                           1
    y1,25     E1,25                          -1
    y1,25     I1,25                           1
    y1,26     E1,26                          -1
    y1,26     I1,26                           1
    y1,27     E1,27                          -1
    y1,27     I1,27                           1
    y1,29     E1,29                          -1
    y1,29     I1,29                           1
    y1,30     E1,30                          -1
    y1,30     I1,30                           1
    y1,31     E1,31                          -1
    y1,31     I1,31                           1
    y1,33     E1,33                          -1
    y1,33     I1,33                           1
    y1,34     E1,34                          -1
    y1,34     I1,34                           1
    y1,35     E1,35                          -1
    y1,35     I1,35                           1
    y1,36     E1,36                          -1
    y1,36     I1,36                           1
    y1,37     E1,37                          -1
    y1,37     I1,37                           1
    y1,40     E1,40                          -1
    y1,40     I1,40                           1
    y1,41     E1,41                          -1
    y1,41     I1,41                           1
    y1,44     E1,44                          -1
    y1,44     I1,44                           1
    y1,48     E1,48                          -1
    y1,48     I1,48                           1
    y2,3      E2,3                           -1
    y2,3      I2,3                            1
    y2,4      E2,4                           -1
    y2,4      I2,4                            1
    y2,5      E2,5                           -1
    y2,5      I2,5                            1
    y2,7      E2,7                           -1
    y2,7      I2,7                            1
    y2,10     E2,10                          -1
    y2,10     I2,10                           1
    y2,12     E2,12                          -1
    y2,12     I2,12                           1
    y2,14     E2,14                          -1
    y2,14     I2,14                           1
    y2,16     E2,16                          -1
    y2,16     I2,16                           1
    y2,18     E2,18                          -1
    y2,18     I2,18                           1
    y2,19     E2,19                          -1
    y2,19     I2,19                           1
    y2,20     E2,20                          -1
    y2,20     I2,20                           1
    y2,21     E2,21                          -1
    y2,21     I2,21                           1
    y2,26     E2,26                          -1
    y2,26     I2,26                           1
    y2,28     E2,28                          -1
    y2,28     I2,28                           1
    y2,29     E2,29                          -1
    y2,29     I2,29                           1
    y2,31     E2,31                          -1
    y2,31     I2,31                           1
    y2,32     E2,32                          -1
    y2,32     I2,32                           1
    y2,33     E2,33                          -1
    y2,33     I2,33                           1
    y2,34     E2,34                          -1
    y2,34     I2,34                           1
    y2,35     E2,35                          -1
    y2,35     I2,35                           1
    y2,36     E2,36                          -1
    y2,36     I2,36                           1
    y2,37     E2,37                          -1
    y2,37     I2,37                           1
    y2,38     E2,38                          -1
    y2,38     I2,38                           1
    y2,39     E2,39                          -1
    y2,39     I2,39                           1
    y2,40     E2,40                          -1
    y2,40     I2,40                           1
    y2,44     E2,44                          -1
    y2,44     I2,44                           1
    y2,45     E2,45                          -1
    y2,45     I2,45                           1
    y2,46     E2,46                          -1
    y2,46     I2,46                           1
    y2,48     E2,48                          -1
    y2,48     I2,48                           1
    y2,49     E2,49                          -1
    y2,49     I2,49                           1
    y3,4      E3,4                           -1
    y3,4      I3,4                            1
    y3,6      E3,6                           -1
    y3,6      I3,6                            1
    y3,7      E3,7                           -1
    y3,7      I3,7                            1
    y3,8      E3,8                           -1
    y3,8      I3,8                            1
    y3,9      E3,9                           -1
    y3,9      I3,9                            1
    y3,10     E3,10                          -1
    y3,10     I3,10                           1
    y3,11     E3,11                          -1
    y3,11     I3,11                           1
    y3,12     E3,12                          -1
    y3,12     I3,12                           1
    y3,13     E3,13                          -1
    y3,13     I3,13                           1
    y3,14     E3,14                          -1
    y3,14     I3,14                           1
    y3,15     E3,15                          -1
    y3,15     I3,15                           1
    y3,16     E3,16                          -1
    y3,16     I3,16                           1
    y3,17     E3,17                          -1
    y3,17     I3,17                           1
    y3,18     E3,18                          -1
    y3,18     I3,18                           1
    y3,21     E3,21                          -1
    y3,21     I3,21                           1
    y3,22     E3,22                          -1
    y3,22     I3,22                           1
    y3,24     E3,24                          -1
    y3,24     I3,24                           1
    y3,25     E3,25                          -1
    y3,25     I3,25                           1
    y3,26     E3,26                          -1
    y3,26     I3,26                           1
    y3,29     E3,29                          -1
    y3,29     I3,29                           1
    y3,30     E3,30                          -1
    y3,30     I3,30                           1
    y3,31     E3,31                          -1
    y3,31     I3,31                           1
    y3,33     E3,33                          -1
    y3,33     I3,33                           1
    y3,35     E3,35                          -1
    y3,35     I3,35                           1
    y3,36     E3,36                          -1
    y3,36     I3,36                           1
    y3,37     E3,37                          -1
    y3,37     I3,37                           1
    y3,38     E3,38                          -1
    y3,38     I3,38                           1
    y3,43     E3,43                          -1
    y3,43     I3,43                           1
    y3,45     E3,45                          -1
    y3,45     I3,45                           1
    y3,47     E3,47                          -1
    y3,47     I3,47                           1
    y4,5      E4,5                           -1
    y4,5      I4,5                            1
    y4,9      E4,9                           -1
    y4,9      I4,9                            1
    y4,11     E4,11                          -1
    y4,11     I4,11                           1
    y4,12     E4,12                          -1
    y4,12     I4,12                           1
    y4,13     E4,13                          -1
    y4,13     I4,13                           1
    y4,14     E4,14                          -1
    y4,14     I4,14                           1
    y4,15     E4,15                          -1
    y4,15     I4,15                           1
    y4,16     E4,16                          -1
    y4,16     I4,16                           1
    y4,17     E4,17                          -1
    y4,17     I4,17                           1
    y4,19     E4,19                          -1
    y4,19     I4,19                           1
    y4,22     E4,22                          -1
    y4,22     I4,22                           1
    y4,23     E4,23                          -1
    y4,23     I4,23                           1
    y4,24     E4,24                          -1
    y4,24     I4,24                           1
    y4,25     E4,25                          -1
    y4,25     I4,25                           1
    y4,26     E4,26                          -1
    y4,26     I4,26                           1
    y4,27     E4,27                          -1
    y4,27     I4,27                           1
    y4,31     E4,31                          -1
    y4,31     I4,31                           1
    y4,32     E4,32                          -1
    y4,32     I4,32                           1
    y4,33     E4,33                          -1
    y4,33     I4,33                           1
    y4,34     E4,34                          -1
    y4,34     I4,34                           1
    y4,35     E4,35                          -1
    y4,35     I4,35                           1
    y4,36     E4,36                          -1
    y4,36     I4,36                           1
    y4,37     E4,37                          -1
    y4,37     I4,37                           1
    y4,38     E4,38                          -1
    y4,38     I4,38                           1
    y4,40     E4,40                          -1
    y4,40     I4,40                           1
    y4,41     E4,41                          -1
    y4,41     I4,41                           1
    y4,42     E4,42                          -1
    y4,42     I4,42                           1
    y4,44     E4,44                          -1
    y4,44     I4,44                           1
    y4,45     E4,45                          -1
    y4,45     I4,45                           1
    y4,46     E4,46                          -1
    y4,46     I4,46                           1
    y4,47     E4,47                          -1
    y4,47     I4,47                           1
    y4,48     E4,48                          -1
    y4,48     I4,48                           1
    y5,6      E5,6                           -1
    y5,6      I5,6                            1
    y5,7      E5,7                           -1
    y5,7      I5,7                            1
    y5,8      E5,8                           -1
    y5,8      I5,8                            1
    y5,9      E5,9                           -1
    y5,9      I5,9                            1
    y5,10     E5,10                          -1
    y5,10     I5,10                           1
    y5,11     E5,11                          -1
    y5,11     I5,11                           1
    y5,12     E5,12                          -1
    y5,12     I5,12                           1
    y5,13     E5,13                          -1
    y5,13     I5,13                           1
    y5,14     E5,14                          -1
    y5,14     I5,14                           1
    y5,15     E5,15                          -1
    y5,15     I5,15                           1
    y5,16     E5,16                          -1
    y5,16     I5,16                           1
    y5,17     E5,17                          -1
    y5,17     I5,17                           1
    y5,19     E5,19                          -1
    y5,19     I5,19                           1
    y5,20     E5,20                          -1
    y5,20     I5,20                           1
    y5,22     E5,22                          -1
    y5,22     I5,22                           1
    y5,23     E5,23                          -1
    y5,23     I5,23                           1
    y5,24     E5,24                          -1
    y5,24     I5,24                           1
    y5,25     E5,25                          -1
    y5,25     I5,25                           1
    y5,26     E5,26                          -1
    y5,26     I5,26                           1
    y5,27     E5,27                          -1
    y5,27     I5,27                           1
    y5,28     E5,28                          -1
    y5,28     I5,28                           1
    y5,30     E5,30                          -1
    y5,30     I5,30                           1
    y5,31     E5,31                          -1
    y5,31     I5,31                           1
    y5,33     E5,33                          -1
    y5,33     I5,33                           1
    y5,35     E5,35                          -1
    y5,35     I5,35                           1
    y5,38     E5,38                          -1
    y5,38     I5,38                           1
    y5,39     E5,39                          -1
    y5,39     I5,39                           1
    y5,40     E5,40                          -1
    y5,40     I5,40                           1
    y5,41     E5,41                          -1
    y5,41     I5,41                           1
    y5,42     E5,42                          -1
    y5,42     I5,42                           1
    y5,45     E5,45                          -1
    y5,45     I5,45                           1
    y5,47     E5,47                          -1
    y5,47     I5,47                           1
    y5,48     E5,48                          -1
    y5,48     I5,48                           1
    y5,49     E5,49                          -1
    y5,49     I5,49                           1
    y6,9      E6,9                           -1
    y6,9      I6,9                            1
    y6,10     E6,10                          -1
    y6,10     I6,10                           1
    y6,11     E6,11                          -1
    y6,11     I6,11                           1
    y6,13     E6,13                          -1
    y6,13     I6,13                           1
    y6,16     E6,16                          -1
    y6,16     I6,16                           1
    y6,17     E6,17                          -1
    y6,17     I6,17                           1
    y6,21     E6,21                          -1
    y6,21     I6,21                           1
    y6,23     E6,23                          -1
    y6,23     I6,23                           1
    y6,24     E6,24                          -1
    y6,24     I6,24                           1
    y6,26     E6,26                          -1
    y6,26     I6,26                           1
    y6,27     E6,27                          -1
    y6,27     I6,27                           1
    y6,28     E6,28                          -1
    y6,28     I6,28                           1
    y6,29     E6,29                          -1
    y6,29     I6,29                           1
    y6,30     E6,30                          -1
    y6,30     I6,30                           1
    y6,31     E6,31                          -1
    y6,31     I6,31                           1
    y6,32     E6,32                          -1
    y6,32     I6,32                           1
    y6,34     E6,34                          -1
    y6,34     I6,34                           1
    y6,35     E6,35                          -1
    y6,35     I6,35                           1
    y6,36     E6,36                          -1
    y6,36     I6,36                           1
    y6,38     E6,38                          -1
    y6,38     I6,38                           1
    y6,43     E6,43                          -1
    y6,43     I6,43                           1
    y6,46     E6,46                          -1
    y6,46     I6,46                           1
    y6,47     E6,47                          -1
    y6,47     I6,47                           1
    y6,49     E6,49                          -1
    y6,49     I6,49                           1
    y7,8      E7,8                           -1
    y7,8      I7,8                            1
    y7,9      E7,9                           -1
    y7,9      I7,9                            1
    y7,10     E7,10                          -1
    y7,10     I7,10                           1
    y7,13     E7,13                          -1
    y7,13     I7,13                           1
    y7,14     E7,14                          -1
    y7,14     I7,14                           1
    y7,15     E7,15                          -1
    y7,15     I7,15                           1
    y7,16     E7,16                          -1
    y7,16     I7,16                           1
    y7,20     E7,20                          -1
    y7,20     I7,20                           1
    y7,21     E7,21                          -1
    y7,21     I7,21                           1
    y7,25     E7,25                          -1
    y7,25     I7,25                           1
    y7,26     E7,26                          -1
    y7,26     I7,26                           1
    y7,27     E7,27                          -1
    y7,27     I7,27                           1
    y7,28     E7,28                          -1
    y7,28     I7,28                           1
    y7,29     E7,29                          -1
    y7,29     I7,29                           1
    y7,30     E7,30                          -1
    y7,30     I7,30                           1
    y7,31     E7,31                          -1
    y7,31     I7,31                           1
    y7,32     E7,32                          -1
    y7,32     I7,32                           1
    y7,33     E7,33                          -1
    y7,33     I7,33                           1
    y7,38     E7,38                          -1
    y7,38     I7,38                           1
    y7,39     E7,39                          -1
    y7,39     I7,39                           1
    y7,40     E7,40                          -1
    y7,40     I7,40                           1
    y7,46     E7,46                          -1
    y7,46     I7,46                           1
    y7,49     E7,49                          -1
    y7,49     I7,49                           1
    y8,9      E8,9                           -1
    y8,9      I8,9                            1
    y8,12     E8,12                          -1
    y8,12     I8,12                           1
    y8,13     E8,13                          -1
    y8,13     I8,13                           1
    y8,14     E8,14                          -1
    y8,14     I8,14                           1
    y8,16     E8,16                          -1
    y8,16     I8,16                           1
    y8,18     E8,18                          -1
    y8,18     I8,18                           1
    y8,19     E8,19                          -1
    y8,19     I8,19                           1
    y8,20     E8,20                          -1
    y8,20     I8,20                           1
    y8,21     E8,21                          -1
    y8,21     I8,21                           1
    y8,22     E8,22                          -1
    y8,22     I8,22                           1
    y8,25     E8,25                          -1
    y8,25     I8,25                           1
    y8,29     E8,29                          -1
    y8,29     I8,29                           1
    y8,30     E8,30                          -1
    y8,30     I8,30                           1
    y8,33     E8,33                          -1
    y8,33     I8,33                           1
    y8,34     E8,34                          -1
    y8,34     I8,34                           1
    y8,35     E8,35                          -1
    y8,35     I8,35                           1
    y8,37     E8,37                          -1
    y8,37     I8,37                           1
    y8,39     E8,39                          -1
    y8,39     I8,39                           1
    y8,40     E8,40                          -1
    y8,40     I8,40                           1
    y8,41     E8,41                          -1
    y8,41     I8,41                           1
    y8,42     E8,42                          -1
    y8,42     I8,42                           1
    y8,43     E8,43                          -1
    y8,43     I8,43                           1
    y8,44     E8,44                          -1
    y8,44     I8,44                           1
    y8,45     E8,45                          -1
    y8,45     I8,45                           1
    y8,47     E8,47                          -1
    y8,47     I8,47                           1
    y8,48     E8,48                          -1
    y8,48     I8,48                           1
    y8,49     E8,49                          -1
    y8,49     I8,49                           1
    y9,10     E9,10                          -1
    y9,10     I9,10                           1
    y9,11     E9,11                          -1
    y9,11     I9,11                           1
    y9,12     E9,12                          -1
    y9,12     I9,12                           1
    y9,13     E9,13                          -1
    y9,13     I9,13                           1
    y9,14     E9,14                          -1
    y9,14     I9,14                           1
    y9,15     E9,15                          -1
    y9,15     I9,15                           1
    y9,17     E9,17                          -1
    y9,17     I9,17                           1
    y9,19     E9,19                          -1
    y9,19     I9,19                           1
    y9,20     E9,20                          -1
    y9,20     I9,20                           1
    y9,21     E9,21                          -1
    y9,21     I9,21                           1
    y9,23     E9,23                          -1
    y9,23     I9,23                           1
    y9,24     E9,24                          -1
    y9,24     I9,24                           1
    y9,25     E9,25                          -1
    y9,25     I9,25                           1
    y9,26     E9,26                          -1
    y9,26     I9,26                           1
    y9,27     E9,27                          -1
    y9,27     I9,27                           1
    y9,28     E9,28                          -1
    y9,28     I9,28                           1
    y9,29     E9,29                          -1
    y9,29     I9,29                           1
    y9,30     E9,30                          -1
    y9,30     I9,30                           1
    y9,33     E9,33                          -1
    y9,33     I9,33                           1
    y9,34     E9,34                          -1
    y9,34     I9,34                           1
    y9,35     E9,35                          -1
    y9,35     I9,35                           1
    y9,37     E9,37                          -1
    y9,37     I9,37                           1
    y9,38     E9,38                          -1
    y9,38     I9,38                           1
    y9,39     E9,39                          -1
    y9,39     I9,39                           1
    y9,40     E9,40                          -1
    y9,40     I9,40                           1
    y9,41     E9,41                          -1
    y9,41     I9,41                           1
    y9,42     E9,42                          -1
    y9,42     I9,42                           1
    y9,45     E9,45                          -1
    y9,45     I9,45                           1
    y9,47     E9,47                          -1
    y9,47     I9,47                           1
    y9,48     E9,48                          -1
    y9,48     I9,48                           1
    y9,49     E9,49                          -1
    y9,49     I9,49                           1
    y10,11    E10,11                         -1
    y10,11    I10,11                          1
    y10,12    E10,12                         -1
    y10,12    I10,12                          1
    y10,13    E10,13                         -1
    y10,13    I10,13                          1
    y10,14    E10,14                         -1
    y10,14    I10,14                          1
    y10,15    E10,15                         -1
    y10,15    I10,15                          1
    y10,16    E10,16                         -1
    y10,16    I10,16                          1
    y10,20    E10,20                         -1
    y10,20    I10,20                          1
    y10,21    E10,21                         -1
    y10,21    I10,21                          1
    y10,23    E10,23                         -1
    y10,23    I10,23                          1
    y10,24    E10,24                         -1
    y10,24    I10,24                          1
    y10,27    E10,27                         -1
    y10,27    I10,27                          1
    y10,28    E10,28                         -1
    y10,28    I10,28                          1
    y10,29    E10,29                         -1
    y10,29    I10,29                          1
    y10,30    E10,30                         -1
    y10,30    I10,30                          1
    y10,31    E10,31                         -1
    y10,31    I10,31                          1
    y10,32    E10,32                         -1
    y10,32    I10,32                          1
    y10,33    E10,33                         -1
    y10,33    I10,33                          1
    y10,34    E10,34                         -1
    y10,34    I10,34                          1
    y10,35    E10,35                         -1
    y10,35    I10,35                          1
    y10,36    E10,36                         -1
    y10,36    I10,36                          1
    y10,37    E10,37                         -1
    y10,37    I10,37                          1
    y10,40    E10,40                         -1
    y10,40    I10,40                          1
    y10,41    E10,41                         -1
    y10,41    I10,41                          1
    y10,42    E10,42                         -1
    y10,42    I10,42                          1
    y10,43    E10,43                         -1
    y10,43    I10,43                          1
    y10,44    E10,44                         -1
    y10,44    I10,44                          1
    y10,45    E10,45                         -1
    y10,45    I10,45                          1
    y10,46    E10,46                         -1
    y10,46    I10,46                          1
    y10,48    E10,48                         -1
    y10,48    I10,48                          1
    y10,49    E10,49                         -1
    y10,49    I10,49                          1
    y11,12    E11,12                         -1
    y11,12    I11,12                          1
    y11,14    E11,14                         -1
    y11,14    I11,14                          1
    y11,15    E11,15                         -1
    y11,15    I11,15                          1
    y11,16    E11,16                         -1
    y11,16    I11,16                          1
    y11,18    E11,18                         -1
    y11,18    I11,18                          1
    y11,20    E11,20                         -1
    y11,20    I11,20                          1
    y11,21    E11,21                         -1
    y11,21    I11,21                          1
    y11,22    E11,22                         -1
    y11,22    I11,22                          1
    y11,23    E11,23                         -1
    y11,23    I11,23                          1
    y11,25    E11,25                         -1
    y11,25    I11,25                          1
    y11,27    E11,27                         -1
    y11,27    I11,27                          1
    y11,28    E11,28                         -1
    y11,28    I11,28                          1
    y11,29    E11,29                         -1
    y11,29    I11,29                          1
    y11,30    E11,30                         -1
    y11,30    I11,30                          1
    y11,31    E11,31                         -1
    y11,31    I11,31                          1
    y11,33    E11,33                         -1
    y11,33    I11,33                          1
    y11,34    E11,34                         -1
    y11,34    I11,34                          1
    y11,35    E11,35                         -1
    y11,35    I11,35                          1
    y11,36    E11,36                         -1
    y11,36    I11,36                          1
    y11,37    E11,37                         -1
    y11,37    I11,37                          1
    y11,38    E11,38                         -1
    y11,38    I11,38                          1
    y11,39    E11,39                         -1
    y11,39    I11,39                          1
    y11,40    E11,40                         -1
    y11,40    I11,40                          1
    y11,42    E11,42                         -1
    y11,42    I11,42                          1
    y11,43    E11,43                         -1
    y11,43    I11,43                          1
    y11,44    E11,44                         -1
    y11,44    I11,44                          1
    y11,46    E11,46                         -1
    y11,46    I11,46                          1
    y11,47    E11,47                         -1
    y11,47    I11,47                          1
    y11,48    E11,48                         -1
    y11,48    I11,48                          1
    y12,13    E12,13                         -1
    y12,13    I12,13                          1
    y12,14    E12,14                         -1
    y12,14    I12,14                          1
    y12,15    E12,15                         -1
    y12,15    I12,15                          1
    y12,17    E12,17                         -1
    y12,17    I12,17                          1
    y12,20    E12,20                         -1
    y12,20    I12,20                          1
    y12,21    E12,21                         -1
    y12,21    I12,21                          1
    y12,23    E12,23                         -1
    y12,23    I12,23                          1
    y12,24    E12,24                         -1
    y12,24    I12,24                          1
    y12,25    E12,25                         -1
    y12,25    I12,25                          1
    y12,26    E12,26                         -1
    y12,26    I12,26                          1
    y12,27    E12,27                         -1
    y12,27    I12,27                          1
    y12,28    E12,28                         -1
    y12,28    I12,28                          1
    y12,29    E12,29                         -1
    y12,29    I12,29                          1
    y12,30    E12,30                         -1
    y12,30    I12,30                          1
    y12,32    E12,32                         -1
    y12,32    I12,32                          1
    y12,33    E12,33                         -1
    y12,33    I12,33                          1
    y12,34    E12,34                         -1
    y12,34    I12,34                          1
    y12,35    E12,35                         -1
    y12,35    I12,35                          1
    y12,36    E12,36                         -1
    y12,36    I12,36                          1
    y12,37    E12,37                         -1
    y12,37    I12,37                          1
    y12,38    E12,38                         -1
    y12,38    I12,38                          1
    y12,39    E12,39                         -1
    y12,39    I12,39                          1
    y12,40    E12,40                         -1
    y12,40    I12,40                          1
    y12,41    E12,41                         -1
    y12,41    I12,41                          1
    y12,42    E12,42                         -1
    y12,42    I12,42                          1
    y12,44    E12,44                         -1
    y12,44    I12,44                          1
    y12,46    E12,46                         -1
    y12,46    I12,46                          1
    y12,47    E12,47                         -1
    y12,47    I12,47                          1
    y12,49    E12,49                         -1
    y12,49    I12,49                          1
    y13,15    E13,15                         -1
    y13,15    I13,15                          1
    y13,16    E13,16                         -1
    y13,16    I13,16                          1
    y13,18    E13,18                         -1
    y13,18    I13,18                          1
    y13,21    E13,21                         -1
    y13,21    I13,21                          1
    y13,22    E13,22                         -1
    y13,22    I13,22                          1
    y13,23    E13,23                         -1
    y13,23    I13,23                          1
    y13,24    E13,24                         -1
    y13,24    I13,24                          1
    y13,26    E13,26                         -1
    y13,26    I13,26                          1
    y13,27    E13,27                         -1
    y13,27    I13,27                          1
    y13,31    E13,31                         -1
    y13,31    I13,31                          1
    y13,32    E13,32                         -1
    y13,32    I13,32                          1
    y13,34    E13,34                         -1
    y13,34    I13,34                          1
    y13,35    E13,35                         -1
    y13,35    I13,35                          1
    y13,38    E13,38                         -1
    y13,38    I13,38                          1
    y13,39    E13,39                         -1
    y13,39    I13,39                          1
    y13,40    E13,40                         -1
    y13,40    I13,40                          1
    y13,41    E13,41                         -1
    y13,41    I13,41                          1
    y13,42    E13,42                         -1
    y13,42    I13,42                          1
    y13,43    E13,43                         -1
    y13,43    I13,43                          1
    y13,44    E13,44                         -1
    y13,44    I13,44                          1
    y13,45    E13,45                         -1
    y13,45    I13,45                          1
    y13,47    E13,47                         -1
    y13,47    I13,47                          1
    y13,49    E13,49                         -1
    y13,49    I13,49                          1
    y14,15    E14,15                         -1
    y14,15    I14,15                          1
    y14,16    E14,16                         -1
    y14,16    I14,16                          1
    y14,17    E14,17                         -1
    y14,17    I14,17                          1
    y14,18    E14,18                         -1
    y14,18    I14,18                          1
    y14,19    E14,19                         -1
    y14,19    I14,19                          1
    y14,20    E14,20                         -1
    y14,20    I14,20                          1
    y14,22    E14,22                         -1
    y14,22    I14,22                          1
    y14,23    E14,23                         -1
    y14,23    I14,23                          1
    y14,24    E14,24                         -1
    y14,24    I14,24                          1
    y14,25    E14,25                         -1
    y14,25    I14,25                          1
    y14,26    E14,26                         -1
    y14,26    I14,26                          1
    y14,27    E14,27                         -1
    y14,27    I14,27                          1
    y14,30    E14,30                         -1
    y14,30    I14,30                          1
    y14,31    E14,31                         -1
    y14,31    I14,31                          1
    y14,32    E14,32                         -1
    y14,32    I14,32                          1
    y14,33    E14,33                         -1
    y14,33    I14,33                          1
    y14,36    E14,36                         -1
    y14,36    I14,36                          1
    y14,37    E14,37                         -1
    y14,37    I14,37                          1
    y14,39    E14,39                         -1
    y14,39    I14,39                          1
    y14,40    E14,40                         -1
    y14,40    I14,40                          1
    y14,41    E14,41                         -1
    y14,41    I14,41                          1
    y14,46    E14,46                         -1
    y14,46    I14,46                          1
    y14,47    E14,47                         -1
    y14,47    I14,47                          1
    y14,48    E14,48                         -1
    y14,48    I14,48                          1
    y15,16    E15,16                         -1
    y15,16    I15,16                          1
    y15,17    E15,17                         -1
    y15,17    I15,17                          1
    y15,19    E15,19                         -1
    y15,19    I15,19                          1
    y15,20    E15,20                         -1
    y15,20    I15,20                          1
    y15,21    E15,21                         -1
    y15,21    I15,21                          1
    y15,22    E15,22                         -1
    y15,22    I15,22                          1
    y15,23    E15,23                         -1
    y15,23    I15,23                          1
    y15,24    E15,24                         -1
    y15,24    I15,24                          1
    y15,26    E15,26                         -1
    y15,26    I15,26                          1
    y15,27    E15,27                         -1
    y15,27    I15,27                          1
    y15,28    E15,28                         -1
    y15,28    I15,28                          1
    y15,29    E15,29                         -1
    y15,29    I15,29                          1
    y15,30    E15,30                         -1
    y15,30    I15,30                          1
    y15,32    E15,32                         -1
    y15,32    I15,32                          1
    y15,33    E15,33                         -1
    y15,33    I15,33                          1
    y15,34    E15,34                         -1
    y15,34    I15,34                          1
    y15,37    E15,37                         -1
    y15,37    I15,37                          1
    y15,38    E15,38                         -1
    y15,38    I15,38                          1
    y15,40    E15,40                         -1
    y15,40    I15,40                          1
    y15,41    E15,41                         -1
    y15,41    I15,41                          1
    y15,44    E15,44                         -1
    y15,44    I15,44                          1
    y15,45    E15,45                         -1
    y15,45    I15,45                          1
    y15,46    E15,46                         -1
    y15,46    I15,46                          1
    y15,48    E15,48                         -1
    y15,48    I15,48                          1
    y16,17    E16,17                         -1
    y16,17    I16,17                          1
    y16,18    E16,18                         -1
    y16,18    I16,18                          1
    y16,19    E16,19                         -1
    y16,19    I16,19                          1
    y16,22    E16,22                         -1
    y16,22    I16,22                          1
    y16,23    E16,23                         -1
    y16,23    I16,23                          1
    y16,26    E16,26                         -1
    y16,26    I16,26                          1
    y16,27    E16,27                         -1
    y16,27    I16,27                          1
    y16,28    E16,28                         -1
    y16,28    I16,28                          1
    y16,29    E16,29                         -1
    y16,29    I16,29                          1
    y16,30    E16,30                         -1
    y16,30    I16,30                          1
    y16,31    E16,31                         -1
    y16,31    I16,31                          1
    y16,37    E16,37                         -1
    y16,37    I16,37                          1
    y16,38    E16,38                         -1
    y16,38    I16,38                          1
    y16,39    E16,39                         -1
    y16,39    I16,39                          1
    y16,40    E16,40                         -1
    y16,40    I16,40                          1
    y16,41    E16,41                         -1
    y16,41    I16,41                          1
    y16,44    E16,44                         -1
    y16,44    I16,44                          1
    y16,46    E16,46                         -1
    y16,46    I16,46                          1
    y16,47    E16,47                         -1
    y16,47    I16,47                          1
    y16,48    E16,48                         -1
    y16,48    I16,48                          1
    y16,49    E16,49                         -1
    y16,49    I16,49                          1
    y17,18    E17,18                         -1
    y17,18    I17,18                          1
    y17,19    E17,19                         -1
    y17,19    I17,19                          1
    y17,20    E17,20                         -1
    y17,20    I17,20                          1
    y17,21    E17,21                         -1
    y17,21    I17,21                          1
    y17,22    E17,22                         -1
    y17,22    I17,22                          1
    y17,23    E17,23                         -1
    y17,23    I17,23                          1
    y17,27    E17,27                         -1
    y17,27    I17,27                          1
    y17,29    E17,29                         -1
    y17,29    I17,29                          1
    y17,30    E17,30                         -1
    y17,30    I17,30                          1
    y17,31    E17,31                         -1
    y17,31    I17,31                          1
    y17,32    E17,32                         -1
    y17,32    I17,32                          1
    y17,33    E17,33                         -1
    y17,33    I17,33                          1
    y17,35    E17,35                         -1
    y17,35    I17,35                          1
    y17,36    E17,36                         -1
    y17,36    I17,36                          1
    y17,39    E17,39                         -1
    y17,39    I17,39                          1
    y17,40    E17,40                         -1
    y17,40    I17,40                          1
    y17,41    E17,41                         -1
    y17,41    I17,41                          1
    y17,42    E17,42                         -1
    y17,42    I17,42                          1
    y17,43    E17,43                         -1
    y17,43    I17,43                          1
    y17,44    E17,44                         -1
    y17,44    I17,44                          1
    y17,46    E17,46                         -1
    y17,46    I17,46                          1
    y17,47    E17,47                         -1
    y17,47    I17,47                          1
    y17,49    E17,49                         -1
    y17,49    I17,49                          1
    y18,21    E18,21                         -1
    y18,21    I18,21                          1
    y18,22    E18,22                         -1
    y18,22    I18,22                          1
    y18,23    E18,23                         -1
    y18,23    I18,23                          1
    y18,24    E18,24                         -1
    y18,24    I18,24                          1
    y18,26    E18,26                         -1
    y18,26    I18,26                          1
    y18,27    E18,27                         -1
    y18,27    I18,27                          1
    y18,31    E18,31                         -1
    y18,31    I18,31                          1
    y18,32    E18,32                         -1
    y18,32    I18,32                          1
    y18,33    E18,33                         -1
    y18,33    I18,33                          1
    y18,34    E18,34                         -1
    y18,34    I18,34                          1
    y18,35    E18,35                         -1
    y18,35    I18,35                          1
    y18,36    E18,36                         -1
    y18,36    I18,36                          1
    y18,37    E18,37                         -1
    y18,37    I18,37                          1
    y18,38    E18,38                         -1
    y18,38    I18,38                          1
    y18,40    E18,40                         -1
    y18,40    I18,40                          1
    y18,42    E18,42                         -1
    y18,42    I18,42                          1
    y18,43    E18,43                         -1
    y18,43    I18,43                          1
    y18,45    E18,45                         -1
    y18,45    I18,45                          1
    y18,46    E18,46                         -1
    y18,46    I18,46                          1
    y18,47    E18,47                         -1
    y18,47    I18,47                          1
    y18,48    E18,48                         -1
    y18,48    I18,48                          1
    y18,49    E18,49                         -1
    y18,49    I18,49                          1
    y19,21    E19,21                         -1
    y19,21    I19,21                          1
    y19,23    E19,23                         -1
    y19,23    I19,23                          1
    y19,24    E19,24                         -1
    y19,24    I19,24                          1
    y19,25    E19,25                         -1
    y19,25    I19,25                          1
    y19,26    E19,26                         -1
    y19,26    I19,26                          1
    y19,28    E19,28                         -1
    y19,28    I19,28                          1
    y19,29    E19,29                         -1
    y19,29    I19,29                          1
    y19,30    E19,30                         -1
    y19,30    I19,30                          1
    y19,31    E19,31                         -1
    y19,31    I19,31                          1
    y19,32    E19,32                         -1
    y19,32    I19,32                          1
    y19,34    E19,34                         -1
    y19,34    I19,34                          1
    y19,37    E19,37                         -1
    y19,37    I19,37                          1
    y19,38    E19,38                         -1
    y19,38    I19,38                          1
    y19,39    E19,39                         -1
    y19,39    I19,39                          1
    y19,40    E19,40                         -1
    y19,40    I19,40                          1
    y19,41    E19,41                         -1
    y19,41    I19,41                          1
    y19,44    E19,44                         -1
    y19,44    I19,44                          1
    y19,45    E19,45                         -1
    y19,45    I19,45                          1
    y19,46    E19,46                         -1
    y19,46    I19,46                          1
    y19,47    E19,47                         -1
    y19,47    I19,47                          1
    y19,48    E19,48                         -1
    y19,48    I19,48                          1
    y19,49    E19,49                         -1
    y19,49    I19,49                          1
    y20,21    E20,21                         -1
    y20,21    I20,21                          1
    y20,22    E20,22                         -1
    y20,22    I20,22                          1
    y20,23    E20,23                         -1
    y20,23    I20,23                          1
    y20,24    E20,24                         -1
    y20,24    I20,24                          1
    y20,26    E20,26                         -1
    y20,26    I20,26                          1
    y20,27    E20,27                         -1
    y20,27    I20,27                          1
    y20,29    E20,29                         -1
    y20,29    I20,29                          1
    y20,30    E20,30                         -1
    y20,30    I20,30                          1
    y20,32    E20,32                         -1
    y20,32    I20,32                          1
    y20,33    E20,33                         -1
    y20,33    I20,33                          1
    y20,35    E20,35                         -1
    y20,35    I20,35                          1
    y20,37    E20,37                         -1
    y20,37    I20,37                          1
    y20,39    E20,39                         -1
    y20,39    I20,39                          1
    y20,40    E20,40                         -1
    y20,40    I20,40                          1
    y20,41    E20,41                         -1
    y20,41    I20,41                          1
    y20,43    E20,43                         -1
    y20,43    I20,43                          1
    y20,44    E20,44                         -1
    y20,44    I20,44                          1
    y20,45    E20,45                         -1
    y20,45    I20,45                          1
    y20,47    E20,47                         -1
    y20,47    I20,47                          1
    y20,48    E20,48                         -1
    y20,48    I20,48                          1
    y20,49    E20,49                         -1
    y20,49    I20,49                          1
    y21,22    E21,22                         -1
    y21,22    I21,22                          1
    y21,25    E21,25                         -1
    y21,25    I21,25                          1
    y21,26    E21,26                         -1
    y21,26    I21,26                          1
    y21,27    E21,27                         -1
    y21,27    I21,27                          1
    y21,29    E21,29                         -1
    y21,29    I21,29                          1
    y21,33    E21,33                         -1
    y21,33    I21,33                          1
    y21,34    E21,34                         -1
    y21,34    I21,34                          1
    y21,35    E21,35                         -1
    y21,35    I21,35                          1
    y21,36    E21,36                         -1
    y21,36    I21,36                          1
    y21,38    E21,38                         -1
    y21,38    I21,38                          1
    y21,39    E21,39                         -1
    y21,39    I21,39                          1
    y21,42    E21,42                         -1
    y21,42    I21,42                          1
    y21,44    E21,44                         -1
    y21,44    I21,44                          1
    y21,45    E21,45                         -1
    y21,45    I21,45                          1
    y21,47    E21,47                         -1
    y21,47    I21,47                          1
    y21,49    E21,49                         -1
    y21,49    I21,49                          1
    y22,23    E22,23                         -1
    y22,23    I22,23                          1
    y22,24    E22,24                         -1
    y22,24    I22,24                          1
    y22,25    E22,25                         -1
    y22,25    I22,25                          1
    y22,26    E22,26                         -1
    y22,26    I22,26                          1
    y22,27    E22,27                         -1
    y22,27    I22,27                          1
    y22,29    E22,29                         -1
    y22,29    I22,29                          1
    y22,30    E22,30                         -1
    y22,30    I22,30                          1
    y22,31    E22,31                         -1
    y22,31    I22,31                          1
    y22,35    E22,35                         -1
    y22,35    I22,35                          1
    y22,36    E22,36                         -1
    y22,36    I22,36                          1
    y22,38    E22,38                         -1
    y22,38    I22,38                          1
    y22,39    E22,39                         -1
    y22,39    I22,39                          1
    y22,40    E22,40                         -1
    y22,40    I22,40                          1
    y22,42    E22,42                         -1
    y22,42    I22,42                          1
    y22,43    E22,43                         -1
    y22,43    I22,43                          1
    y22,45    E22,45                         -1
    y22,45    I22,45                          1
    y22,47    E22,47                         -1
    y22,47    I22,47                          1
    y22,48    E22,48                         -1
    y22,48    I22,48                          1
    y23,25    E23,25                         -1
    y23,25    I23,25                          1
    y23,26    E23,26                         -1
    y23,26    I23,26                          1
    y23,27    E23,27                         -1
    y23,27    I23,27                          1
    y23,28    E23,28                         -1
    y23,28    I23,28                          1
    y23,29    E23,29                         -1
    y23,29    I23,29                          1
    y23,30    E23,30                         -1
    y23,30    I23,30                          1
    y23,31    E23,31                         -1
    y23,31    I23,31                          1
    y23,32    E23,32                         -1
    y23,32    I23,32                          1
    y23,33    E23,33                         -1
    y23,33    I23,33                          1
    y23,34    E23,34                         -1
    y23,34    I23,34                          1
    y23,35    E23,35                         -1
    y23,35    I23,35                          1
    y23,37    E23,37                         -1
    y23,37    I23,37                          1
    y23,39    E23,39                         -1
    y23,39    I23,39                          1
    y23,40    E23,40                         -1
    y23,40    I23,40                          1
    y23,42    E23,42                         -1
    y23,42    I23,42                          1
    y23,44    E23,44                         -1
    y23,44    I23,44                          1
    y23,46    E23,46                         -1
    y23,46    I23,46                          1
    y23,47    E23,47                         -1
    y23,47    I23,47                          1
    y23,48    E23,48                         -1
    y23,48    I23,48                          1
    y24,25    E24,25                         -1
    y24,25    I24,25                          1
    y24,26    E24,26                         -1
    y24,26    I24,26                          1
    y24,27    E24,27                         -1
    y24,27    I24,27                          1
    y24,29    E24,29                         -1
    y24,29    I24,29                          1
    y24,30    E24,30                         -1
    y24,30    I24,30                          1
    y24,32    E24,32                         -1
    y24,32    I24,32                          1
    y24,33    E24,33                         -1
    y24,33    I24,33                          1
    y24,35    E24,35                         -1
    y24,35    I24,35                          1
    y24,36    E24,36                         -1
    y24,36    I24,36                          1
    y24,38    E24,38                         -1
    y24,38    I24,38                          1
    y24,41    E24,41                         -1
    y24,41    I24,41                          1
    y24,42    E24,42                         -1
    y24,42    I24,42                          1
    y24,43    E24,43                         -1
    y24,43    I24,43                          1
    y24,44    E24,44                         -1
    y24,44    I24,44                          1
    y24,46    E24,46                         -1
    y24,46    I24,46                          1
    y24,49    E24,49                         -1
    y24,49    I24,49                          1
    y25,26    E25,26                         -1
    y25,26    I25,26                          1
    y25,27    E25,27                         -1
    y25,27    I25,27                          1
    y25,28    E25,28                         -1
    y25,28    I25,28                          1
    y25,30    E25,30                         -1
    y25,30    I25,30                          1
    y25,31    E25,31                         -1
    y25,31    I25,31                          1
    y25,33    E25,33                         -1
    y25,33    I25,33                          1
    y25,34    E25,34                         -1
    y25,34    I25,34                          1
    y25,35    E25,35                         -1
    y25,35    I25,35                          1
    y25,36    E25,36                         -1
    y25,36    I25,36                          1
    y25,40    E25,40                         -1
    y25,40    I25,40                          1
    y25,41    E25,41                         -1
    y25,41    I25,41                          1
    y25,42    E25,42                         -1
    y25,42    I25,42                          1
    y25,44    E25,44                         -1
    y25,44    I25,44                          1
    y25,46    E25,46                         -1
    y25,46    I25,46                          1
    y25,47    E25,47                         -1
    y25,47    I25,47                          1
    y25,48    E25,48                         -1
    y25,48    I25,48                          1
    y25,49    E25,49                         -1
    y25,49    I25,49                          1
    y26,27    E26,27                         -1
    y26,27    I26,27                          1
    y26,28    E26,28                         -1
    y26,28    I26,28                          1
    y26,29    E26,29                         -1
    y26,29    I26,29                          1
    y26,30    E26,30                         -1
    y26,30    I26,30                          1
    y26,31    E26,31                         -1
    y26,31    I26,31                          1
    y26,32    E26,32                         -1
    y26,32    I26,32                          1
    y26,34    E26,34                         -1
    y26,34    I26,34                          1
    y26,35    E26,35                         -1
    y26,35    I26,35                          1
    y26,37    E26,37                         -1
    y26,37    I26,37                          1
    y26,38    E26,38                         -1
    y26,38    I26,38                          1
    y26,40    E26,40                         -1
    y26,40    I26,40                          1
    y26,41    E26,41                         -1
    y26,41    I26,41                          1
    y26,42    E26,42                         -1
    y26,42    I26,42                          1
    y26,44    E26,44                         -1
    y26,44    I26,44                          1
    y26,45    E26,45                         -1
    y26,45    I26,45                          1
    y26,46    E26,46                         -1
    y26,46    I26,46                          1
    y26,48    E26,48                         -1
    y26,48    I26,48                          1
    y26,49    E26,49                         -1
    y26,49    I26,49                          1
    y27,28    E27,28                         -1
    y27,28    I27,28                          1
    y27,29    E27,29                         -1
    y27,29    I27,29                          1
    y27,30    E27,30                         -1
    y27,30    I27,30                          1
    y27,31    E27,31                         -1
    y27,31    I27,31                          1
    y27,34    E27,34                         -1
    y27,34    I27,34                          1
    y27,35    E27,35                         -1
    y27,35    I27,35                          1
    y27,36    E27,36                         -1
    y27,36    I27,36                          1
    y27,40    E27,40                         -1
    y27,40    I27,40                          1
    y27,42    E27,42                         -1
    y27,42    I27,42                          1
    y27,43    E27,43                         -1
    y27,43    I27,43                          1
    y27,44    E27,44                         -1
    y27,44    I27,44                          1
    y27,45    E27,45                         -1
    y27,45    I27,45                          1
    y27,47    E27,47                         -1
    y27,47    I27,47                          1
    y27,48    E27,48                         -1
    y27,48    I27,48                          1
    y27,49    E27,49                         -1
    y27,49    I27,49                          1
    y28,31    E28,31                         -1
    y28,31    I28,31                          1
    y28,32    E28,32                         -1
    y28,32    I28,32                          1
    y28,33    E28,33                         -1
    y28,33    I28,33                          1
    y28,34    E28,34                         -1
    y28,34    I28,34                          1
    y28,35    E28,35                         -1
    y28,35    I28,35                          1
    y28,36    E28,36                         -1
    y28,36    I28,36                          1
    y28,37    E28,37                         -1
    y28,37    I28,37                          1
    y28,38    E28,38                         -1
    y28,38    I28,38                          1
    y28,39    E28,39                         -1
    y28,39    I28,39                          1
    y28,40    E28,40                         -1
    y28,40    I28,40                          1
    y28,41    E28,41                         -1
    y28,41    I28,41                          1
    y28,42    E28,42                         -1
    y28,42    I28,42                          1
    y28,43    E28,43                         -1
    y28,43    I28,43                          1
    y28,44    E28,44                         -1
    y28,44    I28,44                          1
    y28,45    E28,45                         -1
    y28,45    I28,45                          1
    y28,46    E28,46                         -1
    y28,46    I28,46                          1
    y28,48    E28,48                         -1
    y28,48    I28,48                          1
    y28,49    E28,49                         -1
    y28,49    I28,49                          1
    y29,30    E29,30                         -1
    y29,30    I29,30                          1
    y29,31    E29,31                         -1
    y29,31    I29,31                          1
    y29,32    E29,32                         -1
    y29,32    I29,32                          1
    y29,34    E29,34                         -1
    y29,34    I29,34                          1
    y29,35    E29,35                         -1
    y29,35    I29,35                          1
    y29,36    E29,36                         -1
    y29,36    I29,36                          1
    y29,37    E29,37                         -1
    y29,37    I29,37                          1
    y29,38    E29,38                         -1
    y29,38    I29,38                          1
    y29,39    E29,39                         -1
    y29,39    I29,39                          1
    y29,40    E29,40                         -1
    y29,40    I29,40                          1
    y29,42    E29,42                         -1
    y29,42    I29,42                          1
    y29,43    E29,43                         -1
    y29,43    I29,43                          1
    y29,44    E29,44                         -1
    y29,44    I29,44                          1
    y29,45    E29,45                         -1
    y29,45    I29,45                          1
    y29,47    E29,47                         -1
    y29,47    I29,47                          1
    y29,48    E29,48                         -1
    y29,48    I29,48                          1
    y29,49    E29,49                         -1
    y29,49    I29,49                          1
    y30,32    E30,32                         -1
    y30,32    I30,32                          1
    y30,33    E30,33                         -1
    y30,33    I30,33                          1
    y30,34    E30,34                         -1
    y30,34    I30,34                          1
    y30,35    E30,35                         -1
    y30,35    I30,35                          1
    y30,36    E30,36                         -1
    y30,36    I30,36                          1
    y30,37    E30,37                         -1
    y30,37    I30,37                          1
    y30,38    E30,38                         -1
    y30,38    I30,38                          1
    y30,39    E30,39                         -1
    y30,39    I30,39                          1
    y30,40    E30,40                         -1
    y30,40    I30,40                          1
    y30,43    E30,43                         -1
    y30,43    I30,43                          1
    y30,44    E30,44                         -1
    y30,44    I30,44                          1
    y30,45    E30,45                         -1
    y30,45    I30,45                          1
    y30,46    E30,46                         -1
    y30,46    I30,46                          1
    y30,47    E30,47                         -1
    y30,47    I30,47                          1
    y30,49    E30,49                         -1
    y30,49    I30,49                          1
    y31,34    E31,34                         -1
    y31,34    I31,34                          1
    y31,35    E31,35                         -1
    y31,35    I31,35                          1
    y31,36    E31,36                         -1
    y31,36    I31,36                          1
    y31,37    E31,37                         -1
    y31,37    I31,37                          1
    y31,39    E31,39                         -1
    y31,39    I31,39                          1
    y31,40    E31,40                         -1
    y31,40    I31,40                          1
    y31,41    E31,41                         -1
    y31,41    I31,41                          1
    y31,43    E31,43                         -1
    y31,43    I31,43                          1
    y31,45    E31,45                         -1
    y31,45    I31,45                          1
    y31,46    E31,46                         -1
    y31,46    I31,46                          1
    y31,48    E31,48                         -1
    y31,48    I31,48                          1
    y31,49    E31,49                         -1
    y31,49    I31,49                          1
    y32,33    E32,33                         -1
    y32,33    I32,33                          1
    y32,34    E32,34                         -1
    y32,34    I32,34                          1
    y32,37    E32,37                         -1
    y32,37    I32,37                          1
    y32,38    E32,38                         -1
    y32,38    I32,38                          1
    y32,39    E32,39                         -1
    y32,39    I32,39                          1
    y32,40    E32,40                         -1
    y32,40    I32,40                          1
    y32,41    E32,41                         -1
    y32,41    I32,41                          1
    y32,42    E32,42                         -1
    y32,42    I32,42                          1
    y32,43    E32,43                         -1
    y32,43    I32,43                          1
    y32,46    E32,46                         -1
    y32,46    I32,46                          1
    y32,47    E32,47                         -1
    y32,47    I32,47                          1
    y32,48    E32,48                         -1
    y32,48    I32,48                          1
    y32,49    E32,49                         -1
    y32,49    I32,49                          1
    y33,34    E33,34                         -1
    y33,34    I33,34                          1
    y33,36    E33,36                         -1
    y33,36    I33,36                          1
    y33,37    E33,37                         -1
    y33,37    I33,37                          1
    y33,38    E33,38                         -1
    y33,38    I33,38                          1
    y33,39    E33,39                         -1
    y33,39    I33,39                          1
    y33,42    E33,42                         -1
    y33,42    I33,42                          1
    y33,44    E33,44                         -1
    y33,44    I33,44                          1
    y33,45    E33,45                         -1
    y33,45    I33,45                          1
    y33,46    E33,46                         -1
    y33,46    I33,46                          1
    y33,48    E33,48                         -1
    y33,48    I33,48                          1
    y33,49    E33,49                         -1
    y33,49    I33,49                          1
    y34,36    E34,36                         -1
    y34,36    I34,36                          1
    y34,38    E34,38                         -1
    y34,38    I34,38                          1
    y34,40    E34,40                         -1
    y34,40    I34,40                          1
    y34,43    E34,43                         -1
    y34,43    I34,43                          1
    y34,44    E34,44                         -1
    y34,44    I34,44                          1
    y34,45    E34,45                         -1
    y34,45    I34,45                          1
    y34,46    E34,46                         -1
    y34,46    I34,46                          1
    y34,47    E34,47                         -1
    y34,47    I34,47                          1
    y34,49    E34,49                         -1
    y34,49    I34,49                          1
    y35,36    E35,36                         -1
    y35,36    I35,36                          1
    y35,37    E35,37                         -1
    y35,37    I35,37                          1
    y35,38    E35,38                         -1
    y35,38    I35,38                          1
    y35,39    E35,39                         -1
    y35,39    I35,39                          1
    y35,40    E35,40                         -1
    y35,40    I35,40                          1
    y35,43    E35,43                         -1
    y35,43    I35,43                          1
    y35,44    E35,44                         -1
    y35,44    I35,44                          1
    y35,46    E35,46                         -1
    y35,46    I35,46                          1
    y35,47    E35,47                         -1
    y35,47    I35,47                          1
    y35,49    E35,49                         -1
    y35,49    I35,49                          1
    y36,37    E36,37                         -1
    y36,37    I36,37                          1
    y36,38    E36,38                         -1
    y36,38    I36,38                          1
    y36,40    E36,40                         -1
    y36,40    I36,40                          1
    y36,41    E36,41                         -1
    y36,41    I36,41                          1
    y36,44    E36,44                         -1
    y36,44    I36,44                          1
    y36,45    E36,45                         -1
    y36,45    I36,45                          1
    y36,46    E36,46                         -1
    y36,46    I36,46                          1
    y36,47    E36,47                         -1
    y36,47    I36,47                          1
    y36,48    E36,48                         -1
    y36,48    I36,48                          1
    y36,49    E36,49                         -1
    y36,49    I36,49                          1
    y37,39    E37,39                         -1
    y37,39    I37,39                          1
    y37,40    E37,40                         -1
    y37,40    I37,40                          1
    y37,42    E37,42                         -1
    y37,42    I37,42                          1
    y37,43    E37,43                         -1
    y37,43    I37,43                          1
    y37,44    E37,44                         -1
    y37,44    I37,44                          1
    y37,45    E37,45                         -1
    y37,45    I37,45                          1
    y37,46    E37,46                         -1
    y37,46    I37,46                          1
    y37,47    E37,47                         -1
    y37,47    I37,47                          1
    y37,48    E37,48                         -1
    y37,48    I37,48                          1
    y37,49    E37,49                         -1
    y37,49    I37,49                          1
    y38,39    E38,39                         -1
    y38,39    I38,39                          1
    y38,40    E38,40                         -1
    y38,40    I38,40                          1
    y38,42    E38,42                         -1
    y38,42    I38,42                          1
    y38,43    E38,43                         -1
    y38,43    I38,43                          1
    y38,44    E38,44                         -1
    y38,44    I38,44                          1
    y38,45    E38,45                         -1
    y38,45    I38,45                          1
    y38,46    E38,46                         -1
    y38,46    I38,46                          1
    y38,48    E38,48                         -1
    y38,48    I38,48                          1
    y38,49    E38,49                         -1
    y38,49    I38,49                          1
    y39,41    E39,41                         -1
    y39,41    I39,41                          1
    y39,42    E39,42                         -1
    y39,42    I39,42                          1
    y39,44    E39,44                         -1
    y39,44    I39,44                          1
    y39,45    E39,45                         -1
    y39,45    I39,45                          1
    y39,49    E39,49                         -1
    y39,49    I39,49                          1
    y40,43    E40,43                         -1
    y40,43    I40,43                          1
    y40,45    E40,45                         -1
    y40,45    I40,45                          1
    y40,47    E40,47                         -1
    y40,47    I40,47                          1
    y40,48    E40,48                         -1
    y40,48    I40,48                          1
    y41,42    E41,42                         -1
    y41,42    I41,42                          1
    y41,43    E41,43                         -1
    y41,43    I41,43                          1
    y41,44    E41,44                         -1
    y41,44    I41,44                          1
    y41,45    E41,45                         -1
    y41,45    I41,45                          1
    y41,46    E41,46                         -1
    y41,46    I41,46                          1
    y41,47    E41,47                         -1
    y41,47    I41,47                          1
    y41,48    E41,48                         -1
    y41,48    I41,48                          1
    y42,43    E42,43                         -1
    y42,43    I42,43                          1
    y42,45    E42,45                         -1
    y42,45    I42,45                          1
    y42,46    E42,46                         -1
    y42,46    I42,46                          1
    y42,48    E42,48                         -1
    y42,48    I42,48                          1
    y42,49    E42,49                         -1
    y42,49    I42,49                          1
    y43,45    E43,45                         -1
    y43,45    I43,45                          1
    y43,46    E43,46                         -1
    y43,46    I43,46                          1
    y43,47    E43,47                         -1
    y43,47    I43,47                          1
    y43,49    E43,49                         -1
    y43,49    I43,49                          1
    y44,45    E44,45                         -1
    y44,45    I44,45                          1
    y44,46    E44,46                         -1
    y44,46    I44,46                          1
    y44,48    E44,48                         -1
    y44,48    I44,48                          1
    y44,49    E44,49                         -1
    y44,49    I44,49                          1
    y45,47    E45,47                         -1
    y45,47    I45,47                          1
    y46,47    E46,47                         -1
    y46,47    I46,47                          1
    y46,48    E46,48                         -1
    y46,48    I46,48                          1
    y46,49    E46,49                         -1
    y46,49    I46,49                          1
    y47,48    E47,48                         -1
    y47,48    I47,48                          1
    y47,49    E47,49                         -1
    y47,49    I47,49                          1
    x0        cost                            1
    x0        C0,9                            1
    x0        C0,11                           1
    x0        C0,13                           1
    x0        C0,18                           1
    x0        C0,25                           1
    x0        C0,28                           1
    x0        C0,30                           1
    x0        C0,31                           1
    x0        C0,36                           1
    x0        C0,44                           1
    x0        C0,48                           1
    x0        C0,49                           1
    x0        E0,1                            1
    x0        E0,2                            1
    x0        E0,3                            1
    x0        E0,4                            1
    x0        E0,5                            1
    x0        E0,6                            1
    x0        E0,7                            1
    x0        E0,8                            1
    x0        E0,10                           1
    x0        E0,12                           1
    x0        E0,14                           1
    x0        E0,15                           1
    x0        E0,16                           1
    x0        E0,17                           1
    x0        E0,19                           1
    x0        E0,20                           1
    x0        E0,21                           1
    x0        E0,22                           1
    x0        E0,23                           1
    x0        E0,24                           1
    x0        E0,26                           1
    x0        E0,27                           1
    x0        E0,29                           1
    x0        E0,32                           1
    x0        E0,33                           1
    x0        E0,34                           1
    x0        E0,35                           1
    x0        E0,37                           1
    x0        E0,38                           1
    x0        E0,39                           1
    x0        E0,40                           1
    x0        E0,41                           1
    x0        E0,42                           1
    x0        E0,43                           1
    x0        E0,45                           1
    x0        E0,46                           1
    x0        E0,47                           1
    x1        cost                            1
    x1        C1,2                            1
    x1        C1,10                           1
    x1        C1,14                           1
    x1        C1,15                           1
    x1        C1,19                           1
    x1        C1,28                           1
    x1        C1,32                           1
    x1        C1,38                           1
    x1        C1,39                           1
    x1        C1,42                           1
    x1        C1,43                           1
    x1        C1,45                           1
    x1        C1,46                           1
    x1        C1,47                           1
    x1        C1,49                           1
    x1        E0,1                            1
    x1        E1,3                            1
    x1        E1,4                            1
    x1        E1,5                            1
    x1        E1,6                            1
    x1        E1,7                            1
    x1        E1,8                            1
    x1        E1,9                            1
    x1        E1,11                           1
    x1        E1,12                           1
    x1        E1,13                           1
    x1        E1,16                           1
    x1        E1,17                           1
    x1        E1,18                           1
    x1        E1,20                           1
    x1        E1,21                           1
    x1        E1,22                           1
    x1        E1,23                           1
    x1        E1,24                           1
    x1        E1,25                           1
    x1        E1,26                           1
    x1        E1,27                           1
    x1        E1,29                           1
    x1        E1,30                           1
    x1        E1,31                           1
    x1        E1,33                           1
    x1        E1,34                           1
    x1        E1,35                           1
    x1        E1,36                           1
    x1        E1,37                           1
    x1        E1,40                           1
    x1        E1,41                           1
    x1        E1,44                           1
    x1        E1,48                           1
    x2        cost                            1
    x2        C1,2                            1
    x2        C2,6                            1
    x2        C2,8                            1
    x2        C2,9                            1
    x2        C2,11                           1
    x2        C2,13                           1
    x2        C2,15                           1
    x2        C2,17                           1
    x2        C2,22                           1
    x2        C2,23                           1
    x2        C2,24                           1
    x2        C2,25                           1
    x2        C2,27                           1
    x2        C2,30                           1
    x2        C2,41                           1
    x2        C2,42                           1
    x2        C2,43                           1
    x2        C2,47                           1
    x2        E0,2                            1
    x2        E2,3                            1
    x2        E2,4                            1
    x2        E2,5                            1
    x2        E2,7                            1
    x2        E2,10                           1
    x2        E2,12                           1
    x2        E2,14                           1
    x2        E2,16                           1
    x2        E2,18                           1
    x2        E2,19                           1
    x2        E2,20                           1
    x2        E2,21                           1
    x2        E2,26                           1
    x2        E2,28                           1
    x2        E2,29                           1
    x2        E2,31                           1
    x2        E2,32                           1
    x2        E2,33                           1
    x2        E2,34                           1
    x2        E2,35                           1
    x2        E2,36                           1
    x2        E2,37                           1
    x2        E2,38                           1
    x2        E2,39                           1
    x2        E2,40                           1
    x2        E2,44                           1
    x2        E2,45                           1
    x2        E2,46                           1
    x2        E2,48                           1
    x2        E2,49                           1
    x3        cost                            1
    x3        C3,5                            1
    x3        C3,19                           1
    x3        C3,20                           1
    x3        C3,23                           1
    x3        C3,27                           1
    x3        C3,28                           1
    x3        C3,32                           1
    x3        C3,34                           1
    x3        C3,39                           1
    x3        C3,40                           1
    x3        C3,41                           1
    x3        C3,42                           1
    x3        C3,44                           1
    x3        C3,46                           1
    x3        C3,48                           1
    x3        C3,49                           1
    x3        E0,3                            1
    x3        E1,3                            1
    x3        E2,3                            1
    x3        E3,4                            1
    x3        E3,6                            1
    x3        E3,7                            1
    x3        E3,8                            1
    x3        E3,9                            1
    x3        E3,10                           1
    x3        E3,11                           1
    x3        E3,12                           1
    x3        E3,13                           1
    x3        E3,14                           1
    x3        E3,15                           1
    x3        E3,16                           1
    x3        E3,17                           1
    x3        E3,18                           1
    x3        E3,21                           1
    x3        E3,22                           1
    x3        E3,24                           1
    x3        E3,25                           1
    x3        E3,26                           1
    x3        E3,29                           1
    x3        E3,30                           1
    x3        E3,31                           1
    x3        E3,33                           1
    x3        E3,35                           1
    x3        E3,36                           1
    x3        E3,37                           1
    x3        E3,38                           1
    x3        E3,43                           1
    x3        E3,45                           1
    x3        E3,47                           1
    x4        cost                            1
    x4        C4,6                            1
    x4        C4,7                            1
    x4        C4,8                            1
    x4        C4,10                           1
    x4        C4,18                           1
    x4        C4,20                           1
    x4        C4,21                           1
    x4        C4,28                           1
    x4        C4,29                           1
    x4        C4,30                           1
    x4        C4,39                           1
    x4        C4,43                           1
    x4        C4,49                           1
    x4        E0,4                            1
    x4        E1,4                            1
    x4        E2,4                            1
    x4        E3,4                            1
    x4        E4,5                            1
    x4        E4,9                            1
    x4        E4,11                           1
    x4        E4,12                           1
    x4        E4,13                           1
    x4        E4,14                           1
    x4        E4,15                           1
    x4        E4,16                           1
    x4        E4,17                           1
    x4        E4,19                           1
    x4        E4,22                           1
    x4        E4,23                           1
    x4        E4,24                           1
    x4        E4,25                           1
    x4        E4,26                           1
    x4        E4,27                           1
    x4        E4,31                           1
    x4        E4,32                           1
    x4        E4,33                           1
    x4        E4,34                           1
    x4        E4,35                           1
    x4        E4,36                           1
    x4        E4,37                           1
    x4        E4,38                           1
    x4        E4,40                           1
    x4        E4,41                           1
    x4        E4,42                           1
    x4        E4,44                           1
    x4        E4,45                           1
    x4        E4,46                           1
    x4        E4,47                           1
    x4        E4,48                           1
    x5        cost                            1
    x5        C3,5                            1
    x5        C5,18                           1
    x5        C5,21                           1
    x5        C5,29                           1
    x5        C5,32                           1
    x5        C5,34                           1
    x5        C5,36                           1
    x5        C5,37                           1
    x5        C5,43                           1
    x5        C5,44                           1
    x5        C5,46                           1
    x5        E0,5                            1
    x5        E1,5                            1
    x5        E2,5                            1
    x5        E4,5                            1
    x5        E5,6                            1
    x5        E5,7                            1
    x5        E5,8                            1
    x5        E5,9                            1
    x5        E5,10                           1
    x5        E5,11                           1
    x5        E5,12                           1
    x5        E5,13                           1
    x5        E5,14                           1
    x5        E5,15                           1
    x5        E5,16                           1
    x5        E5,17                           1
    x5        E5,19                           1
    x5        E5,20                           1
    x5        E5,22                           1
    x5        E5,23                           1
    x5        E5,24                           1
    x5        E5,25                           1
    x5        E5,26                           1
    x5        E5,27                           1
    x5        E5,28                           1
    x5        E5,30                           1
    x5        E5,31                           1
    x5        E5,33                           1
    x5        E5,35                           1
    x5        E5,38                           1
    x5        E5,39                           1
    x5        E5,40                           1
    x5        E5,41                           1
    x5        E5,42                           1
    x5        E5,45                           1
    x5        E5,47                           1
    x5        E5,48                           1
    x5        E5,49                           1
    x6        cost                            1
    x6        C2,6                            1
    x6        C4,6                            1
    x6        C6,7                            1
    x6        C6,8                            1
    x6        C6,12                           1
    x6        C6,14                           1
    x6        C6,15                           1
    x6        C6,18                           1
    x6        C6,19                           1
    x6        C6,20                           1
    x6        C6,22                           1
    x6        C6,25                           1
    x6        C6,33                           1
    x6        C6,37                           1
    x6        C6,39                           1
    x6        C6,40                           1
    x6        C6,41                           1
    x6        C6,42                           1
    x6        C6,44                           1
    x6        C6,45                           1
    x6        C6,48                           1
    x6        E0,6                            1
    x6        E1,6                            1
    x6        E3,6                            1
    x6        E5,6                            1
    x6        E6,9                            1
    x6        E6,10                           1
    x6        E6,11                           1
    x6        E6,13                           1
    x6        E6,16                           1
    x6        E6,17                           1
    x6        E6,21                           1
    x6        E6,23                           1
    x6        E6,24                           1
    x6        E6,26                           1
    x6        E6,27                           1
    x6        E6,28                           1
    x6        E6,29                           1
    x6        E6,30                           1
    x6        E6,31                           1
    x6        E6,32                           1
    x6        E6,34                           1
    x6        E6,35                           1
    x6        E6,36                           1
    x6        E6,38                           1
    x6        E6,43                           1
    x6        E6,46                           1
    x6        E6,47                           1
    x6        E6,49                           1
    x7        cost                            1
    x7        C4,7                            1
    x7        C6,7                            1
    x7        C7,11                           1
    x7        C7,12                           1
    x7        C7,17                           1
    x7        C7,18                           1
    x7        C7,19                           1
    x7        C7,22                           1
    x7        C7,23                           1
    x7        C7,24                           1
    x7        C7,34                           1
    x7        C7,35                           1
    x7        C7,36                           1
    x7        C7,37                           1
    x7        C7,41                           1
    x7        C7,42                           1
    x7        C7,43                           1
    x7        C7,44                           1
    x7        C7,45                           1
    x7        C7,47                           1
    x7        C7,48                           1
    x7        E0,7                            1
    x7        E1,7                            1
    x7        E2,7                            1
    x7        E3,7                            1
    x7        E5,7                            1
    x7        E7,8                            1
    x7        E7,9                            1
    x7        E7,10                           1
    x7        E7,13                           1
    x7        E7,14                           1
    x7        E7,15                           1
    x7        E7,16                           1
    x7        E7,20                           1
    x7        E7,21                           1
    x7        E7,25                           1
    x7        E7,26                           1
    x7        E7,27                           1
    x7        E7,28                           1
    x7        E7,29                           1
    x7        E7,30                           1
    x7        E7,31                           1
    x7        E7,32                           1
    x7        E7,33                           1
    x7        E7,38                           1
    x7        E7,39                           1
    x7        E7,40                           1
    x7        E7,46                           1
    x7        E7,49                           1
    x8        cost                            1
    x8        C2,8                            1
    x8        C4,8                            1
    x8        C6,8                            1
    x8        C8,10                           1
    x8        C8,11                           1
    x8        C8,15                           1
    x8        C8,17                           1
    x8        C8,23                           1
    x8        C8,24                           1
    x8        C8,26                           1
    x8        C8,27                           1
    x8        C8,28                           1
    x8        C8,31                           1
    x8        C8,32                           1
    x8        C8,36                           1
    x8        C8,38                           1
    x8        C8,46                           1
    x8        E0,8                            1
    x8        E1,8                            1
    x8        E3,8                            1
    x8        E5,8                            1
    x8        E7,8                            1
    x8        E8,9                            1
    x8        E8,12                           1
    x8        E8,13                           1
    x8        E8,14                           1
    x8        E8,16                           1
    x8        E8,18                           1
    x8        E8,19                           1
    x8        E8,20                           1
    x8        E8,21                           1
    x8        E8,22                           1
    x8        E8,25                           1
    x8        E8,29                           1
    x8        E8,30                           1
    x8        E8,33                           1
    x8        E8,34                           1
    x8        E8,35                           1
    x8        E8,37                           1
    x8        E8,39                           1
    x8        E8,40                           1
    x8        E8,41                           1
    x8        E8,42                           1
    x8        E8,43                           1
    x8        E8,44                           1
    x8        E8,45                           1
    x8        E8,47                           1
    x8        E8,48                           1
    x8        E8,49                           1
    x9        cost                            1
    x9        C0,9                            1
    x9        C2,9                            1
    x9        C9,16                           1
    x9        C9,18                           1
    x9        C9,22                           1
    x9        C9,31                           1
    x9        C9,32                           1
    x9        C9,36                           1
    x9        C9,43                           1
    x9        C9,44                           1
    x9        C9,46                           1
    x9        E1,9                            1
    x9        E3,9                            1
    x9        E4,9                            1
    x9        E5,9                            1
    x9        E6,9                            1
    x9        E7,9                            1
    x9        E8,9                            1
    x9        E9,10                           1
    x9        E9,11                           1
    x9        E9,12                           1
    x9        E9,13                           1
    x9        E9,14                           1
    x9        E9,15                           1
    x9        E9,17                           1
    x9        E9,19                           1
    x9        E9,20                           1
    x9        E9,21                           1
    x9        E9,23                           1
    x9        E9,24                           1
    x9        E9,25                           1
    x9        E9,26                           1
    x9        E9,27                           1
    x9        E9,28                           1
    x9        E9,29                           1
    x9        E9,30                           1
    x9        E9,33                           1
    x9        E9,34                           1
    x9        E9,35                           1
    x9        E9,37                           1
    x9        E9,38                           1
    x9        E9,39                           1
    x9        E9,40                           1
    x9        E9,41                           1
    x9        E9,42                           1
    x9        E9,45                           1
    x9        E9,47                           1
    x9        E9,48                           1
    x9        E9,49                           1
    x10       cost                            1
    x10       C1,10                           1
    x10       C4,10                           1
    x10       C8,10                           1
    x10       C10,17                          1
    x10       C10,18                          1
    x10       C10,19                          1
    x10       C10,22                          1
    x10       C10,25                          1
    x10       C10,26                          1
    x10       C10,38                          1
    x10       C10,39                          1
    x10       C10,47                          1
    x10       E0,10                           1
    x10       E2,10                           1
    x10       E3,10                           1
    x10       E5,10                           1
    x10       E6,10                           1
    x10       E7,10                           1
    x10       E9,10                           1
    x10       E10,11                          1
    x10       E10,12                          1
    x10       E10,13                          1
    x10       E10,14                          1
    x10       E10,15                          1
    x10       E10,16                          1
    x10       E10,20                          1
    x10       E10,21                          1
    x10       E10,23                          1
    x10       E10,24                          1
    x10       E10,27                          1
    x10       E10,28                          1
    x10       E10,29                          1
    x10       E10,30                          1
    x10       E10,31                          1
    x10       E10,32                          1
    x10       E10,33                          1
    x10       E10,34                          1
    x10       E10,35                          1
    x10       E10,36                          1
    x10       E10,37                          1
    x10       E10,40                          1
    x10       E10,41                          1
    x10       E10,42                          1
    x10       E10,43                          1
    x10       E10,44                          1
    x10       E10,45                          1
    x10       E10,46                          1
    x10       E10,48                          1
    x10       E10,49                          1
    x11       cost                            1
    x11       C0,11                           1
    x11       C2,11                           1
    x11       C7,11                           1
    x11       C8,11                           1
    x11       C11,13                          1
    x11       C11,17                          1
    x11       C11,19                          1
    x11       C11,24                          1
    x11       C11,26                          1
    x11       C11,32                          1
    x11       C11,41                          1
    x11       C11,45                          1
    x11       C11,49                          1
    x11       E1,11                           1
    x11       E3,11                           1
    x11       E4,11                           1
    x11       E5,11                           1
    x11       E6,11                           1
    x11       E9,11                           1
    x11       E10,11                          1
    x11       E11,12                          1
    x11       E11,14                          1
    x11       E11,15                          1
    x11       E11,16                          1
    x11       E11,18                          1
    x11       E11,20                          1
    x11       E11,21                          1
    x11       E11,22                          1
    x11       E11,23                          1
    x11       E11,25                          1
    x11       E11,27                          1
    x11       E11,28                          1
    x11       E11,29                          1
    x11       E11,30                          1
    x11       E11,31                          1
    x11       E11,33                          1
    x11       E11,34                          1
    x11       E11,35                          1
    x11       E11,36                          1
    x11       E11,37                          1
    x11       E11,38                          1
    x11       E11,39                          1
    x11       E11,40                          1
    x11       E11,42                          1
    x11       E11,43                          1
    x11       E11,44                          1
    x11       E11,46                          1
    x11       E11,47                          1
    x11       E11,48                          1
    x12       cost                            1
    x12       C6,12                           1
    x12       C7,12                           1
    x12       C12,16                          1
    x12       C12,18                          1
    x12       C12,19                          1
    x12       C12,22                          1
    x12       C12,31                          1
    x12       C12,43                          1
    x12       C12,45                          1
    x12       C12,48                          1
    x12       E0,12                           1
    x12       E1,12                           1
    x12       E2,12                           1
    x12       E3,12                           1
    x12       E4,12                           1
    x12       E5,12                           1
    x12       E8,12                           1
    x12       E9,12                           1
    x12       E10,12                          1
    x12       E11,12                          1
    x12       E12,13                          1
    x12       E12,14                          1
    x12       E12,15                          1
    x12       E12,17                          1
    x12       E12,20                          1
    x12       E12,21                          1
    x12       E12,23                          1
    x12       E12,24                          1
    x12       E12,25                          1
    x12       E12,26                          1
    x12       E12,27                          1
    x12       E12,28                          1
    x12       E12,29                          1
    x12       E12,30                          1
    x12       E12,32                          1
    x12       E12,33                          1
    x12       E12,34                          1
    x12       E12,35                          1
    x12       E12,36                          1
    x12       E12,37                          1
    x12       E12,38                          1
    x12       E12,39                          1
    x12       E12,40                          1
    x12       E12,41                          1
    x12       E12,42                          1
    x12       E12,44                          1
    x12       E12,46                          1
    x12       E12,47                          1
    x12       E12,49                          1
    x13       cost                            1
    x13       C0,13                           1
    x13       C2,13                           1
    x13       C11,13                          1
    x13       C13,14                          1
    x13       C13,17                          1
    x13       C13,19                          1
    x13       C13,20                          1
    x13       C13,25                          1
    x13       C13,28                          1
    x13       C13,29                          1
    x13       C13,30                          1
    x13       C13,33                          1
    x13       C13,36                          1
    x13       C13,37                          1
    x13       C13,46                          1
    x13       C13,48                          1
    x13       E1,13                           1
    x13       E3,13                           1
    x13       E4,13                           1
    x13       E5,13                           1
    x13       E6,13                           1
    x13       E7,13                           1
    x13       E8,13                           1
    x13       E9,13                           1
    x13       E10,13                          1
    x13       E12,13                          1
    x13       E13,15                          1
    x13       E13,16                          1
    x13       E13,18                          1
    x13       E13,21                          1
    x13       E13,22                          1
    x13       E13,23                          1
    x13       E13,24                          1
    x13       E13,26                          1
    x13       E13,27                          1
    x13       E13,31                          1
    x13       E13,32                          1
    x13       E13,34                          1
    x13       E13,35                          1
    x13       E13,38                          1
    x13       E13,39                          1
    x13       E13,40                          1
    x13       E13,41                          1
    x13       E13,42                          1
    x13       E13,43                          1
    x13       E13,44                          1
    x13       E13,45                          1
    x13       E13,47                          1
    x13       E13,49                          1
    x14       cost                            1
    x14       C1,14                           1
    x14       C6,14                           1
    x14       C13,14                          1
    x14       C14,21                          1
    x14       C14,28                          1
    x14       C14,29                          1
    x14       C14,34                          1
    x14       C14,35                          1
    x14       C14,38                          1
    x14       C14,42                          1
    x14       C14,43                          1
    x14       C14,44                          1
    x14       C14,45                          1
    x14       C14,49                          1
    x14       E0,14                           1
    x14       E2,14                           1
    x14       E3,14                           1
    x14       E4,14                           1
    x14       E5,14                           1
    x14       E7,14                           1
    x14       E8,14                           1
    x14       E9,14                           1
    x14       E10,14                          1
    x14       E11,14                          1
    x14       E12,14                          1
    x14       E14,15                          1
    x14       E14,16                          1
    x14       E14,17                          1
    x14       E14,18                          1
    x14       E14,19                          1
    x14       E14,20                          1
    x14       E14,22                          1
    x14       E14,23                          1
    x14       E14,24                          1
    x14       E14,25                          1
    x14       E14,26                          1
    x14       E14,27                          1
    x14       E14,30                          1
    x14       E14,31                          1
    x14       E14,32                          1
    x14       E14,33                          1
    x14       E14,36                          1
    x14       E14,37                          1
    x14       E14,39                          1
    x14       E14,40                          1
    x14       E14,41                          1
    x14       E14,46                          1
    x14       E14,47                          1
    x14       E14,48                          1
    x15       cost                            1
    x15       C1,15                           1
    x15       C2,15                           1
    x15       C6,15                           1
    x15       C8,15                           1
    x15       C15,18                          1
    x15       C15,25                          1
    x15       C15,31                          1
    x15       C15,35                          1
    x15       C15,36                          1
    x15       C15,39                          1
    x15       C15,42                          1
    x15       C15,43                          1
    x15       C15,47                          1
    x15       C15,49                          1
    x15       E0,15                           1
    x15       E3,15                           1
    x15       E4,15                           1
    x15       E5,15                           1
    x15       E7,15                           1
    x15       E9,15                           1
    x15       E10,15                          1
    x15       E11,15                          1
    x15       E12,15                          1
    x15       E13,15                          1
    x15       E14,15                          1
    x15       E15,16                          1
    x15       E15,17                          1
    x15       E15,19                          1
    x15       E15,20                          1
    x15       E15,21                          1
    x15       E15,22                          1
    x15       E15,23                          1
    x15       E15,24                          1
    x15       E15,26                          1
    x15       E15,27                          1
    x15       E15,28                          1
    x15       E15,29                          1
    x15       E15,30                          1
    x15       E15,32                          1
    x15       E15,33                          1
    x15       E15,34                          1
    x15       E15,37                          1
    x15       E15,38                          1
    x15       E15,40                          1
    x15       E15,41                          1
    x15       E15,44                          1
    x15       E15,45                          1
    x15       E15,46                          1
    x15       E15,48                          1
    x16       cost                            1
    x16       C9,16                           1
    x16       C12,16                          1
    x16       C16,20                          1
    x16       C16,21                          1
    x16       C16,24                          1
    x16       C16,25                          1
    x16       C16,32                          1
    x16       C16,33                          1
    x16       C16,34                          1
    x16       C16,35                          1
    x16       C16,36                          1
    x16       C16,42                          1
    x16       C16,43                          1
    x16       C16,45                          1
    x16       E0,16                           1
    x16       E1,16                           1
    x16       E2,16                           1
    x16       E3,16                           1
    x16       E4,16                           1
    x16       E5,16                           1
    x16       E6,16                           1
    x16       E7,16                           1
    x16       E8,16                           1
    x16       E10,16                          1
    x16       E11,16                          1
    x16       E13,16                          1
    x16       E14,16                          1
    x16       E15,16                          1
    x16       E16,17                          1
    x16       E16,18                          1
    x16       E16,19                          1
    x16       E16,22                          1
    x16       E16,23                          1
    x16       E16,26                          1
    x16       E16,27                          1
    x16       E16,28                          1
    x16       E16,29                          1
    x16       E16,30                          1
    x16       E16,31                          1
    x16       E16,37                          1
    x16       E16,38                          1
    x16       E16,39                          1
    x16       E16,40                          1
    x16       E16,41                          1
    x16       E16,44                          1
    x16       E16,46                          1
    x16       E16,47                          1
    x16       E16,48                          1
    x16       E16,49                          1
    x17       cost                            1
    x17       C2,17                           1
    x17       C7,17                           1
    x17       C8,17                           1
    x17       C10,17                          1
    x17       C11,17                          1
    x17       C13,17                          1
    x17       C17,24                          1
    x17       C17,25                          1
    x17       C17,26                          1
    x17       C17,28                          1
    x17       C17,34                          1
    x17       C17,37                          1
    x17       C17,38                          1
    x17       C17,45                          1
    x17       C17,48                          1
    x17       E0,17                           1
    x17       E1,17                           1
    x17       E3,17                           1
    x17       E4,17                           1
    x17       E5,17                           1
    x17       E6,17                           1
    x17       E9,17                           1
    x17       E12,17                          1
    x17       E14,17                          1
    x17       E15,17                          1
    x17       E16,17                          1
    x17       E17,18                          1
    x17       E17,19                          1
    x17       E17,20                          1
    x17       E17,21                          1
    x17       E17,22                          1
    x17       E17,23                          1
    x17       E17,27                          1
    x17       E17,29                          1
    x17       E17,30                          1
    x17       E17,31                          1
    x17       E17,32                          1
    x17       E17,33                          1
    x17       E17,35                          1
    x17       E17,36                          1
    x17       E17,39                          1
    x17       E17,40                          1
    x17       E17,41                          1
    x17       E17,42                          1
    x17       E17,43                          1
    x17       E17,44                          1
    x17       E17,46                          1
    x17       E17,47                          1
    x17       E17,49                          1
    x18       cost                            1
    x18       C0,18                           1
    x18       C4,18                           1
    x18       C5,18                           1
    x18       C6,18                           1
    x18       C7,18                           1
    x18       C9,18                           1
    x18       C10,18                          1
    x18       C12,18                          1
    x18       C15,18                          1
    x18       C18,19                          1
    x18       C18,20                          1
    x18       C18,25                          1
    x18       C18,28                          1
    x18       C18,29                          1
    x18       C18,30                          1
    x18       C18,39                          1
    x18       C18,41                          1
    x18       C18,44                          1
    x18       E1,18                           1
    x18       E2,18                           1
    x18       E3,18                           1
    x18       E8,18                           1
    x18       E11,18                          1
    x18       E13,18                          1
    x18       E14,18                          1
    x18       E16,18                          1
    x18       E17,18                          1
    x18       E18,21                          1
    x18       E18,22                          1
    x18       E18,23                          1
    x18       E18,24                          1
    x18       E18,26                          1
    x18       E18,27                          1
    x18       E18,31                          1
    x18       E18,32                          1
    x18       E18,33                          1
    x18       E18,34                          1
    x18       E18,35                          1
    x18       E18,36                          1
    x18       E18,37                          1
    x18       E18,38                          1
    x18       E18,40                          1
    x18       E18,42                          1
    x18       E18,43                          1
    x18       E18,45                          1
    x18       E18,46                          1
    x18       E18,47                          1
    x18       E18,48                          1
    x18       E18,49                          1
    x19       cost                            1
    x19       C1,19                           1
    x19       C3,19                           1
    x19       C6,19                           1
    x19       C7,19                           1
    x19       C10,19                          1
    x19       C11,19                          1
    x19       C12,19                          1
    x19       C13,19                          1
    x19       C18,19                          1
    x19       C19,20                          1
    x19       C19,22                          1
    x19       C19,27                          1
    x19       C19,33                          1
    x19       C19,35                          1
    x19       C19,36                          1
    x19       C19,42                          1
    x19       C19,43                          1
    x19       E0,19                           1
    x19       E2,19                           1
    x19       E4,19                           1
    x19       E5,19                           1
    x19       E8,19                           1
    x19       E9,19                           1
    x19       E14,19                          1
    x19       E15,19                          1
    x19       E16,19                          1
    x19       E17,19                          1
    x19       E19,21                          1
    x19       E19,23                          1
    x19       E19,24                          1
    x19       E19,25                          1
    x19       E19,26                          1
    x19       E19,28                          1
    x19       E19,29                          1
    x19       E19,30                          1
    x19       E19,31                          1
    x19       E19,32                          1
    x19       E19,34                          1
    x19       E19,37                          1
    x19       E19,38                          1
    x19       E19,39                          1
    x19       E19,40                          1
    x19       E19,41                          1
    x19       E19,44                          1
    x19       E19,45                          1
    x19       E19,46                          1
    x19       E19,47                          1
    x19       E19,48                          1
    x19       E19,49                          1
    x20       cost                            1
    x20       C3,20                           1
    x20       C4,20                           1
    x20       C6,20                           1
    x20       C13,20                          1
    x20       C16,20                          1
    x20       C18,20                          1
    x20       C19,20                          1
    x20       C20,25                          1
    x20       C20,28                          1
    x20       C20,31                          1
    x20       C20,34                          1
    x20       C20,36                          1
    x20       C20,38                          1
    x20       C20,42                          1
    x20       C20,46                          1
    x20       E0,20                           1
    x20       E1,20                           1
    x20       E2,20                           1
    x20       E5,20                           1
    x20       E7,20                           1
    x20       E8,20                           1
    x20       E9,20                           1
    x20       E10,20                          1
    x20       E11,20                          1
    x20       E12,20                          1
    x20       E14,20                          1
    x20       E15,20                          1
    x20       E17,20                          1
    x20       E20,21                          1
    x20       E20,22                          1
    x20       E20,23                          1
    x20       E20,24                          1
    x20       E20,26                          1
    x20       E20,27                          1
    x20       E20,29                          1
    x20       E20,30                          1
    x20       E20,32                          1
    x20       E20,33                          1
    x20       E20,35                          1
    x20       E20,37                          1
    x20       E20,39                          1
    x20       E20,40                          1
    x20       E20,41                          1
    x20       E20,43                          1
    x20       E20,44                          1
    x20       E20,45                          1
    x20       E20,47                          1
    x20       E20,48                          1
    x20       E20,49                          1
    x21       cost                            1
    x21       C4,21                           1
    x21       C5,21                           1
    x21       C14,21                          1
    x21       C16,21                          1
    x21       C21,23                          1
    x21       C21,24                          1
    x21       C21,28                          1
    x21       C21,30                          1
    x21       C21,31                          1
    x21       C21,32                          1
    x21       C21,37                          1
    x21       C21,40                          1
    x21       C21,41                          1
    x21       C21,43                          1
    x21       C21,46                          1
    x21       C21,48                          1
    x21       E0,21                           1
    x21       E1,21                           1
    x21       E2,21                           1
    x21       E3,21                           1
    x21       E6,21                           1
    x21       E7,21                           1
    x21       E8,21                           1
    x21       E9,21                           1
    x21       E10,21                          1
    x21       E11,21                          1
    x21       E12,21                          1
    x21       E13,21                          1
    x21       E15,21                          1
    x21       E17,21                          1
    x21       E18,21                          1
    x21       E19,21                          1
    x21       E20,21                          1
    x21       E21,22                          1
    x21       E21,25                          1
    x21       E21,26                          1
    x21       E21,27                          1
    x21       E21,29                          1
    x21       E21,33                          1
    x21       E21,34                          1
    x21       E21,35                          1
    x21       E21,36                          1
    x21       E21,38                          1
    x21       E21,39                          1
    x21       E21,42                          1
    x21       E21,44                          1
    x21       E21,45                          1
    x21       E21,47                          1
    x21       E21,49                          1
    x22       cost                            1
    x22       C2,22                           1
    x22       C6,22                           1
    x22       C7,22                           1
    x22       C9,22                           1
    x22       C10,22                          1
    x22       C12,22                          1
    x22       C19,22                          1
    x22       C22,28                          1
    x22       C22,32                          1
    x22       C22,33                          1
    x22       C22,34                          1
    x22       C22,37                          1
    x22       C22,41                          1
    x22       C22,44                          1
    x22       C22,46                          1
    x22       C22,49                          1
    x22       E0,22                           1
    x22       E1,22                           1
    x22       E3,22                           1
    x22       E4,22                           1
    x22       E5,22                           1
    x22       E8,22                           1
    x22       E11,22                          1
    x22       E13,22                          1
    x22       E14,22                          1
    x22       E15,22                          1
    x22       E16,22                          1
    x22       E17,22                          1
    x22       E18,22                          1
    x22       E20,22                          1
    x22       E21,22                          1
    x22       E22,23                          1
    x22       E22,24                          1
    x22       E22,25                          1
    x22       E22,26                          1
    x22       E22,27                          1
    x22       E22,29                          1
    x22       E22,30                          1
    x22       E22,31                          1
    x22       E22,35                          1
    x22       E22,36                          1
    x22       E22,38                          1
    x22       E22,39                          1
    x22       E22,40                          1
    x22       E22,42                          1
    x22       E22,43                          1
    x22       E22,45                          1
    x22       E22,47                          1
    x22       E22,48                          1
    x23       cost                            1
    x23       C2,23                           1
    x23       C3,23                           1
    x23       C7,23                           1
    x23       C8,23                           1
    x23       C21,23                          1
    x23       C23,24                          1
    x23       C23,36                          1
    x23       C23,38                          1
    x23       C23,41                          1
    x23       C23,43                          1
    x23       C23,45                          1
    x23       C23,49                          1
    x23       E0,23                           1
    x23       E1,23                           1
    x23       E4,23                           1
    x23       E5,23                           1
    x23       E6,23                           1
    x23       E9,23                           1
    x23       E10,23                          1
    x23       E11,23                          1
    x23       E12,23                          1
    x23       E13,23                          1
    x23       E14,23                          1
    x23       E15,23                          1
    x23       E16,23                          1
    x23       E17,23                          1
    x23       E18,23                          1
    x23       E19,23                          1
    x23       E20,23                          1
    x23       E22,23                          1
    x23       E23,25                          1
    x23       E23,26                          1
    x23       E23,27                          1
    x23       E23,28                          1
    x23       E23,29                          1
    x23       E23,30                          1
    x23       E23,31                          1
    x23       E23,32                          1
    x23       E23,33                          1
    x23       E23,34                          1
    x23       E23,35                          1
    x23       E23,37                          1
    x23       E23,39                          1
    x23       E23,40                          1
    x23       E23,42                          1
    x23       E23,44                          1
    x23       E23,46                          1
    x23       E23,47                          1
    x23       E23,48                          1
    x24       cost                            1
    x24       C2,24                           1
    x24       C7,24                           1
    x24       C8,24                           1
    x24       C11,24                          1
    x24       C16,24                          1
    x24       C17,24                          1
    x24       C21,24                          1
    x24       C23,24                          1
    x24       C24,28                          1
    x24       C24,31                          1
    x24       C24,34                          1
    x24       C24,37                          1
    x24       C24,39                          1
    x24       C24,40                          1
    x24       C24,45                          1
    x24       C24,47                          1
    x24       C24,48                          1
    x24       E0,24                           1
    x24       E1,24                           1
    x24       E3,24                           1
    x24       E4,24                           1
    x24       E5,24                           1
    x24       E6,24                           1
    x24       E9,24                           1
    x24       E10,24                          1
    x24       E12,24                          1
    x24       E13,24                          1
    x24       E14,24                          1
    x24       E15,24                          1
    x24       E18,24                          1
    x24       E19,24                          1
    x24       E20,24                          1
    x24       E22,24                          1
    x24       E24,25                          1
    x24       E24,26                          1
    x24       E24,27                          1
    x24       E24,29                          1
    x24       E24,30                          1
    x24       E24,32                          1
    x24       E24,33                          1
    x24       E24,35                          1
    x24       E24,36                          1
    x24       E24,38                          1
    x24       E24,41                          1
    x24       E24,42                          1
    x24       E24,43                          1
    x24       E24,44                          1
    x24       E24,46                          1
    x24       E24,49                          1
    x25       cost                            1
    x25       C0,25                           1
    x25       C2,25                           1
    x25       C6,25                           1
    x25       C10,25                          1
    x25       C13,25                          1
    x25       C15,25                          1
    x25       C16,25                          1
    x25       C17,25                          1
    x25       C18,25                          1
    x25       C20,25                          1
    x25       C25,29                          1
    x25       C25,32                          1
    x25       C25,37                          1
    x25       C25,38                          1
    x25       C25,39                          1
    x25       C25,43                          1
    x25       C25,45                          1
    x25       E1,25                           1
    x25       E3,25                           1
    x25       E4,25                           1
    x25       E5,25                           1
    x25       E7,25                           1
    x25       E8,25                           1
    x25       E9,25                           1
    x25       E11,25                          1
    x25       E12,25                          1
    x25       E14,25                          1
    x25       E19,25                          1
    x25       E21,25                          1
    x25       E22,25                          1
    x25       E23,25                          1
    x25       E24,25                          1
    x25       E25,26                          1
    x25       E25,27                          1
    x25       E25,28                          1
    x25       E25,30                          1
    x25       E25,31                          1
    x25       E25,33                          1
    x25       E25,34                          1
    x25       E25,35                          1
    x25       E25,36                          1
    x25       E25,40                          1
    x25       E25,41                          1
    x25       E25,42                          1
    x25       E25,44                          1
    x25       E25,46                          1
    x25       E25,47                          1
    x25       E25,48                          1
    x25       E25,49                          1
    x26       cost                            1
    x26       C8,26                           1
    x26       C10,26                          1
    x26       C11,26                          1
    x26       C17,26                          1
    x26       C26,33                          1
    x26       C26,36                          1
    x26       C26,39                          1
    x26       C26,43                          1
    x26       C26,47                          1
    x26       E0,26                           1
    x26       E1,26                           1
    x26       E2,26                           1
    x26       E3,26                           1
    x26       E4,26                           1
    x26       E5,26                           1
    x26       E6,26                           1
    x26       E7,26                           1
    x26       E9,26                           1
    x26       E12,26                          1
    x26       E13,26                          1
    x26       E14,26                          1
    x26       E15,26                          1
    x26       E16,26                          1
    x26       E18,26                          1
    x26       E19,26                          1
    x26       E20,26                          1
    x26       E21,26                          1
    x26       E22,26                          1
    x26       E23,26                          1
    x26       E24,26                          1
    x26       E25,26                          1
    x26       E26,27                          1
    x26       E26,28                          1
    x26       E26,29                          1
    x26       E26,30                          1
    x26       E26,31                          1
    x26       E26,32                          1
    x26       E26,34                          1
    x26       E26,35                          1
    x26       E26,37                          1
    x26       E26,38                          1
    x26       E26,40                          1
    x26       E26,41                          1
    x26       E26,42                          1
    x26       E26,44                          1
    x26       E26,45                          1
    x26       E26,46                          1
    x26       E26,48                          1
    x26       E26,49                          1
    x27       cost                            1
    x27       C2,27                           1
    x27       C3,27                           1
    x27       C8,27                           1
    x27       C19,27                          1
    x27       C27,32                          1
    x27       C27,33                          1
    x27       C27,37                          1
    x27       C27,38                          1
    x27       C27,39                          1
    x27       C27,41                          1
    x27       C27,46                          1
    x27       E0,27                           1
    x27       E1,27                           1
    x27       E4,27                           1
    x27       E5,27                           1
    x27       E6,27                           1
    x27       E7,27                           1
    x27       E9,27                           1
    x27       E10,27                          1
    x27       E11,27                          1
    x27       E12,27                          1
    x27       E13,27                          1
    x27       E14,27                          1
    x27       E15,27                          1
    x27       E16,27                          1
    x27       E17,27                          1
    x27       E18,27                          1
    x27       E20,27                          1
    x27       E21,27                          1
    x27       E22,27                          1
    x27       E23,27                          1
    x27       E24,27                          1
    x27       E25,27                          1
    x27       E26,27                          1
    x27       E27,28                          1
    x27       E27,29                          1
    x27       E27,30                          1
    x27       E27,31                          1
    x27       E27,34                          1
    x27       E27,35                          1
    x27       E27,36                          1
    x27       E27,40                          1
    x27       E27,42                          1
    x27       E27,43                          1
    x27       E27,44                          1
    x27       E27,45                          1
    x27       E27,47                          1
    x27       E27,48                          1
    x27       E27,49                          1
    x28       cost                            1
    x28       C0,28                           1
    x28       C1,28                           1
    x28       C3,28                           1
    x28       C4,28                           1
    x28       C8,28                           1
    x28       C13,28                          1
    x28       C14,28                          1
    x28       C17,28                          1
    x28       C18,28                          1
    x28       C20,28                          1
    x28       C21,28                          1
    x28       C22,28                          1
    x28       C24,28                          1
    x28       C28,29                          1
    x28       C28,30                          1
    x28       C28,47                          1
    x28       E2,28                           1
    x28       E5,28                           1
    x28       E6,28                           1
    x28       E7,28                           1
    x28       E9,28                           1
    x28       E10,28                          1
    x28       E11,28                          1
    x28       E12,28                          1
    x28       E15,28                          1
    x28       E16,28                          1
    x28       E19,28                          1
    x28       E23,28                          1
    x28       E25,28                          1
    x28       E26,28                          1
    x28       E27,28                          1
    x28       E28,31                          1
    x28       E28,32                          1
    x28       E28,33                          1
    x28       E28,34                          1
    x28       E28,35                          1
    x28       E28,36                          1
    x28       E28,37                          1
    x28       E28,38                          1
    x28       E28,39                          1
    x28       E28,40                          1
    x28       E28,41                          1
    x28       E28,42                          1
    x28       E28,43                          1
    x28       E28,44                          1
    x28       E28,45                          1
    x28       E28,46                          1
    x28       E28,48                          1
    x28       E28,49                          1
    x29       cost                            1
    x29       C4,29                           1
    x29       C5,29                           1
    x29       C13,29                          1
    x29       C14,29                          1
    x29       C18,29                          1
    x29       C25,29                          1
    x29       C28,29                          1
    x29       C29,33                          1
    x29       C29,41                          1
    x29       C29,46                          1
    x29       E0,29                           1
    x29       E1,29                           1
    x29       E2,29                           1
    x29       E3,29                           1
    x29       E6,29                           1
    x29       E7,29                           1
    x29       E8,29                           1
    x29       E9,29                           1
    x29       E10,29                          1
    x29       E11,29                          1
    x29       E12,29                          1
    x29       E15,29                          1
    x29       E16,29                          1
    x29       E17,29                          1
    x29       E19,29                          1
    x29       E20,29                          1
    x29       E21,29                          1
    x29       E22,29                          1
    x29       E23,29                          1
    x29       E24,29                          1
    x29       E26,29                          1
    x29       E27,29                          1
    x29       E29,30                          1
    x29       E29,31                          1
    x29       E29,32                          1
    x29       E29,34                          1
    x29       E29,35                          1
    x29       E29,36                          1
    x29       E29,37                          1
    x29       E29,38                          1
    x29       E29,39                          1
    x29       E29,40                          1
    x29       E29,42                          1
    x29       E29,43                          1
    x29       E29,44                          1
    x29       E29,45                          1
    x29       E29,47                          1
    x29       E29,48                          1
    x29       E29,49                          1
    x30       cost                            1
    x30       C0,30                           1
    x30       C2,30                           1
    x30       C4,30                           1
    x30       C13,30                          1
    x30       C18,30                          1
    x30       C21,30                          1
    x30       C28,30                          1
    x30       C30,31                          1
    x30       C30,41                          1
    x30       C30,42                          1
    x30       C30,48                          1
    x30       E1,30                           1
    x30       E3,30                           1
    x30       E5,30                           1
    x30       E6,30                           1
    x30       E7,30                           1
    x30       E8,30                           1
    x30       E9,30                           1
    x30       E10,30                          1
    x30       E11,30                          1
    x30       E12,30                          1
    x30       E14,30                          1
    x30       E15,30                          1
    x30       E16,30                          1
    x30       E17,30                          1
    x30       E19,30                          1
    x30       E20,30                          1
    x30       E22,30                          1
    x30       E23,30                          1
    x30       E24,30                          1
    x30       E25,30                          1
    x30       E26,30                          1
    x30       E27,30                          1
    x30       E29,30                          1
    x30       E30,32                          1
    x30       E30,33                          1
    x30       E30,34                          1
    x30       E30,35                          1
    x30       E30,36                          1
    x30       E30,37                          1
    x30       E30,38                          1
    x30       E30,39                          1
    x30       E30,40                          1
    x30       E30,43                          1
    x30       E30,44                          1
    x30       E30,45                          1
    x30       E30,46                          1
    x30       E30,47                          1
    x30       E30,49                          1
    x31       cost                            1
    x31       C0,31                           1
    x31       C8,31                           1
    x31       C9,31                           1
    x31       C12,31                          1
    x31       C15,31                          1
    x31       C20,31                          1
    x31       C21,31                          1
    x31       C24,31                          1
    x31       C30,31                          1
    x31       C31,32                          1
    x31       C31,33                          1
    x31       C31,38                          1
    x31       C31,42                          1
    x31       C31,44                          1
    x31       C31,47                          1
    x31       E1,31                           1
    x31       E2,31                           1
    x31       E3,31                           1
    x31       E4,31                           1
    x31       E5,31                           1
    x31       E6,31                           1
    x31       E7,31                           1
    x31       E10,31                          1
    x31       E11,31                          1
    x31       E13,31                          1
    x31       E14,31                          1
    x31       E16,31                          1
    x31       E17,31                          1
    x31       E18,31                          1
    x31       E19,31                          1
    x31       E22,31                          1
    x31       E23,31                          1
    x31       E25,31                          1
    x31       E26,31                          1
    x31       E27,31                          1
    x31       E28,31                          1
    x31       E29,31                          1
    x31       E31,34                          1
    x31       E31,35                          1
    x31       E31,36                          1
    x31       E31,37                          1
    x31       E31,39                          1
    x31       E31,40                          1
    x31       E31,41                          1
    x31       E31,43                          1
    x31       E31,45                          1
    x31       E31,46                          1
    x31       E31,48                          1
    x31       E31,49                          1
    x32       cost                            1
    x32       C1,32                           1
    x32       C3,32                           1
    x32       C5,32                           1
    x32       C8,32                           1
    x32       C9,32                           1
    x32       C11,32                          1
    x32       C16,32                          1
    x32       C21,32                          1
    x32       C22,32                          1
    x32       C25,32                          1
    x32       C27,32                          1
    x32       C31,32                          1
    x32       C32,35                          1
    x32       C32,36                          1
    x32       C32,44                          1
    x32       C32,45                          1
    x32       E0,32                           1
    x32       E2,32                           1
    x32       E4,32                           1
    x32       E6,32                           1
    x32       E7,32                           1
    x32       E10,32                          1
    x32       E12,32                          1
    x32       E13,32                          1
    x32       E14,32                          1
    x32       E15,32                          1
    x32       E17,32                          1
    x32       E18,32                          1
    x32       E19,32                          1
    x32       E20,32                          1
    x32       E23,32                          1
    x32       E24,32                          1
    x32       E26,32                          1
    x32       E28,32                          1
    x32       E29,32                          1
    x32       E30,32                          1
    x32       E32,33                          1
    x32       E32,34                          1
    x32       E32,37                          1
    x32       E32,38                          1
    x32       E32,39                          1
    x32       E32,40                          1
    x32       E32,41                          1
    x32       E32,42                          1
    x32       E32,43                          1
    x32       E32,46                          1
    x32       E32,47                          1
    x32       E32,48                          1
    x32       E32,49                          1
    x33       cost                            1
    x33       C6,33                           1
    x33       C13,33                          1
    x33       C16,33                          1
    x33       C19,33                          1
    x33       C22,33                          1
    x33       C26,33                          1
    x33       C27,33                          1
    x33       C29,33                          1
    x33       C31,33                          1
    x33       C33,35                          1
    x33       C33,40                          1
    x33       C33,41                          1
    x33       C33,43                          1
    x33       C33,47                          1
    x33       E0,33                           1
    x33       E1,33                           1
    x33       E2,33                           1
    x33       E3,33                           1
    x33       E4,33                           1
    x33       E5,33                           1
    x33       E7,33                           1
    x33       E8,33                           1
    x33       E9,33                           1
    x33       E10,33                          1
    x33       E11,33                          1
    x33       E12,33                          1
    x33       E14,33                          1
    x33       E15,33                          1
    x33       E17,33                          1
    x33       E18,33                          1
    x33       E20,33                          1
    x33       E21,33                          1
    x33       E23,33                          1
    x33       E24,33                          1
    x33       E25,33                          1
    x33       E28,33                          1
    x33       E30,33                          1
    x33       E32,33                          1
    x33       E33,34                          1
    x33       E33,36                          1
    x33       E33,37                          1
    x33       E33,38                          1
    x33       E33,39                          1
    x33       E33,42                          1
    x33       E33,44                          1
    x33       E33,45                          1
    x33       E33,46                          1
    x33       E33,48                          1
    x33       E33,49                          1
    x34       cost                            1
    x34       C3,34                           1
    x34       C5,34                           1
    x34       C7,34                           1
    x34       C14,34                          1
    x34       C16,34                          1
    x34       C17,34                          1
    x34       C20,34                          1
    x34       C22,34                          1
    x34       C24,34                          1
    x34       C34,35                          1
    x34       C34,37                          1
    x34       C34,39                          1
    x34       C34,41                          1
    x34       C34,42                          1
    x34       C34,48                          1
    x34       E0,34                           1
    x34       E1,34                           1
    x34       E2,34                           1
    x34       E4,34                           1
    x34       E6,34                           1
    x34       E8,34                           1
    x34       E9,34                           1
    x34       E10,34                          1
    x34       E11,34                          1
    x34       E12,34                          1
    x34       E13,34                          1
    x34       E15,34                          1
    x34       E18,34                          1
    x34       E19,34                          1
    x34       E21,34                          1
    x34       E23,34                          1
    x34       E25,34                          1
    x34       E26,34                          1
    x34       E27,34                          1
    x34       E28,34                          1
    x34       E29,34                          1
    x34       E30,34                          1
    x34       E31,34                          1
    x34       E32,34                          1
    x34       E33,34                          1
    x34       E34,36                          1
    x34       E34,38                          1
    x34       E34,40                          1
    x34       E34,43                          1
    x34       E34,44                          1
    x34       E34,45                          1
    x34       E34,46                          1
    x34       E34,47                          1
    x34       E34,49                          1
    x35       cost                            1
    x35       C7,35                           1
    x35       C14,35                          1
    x35       C15,35                          1
    x35       C16,35                          1
    x35       C19,35                          1
    x35       C32,35                          1
    x35       C33,35                          1
    x35       C34,35                          1
    x35       C35,41                          1
    x35       C35,42                          1
    x35       C35,45                          1
    x35       C35,48                          1
    x35       E0,35                           1
    x35       E1,35                           1
    x35       E2,35                           1
    x35       E3,35                           1
    x35       E4,35                           1
    x35       E5,35                           1
    x35       E6,35                           1
    x35       E8,35                           1
    x35       E9,35                           1
    x35       E10,35                          1
    x35       E11,35                          1
    x35       E12,35                          1
    x35       E13,35                          1
    x35       E17,35                          1
    x35       E18,35                          1
    x35       E20,35                          1
    x35       E21,35                          1
    x35       E22,35                          1
    x35       E23,35                          1
    x35       E24,35                          1
    x35       E25,35                          1
    x35       E26,35                          1
    x35       E27,35                          1
    x35       E28,35                          1
    x35       E29,35                          1
    x35       E30,35                          1
    x35       E31,35                          1
    x35       E35,36                          1
    x35       E35,37                          1
    x35       E35,38                          1
    x35       E35,39                          1
    x35       E35,40                          1
    x35       E35,43                          1
    x35       E35,44                          1
    x35       E35,46                          1
    x35       E35,47                          1
    x35       E35,49                          1
    x36       cost                            1
    x36       C0,36                           1
    x36       C5,36                           1
    x36       C7,36                           1
    x36       C8,36                           1
    x36       C9,36                           1
    x36       C13,36                          1
    x36       C15,36                          1
    x36       C16,36                          1
    x36       C19,36                          1
    x36       C20,36                          1
    x36       C23,36                          1
    x36       C26,36                          1
    x36       C32,36                          1
    x36       C36,39                          1
    x36       C36,42                          1
    x36       C36,43                          1
    x36       E1,36                           1
    x36       E2,36                           1
    x36       E3,36                           1
    x36       E4,36                           1
    x36       E6,36                           1
    x36       E10,36                          1
    x36       E11,36                          1
    x36       E12,36                          1
    x36       E14,36                          1
    x36       E17,36                          1
    x36       E18,36                          1
    x36       E21,36                          1
    x36       E22,36                          1
    x36       E24,36                          1
    x36       E25,36                          1
    x36       E27,36                          1
    x36       E28,36                          1
    x36       E29,36                          1
    x36       E30,36                          1
    x36       E31,36                          1
    x36       E33,36                          1
    x36       E34,36                          1
    x36       E35,36                          1
    x36       E36,37                          1
    x36       E36,38                          1
    x36       E36,40                          1
    x36       E36,41                          1
    x36       E36,44                          1
    x36       E36,45                          1
    x36       E36,46                          1
    x36       E36,47                          1
    x36       E36,48                          1
    x36       E36,49                          1
    x37       cost                            1
    x37       C5,37                           1
    x37       C6,37                           1
    x37       C7,37                           1
    x37       C13,37                          1
    x37       C17,37                          1
    x37       C21,37                          1
    x37       C22,37                          1
    x37       C24,37                          1
    x37       C25,37                          1
    x37       C27,37                          1
    x37       C34,37                          1
    x37       C37,38                          1
    x37       C37,41                          1
    x37       E0,37                           1
    x37       E1,37                           1
    x37       E2,37                           1
    x37       E3,37                           1
    x37       E4,37                           1
    x37       E8,37                           1
    x37       E9,37                           1
    x37       E10,37                          1
    x37       E11,37                          1
    x37       E12,37                          1
    x37       E14,37                          1
    x37       E15,37                          1
    x37       E16,37                          1
    x37       E18,37                          1
    x37       E19,37                          1
    x37       E20,37                          1
    x37       E23,37                          1
    x37       E26,37                          1
    x37       E28,37                          1
    x37       E29,37                          1
    x37       E30,37                          1
    x37       E31,37                          1
    x37       E32,37                          1
    x37       E33,37                          1
    x37       E35,37                          1
    x37       E36,37                          1
    x37       E37,39                          1
    x37       E37,40                          1
    x37       E37,42                          1
    x37       E37,43                          1
    x37       E37,44                          1
    x37       E37,45                          1
    x37       E37,46                          1
    x37       E37,47                          1
    x37       E37,48                          1
    x37       E37,49                          1
    x38       cost                            1
    x38       C1,38                           1
    x38       C8,38                           1
    x38       C10,38                          1
    x38       C14,38                          1
    x38       C17,38                          1
    x38       C20,38                          1
    x38       C23,38                          1
    x38       C25,38                          1
    x38       C27,38                          1
    x38       C31,38                          1
    x38       C37,38                          1
    x38       C38,41                          1
    x38       C38,47                          1
    x38       E0,38                           1
    x38       E2,38                           1
    x38       E3,38                           1
    x38       E4,38                           1
    x38       E5,38                           1
    x38       E6,38                           1
    x38       E7,38                           1
    x38       E9,38                           1
    x38       E11,38                          1
    x38       E12,38                          1
    x38       E13,38                          1
    x38       E15,38                          1
    x38       E16,38                          1
    x38       E18,38                          1
    x38       E19,38                          1
    x38       E21,38                          1
    x38       E22,38                          1
    x38       E24,38                          1
    x38       E26,38                          1
    x38       E28,38                          1
    x38       E29,38                          1
    x38       E30,38                          1
    x38       E32,38                          1
    x38       E33,38                          1
    x38       E34,38                          1
    x38       E35,38                          1
    x38       E36,38                          1
    x38       E38,39                          1
    x38       E38,40                          1
    x38       E38,42                          1
    x38       E38,43                          1
    x38       E38,44                          1
    x38       E38,45                          1
    x38       E38,46                          1
    x38       E38,48                          1
    x38       E38,49                          1
    x39       cost                            1
    x39       C1,39                           1
    x39       C3,39                           1
    x39       C4,39                           1
    x39       C6,39                           1
    x39       C10,39                          1
    x39       C15,39                          1
    x39       C18,39                          1
    x39       C24,39                          1
    x39       C25,39                          1
    x39       C26,39                          1
    x39       C27,39                          1
    x39       C34,39                          1
    x39       C36,39                          1
    x39       C39,40                          1
    x39       C39,43                          1
    x39       C39,46                          1
    x39       C39,47                          1
    x39       C39,48                          1
    x39       E0,39                           1
    x39       E2,39                           1
    x39       E5,39                           1
    x39       E7,39                           1
    x39       E8,39                           1
    x39       E9,39                           1
    x39       E11,39                          1
    x39       E12,39                          1
    x39       E13,39                          1
    x39       E14,39                          1
    x39       E16,39                          1
    x39       E17,39                          1
    x39       E19,39                          1
    x39       E20,39                          1
    x39       E21,39                          1
    x39       E22,39                          1
    x39       E23,39                          1
    x39       E28,39                          1
    x39       E29,39                          1
    x39       E30,39                          1
    x39       E31,39                          1
    x39       E32,39                          1
    x39       E33,39                          1
    x39       E35,39                          1
    x39       E37,39                          1
    x39       E38,39                          1
    x39       E39,41                          1
    x39       E39,42                          1
    x39       E39,44                          1
    x39       E39,45                          1
    x39       E39,49                          1
    x40       cost                            1
    x40       C3,40                           1
    x40       C6,40                           1
    x40       C21,40                          1
    x40       C24,40                          1
    x40       C33,40                          1
    x40       C39,40                          1
    x40       C40,41                          1
    x40       C40,42                          1
    x40       C40,44                          1
    x40       C40,46                          1
    x40       C40,49                          1
    x40       E0,40                           1
    x40       E1,40                           1
    x40       E2,40                           1
    x40       E4,40                           1
    x40       E5,40                           1
    x40       E7,40                           1
    x40       E8,40                           1
    x40       E9,40                           1
    x40       E10,40                          1
    x40       E11,40                          1
    x40       E12,40                          1
    x40       E13,40                          1
    x40       E14,40                          1
    x40       E15,40                          1
    x40       E16,40                          1
    x40       E17,40                          1
    x40       E18,40                          1
    x40       E19,40                          1
    x40       E20,40                          1
    x40       E22,40                          1
    x40       E23,40                          1
    x40       E25,40                          1
    x40       E26,40                          1
    x40       E27,40                          1
    x40       E28,40                          1
    x40       E29,40                          1
    x40       E30,40                          1
    x40       E31,40                          1
    x40       E32,40                          1
    x40       E34,40                          1
    x40       E35,40                          1
    x40       E36,40                          1
    x40       E37,40                          1
    x40       E38,40                          1
    x40       E40,43                          1
    x40       E40,45                          1
    x40       E40,47                          1
    x40       E40,48                          1
    x41       cost                            1
    x41       C2,41                           1
    x41       C3,41                           1
    x41       C6,41                           1
    x41       C7,41                           1
    x41       C11,41                          1
    x41       C18,41                          1
    x41       C21,41                          1
    x41       C22,41                          1
    x41       C23,41                          1
    x41       C27,41                          1
    x41       C29,41                          1
    x41       C30,41                          1
    x41       C33,41                          1
    x41       C34,41                          1
    x41       C35,41                          1
    x41       C37,41                          1
    x41       C38,41                          1
    x41       C40,41                          1
    x41       C41,49                          1
    x41       E0,41                           1
    x41       E1,41                           1
    x41       E4,41                           1
    x41       E5,41                           1
    x41       E8,41                           1
    x41       E9,41                           1
    x41       E10,41                          1
    x41       E12,41                          1
    x41       E13,41                          1
    x41       E14,41                          1
    x41       E15,41                          1
    x41       E16,41                          1
    x41       E17,41                          1
    x41       E19,41                          1
    x41       E20,41                          1
    x41       E24,41                          1
    x41       E25,41                          1
    x41       E26,41                          1
    x41       E28,41                          1
    x41       E31,41                          1
    x41       E32,41                          1
    x41       E36,41                          1
    x41       E39,41                          1
    x41       E41,42                          1
    x41       E41,43                          1
    x41       E41,44                          1
    x41       E41,45                          1
    x41       E41,46                          1
    x41       E41,47                          1
    x41       E41,48                          1
    x42       cost                            1
    x42       C1,42                           1
    x42       C2,42                           1
    x42       C3,42                           1
    x42       C6,42                           1
    x42       C7,42                           1
    x42       C14,42                          1
    x42       C15,42                          1
    x42       C16,42                          1
    x42       C19,42                          1
    x42       C20,42                          1
    x42       C30,42                          1
    x42       C31,42                          1
    x42       C34,42                          1
    x42       C35,42                          1
    x42       C36,42                          1
    x42       C40,42                          1
    x42       C42,44                          1
    x42       C42,47                          1
    x42       E0,42                           1
    x42       E4,42                           1
    x42       E5,42                           1
    x42       E8,42                           1
    x42       E9,42                           1
    x42       E10,42                          1
    x42       E11,42                          1
    x42       E12,42                          1
    x42       E13,42                          1
    x42       E17,42                          1
    x42       E18,42                          1
    x42       E21,42                          1
    x42       E22,42                          1
    x42       E23,42                          1
    x42       E24,42                          1
    x42       E25,42                          1
    x42       E26,42                          1
    x42       E27,42                          1
    x42       E28,42                          1
    x42       E29,42                          1
    x42       E32,42                          1
    x42       E33,42                          1
    x42       E37,42                          1
    x42       E38,42                          1
    x42       E39,42                          1
    x42       E41,42                          1
    x42       E42,43                          1
    x42       E42,45                          1
    x42       E42,46                          1
    x42       E42,48                          1
    x42       E42,49                          1
    x43       cost                            1
    x43       C1,43                           1
    x43       C2,43                           1
    x43       C4,43                           1
    x43       C5,43                           1
    x43       C7,43                           1
    x43       C9,43                           1
    x43       C12,43                          1
    x43       C14,43                          1
    x43       C15,43                          1
    x43       C16,43                          1
    x43       C19,43                          1
    x43       C21,43                          1
    x43       C23,43                          1
    x43       C25,43                          1
    x43       C26,43                          1
    x43       C33,43                          1
    x43       C36,43                          1
    x43       C39,43                          1
    x43       C43,44                          1
    x43       C43,48                          1
    x43       E0,43                           1
    x43       E3,43                           1
    x43       E6,43                           1
    x43       E8,43                           1
    x43       E10,43                          1
    x43       E11,43                          1
    x43       E13,43                          1
    x43       E17,43                          1
    x43       E18,43                          1
    x43       E20,43                          1
    x43       E22,43                          1
    x43       E24,43                          1
    x43       E27,43                          1
    x43       E28,43                          1
    x43       E29,43                          1
    x43       E30,43                          1
    x43       E31,43                          1
    x43       E32,43                          1
    x43       E34,43                          1
    x43       E35,43                          1
    x43       E37,43                          1
    x43       E38,43                          1
    x43       E40,43                          1
    x43       E41,43                          1
    x43       E42,43                          1
    x43       E43,45                          1
    x43       E43,46                          1
    x43       E43,47                          1
    x43       E43,49                          1
    x44       cost                            1
    x44       C0,44                           1
    x44       C3,44                           1
    x44       C5,44                           1
    x44       C6,44                           1
    x44       C7,44                           1
    x44       C9,44                           1
    x44       C14,44                          1
    x44       C18,44                          1
    x44       C22,44                          1
    x44       C31,44                          1
    x44       C32,44                          1
    x44       C40,44                          1
    x44       C42,44                          1
    x44       C43,44                          1
    x44       C44,47                          1
    x44       E1,44                           1
    x44       E2,44                           1
    x44       E4,44                           1
    x44       E8,44                           1
    x44       E10,44                          1
    x44       E11,44                          1
    x44       E12,44                          1
    x44       E13,44                          1
    x44       E15,44                          1
    x44       E16,44                          1
    x44       E17,44                          1
    x44       E19,44                          1
    x44       E20,44                          1
    x44       E21,44                          1
    x44       E23,44                          1
    x44       E24,44                          1
    x44       E25,44                          1
    x44       E26,44                          1
    x44       E27,44                          1
    x44       E28,44                          1
    x44       E29,44                          1
    x44       E30,44                          1
    x44       E33,44                          1
    x44       E34,44                          1
    x44       E35,44                          1
    x44       E36,44                          1
    x44       E37,44                          1
    x44       E38,44                          1
    x44       E39,44                          1
    x44       E41,44                          1
    x44       E44,45                          1
    x44       E44,46                          1
    x44       E44,48                          1
    x44       E44,49                          1
    x45       cost                            1
    x45       C1,45                           1
    x45       C6,45                           1
    x45       C7,45                           1
    x45       C11,45                          1
    x45       C12,45                          1
    x45       C14,45                          1
    x45       C16,45                          1
    x45       C17,45                          1
    x45       C23,45                          1
    x45       C24,45                          1
    x45       C25,45                          1
    x45       C32,45                          1
    x45       C35,45                          1
    x45       C45,46                          1
    x45       C45,48                          1
    x45       C45,49                          1
    x45       E0,45                           1
    x45       E2,45                           1
    x45       E3,45                           1
    x45       E4,45                           1
    x45       E5,45                           1
    x45       E8,45                           1
    x45       E9,45                           1
    x45       E10,45                          1
    x45       E13,45                          1
    x45       E15,45                          1
    x45       E18,45                          1
    x45       E19,45                          1
    x45       E20,45                          1
    x45       E21,45                          1
    x45       E22,45                          1
    x45       E26,45                          1
    x45       E27,45                          1
    x45       E28,45                          1
    x45       E29,45                          1
    x45       E30,45                          1
    x45       E31,45                          1
    x45       E33,45                          1
    x45       E34,45                          1
    x45       E36,45                          1
    x45       E37,45                          1
    x45       E38,45                          1
    x45       E39,45                          1
    x45       E40,45                          1
    x45       E41,45                          1
    x45       E42,45                          1
    x45       E43,45                          1
    x45       E44,45                          1
    x45       E45,47                          1
    x46       cost                            1
    x46       C1,46                           1
    x46       C3,46                           1
    x46       C5,46                           1
    x46       C8,46                           1
    x46       C9,46                           1
    x46       C13,46                          1
    x46       C20,46                          1
    x46       C21,46                          1
    x46       C22,46                          1
    x46       C27,46                          1
    x46       C29,46                          1
    x46       C39,46                          1
    x46       C40,46                          1
    x46       C45,46                          1
    x46       E0,46                           1
    x46       E2,46                           1
    x46       E4,46                           1
    x46       E6,46                           1
    x46       E7,46                           1
    x46       E10,46                          1
    x46       E11,46                          1
    x46       E12,46                          1
    x46       E14,46                          1
    x46       E15,46                          1
    x46       E16,46                          1
    x46       E17,46                          1
    x46       E18,46                          1
    x46       E19,46                          1
    x46       E23,46                          1
    x46       E24,46                          1
    x46       E25,46                          1
    x46       E26,46                          1
    x46       E28,46                          1
    x46       E30,46                          1
    x46       E31,46                          1
    x46       E32,46                          1
    x46       E33,46                          1
    x46       E34,46                          1
    x46       E35,46                          1
    x46       E36,46                          1
    x46       E37,46                          1
    x46       E38,46                          1
    x46       E41,46                          1
    x46       E42,46                          1
    x46       E43,46                          1
    x46       E44,46                          1
    x46       E46,47                          1
    x46       E46,48                          1
    x46       E46,49                          1
    x47       cost                            1
    x47       C1,47                           1
    x47       C2,47                           1
    x47       C7,47                           1
    x47       C10,47                          1
    x47       C15,47                          1
    x47       C24,47                          1
    x47       C26,47                          1
    x47       C28,47                          1
    x47       C31,47                          1
    x47       C33,47                          1
    x47       C38,47                          1
    x47       C39,47                          1
    x47       C42,47                          1
    x47       C44,47                          1
    x47       E0,47                           1
    x47       E3,47                           1
    x47       E4,47                           1
    x47       E5,47                           1
    x47       E6,47                           1
    x47       E8,47                           1
    x47       E9,47                           1
    x47       E11,47                          1
    x47       E12,47                          1
    x47       E13,47                          1
    x47       E14,47                          1
    x47       E16,47                          1
    x47       E17,47                          1
    x47       E18,47                          1
    x47       E19,47                          1
    x47       E20,47                          1
    x47       E21,47                          1
    x47       E22,47                          1
    x47       E23,47                          1
    x47       E25,47                          1
    x47       E27,47                          1
    x47       E29,47                          1
    x47       E30,47                          1
    x47       E32,47                          1
    x47       E34,47                          1
    x47       E35,47                          1
    x47       E36,47                          1
    x47       E37,47                          1
    x47       E40,47                          1
    x47       E41,47                          1
    x47       E43,47                          1
    x47       E45,47                          1
    x47       E46,47                          1
    x47       E47,48                          1
    x47       E47,49                          1
    x48       cost                            1
    x48       C0,48                           1
    x48       C3,48                           1
    x48       C6,48                           1
    x48       C7,48                           1
    x48       C12,48                          1
    x48       C13,48                          1
    x48       C17,48                          1
    x48       C21,48                          1
    x48       C24,48                          1
    x48       C30,48                          1
    x48       C34,48                          1
    x48       C35,48                          1
    x48       C39,48                          1
    x48       C43,48                          1
    x48       C45,48                          1
    x48       C48,49                          1
    x48       E1,48                           1
    x48       E2,48                           1
    x48       E4,48                           1
    x48       E5,48                           1
    x48       E8,48                           1
    x48       E9,48                           1
    x48       E10,48                          1
    x48       E11,48                          1
    x48       E14,48                          1
    x48       E15,48                          1
    x48       E16,48                          1
    x48       E18,48                          1
    x48       E19,48                          1
    x48       E20,48                          1
    x48       E22,48                          1
    x48       E23,48                          1
    x48       E25,48                          1
    x48       E26,48                          1
    x48       E27,48                          1
    x48       E28,48                          1
    x48       E29,48                          1
    x48       E31,48                          1
    x48       E32,48                          1
    x48       E33,48                          1
    x48       E36,48                          1
    x48       E37,48                          1
    x48       E38,48                          1
    x48       E40,48                          1
    x48       E41,48                          1
    x48       E42,48                          1
    x48       E44,48                          1
    x48       E46,48                          1
    x48       E47,48                          1
    x49       cost                            1
    x49       C0,49                           1
    x49       C1,49                           1
    x49       C3,49                           1
    x49       C4,49                           1
    x49       C11,49                          1
    x49       C14,49                          1
    x49       C15,49                          1
    x49       C22,49                          1
    x49       C23,49                          1
    x49       C40,49                          1
    x49       C41,49                          1
    x49       C45,49                          1
    x49       C48,49                          1
    x49       E2,49                           1
    x49       E5,49                           1
    x49       E6,49                           1
    x49       E7,49                           1
    x49       E8,49                           1
    x49       E9,49                           1
    x49       E10,49                          1
    x49       E12,49                          1
    x49       E13,49                          1
    x49       E16,49                          1
    x49       E17,49                          1
    x49       E18,49                          1
    x49       E19,49                          1
    x49       E20,49                          1
    x49       E21,49                          1
    x49       E24,49                          1
    x49       E25,49                          1
    x49       E26,49                          1
    x49       E27,49                          1
    x49       E28,49                          1
    x49       E29,49                          1
    x49       E30,49                          1
    x49       E31,49                          1
    x49       E32,49                          1
    x49       E33,49                          1
    x49       E34,49                          1
    x49       E35,49                          1
    x49       E36,49                          1
    x49       E37,49                          1
    x49       E38,49                          1
    x49       E39,49                          1
    x49       E42,49                          1
    x49       E43,49                          1
    x49       E44,49                          1
    x49       E46,49                          1
    x49       E47,49                          1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       KL                            214
    rhs       C0,9                            1
    rhs       C0,11                           1
    rhs       C0,13                           1
    rhs       C0,18                           1
    rhs       C0,25                           1
    rhs       C0,28                           1
    rhs       C0,30                           1
    rhs       C0,31                           1
    rhs       C0,36                           1
    rhs       C0,44                           1
    rhs       C0,48                           1
    rhs       C0,49                           1
    rhs       C1,2                            1
    rhs       C1,10                           1
    rhs       C1,14                           1
    rhs       C1,15                           1
    rhs       C1,19                           1
    rhs       C1,28                           1
    rhs       C1,32                           1
    rhs       C1,38                           1
    rhs       C1,39                           1
    rhs       C1,42                           1
    rhs       C1,43                           1
    rhs       C1,45                           1
    rhs       C1,46                           1
    rhs       C1,47                           1
    rhs       C1,49                           1
    rhs       C2,6                            1
    rhs       C2,8                            1
    rhs       C2,9                            1
    rhs       C2,11                           1
    rhs       C2,13                           1
    rhs       C2,15                           1
    rhs       C2,17                           1
    rhs       C2,22                           1
    rhs       C2,23                           1
    rhs       C2,24                           1
    rhs       C2,25                           1
    rhs       C2,27                           1
    rhs       C2,30                           1
    rhs       C2,41                           1
    rhs       C2,42                           1
    rhs       C2,43                           1
    rhs       C2,47                           1
    rhs       C3,5                            1
    rhs       C3,19                           1
    rhs       C3,20                           1
    rhs       C3,23                           1
    rhs       C3,27                           1
    rhs       C3,28                           1
    rhs       C3,32                           1
    rhs       C3,34                           1
    rhs       C3,39                           1
    rhs       C3,40                           1
    rhs       C3,41                           1
    rhs       C3,42                           1
    rhs       C3,44                           1
    rhs       C3,46                           1
    rhs       C3,48                           1
    rhs       C3,49                           1
    rhs       C4,6                            1
    rhs       C4,7                            1
    rhs       C4,8                            1
    rhs       C4,10                           1
    rhs       C4,18                           1
    rhs       C4,20                           1
    rhs       C4,21                           1
    rhs       C4,28                           1
    rhs       C4,29                           1
    rhs       C4,30                           1
    rhs       C4,39                           1
    rhs       C4,43                           1
    rhs       C4,49                           1
    rhs       C5,18                           1
    rhs       C5,21                           1
    rhs       C5,29                           1
    rhs       C5,32                           1
    rhs       C5,34                           1
    rhs       C5,36                           1
    rhs       C5,37                           1
    rhs       C5,43                           1
    rhs       C5,44                           1
    rhs       C5,46                           1
    rhs       C6,7                            1
    rhs       C6,8                            1
    rhs       C6,12                           1
    rhs       C6,14                           1
    rhs       C6,15                           1
    rhs       C6,18                           1
    rhs       C6,19                           1
    rhs       C6,20                           1
    rhs       C6,22                           1
    rhs       C6,25                           1
    rhs       C6,33                           1
    rhs       C6,37                           1
    rhs       C6,39                           1
    rhs       C6,40                           1
    rhs       C6,41                           1
    rhs       C6,42                           1
    rhs       C6,44                           1
    rhs       C6,45                           1
    rhs       C6,48                           1
    rhs       C7,11                           1
    rhs       C7,12                           1
    rhs       C7,17                           1
    rhs       C7,18                           1
    rhs       C7,19                           1
    rhs       C7,22                           1
    rhs       C7,23                           1
    rhs       C7,24                           1
    rhs       C7,34                           1
    rhs       C7,35                           1
    rhs       C7,36                           1
    rhs       C7,37                           1
    rhs       C7,41                           1
    rhs       C7,42                           1
    rhs       C7,43                           1
    rhs       C7,44                           1
    rhs       C7,45                           1
    rhs       C7,47                           1
    rhs       C7,48                           1
    rhs       C8,10                           1
    rhs       C8,11                           1
    rhs       C8,15                           1
    rhs       C8,17                           1
    rhs       C8,23                           1
    rhs       C8,24                           1
    rhs       C8,26                           1
    rhs       C8,27                           1
    rhs       C8,28                           1
    rhs       C8,31                           1
    rhs       C8,32                           1
    rhs       C8,36                           1
    rhs       C8,38                           1
    rhs       C8,46                           1
    rhs       C9,16                           1
    rhs       C9,18                           1
    rhs       C9,22                           1
    rhs       C9,31                           1
    rhs       C9,32                           1
    rhs       C9,36                           1
    rhs       C9,43                           1
    rhs       C9,44                           1
    rhs       C9,46                           1
    rhs       C10,17                          1
    rhs       C10,18                          1
    rhs       C10,19                          1
    rhs       C10,22                          1
    rhs       C10,25                          1
    rhs       C10,26                          1
    rhs       C10,38                          1
    rhs       C10,39                          1
    rhs       C10,47                          1
    rhs       C11,13                          1
    rhs       C11,17                          1
    rhs       C11,19                          1
    rhs       C11,24                          1
    rhs       C11,26                          1
    rhs       C11,32                          1
    rhs       C11,41                          1
    rhs       C11,45                          1
    rhs       C11,49                          1
    rhs       C12,16                          1
    rhs       C12,18                          1
    rhs       C12,19                          1
    rhs       C12,22                          1
    rhs       C12,31                          1
    rhs       C12,43                          1
    rhs       C12,45                          1
    rhs       C12,48                          1
    rhs       C13,14                          1
    rhs       C13,17                          1
    rhs       C13,19                          1
    rhs       C13,20                          1
    rhs       C13,25                          1
    rhs       C13,28                          1
    rhs       C13,29                          1
    rhs       C13,30                          1
    rhs       C13,33                          1
    rhs       C13,36                          1
    rhs       C13,37                          1
    rhs       C13,46                          1
    rhs       C13,48                          1
    rhs       C14,21                          1
    rhs       C14,28                          1
    rhs       C14,29                          1
    rhs       C14,34                          1
    rhs       C14,35                          1
    rhs       C14,38                          1
    rhs       C14,42                          1
    rhs       C14,43                          1
    rhs       C14,44                          1
    rhs       C14,45                          1
    rhs       C14,49                          1
    rhs       C15,18                          1
    rhs       C15,25                          1
    rhs       C15,31                          1
    rhs       C15,35                          1
    rhs       C15,36                          1
    rhs       C15,39                          1
    rhs       C15,42                          1
    rhs       C15,43                          1
    rhs       C15,47                          1
    rhs       C15,49                          1
    rhs       C16,20                          1
    rhs       C16,21                          1
    rhs       C16,24                          1
    rhs       C16,25                          1
    rhs       C16,32                          1
    rhs       C16,33                          1
    rhs       C16,34                          1
    rhs       C16,35                          1
    rhs       C16,36                          1
    rhs       C16,42                          1
    rhs       C16,43                          1
    rhs       C16,45                          1
    rhs       C17,24                          1
    rhs       C17,25                          1
    rhs       C17,26                          1
    rhs       C17,28                          1
    rhs       C17,34                          1
    rhs       C17,37                          1
    rhs       C17,38                          1
    rhs       C17,45                          1
    rhs       C17,48                          1
    rhs       C18,19                          1
    rhs       C18,20                          1
    rhs       C18,25                          1
    rhs       C18,28                          1
    rhs       C18,29                          1
    rhs       C18,30                          1
    rhs       C18,39                          1
    rhs       C18,41                          1
    rhs       C18,44                          1
    rhs       C19,20                          1
    rhs       C19,22                          1
    rhs       C19,27                          1
    rhs       C19,33                          1
    rhs       C19,35                          1
    rhs       C19,36                          1
    rhs       C19,42                          1
    rhs       C19,43                          1
    rhs       C20,25                          1
    rhs       C20,28                          1
    rhs       C20,31                          1
    rhs       C20,34                          1
    rhs       C20,36                          1
    rhs       C20,38                          1
    rhs       C20,42                          1
    rhs       C20,46                          1
    rhs       C21,23                          1
    rhs       C21,24                          1
    rhs       C21,28                          1
    rhs       C21,30                          1
    rhs       C21,31                          1
    rhs       C21,32                          1
    rhs       C21,37                          1
    rhs       C21,40                          1
    rhs       C21,41                          1
    rhs       C21,43                          1
    rhs       C21,46                          1
    rhs       C21,48                          1
    rhs       C22,28                          1
    rhs       C22,32                          1
    rhs       C22,33                          1
    rhs       C22,34                          1
    rhs       C22,37                          1
    rhs       C22,41                          1
    rhs       C22,44                          1
    rhs       C22,46                          1
    rhs       C22,49                          1
    rhs       C23,24                          1
    rhs       C23,36                          1
    rhs       C23,38                          1
    rhs       C23,41                          1
    rhs       C23,43                          1
    rhs       C23,45                          1
    rhs       C23,49                          1
    rhs       C24,28                          1
    rhs       C24,31                          1
    rhs       C24,34                          1
    rhs       C24,37                          1
    rhs       C24,39                          1
    rhs       C24,40                          1
    rhs       C24,45                          1
    rhs       C24,47                          1
    rhs       C24,48                          1
    rhs       C25,29                          1
    rhs       C25,32                          1
    rhs       C25,37                          1
    rhs       C25,38                          1
    rhs       C25,39                          1
    rhs       C25,43                          1
    rhs       C25,45                          1
    rhs       C26,33                          1
    rhs       C26,36                          1
    rhs       C26,39                          1
    rhs       C26,43                          1
    rhs       C26,47                          1
    rhs       C27,32                          1
    rhs       C27,33                          1
    rhs       C27,37                          1
    rhs       C27,38                          1
    rhs       C27,39                          1
    rhs       C27,41                          1
    rhs       C27,46                          1
    rhs       C28,29                          1
    rhs       C28,30                          1
    rhs       C28,47                          1
    rhs       C29,33                          1
    rhs       C29,41                          1
    rhs       C29,46                          1
    rhs       C30,31                          1
    rhs       C30,41                          1
    rhs       C30,42                          1
    rhs       C30,48                          1
    rhs       C31,32                          1
    rhs       C31,33                          1
    rhs       C31,38                          1
    rhs       C31,42                          1
    rhs       C31,44                          1
    rhs       C31,47                          1
    rhs       C32,35                          1
    rhs       C32,36                          1
    rhs       C32,44                          1
    rhs       C32,45                          1
    rhs       C33,35                          1
    rhs       C33,40                          1
    rhs       C33,41                          1
    rhs       C33,43                          1
    rhs       C33,47                          1
    rhs       C34,35                          1
    rhs       C34,37                          1
    rhs       C34,39                          1
    rhs       C34,41                          1
    rhs       C34,42                          1
    rhs       C34,48                          1
    rhs       C35,41                          1
    rhs       C35,42                          1
    rhs       C35,45                          1
    rhs       C35,48                          1
    rhs       C36,39                          1
    rhs       C36,42                          1
    rhs       C36,43                          1
    rhs       C37,38                          1
    rhs       C37,41                          1
    rhs       C38,41                          1
    rhs       C38,47                          1
    rhs       C39,40                          1
    rhs       C39,43                          1
    rhs       C39,46                          1
    rhs       C39,47                          1
    rhs       C39,48                          1
    rhs       C40,41                          1
    rhs       C40,42                          1
    rhs       C40,44                          1
    rhs       C40,46                          1
    rhs       C40,49                          1
    rhs       C41,49                          1
    rhs       C42,44                          1
    rhs       C42,47                          1
    rhs       C43,44                          1
    rhs       C43,48                          1
    rhs       C44,47                          1
    rhs       C45,46                          1
    rhs       C45,48                          1
    rhs       C45,49                          1
    rhs       C48,49                          1
    rhs       E0,1                            1
    rhs       E0,2                            1
    rhs       E0,3                            1
    rhs       E0,4                            1
    rhs       E0,5                            1
    rhs       E0,6                            1
    rhs       E0,7                            1
    rhs       E0,8                            1
    rhs       E0,10                           1
    rhs       E0,12                           1
    rhs       E0,14                           1
    rhs       E0,15                           1
    rhs       E0,16                           1
    rhs       E0,17                           1
    rhs       E0,19                           1
    rhs       E0,20                           1
    rhs       E0,21                           1
    rhs       E0,22                           1
    rhs       E0,23                           1
    rhs       E0,24                           1
    rhs       E0,26                           1
    rhs       E0,27                           1
    rhs       E0,29                           1
    rhs       E0,32                           1
    rhs       E0,33                           1
    rhs       E0,34                           1
    rhs       E0,35                           1
    rhs       E0,37                           1
    rhs       E0,38                           1
    rhs       E0,39                           1
    rhs       E0,40                           1
    rhs       E0,41                           1
    rhs       E0,42                           1
    rhs       E0,43                           1
    rhs       E0,45                           1
    rhs       E0,46                           1
    rhs       E0,47                           1
    rhs       E1,3                            1
    rhs       E1,4                            1
    rhs       E1,5                            1
    rhs       E1,6                            1
    rhs       E1,7                            1
    rhs       E1,8                            1
    rhs       E1,9                            1
    rhs       E1,11                           1
    rhs       E1,12                           1
    rhs       E1,13                           1
    rhs       E1,16                           1
    rhs       E1,17                           1
    rhs       E1,18                           1
    rhs       E1,20                           1
    rhs       E1,21                           1
    rhs       E1,22                           1
    rhs       E1,23                           1
    rhs       E1,24                           1
    rhs       E1,25                           1
    rhs       E1,26                           1
    rhs       E1,27                           1
    rhs       E1,29                           1
    rhs       E1,30                           1
    rhs       E1,31                           1
    rhs       E1,33                           1
    rhs       E1,34                           1
    rhs       E1,35                           1
    rhs       E1,36                           1
    rhs       E1,37                           1
    rhs       E1,40                           1
    rhs       E1,41                           1
    rhs       E1,44                           1
    rhs       E1,48                           1
    rhs       E2,3                            1
    rhs       E2,4                            1
    rhs       E2,5                            1
    rhs       E2,7                            1
    rhs       E2,10                           1
    rhs       E2,12                           1
    rhs       E2,14                           1
    rhs       E2,16                           1
    rhs       E2,18                           1
    rhs       E2,19                           1
    rhs       E2,20                           1
    rhs       E2,21                           1
    rhs       E2,26                           1
    rhs       E2,28                           1
    rhs       E2,29                           1
    rhs       E2,31                           1
    rhs       E2,32                           1
    rhs       E2,33                           1
    rhs       E2,34                           1
    rhs       E2,35                           1
    rhs       E2,36                           1
    rhs       E2,37                           1
    rhs       E2,38                           1
    rhs       E2,39                           1
    rhs       E2,40                           1
    rhs       E2,44                           1
    rhs       E2,45                           1
    rhs       E2,46                           1
    rhs       E2,48                           1
    rhs       E2,49                           1
    rhs       E3,4                            1
    rhs       E3,6                            1
    rhs       E3,7                            1
    rhs       E3,8                            1
    rhs       E3,9                            1
    rhs       E3,10                           1
    rhs       E3,11                           1
    rhs       E3,12                           1
    rhs       E3,13                           1
    rhs       E3,14                           1
    rhs       E3,15                           1
    rhs       E3,16                           1
    rhs       E3,17                           1
    rhs       E3,18                           1
    rhs       E3,21                           1
    rhs       E3,22                           1
    rhs       E3,24                           1
    rhs       E3,25                           1
    rhs       E3,26                           1
    rhs       E3,29                           1
    rhs       E3,30                           1
    rhs       E3,31                           1
    rhs       E3,33                           1
    rhs       E3,35                           1
    rhs       E3,36                           1
    rhs       E3,37                           1
    rhs       E3,38                           1
    rhs       E3,43                           1
    rhs       E3,45                           1
    rhs       E3,47                           1
    rhs       E4,5                            1
    rhs       E4,9                            1
    rhs       E4,11                           1
    rhs       E4,12                           1
    rhs       E4,13                           1
    rhs       E4,14                           1
    rhs       E4,15                           1
    rhs       E4,16                           1
    rhs       E4,17                           1
    rhs       E4,19                           1
    rhs       E4,22                           1
    rhs       E4,23                           1
    rhs       E4,24                           1
    rhs       E4,25                           1
    rhs       E4,26                           1
    rhs       E4,27                           1
    rhs       E4,31                           1
    rhs       E4,32                           1
    rhs       E4,33                           1
    rhs       E4,34                           1
    rhs       E4,35                           1
    rhs       E4,36                           1
    rhs       E4,37                           1
    rhs       E4,38                           1
    rhs       E4,40                           1
    rhs       E4,41                           1
    rhs       E4,42                           1
    rhs       E4,44                           1
    rhs       E4,45                           1
    rhs       E4,46                           1
    rhs       E4,47                           1
    rhs       E4,48                           1
    rhs       E5,6                            1
    rhs       E5,7                            1
    rhs       E5,8                            1
    rhs       E5,9                            1
    rhs       E5,10                           1
    rhs       E5,11                           1
    rhs       E5,12                           1
    rhs       E5,13                           1
    rhs       E5,14                           1
    rhs       E5,15                           1
    rhs       E5,16                           1
    rhs       E5,17                           1
    rhs       E5,19                           1
    rhs       E5,20                           1
    rhs       E5,22                           1
    rhs       E5,23                           1
    rhs       E5,24                           1
    rhs       E5,25                           1
    rhs       E5,26                           1
    rhs       E5,27                           1
    rhs       E5,28                           1
    rhs       E5,30                           1
    rhs       E5,31                           1
    rhs       E5,33                           1
    rhs       E5,35                           1
    rhs       E5,38                           1
    rhs       E5,39                           1
    rhs       E5,40                           1
    rhs       E5,41                           1
    rhs       E5,42                           1
    rhs       E5,45                           1
    rhs       E5,47                           1
    rhs       E5,48                           1
    rhs       E5,49                           1
    rhs       E6,9                            1
    rhs       E6,10                           1
    rhs       E6,11                           1
    rhs       E6,13                           1
    rhs       E6,16                           1
    rhs       E6,17                           1
    rhs       E6,21                           1
    rhs       E6,23                           1
    rhs       E6,24                           1
    rhs       E6,26                           1
    rhs       E6,27                           1
    rhs       E6,28                           1
    rhs       E6,29                           1
    rhs       E6,30                           1
    rhs       E6,31                           1
    rhs       E6,32                           1
    rhs       E6,34                           1
    rhs       E6,35                           1
    rhs       E6,36                           1
    rhs       E6,38                           1
    rhs       E6,43                           1
    rhs       E6,46                           1
    rhs       E6,47                           1
    rhs       E6,49                           1
    rhs       E7,8                            1
    rhs       E7,9                            1
    rhs       E7,10                           1
    rhs       E7,13                           1
    rhs       E7,14                           1
    rhs       E7,15                           1
    rhs       E7,16                           1
    rhs       E7,20                           1
    rhs       E7,21                           1
    rhs       E7,25                           1
    rhs       E7,26                           1
    rhs       E7,27                           1
    rhs       E7,28                           1
    rhs       E7,29                           1
    rhs       E7,30                           1
    rhs       E7,31                           1
    rhs       E7,32                           1
    rhs       E7,33                           1
    rhs       E7,38                           1
    rhs       E7,39                           1
    rhs       E7,40                           1
    rhs       E7,46                           1
    rhs       E7,49                           1
    rhs       E8,9                            1
    rhs       E8,12                           1
    rhs       E8,13                           1
    rhs       E8,14                           1
    rhs       E8,16                           1
    rhs       E8,18                           1
    rhs       E8,19                           1
    rhs       E8,20                           1
    rhs       E8,21                           1
    rhs       E8,22                           1
    rhs       E8,25                           1
    rhs       E8,29                           1
    rhs       E8,30                           1
    rhs       E8,33                           1
    rhs       E8,34                           1
    rhs       E8,35                           1
    rhs       E8,37                           1
    rhs       E8,39                           1
    rhs       E8,40                           1
    rhs       E8,41                           1
    rhs       E8,42                           1
    rhs       E8,43                           1
    rhs       E8,44                           1
    rhs       E8,45                           1
    rhs       E8,47                           1
    rhs       E8,48                           1
    rhs       E8,49                           1
    rhs       E9,10                           1
    rhs       E9,11                           1
    rhs       E9,12                           1
    rhs       E9,13                           1
    rhs       E9,14                           1
    rhs       E9,15                           1
    rhs       E9,17                           1
    rhs       E9,19                           1
    rhs       E9,20                           1
    rhs       E9,21                           1
    rhs       E9,23                           1
    rhs       E9,24                           1
    rhs       E9,25                           1
    rhs       E9,26                           1
    rhs       E9,27                           1
    rhs       E9,28                           1
    rhs       E9,29                           1
    rhs       E9,30                           1
    rhs       E9,33                           1
    rhs       E9,34                           1
    rhs       E9,35                           1
    rhs       E9,37                           1
    rhs       E9,38                           1
    rhs       E9,39                           1
    rhs       E9,40                           1
    rhs       E9,41                           1
    rhs       E9,42                           1
    rhs       E9,45                           1
    rhs       E9,47                           1
    rhs       E9,48                           1
    rhs       E9,49                           1
    rhs       E10,11                          1
    rhs       E10,12                          1
    rhs       E10,13                          1
    rhs       E10,14                          1
    rhs       E10,15                          1
    rhs       E10,16                          1
    rhs       E10,20                          1
    rhs       E10,21                          1
    rhs       E10,23                          1
    rhs       E10,24                          1
    rhs       E10,27                          1
    rhs       E10,28                          1
    rhs       E10,29                          1
    rhs       E10,30                          1
    rhs       E10,31                          1
    rhs       E10,32                          1
    rhs       E10,33                          1
    rhs       E10,34                          1
    rhs       E10,35                          1
    rhs       E10,36                          1
    rhs       E10,37                          1
    rhs       E10,40                          1
    rhs       E10,41                          1
    rhs       E10,42                          1
    rhs       E10,43                          1
    rhs       E10,44                          1
    rhs       E10,45                          1
    rhs       E10,46                          1
    rhs       E10,48                          1
    rhs       E10,49                          1
    rhs       E11,12                          1
    rhs       E11,14                          1
    rhs       E11,15                          1
    rhs       E11,16                          1
    rhs       E11,18                          1
    rhs       E11,20                          1
    rhs       E11,21                          1
    rhs       E11,22                          1
    rhs       E11,23                          1
    rhs       E11,25                          1
    rhs       E11,27                          1
    rhs       E11,28                          1
    rhs       E11,29                          1
    rhs       E11,30                          1
    rhs       E11,31                          1
    rhs       E11,33                          1
    rhs       E11,34                          1
    rhs       E11,35                          1
    rhs       E11,36                          1
    rhs       E11,37                          1
    rhs       E11,38                          1
    rhs       E11,39                          1
    rhs       E11,40                          1
    rhs       E11,42                          1
    rhs       E11,43                          1
    rhs       E11,44                          1
    rhs       E11,46                          1
    rhs       E11,47                          1
    rhs       E11,48                          1
    rhs       E12,13                          1
    rhs       E12,14                          1
    rhs       E12,15                          1
    rhs       E12,17                          1
    rhs       E12,20                          1
    rhs       E12,21                          1
    rhs       E12,23                          1
    rhs       E12,24                          1
    rhs       E12,25                          1
    rhs       E12,26                          1
    rhs       E12,27                          1
    rhs       E12,28                          1
    rhs       E12,29                          1
    rhs       E12,30                          1
    rhs       E12,32                          1
    rhs       E12,33                          1
    rhs       E12,34                          1
    rhs       E12,35                          1
    rhs       E12,36                          1
    rhs       E12,37                          1
    rhs       E12,38                          1
    rhs       E12,39                          1
    rhs       E12,40                          1
    rhs       E12,41                          1
    rhs       E12,42                          1
    rhs       E12,44                          1
    rhs       E12,46                          1
    rhs       E12,47                          1
    rhs       E12,49                          1
    rhs       E13,15                          1
    rhs       E13,16                          1
    rhs       E13,18                          1
    rhs       E13,21                          1
    rhs       E13,22                          1
    rhs       E13,23                          1
    rhs       E13,24                          1
    rhs       E13,26                          1
    rhs       E13,27                          1
    rhs       E13,31                          1
    rhs       E13,32                          1
    rhs       E13,34                          1
    rhs       E13,35                          1
    rhs       E13,38                          1
    rhs       E13,39                          1
    rhs       E13,40                          1
    rhs       E13,41                          1
    rhs       E13,42                          1
    rhs       E13,43                          1
    rhs       E13,44                          1
    rhs       E13,45                          1
    rhs       E13,47                          1
    rhs       E13,49                          1
    rhs       E14,15                          1
    rhs       E14,16                          1
    rhs       E14,17                          1
    rhs       E14,18                          1
    rhs       E14,19                          1
    rhs       E14,20                          1
    rhs       E14,22                          1
    rhs       E14,23                          1
    rhs       E14,24                          1
    rhs       E14,25                          1
    rhs       E14,26                          1
    rhs       E14,27                          1
    rhs       E14,30                          1
    rhs       E14,31                          1
    rhs       E14,32                          1
    rhs       E14,33                          1
    rhs       E14,36                          1
    rhs       E14,37                          1
    rhs       E14,39                          1
    rhs       E14,40                          1
    rhs       E14,41                          1
    rhs       E14,46                          1
    rhs       E14,47                          1
    rhs       E14,48                          1
    rhs       E15,16                          1
    rhs       E15,17                          1
    rhs       E15,19                          1
    rhs       E15,20                          1
    rhs       E15,21                          1
    rhs       E15,22                          1
    rhs       E15,23                          1
    rhs       E15,24                          1
    rhs       E15,26                          1
    rhs       E15,27                          1
    rhs       E15,28                          1
    rhs       E15,29                          1
    rhs       E15,30                          1
    rhs       E15,32                          1
    rhs       E15,33                          1
    rhs       E15,34                          1
    rhs       E15,37                          1
    rhs       E15,38                          1
    rhs       E15,40                          1
    rhs       E15,41                          1
    rhs       E15,44                          1
    rhs       E15,45                          1
    rhs       E15,46                          1
    rhs       E15,48                          1
    rhs       E16,17                          1
    rhs       E16,18                          1
    rhs       E16,19                          1
    rhs       E16,22                          1
    rhs       E16,23                          1
    rhs       E16,26                          1
    rhs       E16,27                          1
    rhs       E16,28                          1
    rhs       E16,29                          1
    rhs       E16,30                          1
    rhs       E16,31                          1
    rhs       E16,37                          1
    rhs       E16,38                          1
    rhs       E16,39                          1
    rhs       E16,40                          1
    rhs       E16,41                          1
    rhs       E16,44                          1
    rhs       E16,46                          1
    rhs       E16,47                          1
    rhs       E16,48                          1
    rhs       E16,49                          1
    rhs       E17,18                          1
    rhs       E17,19                          1
    rhs       E17,20                          1
    rhs       E17,21                          1
    rhs       E17,22                          1
    rhs       E17,23                          1
    rhs       E17,27                          1
    rhs       E17,29                          1
    rhs       E17,30                          1
    rhs       E17,31                          1
    rhs       E17,32                          1
    rhs       E17,33                          1
    rhs       E17,35                          1
    rhs       E17,36                          1
    rhs       E17,39                          1
    rhs       E17,40                          1
    rhs       E17,41                          1
    rhs       E17,42                          1
    rhs       E17,43                          1
    rhs       E17,44                          1
    rhs       E17,46                          1
    rhs       E17,47                          1
    rhs       E17,49                          1
    rhs       E18,21                          1
    rhs       E18,22                          1
    rhs       E18,23                          1
    rhs       E18,24                          1
    rhs       E18,26                          1
    rhs       E18,27                          1
    rhs       E18,31                          1
    rhs       E18,32                          1
    rhs       E18,33                          1
    rhs       E18,34                          1
    rhs       E18,35                          1
    rhs       E18,36                          1
    rhs       E18,37                          1
    rhs       E18,38                          1
    rhs       E18,40                          1
    rhs       E18,42                          1
    rhs       E18,43                          1
    rhs       E18,45                          1
    rhs       E18,46                          1
    rhs       E18,47                          1
    rhs       E18,48                          1
    rhs       E18,49                          1
    rhs       E19,21                          1
    rhs       E19,23                          1
    rhs       E19,24                          1
    rhs       E19,25                          1
    rhs       E19,26                          1
    rhs       E19,28                          1
    rhs       E19,29                          1
    rhs       E19,30                          1
    rhs       E19,31                          1
    rhs       E19,32                          1
    rhs       E19,34                          1
    rhs       E19,37                          1
    rhs       E19,38                          1
    rhs       E19,39                          1
    rhs       E19,40                          1
    rhs       E19,41                          1
    rhs       E19,44                          1
    rhs       E19,45                          1
    rhs       E19,46                          1
    rhs       E19,47                          1
    rhs       E19,48                          1
    rhs       E19,49                          1
    rhs       E20,21                          1
    rhs       E20,22                          1
    rhs       E20,23                          1
    rhs       E20,24                          1
    rhs       E20,26                          1
    rhs       E20,27                          1
    rhs       E20,29                          1
    rhs       E20,30                          1
    rhs       E20,32                          1
    rhs       E20,33                          1
    rhs       E20,35                          1
    rhs       E20,37                          1
    rhs       E20,39                          1
    rhs       E20,40                          1
    rhs       E20,41                          1
    rhs       E20,43                          1
    rhs       E20,44                          1
    rhs       E20,45                          1
    rhs       E20,47                          1
    rhs       E20,48                          1
    rhs       E20,49                          1
    rhs       E21,22                          1
    rhs       E21,25                          1
    rhs       E21,26                          1
    rhs       E21,27                          1
    rhs       E21,29                          1
    rhs       E21,33                          1
    rhs       E21,34                          1
    rhs       E21,35                          1
    rhs       E21,36                          1
    rhs       E21,38                          1
    rhs       E21,39                          1
    rhs       E21,42                          1
    rhs       E21,44                          1
    rhs       E21,45                          1
    rhs       E21,47                          1
    rhs       E21,49                          1
    rhs       E22,23                          1
    rhs       E22,24                          1
    rhs       E22,25                          1
    rhs       E22,26                          1
    rhs       E22,27                          1
    rhs       E22,29                          1
    rhs       E22,30                          1
    rhs       E22,31                          1
    rhs       E22,35                          1
    rhs       E22,36                          1
    rhs       E22,38                          1
    rhs       E22,39                          1
    rhs       E22,40                          1
    rhs       E22,42                          1
    rhs       E22,43                          1
    rhs       E22,45                          1
    rhs       E22,47                          1
    rhs       E22,48                          1
    rhs       E23,25                          1
    rhs       E23,26                          1
    rhs       E23,27                          1
    rhs       E23,28                          1
    rhs       E23,29                          1
    rhs       E23,30                          1
    rhs       E23,31                          1
    rhs       E23,32                          1
    rhs       E23,33                          1
    rhs       E23,34                          1
    rhs       E23,35                          1
    rhs       E23,37                          1
    rhs       E23,39                          1
    rhs       E23,40                          1
    rhs       E23,42                          1
    rhs       E23,44                          1
    rhs       E23,46                          1
    rhs       E23,47                          1
    rhs       E23,48                          1
    rhs       E24,25                          1
    rhs       E24,26                          1
    rhs       E24,27                          1
    rhs       E24,29                          1
    rhs       E24,30                          1
    rhs       E24,32                          1
    rhs       E24,33                          1
    rhs       E24,35                          1
    rhs       E24,36                          1
    rhs       E24,38                          1
    rhs       E24,41                          1
    rhs       E24,42                          1
    rhs       E24,43                          1
    rhs       E24,44                          1
    rhs       E24,46                          1
    rhs       E24,49                          1
    rhs       E25,26                          1
    rhs       E25,27                          1
    rhs       E25,28                          1
    rhs       E25,30                          1
    rhs       E25,31                          1
    rhs       E25,33                          1
    rhs       E25,34                          1
    rhs       E25,35                          1
    rhs       E25,36                          1
    rhs       E25,40                          1
    rhs       E25,41                          1
    rhs       E25,42                          1
    rhs       E25,44                          1
    rhs       E25,46                          1
    rhs       E25,47                          1
    rhs       E25,48                          1
    rhs       E25,49                          1
    rhs       E26,27                          1
    rhs       E26,28                          1
    rhs       E26,29                          1
    rhs       E26,30                          1
    rhs       E26,31                          1
    rhs       E26,32                          1
    rhs       E26,34                          1
    rhs       E26,35                          1
    rhs       E26,37                          1
    rhs       E26,38                          1
    rhs       E26,40                          1
    rhs       E26,41                          1
    rhs       E26,42                          1
    rhs       E26,44                          1
    rhs       E26,45                          1
    rhs       E26,46                          1
    rhs       E26,48                          1
    rhs       E26,49                          1
    rhs       E27,28                          1
    rhs       E27,29                          1
    rhs       E27,30                          1
    rhs       E27,31                          1
    rhs       E27,34                          1
    rhs       E27,35                          1
    rhs       E27,36                          1
    rhs       E27,40                          1
    rhs       E27,42                          1
    rhs       E27,43                          1
    rhs       E27,44                          1
    rhs       E27,45                          1
    rhs       E27,47                          1
    rhs       E27,48                          1
    rhs       E27,49                          1
    rhs       E28,31                          1
    rhs       E28,32                          1
    rhs       E28,33                          1
    rhs       E28,34                          1
    rhs       E28,35                          1
    rhs       E28,36                          1
    rhs       E28,37                          1
    rhs       E28,38                          1
    rhs       E28,39                          1
    rhs       E28,40                          1
    rhs       E28,41                          1
    rhs       E28,42                          1
    rhs       E28,43                          1
    rhs       E28,44                          1
    rhs       E28,45                          1
    rhs       E28,46                          1
    rhs       E28,48                          1
    rhs       E28,49                          1
    rhs       E29,30                          1
    rhs       E29,31                          1
    rhs       E29,32                          1
    rhs       E29,34                          1
    rhs       E29,35                          1
    rhs       E29,36                          1
    rhs       E29,37                          1
    rhs       E29,38                          1
    rhs       E29,39                          1
    rhs       E29,40                          1
    rhs       E29,42                          1
    rhs       E29,43                          1
    rhs       E29,44                          1
    rhs       E29,45                          1
    rhs       E29,47                          1
    rhs       E29,48                          1
    rhs       E29,49                          1
    rhs       E30,32                          1
    rhs       E30,33                          1
    rhs       E30,34                          1
    rhs       E30,35                          1
    rhs       E30,36                          1
    rhs       E30,37                          1
    rhs       E30,38                          1
    rhs       E30,39                          1
    rhs       E30,40                          1
    rhs       E30,43                          1
    rhs       E30,44                          1
    rhs       E30,45                          1
    rhs       E30,46                          1
    rhs       E30,47                          1
    rhs       E30,49                          1
    rhs       E31,34                          1
    rhs       E31,35                          1
    rhs       E31,36                          1
    rhs       E31,37                          1
    rhs       E31,39                          1
    rhs       E31,40                          1
    rhs       E31,41                          1
    rhs       E31,43                          1
    rhs       E31,45                          1
    rhs       E31,46                          1
    rhs       E31,48                          1
    rhs       E31,49                          1
    rhs       E32,33                          1
    rhs       E32,34                          1
    rhs       E32,37                          1
    rhs       E32,38                          1
    rhs       E32,39                          1
    rhs       E32,40                          1
    rhs       E32,41                          1
    rhs       E32,42                          1
    rhs       E32,43                          1
    rhs       E32,46                          1
    rhs       E32,47                          1
    rhs       E32,48                          1
    rhs       E32,49                          1
    rhs       E33,34                          1
    rhs       E33,36                          1
    rhs       E33,37                          1
    rhs       E33,38                          1
    rhs       E33,39                          1
    rhs       E33,42                          1
    rhs       E33,44                          1
    rhs       E33,45                          1
    rhs       E33,46                          1
    rhs       E33,48                          1
    rhs       E33,49                          1
    rhs       E34,36                          1
    rhs       E34,38                          1
    rhs       E34,40                          1
    rhs       E34,43                          1
    rhs       E34,44                          1
    rhs       E34,45                          1
    rhs       E34,46                          1
    rhs       E34,47                          1
    rhs       E34,49                          1
    rhs       E35,36                          1
    rhs       E35,37                          1
    rhs       E35,38                          1
    rhs       E35,39                          1
    rhs       E35,40                          1
    rhs       E35,43                          1
    rhs       E35,44                          1
    rhs       E35,46                          1
    rhs       E35,47                          1
    rhs       E35,49                          1
    rhs       E36,37                          1
    rhs       E36,38                          1
    rhs       E36,40                          1
    rhs       E36,41                          1
    rhs       E36,44                          1
    rhs       E36,45                          1
    rhs       E36,46                          1
    rhs       E36,47                          1
    rhs       E36,48                          1
    rhs       E36,49                          1
    rhs       E37,39                          1
    rhs       E37,40                          1
    rhs       E37,42                          1
    rhs       E37,43                          1
    rhs       E37,44                          1
    rhs       E37,45                          1
    rhs       E37,46                          1
    rhs       E37,47                          1
    rhs       E37,48                          1
    rhs       E37,49                          1
    rhs       E38,39                          1
    rhs       E38,40                          1
    rhs       E38,42                          1
    rhs       E38,43                          1
    rhs       E38,44                          1
    rhs       E38,45                          1
    rhs       E38,46                          1
    rhs       E38,48                          1
    rhs       E38,49                          1
    rhs       E39,41                          1
    rhs       E39,42                          1
    rhs       E39,44                          1
    rhs       E39,45                          1
    rhs       E39,49                          1
    rhs       E40,43                          1
    rhs       E40,45                          1
    rhs       E40,47                          1
    rhs       E40,48                          1
    rhs       E41,42                          1
    rhs       E41,43                          1
    rhs       E41,44                          1
    rhs       E41,45                          1
    rhs       E41,46                          1
    rhs       E41,47                          1
    rhs       E41,48                          1
    rhs       E42,43                          1
    rhs       E42,45                          1
    rhs       E42,46                          1
    rhs       E42,48                          1
    rhs       E42,49                          1
    rhs       E43,45                          1
    rhs       E43,46                          1
    rhs       E43,47                          1
    rhs       E43,49                          1
    rhs       E44,45                          1
    rhs       E44,46                          1
    rhs       E44,48                          1
    rhs       E44,49                          1
    rhs       E45,47                          1
    rhs       E46,47                          1
    rhs       E46,48                          1
    rhs       E46,49                          1
    rhs       E47,48                          1
    rhs       E47,49                          1
    rhs       I0,1                            1
    rhs       I0,2                            1
    rhs       I0,3                            1
    rhs       I0,4                            1
    rhs       I0,5                            1
    rhs       I0,6                            1
    rhs       I0,7                            1
    rhs       I0,8                            1
    rhs       I0,10                           1
    rhs       I0,12                           1
    rhs       I0,14                           1
    rhs       I0,15                           1
    rhs       I0,16                           1
    rhs       I0,17                           1
    rhs       I0,19                           1
    rhs       I0,20                           1
    rhs       I0,21                           1
    rhs       I0,22                           1
    rhs       I0,23                           1
    rhs       I0,24                           1
    rhs       I0,26                           1
    rhs       I0,27                           1
    rhs       I0,29                           1
    rhs       I0,32                           1
    rhs       I0,33                           1
    rhs       I0,34                           1
    rhs       I0,35                           1
    rhs       I0,37                           1
    rhs       I0,38                           1
    rhs       I0,39                           1
    rhs       I0,40                           1
    rhs       I0,41                           1
    rhs       I0,42                           1
    rhs       I0,43                           1
    rhs       I0,45                           1
    rhs       I0,46                           1
    rhs       I0,47                           1
    rhs       I1,3                            1
    rhs       I1,4                            1
    rhs       I1,5                            1
    rhs       I1,6                            1
    rhs       I1,7                            1
    rhs       I1,8                            1
    rhs       I1,9                            1
    rhs       I1,11                           1
    rhs       I1,12                           1
    rhs       I1,13                           1
    rhs       I1,16                           1
    rhs       I1,17                           1
    rhs       I1,18                           1
    rhs       I1,20                           1
    rhs       I1,21                           1
    rhs       I1,22                           1
    rhs       I1,23                           1
    rhs       I1,24                           1
    rhs       I1,25                           1
    rhs       I1,26                           1
    rhs       I1,27                           1
    rhs       I1,29                           1
    rhs       I1,30                           1
    rhs       I1,31                           1
    rhs       I1,33                           1
    rhs       I1,34                           1
    rhs       I1,35                           1
    rhs       I1,36                           1
    rhs       I1,37                           1
    rhs       I1,40                           1
    rhs       I1,41                           1
    rhs       I1,44                           1
    rhs       I1,48                           1
    rhs       I2,3                            1
    rhs       I2,4                            1
    rhs       I2,5                            1
    rhs       I2,7                            1
    rhs       I2,10                           1
    rhs       I2,12                           1
    rhs       I2,14                           1
    rhs       I2,16                           1
    rhs       I2,18                           1
    rhs       I2,19                           1
    rhs       I2,20                           1
    rhs       I2,21                           1
    rhs       I2,26                           1
    rhs       I2,28                           1
    rhs       I2,29                           1
    rhs       I2,31                           1
    rhs       I2,32                           1
    rhs       I2,33                           1
    rhs       I2,34                           1
    rhs       I2,35                           1
    rhs       I2,36                           1
    rhs       I2,37                           1
    rhs       I2,38                           1
    rhs       I2,39                           1
    rhs       I2,40                           1
    rhs       I2,44                           1
    rhs       I2,45                           1
    rhs       I2,46                           1
    rhs       I2,48                           1
    rhs       I2,49                           1
    rhs       I3,4                            1
    rhs       I3,6                            1
    rhs       I3,7                            1
    rhs       I3,8                            1
    rhs       I3,9                            1
    rhs       I3,10                           1
    rhs       I3,11                           1
    rhs       I3,12                           1
    rhs       I3,13                           1
    rhs       I3,14                           1
    rhs       I3,15                           1
    rhs       I3,16                           1
    rhs       I3,17                           1
    rhs       I3,18                           1
    rhs       I3,21                           1
    rhs       I3,22                           1
    rhs       I3,24                           1
    rhs       I3,25                           1
    rhs       I3,26                           1
    rhs       I3,29                           1
    rhs       I3,30                           1
    rhs       I3,31                           1
    rhs       I3,33                           1
    rhs       I3,35                           1
    rhs       I3,36                           1
    rhs       I3,37                           1
    rhs       I3,38                           1
    rhs       I3,43                           1
    rhs       I3,45                           1
    rhs       I3,47                           1
    rhs       I4,5                            1
    rhs       I4,9                            1
    rhs       I4,11                           1
    rhs       I4,12                           1
    rhs       I4,13                           1
    rhs       I4,14                           1
    rhs       I4,15                           1
    rhs       I4,16                           1
    rhs       I4,17                           1
    rhs       I4,19                           1
    rhs       I4,22                           1
    rhs       I4,23                           1
    rhs       I4,24                           1
    rhs       I4,25                           1
    rhs       I4,26                           1
    rhs       I4,27                           1
    rhs       I4,31                           1
    rhs       I4,32                           1
    rhs       I4,33                           1
    rhs       I4,34                           1
    rhs       I4,35                           1
    rhs       I4,36                           1
    rhs       I4,37                           1
    rhs       I4,38                           1
    rhs       I4,40                           1
    rhs       I4,41                           1
    rhs       I4,42                           1
    rhs       I4,44                           1
    rhs       I4,45                           1
    rhs       I4,46                           1
    rhs       I4,47                           1
    rhs       I4,48                           1
    rhs       I5,6                            1
    rhs       I5,7                            1
    rhs       I5,8                            1
    rhs       I5,9                            1
    rhs       I5,10                           1
    rhs       I5,11                           1
    rhs       I5,12                           1
    rhs       I5,13                           1
    rhs       I5,14                           1
    rhs       I5,15                           1
    rhs       I5,16                           1
    rhs       I5,17                           1
    rhs       I5,19                           1
    rhs       I5,20                           1
    rhs       I5,22                           1
    rhs       I5,23                           1
    rhs       I5,24                           1
    rhs       I5,25                           1
    rhs       I5,26                           1
    rhs       I5,27                           1
    rhs       I5,28                           1
    rhs       I5,30                           1
    rhs       I5,31                           1
    rhs       I5,33                           1
    rhs       I5,35                           1
    rhs       I5,38                           1
    rhs       I5,39                           1
    rhs       I5,40                           1
    rhs       I5,41                           1
    rhs       I5,42                           1
    rhs       I5,45                           1
    rhs       I5,47                           1
    rhs       I5,48                           1
    rhs       I5,49                           1
    rhs       I6,9                            1
    rhs       I6,10                           1
    rhs       I6,11                           1
    rhs       I6,13                           1
    rhs       I6,16                           1
    rhs       I6,17                           1
    rhs       I6,21                           1
    rhs       I6,23                           1
    rhs       I6,24                           1
    rhs       I6,26                           1
    rhs       I6,27                           1
    rhs       I6,28                           1
    rhs       I6,29                           1
    rhs       I6,30                           1
    rhs       I6,31                           1
    rhs       I6,32                           1
    rhs       I6,34                           1
    rhs       I6,35                           1
    rhs       I6,36                           1
    rhs       I6,38                           1
    rhs       I6,43                           1
    rhs       I6,46                           1
    rhs       I6,47                           1
    rhs       I6,49                           1
    rhs       I7,8                            1
    rhs       I7,9                            1
    rhs       I7,10                           1
    rhs       I7,13                           1
    rhs       I7,14                           1
    rhs       I7,15                           1
    rhs       I7,16                           1
    rhs       I7,20                           1
    rhs       I7,21                           1
    rhs       I7,25                           1
    rhs       I7,26                           1
    rhs       I7,27                           1
    rhs       I7,28                           1
    rhs       I7,29                           1
    rhs       I7,30                           1
    rhs       I7,31                           1
    rhs       I7,32                           1
    rhs       I7,33                           1
    rhs       I7,38                           1
    rhs       I7,39                           1
    rhs       I7,40                           1
    rhs       I7,46                           1
    rhs       I7,49                           1
    rhs       I8,9                            1
    rhs       I8,12                           1
    rhs       I8,13                           1
    rhs       I8,14                           1
    rhs       I8,16                           1
    rhs       I8,18                           1
    rhs       I8,19                           1
    rhs       I8,20                           1
    rhs       I8,21                           1
    rhs       I8,22                           1
    rhs       I8,25                           1
    rhs       I8,29                           1
    rhs       I8,30                           1
    rhs       I8,33                           1
    rhs       I8,34                           1
    rhs       I8,35                           1
    rhs       I8,37                           1
    rhs       I8,39                           1
    rhs       I8,40                           1
    rhs       I8,41                           1
    rhs       I8,42                           1
    rhs       I8,43                           1
    rhs       I8,44                           1
    rhs       I8,45                           1
    rhs       I8,47                           1
    rhs       I8,48                           1
    rhs       I8,49                           1
    rhs       I9,10                           1
    rhs       I9,11                           1
    rhs       I9,12                           1
    rhs       I9,13                           1
    rhs       I9,14                           1
    rhs       I9,15                           1
    rhs       I9,17                           1
    rhs       I9,19                           1
    rhs       I9,20                           1
    rhs       I9,21                           1
    rhs       I9,23                           1
    rhs       I9,24                           1
    rhs       I9,25                           1
    rhs       I9,26                           1
    rhs       I9,27                           1
    rhs       I9,28                           1
    rhs       I9,29                           1
    rhs       I9,30                           1
    rhs       I9,33                           1
    rhs       I9,34                           1
    rhs       I9,35                           1
    rhs       I9,37                           1
    rhs       I9,38                           1
    rhs       I9,39                           1
    rhs       I9,40                           1
    rhs       I9,41                           1
    rhs       I9,42                           1
    rhs       I9,45                           1
    rhs       I9,47                           1
    rhs       I9,48                           1
    rhs       I9,49                           1
    rhs       I10,11                          1
    rhs       I10,12                          1
    rhs       I10,13                          1
    rhs       I10,14                          1
    rhs       I10,15                          1
    rhs       I10,16                          1
    rhs       I10,20                          1
    rhs       I10,21                          1
    rhs       I10,23                          1
    rhs       I10,24                          1
    rhs       I10,27                          1
    rhs       I10,28                          1
    rhs       I10,29                          1
    rhs       I10,30                          1
    rhs       I10,31                          1
    rhs       I10,32                          1
    rhs       I10,33                          1
    rhs       I10,34                          1
    rhs       I10,35                          1
    rhs       I10,36                          1
    rhs       I10,37                          1
    rhs       I10,40                          1
    rhs       I10,41                          1
    rhs       I10,42                          1
    rhs       I10,43                          1
    rhs       I10,44                          1
    rhs       I10,45                          1
    rhs       I10,46                          1
    rhs       I10,48                          1
    rhs       I10,49                          1
    rhs       I11,12                          1
    rhs       I11,14                          1
    rhs       I11,15                          1
    rhs       I11,16                          1
    rhs       I11,18                          1
    rhs       I11,20                          1
    rhs       I11,21                          1
    rhs       I11,22                          1
    rhs       I11,23                          1
    rhs       I11,25                          1
    rhs       I11,27                          1
    rhs       I11,28                          1
    rhs       I11,29                          1
    rhs       I11,30                          1
    rhs       I11,31                          1
    rhs       I11,33                          1
    rhs       I11,34                          1
    rhs       I11,35                          1
    rhs       I11,36                          1
    rhs       I11,37                          1
    rhs       I11,38                          1
    rhs       I11,39                          1
    rhs       I11,40                          1
    rhs       I11,42                          1
    rhs       I11,43                          1
    rhs       I11,44                          1
    rhs       I11,46                          1
    rhs       I11,47                          1
    rhs       I11,48                          1
    rhs       I12,13                          1
    rhs       I12,14                          1
    rhs       I12,15                          1
    rhs       I12,17                          1
    rhs       I12,20                          1
    rhs       I12,21                          1
    rhs       I12,23                          1
    rhs       I12,24                          1
    rhs       I12,25                          1
    rhs       I12,26                          1
    rhs       I12,27                          1
    rhs       I12,28                          1
    rhs       I12,29                          1
    rhs       I12,30                          1
    rhs       I12,32                          1
    rhs       I12,33                          1
    rhs       I12,34                          1
    rhs       I12,35                          1
    rhs       I12,36                          1
    rhs       I12,37                          1
    rhs       I12,38                          1
    rhs       I12,39                          1
    rhs       I12,40                          1
    rhs       I12,41                          1
    rhs       I12,42                          1
    rhs       I12,44                          1
    rhs       I12,46                          1
    rhs       I12,47                          1
    rhs       I12,49                          1
    rhs       I13,15                          1
    rhs       I13,16                          1
    rhs       I13,18                          1
    rhs       I13,21                          1
    rhs       I13,22                          1
    rhs       I13,23                          1
    rhs       I13,24                          1
    rhs       I13,26                          1
    rhs       I13,27                          1
    rhs       I13,31                          1
    rhs       I13,32                          1
    rhs       I13,34                          1
    rhs       I13,35                          1
    rhs       I13,38                          1
    rhs       I13,39                          1
    rhs       I13,40                          1
    rhs       I13,41                          1
    rhs       I13,42                          1
    rhs       I13,43                          1
    rhs       I13,44                          1
    rhs       I13,45                          1
    rhs       I13,47                          1
    rhs       I13,49                          1
    rhs       I14,15                          1
    rhs       I14,16                          1
    rhs       I14,17                          1
    rhs       I14,18                          1
    rhs       I14,19                          1
    rhs       I14,20                          1
    rhs       I14,22                          1
    rhs       I14,23                          1
    rhs       I14,24                          1
    rhs       I14,25                          1
    rhs       I14,26                          1
    rhs       I14,27                          1
    rhs       I14,30                          1
    rhs       I14,31                          1
    rhs       I14,32                          1
    rhs       I14,33                          1
    rhs       I14,36                          1
    rhs       I14,37                          1
    rhs       I14,39                          1
    rhs       I14,40                          1
    rhs       I14,41                          1
    rhs       I14,46                          1
    rhs       I14,47                          1
    rhs       I14,48                          1
    rhs       I15,16                          1
    rhs       I15,17                          1
    rhs       I15,19                          1
    rhs       I15,20                          1
    rhs       I15,21                          1
    rhs       I15,22                          1
    rhs       I15,23                          1
    rhs       I15,24                          1
    rhs       I15,26                          1
    rhs       I15,27                          1
    rhs       I15,28                          1
    rhs       I15,29                          1
    rhs       I15,30                          1
    rhs       I15,32                          1
    rhs       I15,33                          1
    rhs       I15,34                          1
    rhs       I15,37                          1
    rhs       I15,38                          1
    rhs       I15,40                          1
    rhs       I15,41                          1
    rhs       I15,44                          1
    rhs       I15,45                          1
    rhs       I15,46                          1
    rhs       I15,48                          1
    rhs       I16,17                          1
    rhs       I16,18                          1
    rhs       I16,19                          1
    rhs       I16,22                          1
    rhs       I16,23                          1
    rhs       I16,26                          1
    rhs       I16,27                          1
    rhs       I16,28                          1
    rhs       I16,29                          1
    rhs       I16,30                          1
    rhs       I16,31                          1
    rhs       I16,37                          1
    rhs       I16,38                          1
    rhs       I16,39                          1
    rhs       I16,40                          1
    rhs       I16,41                          1
    rhs       I16,44                          1
    rhs       I16,46                          1
    rhs       I16,47                          1
    rhs       I16,48                          1
    rhs       I16,49                          1
    rhs       I17,18                          1
    rhs       I17,19                          1
    rhs       I17,20                          1
    rhs       I17,21                          1
    rhs       I17,22                          1
    rhs       I17,23                          1
    rhs       I17,27                          1
    rhs       I17,29                          1
    rhs       I17,30                          1
    rhs       I17,31                          1
    rhs       I17,32                          1
    rhs       I17,33                          1
    rhs       I17,35                          1
    rhs       I17,36                          1
    rhs       I17,39                          1
    rhs       I17,40                          1
    rhs       I17,41                          1
    rhs       I17,42                          1
    rhs       I17,43                          1
    rhs       I17,44                          1
    rhs       I17,46                          1
    rhs       I17,47                          1
    rhs       I17,49                          1
    rhs       I18,21                          1
    rhs       I18,22                          1
    rhs       I18,23                          1
    rhs       I18,24                          1
    rhs       I18,26                          1
    rhs       I18,27                          1
    rhs       I18,31                          1
    rhs       I18,32                          1
    rhs       I18,33                          1
    rhs       I18,34                          1
    rhs       I18,35                          1
    rhs       I18,36                          1
    rhs       I18,37                          1
    rhs       I18,38                          1
    rhs       I18,40                          1
    rhs       I18,42                          1
    rhs       I18,43                          1
    rhs       I18,45                          1
    rhs       I18,46                          1
    rhs       I18,47                          1
    rhs       I18,48                          1
    rhs       I18,49                          1
    rhs       I19,21                          1
    rhs       I19,23                          1
    rhs       I19,24                          1
    rhs       I19,25                          1
    rhs       I19,26                          1
    rhs       I19,28                          1
    rhs       I19,29                          1
    rhs       I19,30                          1
    rhs       I19,31                          1
    rhs       I19,32                          1
    rhs       I19,34                          1
    rhs       I19,37                          1
    rhs       I19,38                          1
    rhs       I19,39                          1
    rhs       I19,40                          1
    rhs       I19,41                          1
    rhs       I19,44                          1
    rhs       I19,45                          1
    rhs       I19,46                          1
    rhs       I19,47                          1
    rhs       I19,48                          1
    rhs       I19,49                          1
    rhs       I20,21                          1
    rhs       I20,22                          1
    rhs       I20,23                          1
    rhs       I20,24                          1
    rhs       I20,26                          1
    rhs       I20,27                          1
    rhs       I20,29                          1
    rhs       I20,30                          1
    rhs       I20,32                          1
    rhs       I20,33                          1
    rhs       I20,35                          1
    rhs       I20,37                          1
    rhs       I20,39                          1
    rhs       I20,40                          1
    rhs       I20,41                          1
    rhs       I20,43                          1
    rhs       I20,44                          1
    rhs       I20,45                          1
    rhs       I20,47                          1
    rhs       I20,48                          1
    rhs       I20,49                          1
    rhs       I21,22                          1
    rhs       I21,25                          1
    rhs       I21,26                          1
    rhs       I21,27                          1
    rhs       I21,29                          1
    rhs       I21,33                          1
    rhs       I21,34                          1
    rhs       I21,35                          1
    rhs       I21,36                          1
    rhs       I21,38                          1
    rhs       I21,39                          1
    rhs       I21,42                          1
    rhs       I21,44                          1
    rhs       I21,45                          1
    rhs       I21,47                          1
    rhs       I21,49                          1
    rhs       I22,23                          1
    rhs       I22,24                          1
    rhs       I22,25                          1
    rhs       I22,26                          1
    rhs       I22,27                          1
    rhs       I22,29                          1
    rhs       I22,30                          1
    rhs       I22,31                          1
    rhs       I22,35                          1
    rhs       I22,36                          1
    rhs       I22,38                          1
    rhs       I22,39                          1
    rhs       I22,40                          1
    rhs       I22,42                          1
    rhs       I22,43                          1
    rhs       I22,45                          1
    rhs       I22,47                          1
    rhs       I22,48                          1
    rhs       I23,25                          1
    rhs       I23,26                          1
    rhs       I23,27                          1
    rhs       I23,28                          1
    rhs       I23,29                          1
    rhs       I23,30                          1
    rhs       I23,31                          1
    rhs       I23,32                          1
    rhs       I23,33                          1
    rhs       I23,34                          1
    rhs       I23,35                          1
    rhs       I23,37                          1
    rhs       I23,39                          1
    rhs       I23,40                          1
    rhs       I23,42                          1
    rhs       I23,44                          1
    rhs       I23,46                          1
    rhs       I23,47                          1
    rhs       I23,48                          1
    rhs       I24,25                          1
    rhs       I24,26                          1
    rhs       I24,27                          1
    rhs       I24,29                          1
    rhs       I24,30                          1
    rhs       I24,32                          1
    rhs       I24,33                          1
    rhs       I24,35                          1
    rhs       I24,36                          1
    rhs       I24,38                          1
    rhs       I24,41                          1
    rhs       I24,42                          1
    rhs       I24,43                          1
    rhs       I24,44                          1
    rhs       I24,46                          1
    rhs       I24,49                          1
    rhs       I25,26                          1
    rhs       I25,27                          1
    rhs       I25,28                          1
    rhs       I25,30                          1
    rhs       I25,31                          1
    rhs       I25,33                          1
    rhs       I25,34                          1
    rhs       I25,35                          1
    rhs       I25,36                          1
    rhs       I25,40                          1
    rhs       I25,41                          1
    rhs       I25,42                          1
    rhs       I25,44                          1
    rhs       I25,46                          1
    rhs       I25,47                          1
    rhs       I25,48                          1
    rhs       I25,49                          1
    rhs       I26,27                          1
    rhs       I26,28                          1
    rhs       I26,29                          1
    rhs       I26,30                          1
    rhs       I26,31                          1
    rhs       I26,32                          1
    rhs       I26,34                          1
    rhs       I26,35                          1
    rhs       I26,37                          1
    rhs       I26,38                          1
    rhs       I26,40                          1
    rhs       I26,41                          1
    rhs       I26,42                          1
    rhs       I26,44                          1
    rhs       I26,45                          1
    rhs       I26,46                          1
    rhs       I26,48                          1
    rhs       I26,49                          1
    rhs       I27,28                          1
    rhs       I27,29                          1
    rhs       I27,30                          1
    rhs       I27,31                          1
    rhs       I27,34                          1
    rhs       I27,35                          1
    rhs       I27,36                          1
    rhs       I27,40                          1
    rhs       I27,42                          1
    rhs       I27,43                          1
    rhs       I27,44                          1
    rhs       I27,45                          1
    rhs       I27,47                          1
    rhs       I27,48                          1
    rhs       I27,49                          1
    rhs       I28,31                          1
    rhs       I28,32                          1
    rhs       I28,33                          1
    rhs       I28,34                          1
    rhs       I28,35                          1
    rhs       I28,36                          1
    rhs       I28,37                          1
    rhs       I28,38                          1
    rhs       I28,39                          1
    rhs       I28,40                          1
    rhs       I28,41                          1
    rhs       I28,42                          1
    rhs       I28,43                          1
    rhs       I28,44                          1
    rhs       I28,45                          1
    rhs       I28,46                          1
    rhs       I28,48                          1
    rhs       I28,49                          1
    rhs       I29,30                          1
    rhs       I29,31                          1
    rhs       I29,32                          1
    rhs       I29,34                          1
    rhs       I29,35                          1
    rhs       I29,36                          1
    rhs       I29,37                          1
    rhs       I29,38                          1
    rhs       I29,39                          1
    rhs       I29,40                          1
    rhs       I29,42                          1
    rhs       I29,43                          1
    rhs       I29,44                          1
    rhs       I29,45                          1
    rhs       I29,47                          1
    rhs       I29,48                          1
    rhs       I29,49                          1
    rhs       I30,32                          1
    rhs       I30,33                          1
    rhs       I30,34                          1
    rhs       I30,35                          1
    rhs       I30,36                          1
    rhs       I30,37                          1
    rhs       I30,38                          1
    rhs       I30,39                          1
    rhs       I30,40                          1
    rhs       I30,43                          1
    rhs       I30,44                          1
    rhs       I30,45                          1
    rhs       I30,46                          1
    rhs       I30,47                          1
    rhs       I30,49                          1
    rhs       I31,34                          1
    rhs       I31,35                          1
    rhs       I31,36                          1
    rhs       I31,37                          1
    rhs       I31,39                          1
    rhs       I31,40                          1
    rhs       I31,41                          1
    rhs       I31,43                          1
    rhs       I31,45                          1
    rhs       I31,46                          1
    rhs       I31,48                          1
    rhs       I31,49                          1
    rhs       I32,33                          1
    rhs       I32,34                          1
    rhs       I32,37                          1
    rhs       I32,38                          1
    rhs       I32,39                          1
    rhs       I32,40                          1
    rhs       I32,41                          1
    rhs       I32,42                          1
    rhs       I32,43                          1
    rhs       I32,46                          1
    rhs       I32,47                          1
    rhs       I32,48                          1
    rhs       I32,49                          1
    rhs       I33,34                          1
    rhs       I33,36                          1
    rhs       I33,37                          1
    rhs       I33,38                          1
    rhs       I33,39                          1
    rhs       I33,42                          1
    rhs       I33,44                          1
    rhs       I33,45                          1
    rhs       I33,46                          1
    rhs       I33,48                          1
    rhs       I33,49                          1
    rhs       I34,36                          1
    rhs       I34,38                          1
    rhs       I34,40                          1
    rhs       I34,43                          1
    rhs       I34,44                          1
    rhs       I34,45                          1
    rhs       I34,46                          1
    rhs       I34,47                          1
    rhs       I34,49                          1
    rhs       I35,36                          1
    rhs       I35,37                          1
    rhs       I35,38                          1
    rhs       I35,39                          1
    rhs       I35,40                          1
    rhs       I35,43                          1
    rhs       I35,44                          1
    rhs       I35,46                          1
    rhs       I35,47                          1
    rhs       I35,49                          1
    rhs       I36,37                          1
    rhs       I36,38                          1
    rhs       I36,40                          1
    rhs       I36,41                          1
    rhs       I36,44                          1
    rhs       I36,45                          1
    rhs       I36,46                          1
    rhs       I36,47                          1
    rhs       I36,48                          1
    rhs       I36,49                          1
    rhs       I37,39                          1
    rhs       I37,40                          1
    rhs       I37,42                          1
    rhs       I37,43                          1
    rhs       I37,44                          1
    rhs       I37,45                          1
    rhs       I37,46                          1
    rhs       I37,47                          1
    rhs       I37,48                          1
    rhs       I37,49                          1
    rhs       I38,39                          1
    rhs       I38,40                          1
    rhs       I38,42                          1
    rhs       I38,43                          1
    rhs       I38,44                          1
    rhs       I38,45                          1
    rhs       I38,46                          1
    rhs       I38,48                          1
    rhs       I38,49                          1
    rhs       I39,41                          1
    rhs       I39,42                          1
    rhs       I39,44                          1
    rhs       I39,45                          1
    rhs       I39,49                          1
    rhs       I40,43                          1
    rhs       I40,45                          1
    rhs       I40,47                          1
    rhs       I40,48                          1
    rhs       I41,42                          1
    rhs       I41,43                          1
    rhs       I41,44                          1
    rhs       I41,45                          1
    rhs       I41,46                          1
    rhs       I41,47                          1
    rhs       I41,48                          1
    rhs       I42,43                          1
    rhs       I42,45                          1
    rhs       I42,46                          1
    rhs       I42,48                          1
    rhs       I42,49                          1
    rhs       I43,45                          1
    rhs       I43,46                          1
    rhs       I43,47                          1
    rhs       I43,49                          1
    rhs       I44,45                          1
    rhs       I44,46                          1
    rhs       I44,48                          1
    rhs       I44,49                          1
    rhs       I45,47                          1
    rhs       I46,47                          1
    rhs       I46,48                          1
    rhs       I46,49                          1
    rhs       I47,48                          1
    rhs       I47,49                          1
BOUNDS
 BV bnd       w0,1    
 BV bnd       w0,2    
 BV bnd       w0,3    
 BV bnd       w0,4    
 BV bnd       w0,5    
 BV bnd       w0,6    
 BV bnd       w0,7    
 BV bnd       w0,8    
 BV bnd       w0,10   
 BV bnd       w0,12   
 BV bnd       w0,14   
 BV bnd       w0,15   
 BV bnd       w0,16   
 BV bnd       w0,17   
 BV bnd       w0,19   
 BV bnd       w0,20   
 BV bnd       w0,21   
 BV bnd       w0,22   
 BV bnd       w0,23   
 BV bnd       w0,24   
 BV bnd       w0,26   
 BV bnd       w0,27   
 BV bnd       w0,29   
 BV bnd       w0,32   
 BV bnd       w0,33   
 BV bnd       w0,34   
 BV bnd       w0,35   
 BV bnd       w0,37   
 BV bnd       w0,38   
 BV bnd       w0,39   
 BV bnd       w0,40   
 BV bnd       w0,41   
 BV bnd       w0,42   
 BV bnd       w0,43   
 BV bnd       w0,45   
 BV bnd       w0,46   
 BV bnd       w0,47   
 BV bnd       w1,3    
 BV bnd       w1,4    
 BV bnd       w1,5    
 BV bnd       w1,6    
 BV bnd       w1,7    
 BV bnd       w1,8    
 BV bnd       w1,9    
 BV bnd       w1,11   
 BV bnd       w1,12   
 BV bnd       w1,13   
 BV bnd       w1,16   
 BV bnd       w1,17   
 BV bnd       w1,18   
 BV bnd       w1,20   
 BV bnd       w1,21   
 BV bnd       w1,22   
 BV bnd       w1,23   
 BV bnd       w1,24   
 BV bnd       w1,25   
 BV bnd       w1,26   
 BV bnd       w1,27   
 BV bnd       w1,29   
 BV bnd       w1,30   
 BV bnd       w1,31   
 BV bnd       w1,33   
 BV bnd       w1,34   
 BV bnd       w1,35   
 BV bnd       w1,36   
 BV bnd       w1,37   
 BV bnd       w1,40   
 BV bnd       w1,41   
 BV bnd       w1,44   
 BV bnd       w1,48   
 BV bnd       w2,3    
 BV bnd       w2,4    
 BV bnd       w2,5    
 BV bnd       w2,7    
 BV bnd       w2,10   
 BV bnd       w2,12   
 BV bnd       w2,14   
 BV bnd       w2,16   
 BV bnd       w2,18   
 BV bnd       w2,19   
 BV bnd       w2,20   
 BV bnd       w2,21   
 BV bnd       w2,26   
 BV bnd       w2,28   
 BV bnd       w2,29   
 BV bnd       w2,31   
 BV bnd       w2,32   
 BV bnd       w2,33   
 BV bnd       w2,34   
 BV bnd       w2,35   
 BV bnd       w2,36   
 BV bnd       w2,37   
 BV bnd       w2,38   
 BV bnd       w2,39   
 BV bnd       w2,40   
 BV bnd       w2,44   
 BV bnd       w2,45   
 BV bnd       w2,46   
 BV bnd       w2,48   
 BV bnd       w2,49   
 BV bnd       w3,4    
 BV bnd       w3,6    
 BV bnd       w3,7    
 BV bnd       w3,8    
 BV bnd       w3,9    
 BV bnd       w3,10   
 BV bnd       w3,11   
 BV bnd       w3,12   
 BV bnd       w3,13   
 BV bnd       w3,14   
 BV bnd       w3,15   
 BV bnd       w3,16   
 BV bnd       w3,17   
 BV bnd       w3,18   
 BV bnd       w3,21   
 BV bnd       w3,22   
 BV bnd       w3,24   
 BV bnd       w3,25   
 BV bnd       w3,26   
 BV bnd       w3,29   
 BV bnd       w3,30   
 BV bnd       w3,31   
 BV bnd       w3,33   
 BV bnd       w3,35   
 BV bnd       w3,36   
 BV bnd       w3,37   
 BV bnd       w3,38   
 BV bnd       w3,43   
 BV bnd       w3,45   
 BV bnd       w3,47   
 BV bnd       w4,5    
 BV bnd       w4,9    
 BV bnd       w4,11   
 BV bnd       w4,12   
 BV bnd       w4,13   
 BV bnd       w4,14   
 BV bnd       w4,15   
 BV bnd       w4,16   
 BV bnd       w4,17   
 BV bnd       w4,19   
 BV bnd       w4,22   
 BV bnd       w4,23   
 BV bnd       w4,24   
 BV bnd       w4,25   
 BV bnd       w4,26   
 BV bnd       w4,27   
 BV bnd       w4,31   
 BV bnd       w4,32   
 BV bnd       w4,33   
 BV bnd       w4,34   
 BV bnd       w4,35   
 BV bnd       w4,36   
 BV bnd       w4,37   
 BV bnd       w4,38   
 BV bnd       w4,40   
 BV bnd       w4,41   
 BV bnd       w4,42   
 BV bnd       w4,44   
 BV bnd       w4,45   
 BV bnd       w4,46   
 BV bnd       w4,47   
 BV bnd       w4,48   
 BV bnd       w5,6    
 BV bnd       w5,7    
 BV bnd       w5,8    
 BV bnd       w5,9    
 BV bnd       w5,10   
 BV bnd       w5,11   
 BV bnd       w5,12   
 BV bnd       w5,13   
 BV bnd       w5,14   
 BV bnd       w5,15   
 BV bnd       w5,16   
 BV bnd       w5,17   
 BV bnd       w5,19   
 BV bnd       w5,20   
 BV bnd       w5,22   
 BV bnd       w5,23   
 BV bnd       w5,24   
 BV bnd       w5,25   
 BV bnd       w5,26   
 BV bnd       w5,27   
 BV bnd       w5,28   
 BV bnd       w5,30   
 BV bnd       w5,31   
 BV bnd       w5,33   
 BV bnd       w5,35   
 BV bnd       w5,38   
 BV bnd       w5,39   
 BV bnd       w5,40   
 BV bnd       w5,41   
 BV bnd       w5,42   
 BV bnd       w5,45   
 BV bnd       w5,47   
 BV bnd       w5,48   
 BV bnd       w5,49   
 BV bnd       w6,9    
 BV bnd       w6,10   
 BV bnd       w6,11   
 BV bnd       w6,13   
 BV bnd       w6,16   
 BV bnd       w6,17   
 BV bnd       w6,21   
 BV bnd       w6,23   
 BV bnd       w6,24   
 BV bnd       w6,26   
 BV bnd       w6,27   
 BV bnd       w6,28   
 BV bnd       w6,29   
 BV bnd       w6,30   
 BV bnd       w6,31   
 BV bnd       w6,32   
 BV bnd       w6,34   
 BV bnd       w6,35   
 BV bnd       w6,36   
 BV bnd       w6,38   
 BV bnd       w6,43   
 BV bnd       w6,46   
 BV bnd       w6,47   
 BV bnd       w6,49   
 BV bnd       w7,8    
 BV bnd       w7,9    
 BV bnd       w7,10   
 BV bnd       w7,13   
 BV bnd       w7,14   
 BV bnd       w7,15   
 BV bnd       w7,16   
 BV bnd       w7,20   
 BV bnd       w7,21   
 BV bnd       w7,25   
 BV bnd       w7,26   
 BV bnd       w7,27   
 BV bnd       w7,28   
 BV bnd       w7,29   
 BV bnd       w7,30   
 BV bnd       w7,31   
 BV bnd       w7,32   
 BV bnd       w7,33   
 BV bnd       w7,38   
 BV bnd       w7,39   
 BV bnd       w7,40   
 BV bnd       w7,46   
 BV bnd       w7,49   
 BV bnd       w8,9    
 BV bnd       w8,12   
 BV bnd       w8,13   
 BV bnd       w8,14   
 BV bnd       w8,16   
 BV bnd       w8,18   
 BV bnd       w8,19   
 BV bnd       w8,20   
 BV bnd       w8,21   
 BV bnd       w8,22   
 BV bnd       w8,25   
 BV bnd       w8,29   
 BV bnd       w8,30   
 BV bnd       w8,33   
 BV bnd       w8,34   
 BV bnd       w8,35   
 BV bnd       w8,37   
 BV bnd       w8,39   
 BV bnd       w8,40   
 BV bnd       w8,41   
 BV bnd       w8,42   
 BV bnd       w8,43   
 BV bnd       w8,44   
 BV bnd       w8,45   
 BV bnd       w8,47   
 BV bnd       w8,48   
 BV bnd       w8,49   
 BV bnd       w9,10   
 BV bnd       w9,11   
 BV bnd       w9,12   
 BV bnd       w9,13   
 BV bnd       w9,14   
 BV bnd       w9,15   
 BV bnd       w9,17   
 BV bnd       w9,19   
 BV bnd       w9,20   
 BV bnd       w9,21   
 BV bnd       w9,23   
 BV bnd       w9,24   
 BV bnd       w9,25   
 BV bnd       w9,26   
 BV bnd       w9,27   
 BV bnd       w9,28   
 BV bnd       w9,29   
 BV bnd       w9,30   
 BV bnd       w9,33   
 BV bnd       w9,34   
 BV bnd       w9,35   
 BV bnd       w9,37   
 BV bnd       w9,38   
 BV bnd       w9,39   
 BV bnd       w9,40   
 BV bnd       w9,41   
 BV bnd       w9,42   
 BV bnd       w9,45   
 BV bnd       w9,47   
 BV bnd       w9,48   
 BV bnd       w9,49   
 BV bnd       w10,11  
 BV bnd       w10,12  
 BV bnd       w10,13  
 BV bnd       w10,14  
 BV bnd       w10,15  
 BV bnd       w10,16  
 BV bnd       w10,20  
 BV bnd       w10,21  
 BV bnd       w10,23  
 BV bnd       w10,24  
 BV bnd       w10,27  
 BV bnd       w10,28  
 BV bnd       w10,29  
 BV bnd       w10,30  
 BV bnd       w10,31  
 BV bnd       w10,32  
 BV bnd       w10,33  
 BV bnd       w10,34  
 BV bnd       w10,35  
 BV bnd       w10,36  
 BV bnd       w10,37  
 BV bnd       w10,40  
 BV bnd       w10,41  
 BV bnd       w10,42  
 BV bnd       w10,43  
 BV bnd       w10,44  
 BV bnd       w10,45  
 BV bnd       w10,46  
 BV bnd       w10,48  
 BV bnd       w10,49  
 BV bnd       w11,12  
 BV bnd       w11,14  
 BV bnd       w11,15  
 BV bnd       w11,16  
 BV bnd       w11,18  
 BV bnd       w11,20  
 BV bnd       w11,21  
 BV bnd       w11,22  
 BV bnd       w11,23  
 BV bnd       w11,25  
 BV bnd       w11,27  
 BV bnd       w11,28  
 BV bnd       w11,29  
 BV bnd       w11,30  
 BV bnd       w11,31  
 BV bnd       w11,33  
 BV bnd       w11,34  
 BV bnd       w11,35  
 BV bnd       w11,36  
 BV bnd       w11,37  
 BV bnd       w11,38  
 BV bnd       w11,39  
 BV bnd       w11,40  
 BV bnd       w11,42  
 BV bnd       w11,43  
 BV bnd       w11,44  
 BV bnd       w11,46  
 BV bnd       w11,47  
 BV bnd       w11,48  
 BV bnd       w12,13  
 BV bnd       w12,14  
 BV bnd       w12,15  
 BV bnd       w12,17  
 BV bnd       w12,20  
 BV bnd       w12,21  
 BV bnd       w12,23  
 BV bnd       w12,24  
 BV bnd       w12,25  
 BV bnd       w12,26  
 BV bnd       w12,27  
 BV bnd       w12,28  
 BV bnd       w12,29  
 BV bnd       w12,30  
 BV bnd       w12,32  
 BV bnd       w12,33  
 BV bnd       w12,34  
 BV bnd       w12,35  
 BV bnd       w12,36  
 BV bnd       w12,37  
 BV bnd       w12,38  
 BV bnd       w12,39  
 BV bnd       w12,40  
 BV bnd       w12,41  
 BV bnd       w12,42  
 BV bnd       w12,44  
 BV bnd       w12,46  
 BV bnd       w12,47  
 BV bnd       w12,49  
 BV bnd       w13,15  
 BV bnd       w13,16  
 BV bnd       w13,18  
 BV bnd       w13,21  
 BV bnd       w13,22  
 BV bnd       w13,23  
 BV bnd       w13,24  
 BV bnd       w13,26  
 BV bnd       w13,27  
 BV bnd       w13,31  
 BV bnd       w13,32  
 BV bnd       w13,34  
 BV bnd       w13,35  
 BV bnd       w13,38  
 BV bnd       w13,39  
 BV bnd       w13,40  
 BV bnd       w13,41  
 BV bnd       w13,42  
 BV bnd       w13,43  
 BV bnd       w13,44  
 BV bnd       w13,45  
 BV bnd       w13,47  
 BV bnd       w13,49  
 BV bnd       w14,15  
 BV bnd       w14,16  
 BV bnd       w14,17  
 BV bnd       w14,18  
 BV bnd       w14,19  
 BV bnd       w14,20  
 BV bnd       w14,22  
 BV bnd       w14,23  
 BV bnd       w14,24  
 BV bnd       w14,25  
 BV bnd       w14,26  
 BV bnd       w14,27  
 BV bnd       w14,30  
 BV bnd       w14,31  
 BV bnd       w14,32  
 BV bnd       w14,33  
 BV bnd       w14,36  
 BV bnd       w14,37  
 BV bnd       w14,39  
 BV bnd       w14,40  
 BV bnd       w14,41  
 BV bnd       w14,46  
 BV bnd       w14,47  
 BV bnd       w14,48  
 BV bnd       w15,16  
 BV bnd       w15,17  
 BV bnd       w15,19  
 BV bnd       w15,20  
 BV bnd       w15,21  
 BV bnd       w15,22  
 BV bnd       w15,23  
 BV bnd       w15,24  
 BV bnd       w15,26  
 BV bnd       w15,27  
 BV bnd       w15,28  
 BV bnd       w15,29  
 BV bnd       w15,30  
 BV bnd       w15,32  
 BV bnd       w15,33  
 BV bnd       w15,34  
 BV bnd       w15,37  
 BV bnd       w15,38  
 BV bnd       w15,40  
 BV bnd       w15,41  
 BV bnd       w15,44  
 BV bnd       w15,45  
 BV bnd       w15,46  
 BV bnd       w15,48  
 BV bnd       w16,17  
 BV bnd       w16,18  
 BV bnd       w16,19  
 BV bnd       w16,22  
 BV bnd       w16,23  
 BV bnd       w16,26  
 BV bnd       w16,27  
 BV bnd       w16,28  
 BV bnd       w16,29  
 BV bnd       w16,30  
 BV bnd       w16,31  
 BV bnd       w16,37  
 BV bnd       w16,38  
 BV bnd       w16,39  
 BV bnd       w16,40  
 BV bnd       w16,41  
 BV bnd       w16,44  
 BV bnd       w16,46  
 BV bnd       w16,47  
 BV bnd       w16,48  
 BV bnd       w16,49  
 BV bnd       w17,18  
 BV bnd       w17,19  
 BV bnd       w17,20  
 BV bnd       w17,21  
 BV bnd       w17,22  
 BV bnd       w17,23  
 BV bnd       w17,27  
 BV bnd       w17,29  
 BV bnd       w17,30  
 BV bnd       w17,31  
 BV bnd       w17,32  
 BV bnd       w17,33  
 BV bnd       w17,35  
 BV bnd       w17,36  
 BV bnd       w17,39  
 BV bnd       w17,40  
 BV bnd       w17,41  
 BV bnd       w17,42  
 BV bnd       w17,43  
 BV bnd       w17,44  
 BV bnd       w17,46  
 BV bnd       w17,47  
 BV bnd       w17,49  
 BV bnd       w18,21  
 BV bnd       w18,22  
 BV bnd       w18,23  
 BV bnd       w18,24  
 BV bnd       w18,26  
 BV bnd       w18,27  
 BV bnd       w18,31  
 BV bnd       w18,32  
 BV bnd       w18,33  
 BV bnd       w18,34  
 BV bnd       w18,35  
 BV bnd       w18,36  
 BV bnd       w18,37  
 BV bnd       w18,38  
 BV bnd       w18,40  
 BV bnd       w18,42  
 BV bnd       w18,43  
 BV bnd       w18,45  
 BV bnd       w18,46  
 BV bnd       w18,47  
 BV bnd       w18,48  
 BV bnd       w18,49  
 BV bnd       w19,21  
 BV bnd       w19,23  
 BV bnd       w19,24  
 BV bnd       w19,25  
 BV bnd       w19,26  
 BV bnd       w19,28  
 BV bnd       w19,29  
 BV bnd       w19,30  
 BV bnd       w19,31  
 BV bnd       w19,32  
 BV bnd       w19,34  
 BV bnd       w19,37  
 BV bnd       w19,38  
 BV bnd       w19,39  
 BV bnd       w19,40  
 BV bnd       w19,41  
 BV bnd       w19,44  
 BV bnd       w19,45  
 BV bnd       w19,46  
 BV bnd       w19,47  
 BV bnd       w19,48  
 BV bnd       w19,49  
 BV bnd       w20,21  
 BV bnd       w20,22  
 BV bnd       w20,23  
 BV bnd       w20,24  
 BV bnd       w20,26  
 BV bnd       w20,27  
 BV bnd       w20,29  
 BV bnd       w20,30  
 BV bnd       w20,32  
 BV bnd       w20,33  
 BV bnd       w20,35  
 BV bnd       w20,37  
 BV bnd       w20,39  
 BV bnd       w20,40  
 BV bnd       w20,41  
 BV bnd       w20,43  
 BV bnd       w20,44  
 BV bnd       w20,45  
 BV bnd       w20,47  
 BV bnd       w20,48  
 BV bnd       w20,49  
 BV bnd       w21,22  
 BV bnd       w21,25  
 BV bnd       w21,26  
 BV bnd       w21,27  
 BV bnd       w21,29  
 BV bnd       w21,33  
 BV bnd       w21,34  
 BV bnd       w21,35  
 BV bnd       w21,36  
 BV bnd       w21,38  
 BV bnd       w21,39  
 BV bnd       w21,42  
 BV bnd       w21,44  
 BV bnd       w21,45  
 BV bnd       w21,47  
 BV bnd       w21,49  
 BV bnd       w22,23  
 BV bnd       w22,24  
 BV bnd       w22,25  
 BV bnd       w22,26  
 BV bnd       w22,27  
 BV bnd       w22,29  
 BV bnd       w22,30  
 BV bnd       w22,31  
 BV bnd       w22,35  
 BV bnd       w22,36  
 BV bnd       w22,38  
 BV bnd       w22,39  
 BV bnd       w22,40  
 BV bnd       w22,42  
 BV bnd       w22,43  
 BV bnd       w22,45  
 BV bnd       w22,47  
 BV bnd       w22,48  
 BV bnd       w23,25  
 BV bnd       w23,26  
 BV bnd       w23,27  
 BV bnd       w23,28  
 BV bnd       w23,29  
 BV bnd       w23,30  
 BV bnd       w23,31  
 BV bnd       w23,32  
 BV bnd       w23,33  
 BV bnd       w23,34  
 BV bnd       w23,35  
 BV bnd       w23,37  
 BV bnd       w23,39  
 BV bnd       w23,40  
 BV bnd       w23,42  
 BV bnd       w23,44  
 BV bnd       w23,46  
 BV bnd       w23,47  
 BV bnd       w23,48  
 BV bnd       w24,25  
 BV bnd       w24,26  
 BV bnd       w24,27  
 BV bnd       w24,29  
 BV bnd       w24,30  
 BV bnd       w24,32  
 BV bnd       w24,33  
 BV bnd       w24,35  
 BV bnd       w24,36  
 BV bnd       w24,38  
 BV bnd       w24,41  
 BV bnd       w24,42  
 BV bnd       w24,43  
 BV bnd       w24,44  
 BV bnd       w24,46  
 BV bnd       w24,49  
 BV bnd       w25,26  
 BV bnd       w25,27  
 BV bnd       w25,28  
 BV bnd       w25,30  
 BV bnd       w25,31  
 BV bnd       w25,33  
 BV bnd       w25,34  
 BV bnd       w25,35  
 BV bnd       w25,36  
 BV bnd       w25,40  
 BV bnd       w25,41  
 BV bnd       w25,42  
 BV bnd       w25,44  
 BV bnd       w25,46  
 BV bnd       w25,47  
 BV bnd       w25,48  
 BV bnd       w25,49  
 BV bnd       w26,27  
 BV bnd       w26,28  
 BV bnd       w26,29  
 BV bnd       w26,30  
 BV bnd       w26,31  
 BV bnd       w26,32  
 BV bnd       w26,34  
 BV bnd       w26,35  
 BV bnd       w26,37  
 BV bnd       w26,38  
 BV bnd       w26,40  
 BV bnd       w26,41  
 BV bnd       w26,42  
 BV bnd       w26,44  
 BV bnd       w26,45  
 BV bnd       w26,46  
 BV bnd       w26,48  
 BV bnd       w26,49  
 BV bnd       w27,28  
 BV bnd       w27,29  
 BV bnd       w27,30  
 BV bnd       w27,31  
 BV bnd       w27,34  
 BV bnd       w27,35  
 BV bnd       w27,36  
 BV bnd       w27,40  
 BV bnd       w27,42  
 BV bnd       w27,43  
 BV bnd       w27,44  
 BV bnd       w27,45  
 BV bnd       w27,47  
 BV bnd       w27,48  
 BV bnd       w27,49  
 BV bnd       w28,31  
 BV bnd       w28,32  
 BV bnd       w28,33  
 BV bnd       w28,34  
 BV bnd       w28,35  
 BV bnd       w28,36  
 BV bnd       w28,37  
 BV bnd       w28,38  
 BV bnd       w28,39  
 BV bnd       w28,40  
 BV bnd       w28,41  
 BV bnd       w28,42  
 BV bnd       w28,43  
 BV bnd       w28,44  
 BV bnd       w28,45  
 BV bnd       w28,46  
 BV bnd       w28,48  
 BV bnd       w28,49  
 BV bnd       w29,30  
 BV bnd       w29,31  
 BV bnd       w29,32  
 BV bnd       w29,34  
 BV bnd       w29,35  
 BV bnd       w29,36  
 BV bnd       w29,37  
 BV bnd       w29,38  
 BV bnd       w29,39  
 BV bnd       w29,40  
 BV bnd       w29,42  
 BV bnd       w29,43  
 BV bnd       w29,44  
 BV bnd       w29,45  
 BV bnd       w29,47  
 BV bnd       w29,48  
 BV bnd       w29,49  
 BV bnd       w30,32  
 BV bnd       w30,33  
 BV bnd       w30,34  
 BV bnd       w30,35  
 BV bnd       w30,36  
 BV bnd       w30,37  
 BV bnd       w30,38  
 BV bnd       w30,39  
 BV bnd       w30,40  
 BV bnd       w30,43  
 BV bnd       w30,44  
 BV bnd       w30,45  
 BV bnd       w30,46  
 BV bnd       w30,47  
 BV bnd       w30,49  
 BV bnd       w31,34  
 BV bnd       w31,35  
 BV bnd       w31,36  
 BV bnd       w31,37  
 BV bnd       w31,39  
 BV bnd       w31,40  
 BV bnd       w31,41  
 BV bnd       w31,43  
 BV bnd       w31,45  
 BV bnd       w31,46  
 BV bnd       w31,48  
 BV bnd       w31,49  
 BV bnd       w32,33  
 BV bnd       w32,34  
 BV bnd       w32,37  
 BV bnd       w32,38  
 BV bnd       w32,39  
 BV bnd       w32,40  
 BV bnd       w32,41  
 BV bnd       w32,42  
 BV bnd       w32,43  
 BV bnd       w32,46  
 BV bnd       w32,47  
 BV bnd       w32,48  
 BV bnd       w32,49  
 BV bnd       w33,34  
 BV bnd       w33,36  
 BV bnd       w33,37  
 BV bnd       w33,38  
 BV bnd       w33,39  
 BV bnd       w33,42  
 BV bnd       w33,44  
 BV bnd       w33,45  
 BV bnd       w33,46  
 BV bnd       w33,48  
 BV bnd       w33,49  
 BV bnd       w34,36  
 BV bnd       w34,38  
 BV bnd       w34,40  
 BV bnd       w34,43  
 BV bnd       w34,44  
 BV bnd       w34,45  
 BV bnd       w34,46  
 BV bnd       w34,47  
 BV bnd       w34,49  
 BV bnd       w35,36  
 BV bnd       w35,37  
 BV bnd       w35,38  
 BV bnd       w35,39  
 BV bnd       w35,40  
 BV bnd       w35,43  
 BV bnd       w35,44  
 BV bnd       w35,46  
 BV bnd       w35,47  
 BV bnd       w35,49  
 BV bnd       w36,37  
 BV bnd       w36,38  
 BV bnd       w36,40  
 BV bnd       w36,41  
 BV bnd       w36,44  
 BV bnd       w36,45  
 BV bnd       w36,46  
 BV bnd       w36,47  
 BV bnd       w36,48  
 BV bnd       w36,49  
 BV bnd       w37,39  
 BV bnd       w37,40  
 BV bnd       w37,42  
 BV bnd       w37,43  
 BV bnd       w37,44  
 BV bnd       w37,45  
 BV bnd       w37,46  
 BV bnd       w37,47  
 BV bnd       w37,48  
 BV bnd       w37,49  
 BV bnd       w38,39  
 BV bnd       w38,40  
 BV bnd       w38,42  
 BV bnd       w38,43  
 BV bnd       w38,44  
 BV bnd       w38,45  
 BV bnd       w38,46  
 BV bnd       w38,48  
 BV bnd       w38,49  
 BV bnd       w39,41  
 BV bnd       w39,42  
 BV bnd       w39,44  
 BV bnd       w39,45  
 BV bnd       w39,49  
 BV bnd       w40,43  
 BV bnd       w40,45  
 BV bnd       w40,47  
 BV bnd       w40,48  
 BV bnd       w41,42  
 BV bnd       w41,43  
 BV bnd       w41,44  
 BV bnd       w41,45  
 BV bnd       w41,46  
 BV bnd       w41,47  
 BV bnd       w41,48  
 BV bnd       w42,43  
 BV bnd       w42,45  
 BV bnd       w42,46  
 BV bnd       w42,48  
 BV bnd       w42,49  
 BV bnd       w43,45  
 BV bnd       w43,46  
 BV bnd       w43,47  
 BV bnd       w43,49  
 BV bnd       w44,45  
 BV bnd       w44,46  
 BV bnd       w44,48  
 BV bnd       w44,49  
 BV bnd       w45,47  
 BV bnd       w46,47  
 BV bnd       w46,48  
 BV bnd       w46,49  
 BV bnd       w47,48  
 BV bnd       w47,49  
 BV bnd       y0,1    
 BV bnd       y0,2    
 BV bnd       y0,3    
 BV bnd       y0,4    
 BV bnd       y0,5    
 BV bnd       y0,6    
 BV bnd       y0,7    
 BV bnd       y0,8    
 BV bnd       y0,10   
 BV bnd       y0,12   
 BV bnd       y0,14   
 BV bnd       y0,15   
 BV bnd       y0,16   
 BV bnd       y0,17   
 BV bnd       y0,19   
 BV bnd       y0,20   
 BV bnd       y0,21   
 BV bnd       y0,22   
 BV bnd       y0,23   
 BV bnd       y0,24   
 BV bnd       y0,26   
 BV bnd       y0,27   
 BV bnd       y0,29   
 BV bnd       y0,32   
 BV bnd       y0,33   
 BV bnd       y0,34   
 BV bnd       y0,35   
 BV bnd       y0,37   
 BV bnd       y0,38   
 BV bnd       y0,39   
 BV bnd       y0,40   
 BV bnd       y0,41   
 BV bnd       y0,42   
 BV bnd       y0,43   
 BV bnd       y0,45   
 BV bnd       y0,46   
 BV bnd       y0,47   
 BV bnd       y1,3    
 BV bnd       y1,4    
 BV bnd       y1,5    
 BV bnd       y1,6    
 BV bnd       y1,7    
 BV bnd       y1,8    
 BV bnd       y1,9    
 BV bnd       y1,11   
 BV bnd       y1,12   
 BV bnd       y1,13   
 BV bnd       y1,16   
 BV bnd       y1,17   
 BV bnd       y1,18   
 BV bnd       y1,20   
 BV bnd       y1,21   
 BV bnd       y1,22   
 BV bnd       y1,23   
 BV bnd       y1,24   
 BV bnd       y1,25   
 BV bnd       y1,26   
 BV bnd       y1,27   
 BV bnd       y1,29   
 BV bnd       y1,30   
 BV bnd       y1,31   
 BV bnd       y1,33   
 BV bnd       y1,34   
 BV bnd       y1,35   
 BV bnd       y1,36   
 BV bnd       y1,37   
 BV bnd       y1,40   
 BV bnd       y1,41   
 BV bnd       y1,44   
 BV bnd       y1,48   
 BV bnd       y2,3    
 BV bnd       y2,4    
 BV bnd       y2,5    
 BV bnd       y2,7    
 BV bnd       y2,10   
 BV bnd       y2,12   
 BV bnd       y2,14   
 BV bnd       y2,16   
 BV bnd       y2,18   
 BV bnd       y2,19   
 BV bnd       y2,20   
 BV bnd       y2,21   
 BV bnd       y2,26   
 BV bnd       y2,28   
 BV bnd       y2,29   
 BV bnd       y2,31   
 BV bnd       y2,32   
 BV bnd       y2,33   
 BV bnd       y2,34   
 BV bnd       y2,35   
 BV bnd       y2,36   
 BV bnd       y2,37   
 BV bnd       y2,38   
 BV bnd       y2,39   
 BV bnd       y2,40   
 BV bnd       y2,44   
 BV bnd       y2,45   
 BV bnd       y2,46   
 BV bnd       y2,48   
 BV bnd       y2,49   
 BV bnd       y3,4    
 BV bnd       y3,6    
 BV bnd       y3,7    
 BV bnd       y3,8    
 BV bnd       y3,9    
 BV bnd       y3,10   
 BV bnd       y3,11   
 BV bnd       y3,12   
 BV bnd       y3,13   
 BV bnd       y3,14   
 BV bnd       y3,15   
 BV bnd       y3,16   
 BV bnd       y3,17   
 BV bnd       y3,18   
 BV bnd       y3,21   
 BV bnd       y3,22   
 BV bnd       y3,24   
 BV bnd       y3,25   
 BV bnd       y3,26   
 BV bnd       y3,29   
 BV bnd       y3,30   
 BV bnd       y3,31   
 BV bnd       y3,33   
 BV bnd       y3,35   
 BV bnd       y3,36   
 BV bnd       y3,37   
 BV bnd       y3,38   
 BV bnd       y3,43   
 BV bnd       y3,45   
 BV bnd       y3,47   
 BV bnd       y4,5    
 BV bnd       y4,9    
 BV bnd       y4,11   
 BV bnd       y4,12   
 BV bnd       y4,13   
 BV bnd       y4,14   
 BV bnd       y4,15   
 BV bnd       y4,16   
 BV bnd       y4,17   
 BV bnd       y4,19   
 BV bnd       y4,22   
 BV bnd       y4,23   
 BV bnd       y4,24   
 BV bnd       y4,25   
 BV bnd       y4,26   
 BV bnd       y4,27   
 BV bnd       y4,31   
 BV bnd       y4,32   
 BV bnd       y4,33   
 BV bnd       y4,34   
 BV bnd       y4,35   
 BV bnd       y4,36   
 BV bnd       y4,37   
 BV bnd       y4,38   
 BV bnd       y4,40   
 BV bnd       y4,41   
 BV bnd       y4,42   
 BV bnd       y4,44   
 BV bnd       y4,45   
 BV bnd       y4,46   
 BV bnd       y4,47   
 BV bnd       y4,48   
 BV bnd       y5,6    
 BV bnd       y5,7    
 BV bnd       y5,8    
 BV bnd       y5,9    
 BV bnd       y5,10   
 BV bnd       y5,11   
 BV bnd       y5,12   
 BV bnd       y5,13   
 BV bnd       y5,14   
 BV bnd       y5,15   
 BV bnd       y5,16   
 BV bnd       y5,17   
 BV bnd       y5,19   
 BV bnd       y5,20   
 BV bnd       y5,22   
 BV bnd       y5,23   
 BV bnd       y5,24   
 BV bnd       y5,25   
 BV bnd       y5,26   
 BV bnd       y5,27   
 BV bnd       y5,28   
 BV bnd       y5,30   
 BV bnd       y5,31   
 BV bnd       y5,33   
 BV bnd       y5,35   
 BV bnd       y5,38   
 BV bnd       y5,39   
 BV bnd       y5,40   
 BV bnd       y5,41   
 BV bnd       y5,42   
 BV bnd       y5,45   
 BV bnd       y5,47   
 BV bnd       y5,48   
 BV bnd       y5,49   
 BV bnd       y6,9    
 BV bnd       y6,10   
 BV bnd       y6,11   
 BV bnd       y6,13   
 BV bnd       y6,16   
 BV bnd       y6,17   
 BV bnd       y6,21   
 BV bnd       y6,23   
 BV bnd       y6,24   
 BV bnd       y6,26   
 BV bnd       y6,27   
 BV bnd       y6,28   
 BV bnd       y6,29   
 BV bnd       y6,30   
 BV bnd       y6,31   
 BV bnd       y6,32   
 BV bnd       y6,34   
 BV bnd       y6,35   
 BV bnd       y6,36   
 BV bnd       y6,38   
 BV bnd       y6,43   
 BV bnd       y6,46   
 BV bnd       y6,47   
 BV bnd       y6,49   
 BV bnd       y7,8    
 BV bnd       y7,9    
 BV bnd       y7,10   
 BV bnd       y7,13   
 BV bnd       y7,14   
 BV bnd       y7,15   
 BV bnd       y7,16   
 BV bnd       y7,20   
 BV bnd       y7,21   
 BV bnd       y7,25   
 BV bnd       y7,26   
 BV bnd       y7,27   
 BV bnd       y7,28   
 BV bnd       y7,29   
 BV bnd       y7,30   
 BV bnd       y7,31   
 BV bnd       y7,32   
 BV bnd       y7,33   
 BV bnd       y7,38   
 BV bnd       y7,39   
 BV bnd       y7,40   
 BV bnd       y7,46   
 BV bnd       y7,49   
 BV bnd       y8,9    
 BV bnd       y8,12   
 BV bnd       y8,13   
 BV bnd       y8,14   
 BV bnd       y8,16   
 BV bnd       y8,18   
 BV bnd       y8,19   
 BV bnd       y8,20   
 BV bnd       y8,21   
 BV bnd       y8,22   
 BV bnd       y8,25   
 BV bnd       y8,29   
 BV bnd       y8,30   
 BV bnd       y8,33   
 BV bnd       y8,34   
 BV bnd       y8,35   
 BV bnd       y8,37   
 BV bnd       y8,39   
 BV bnd       y8,40   
 BV bnd       y8,41   
 BV bnd       y8,42   
 BV bnd       y8,43   
 BV bnd       y8,44   
 BV bnd       y8,45   
 BV bnd       y8,47   
 BV bnd       y8,48   
 BV bnd       y8,49   
 BV bnd       y9,10   
 BV bnd       y9,11   
 BV bnd       y9,12   
 BV bnd       y9,13   
 BV bnd       y9,14   
 BV bnd       y9,15   
 BV bnd       y9,17   
 BV bnd       y9,19   
 BV bnd       y9,20   
 BV bnd       y9,21   
 BV bnd       y9,23   
 BV bnd       y9,24   
 BV bnd       y9,25   
 BV bnd       y9,26   
 BV bnd       y9,27   
 BV bnd       y9,28   
 BV bnd       y9,29   
 BV bnd       y9,30   
 BV bnd       y9,33   
 BV bnd       y9,34   
 BV bnd       y9,35   
 BV bnd       y9,37   
 BV bnd       y9,38   
 BV bnd       y9,39   
 BV bnd       y9,40   
 BV bnd       y9,41   
 BV bnd       y9,42   
 BV bnd       y9,45   
 BV bnd       y9,47   
 BV bnd       y9,48   
 BV bnd       y9,49   
 BV bnd       y10,11  
 BV bnd       y10,12  
 BV bnd       y10,13  
 BV bnd       y10,14  
 BV bnd       y10,15  
 BV bnd       y10,16  
 BV bnd       y10,20  
 BV bnd       y10,21  
 BV bnd       y10,23  
 BV bnd       y10,24  
 BV bnd       y10,27  
 BV bnd       y10,28  
 BV bnd       y10,29  
 BV bnd       y10,30  
 BV bnd       y10,31  
 BV bnd       y10,32  
 BV bnd       y10,33  
 BV bnd       y10,34  
 BV bnd       y10,35  
 BV bnd       y10,36  
 BV bnd       y10,37  
 BV bnd       y10,40  
 BV bnd       y10,41  
 BV bnd       y10,42  
 BV bnd       y10,43  
 BV bnd       y10,44  
 BV bnd       y10,45  
 BV bnd       y10,46  
 BV bnd       y10,48  
 BV bnd       y10,49  
 BV bnd       y11,12  
 BV bnd       y11,14  
 BV bnd       y11,15  
 BV bnd       y11,16  
 BV bnd       y11,18  
 BV bnd       y11,20  
 BV bnd       y11,21  
 BV bnd       y11,22  
 BV bnd       y11,23  
 BV bnd       y11,25  
 BV bnd       y11,27  
 BV bnd       y11,28  
 BV bnd       y11,29  
 BV bnd       y11,30  
 BV bnd       y11,31  
 BV bnd       y11,33  
 BV bnd       y11,34  
 BV bnd       y11,35  
 BV bnd       y11,36  
 BV bnd       y11,37  
 BV bnd       y11,38  
 BV bnd       y11,39  
 BV bnd       y11,40  
 BV bnd       y11,42  
 BV bnd       y11,43  
 BV bnd       y11,44  
 BV bnd       y11,46  
 BV bnd       y11,47  
 BV bnd       y11,48  
 BV bnd       y12,13  
 BV bnd       y12,14  
 BV bnd       y12,15  
 BV bnd       y12,17  
 BV bnd       y12,20  
 BV bnd       y12,21  
 BV bnd       y12,23  
 BV bnd       y12,24  
 BV bnd       y12,25  
 BV bnd       y12,26  
 BV bnd       y12,27  
 BV bnd       y12,28  
 BV bnd       y12,29  
 BV bnd       y12,30  
 BV bnd       y12,32  
 BV bnd       y12,33  
 BV bnd       y12,34  
 BV bnd       y12,35  
 BV bnd       y12,36  
 BV bnd       y12,37  
 BV bnd       y12,38  
 BV bnd       y12,39  
 BV bnd       y12,40  
 BV bnd       y12,41  
 BV bnd       y12,42  
 BV bnd       y12,44  
 BV bnd       y12,46  
 BV bnd       y12,47  
 BV bnd       y12,49  
 BV bnd       y13,15  
 BV bnd       y13,16  
 BV bnd       y13,18  
 BV bnd       y13,21  
 BV bnd       y13,22  
 BV bnd       y13,23  
 BV bnd       y13,24  
 BV bnd       y13,26  
 BV bnd       y13,27  
 BV bnd       y13,31  
 BV bnd       y13,32  
 BV bnd       y13,34  
 BV bnd       y13,35  
 BV bnd       y13,38  
 BV bnd       y13,39  
 BV bnd       y13,40  
 BV bnd       y13,41  
 BV bnd       y13,42  
 BV bnd       y13,43  
 BV bnd       y13,44  
 BV bnd       y13,45  
 BV bnd       y13,47  
 BV bnd       y13,49  
 BV bnd       y14,15  
 BV bnd       y14,16  
 BV bnd       y14,17  
 BV bnd       y14,18  
 BV bnd       y14,19  
 BV bnd       y14,20  
 BV bnd       y14,22  
 BV bnd       y14,23  
 BV bnd       y14,24  
 BV bnd       y14,25  
 BV bnd       y14,26  
 BV bnd       y14,27  
 BV bnd       y14,30  
 BV bnd       y14,31  
 BV bnd       y14,32  
 BV bnd       y14,33  
 BV bnd       y14,36  
 BV bnd       y14,37  
 BV bnd       y14,39  
 BV bnd       y14,40  
 BV bnd       y14,41  
 BV bnd       y14,46  
 BV bnd       y14,47  
 BV bnd       y14,48  
 BV bnd       y15,16  
 BV bnd       y15,17  
 BV bnd       y15,19  
 BV bnd       y15,20  
 BV bnd       y15,21  
 BV bnd       y15,22  
 BV bnd       y15,23  
 BV bnd       y15,24  
 BV bnd       y15,26  
 BV bnd       y15,27  
 BV bnd       y15,28  
 BV bnd       y15,29  
 BV bnd       y15,30  
 BV bnd       y15,32  
 BV bnd       y15,33  
 BV bnd       y15,34  
 BV bnd       y15,37  
 BV bnd       y15,38  
 BV bnd       y15,40  
 BV bnd       y15,41  
 BV bnd       y15,44  
 BV bnd       y15,45  
 BV bnd       y15,46  
 BV bnd       y15,48  
 BV bnd       y16,17  
 BV bnd       y16,18  
 BV bnd       y16,19  
 BV bnd       y16,22  
 BV bnd       y16,23  
 BV bnd       y16,26  
 BV bnd       y16,27  
 BV bnd       y16,28  
 BV bnd       y16,29  
 BV bnd       y16,30  
 BV bnd       y16,31  
 BV bnd       y16,37  
 BV bnd       y16,38  
 BV bnd       y16,39  
 BV bnd       y16,40  
 BV bnd       y16,41  
 BV bnd       y16,44  
 BV bnd       y16,46  
 BV bnd       y16,47  
 BV bnd       y16,48  
 BV bnd       y16,49  
 BV bnd       y17,18  
 BV bnd       y17,19  
 BV bnd       y17,20  
 BV bnd       y17,21  
 BV bnd       y17,22  
 BV bnd       y17,23  
 BV bnd       y17,27  
 BV bnd       y17,29  
 BV bnd       y17,30  
 BV bnd       y17,31  
 BV bnd       y17,32  
 BV bnd       y17,33  
 BV bnd       y17,35  
 BV bnd       y17,36  
 BV bnd       y17,39  
 BV bnd       y17,40  
 BV bnd       y17,41  
 BV bnd       y17,42  
 BV bnd       y17,43  
 BV bnd       y17,44  
 BV bnd       y17,46  
 BV bnd       y17,47  
 BV bnd       y17,49  
 BV bnd       y18,21  
 BV bnd       y18,22  
 BV bnd       y18,23  
 BV bnd       y18,24  
 BV bnd       y18,26  
 BV bnd       y18,27  
 BV bnd       y18,31  
 BV bnd       y18,32  
 BV bnd       y18,33  
 BV bnd       y18,34  
 BV bnd       y18,35  
 BV bnd       y18,36  
 BV bnd       y18,37  
 BV bnd       y18,38  
 BV bnd       y18,40  
 BV bnd       y18,42  
 BV bnd       y18,43  
 BV bnd       y18,45  
 BV bnd       y18,46  
 BV bnd       y18,47  
 BV bnd       y18,48  
 BV bnd       y18,49  
 BV bnd       y19,21  
 BV bnd       y19,23  
 BV bnd       y19,24  
 BV bnd       y19,25  
 BV bnd       y19,26  
 BV bnd       y19,28  
 BV bnd       y19,29  
 BV bnd       y19,30  
 BV bnd       y19,31  
 BV bnd       y19,32  
 BV bnd       y19,34  
 BV bnd       y19,37  
 BV bnd       y19,38  
 BV bnd       y19,39  
 BV bnd       y19,40  
 BV bnd       y19,41  
 BV bnd       y19,44  
 BV bnd       y19,45  
 BV bnd       y19,46  
 BV bnd       y19,47  
 BV bnd       y19,48  
 BV bnd       y19,49  
 BV bnd       y20,21  
 BV bnd       y20,22  
 BV bnd       y20,23  
 BV bnd       y20,24  
 BV bnd       y20,26  
 BV bnd       y20,27  
 BV bnd       y20,29  
 BV bnd       y20,30  
 BV bnd       y20,32  
 BV bnd       y20,33  
 BV bnd       y20,35  
 BV bnd       y20,37  
 BV bnd       y20,39  
 BV bnd       y20,40  
 BV bnd       y20,41  
 BV bnd       y20,43  
 BV bnd       y20,44  
 BV bnd       y20,45  
 BV bnd       y20,47  
 BV bnd       y20,48  
 BV bnd       y20,49  
 BV bnd       y21,22  
 BV bnd       y21,25  
 BV bnd       y21,26  
 BV bnd       y21,27  
 BV bnd       y21,29  
 BV bnd       y21,33  
 BV bnd       y21,34  
 BV bnd       y21,35  
 BV bnd       y21,36  
 BV bnd       y21,38  
 BV bnd       y21,39  
 BV bnd       y21,42  
 BV bnd       y21,44  
 BV bnd       y21,45  
 BV bnd       y21,47  
 BV bnd       y21,49  
 BV bnd       y22,23  
 BV bnd       y22,24  
 BV bnd       y22,25  
 BV bnd       y22,26  
 BV bnd       y22,27  
 BV bnd       y22,29  
 BV bnd       y22,30  
 BV bnd       y22,31  
 BV bnd       y22,35  
 BV bnd       y22,36  
 BV bnd       y22,38  
 BV bnd       y22,39  
 BV bnd       y22,40  
 BV bnd       y22,42  
 BV bnd       y22,43  
 BV bnd       y22,45  
 BV bnd       y22,47  
 BV bnd       y22,48  
 BV bnd       y23,25  
 BV bnd       y23,26  
 BV bnd       y23,27  
 BV bnd       y23,28  
 BV bnd       y23,29  
 BV bnd       y23,30  
 BV bnd       y23,31  
 BV bnd       y23,32  
 BV bnd       y23,33  
 BV bnd       y23,34  
 BV bnd       y23,35  
 BV bnd       y23,37  
 BV bnd       y23,39  
 BV bnd       y23,40  
 BV bnd       y23,42  
 BV bnd       y23,44  
 BV bnd       y23,46  
 BV bnd       y23,47  
 BV bnd       y23,48  
 BV bnd       y24,25  
 BV bnd       y24,26  
 BV bnd       y24,27  
 BV bnd       y24,29  
 BV bnd       y24,30  
 BV bnd       y24,32  
 BV bnd       y24,33  
 BV bnd       y24,35  
 BV bnd       y24,36  
 BV bnd       y24,38  
 BV bnd       y24,41  
 BV bnd       y24,42  
 BV bnd       y24,43  
 BV bnd       y24,44  
 BV bnd       y24,46  
 BV bnd       y24,49  
 BV bnd       y25,26  
 BV bnd       y25,27  
 BV bnd       y25,28  
 BV bnd       y25,30  
 BV bnd       y25,31  
 BV bnd       y25,33  
 BV bnd       y25,34  
 BV bnd       y25,35  
 BV bnd       y25,36  
 BV bnd       y25,40  
 BV bnd       y25,41  
 BV bnd       y25,42  
 BV bnd       y25,44  
 BV bnd       y25,46  
 BV bnd       y25,47  
 BV bnd       y25,48  
 BV bnd       y25,49  
 BV bnd       y26,27  
 BV bnd       y26,28  
 BV bnd       y26,29  
 BV bnd       y26,30  
 BV bnd       y26,31  
 BV bnd       y26,32  
 BV bnd       y26,34  
 BV bnd       y26,35  
 BV bnd       y26,37  
 BV bnd       y26,38  
 BV bnd       y26,40  
 BV bnd       y26,41  
 BV bnd       y26,42  
 BV bnd       y26,44  
 BV bnd       y26,45  
 BV bnd       y26,46  
 BV bnd       y26,48  
 BV bnd       y26,49  
 BV bnd       y27,28  
 BV bnd       y27,29  
 BV bnd       y27,30  
 BV bnd       y27,31  
 BV bnd       y27,34  
 BV bnd       y27,35  
 BV bnd       y27,36  
 BV bnd       y27,40  
 BV bnd       y27,42  
 BV bnd       y27,43  
 BV bnd       y27,44  
 BV bnd       y27,45  
 BV bnd       y27,47  
 BV bnd       y27,48  
 BV bnd       y27,49  
 BV bnd       y28,31  
 BV bnd       y28,32  
 BV bnd       y28,33  
 BV bnd       y28,34  
 BV bnd       y28,35  
 BV bnd       y28,36  
 BV bnd       y28,37  
 BV bnd       y28,38  
 BV bnd       y28,39  
 BV bnd       y28,40  
 BV bnd       y28,41  
 BV bnd       y28,42  
 BV bnd       y28,43  
 BV bnd       y28,44  
 BV bnd       y28,45  
 BV bnd       y28,46  
 BV bnd       y28,48  
 BV bnd       y28,49  
 BV bnd       y29,30  
 BV bnd       y29,31  
 BV bnd       y29,32  
 BV bnd       y29,34  
 BV bnd       y29,35  
 BV bnd       y29,36  
 BV bnd       y29,37  
 BV bnd       y29,38  
 BV bnd       y29,39  
 BV bnd       y29,40  
 BV bnd       y29,42  
 BV bnd       y29,43  
 BV bnd       y29,44  
 BV bnd       y29,45  
 BV bnd       y29,47  
 BV bnd       y29,48  
 BV bnd       y29,49  
 BV bnd       y30,32  
 BV bnd       y30,33  
 BV bnd       y30,34  
 BV bnd       y30,35  
 BV bnd       y30,36  
 BV bnd       y30,37  
 BV bnd       y30,38  
 BV bnd       y30,39  
 BV bnd       y30,40  
 BV bnd       y30,43  
 BV bnd       y30,44  
 BV bnd       y30,45  
 BV bnd       y30,46  
 BV bnd       y30,47  
 BV bnd       y30,49  
 BV bnd       y31,34  
 BV bnd       y31,35  
 BV bnd       y31,36  
 BV bnd       y31,37  
 BV bnd       y31,39  
 BV bnd       y31,40  
 BV bnd       y31,41  
 BV bnd       y31,43  
 BV bnd       y31,45  
 BV bnd       y31,46  
 BV bnd       y31,48  
 BV bnd       y31,49  
 BV bnd       y32,33  
 BV bnd       y32,34  
 BV bnd       y32,37  
 BV bnd       y32,38  
 BV bnd       y32,39  
 BV bnd       y32,40  
 BV bnd       y32,41  
 BV bnd       y32,42  
 BV bnd       y32,43  
 BV bnd       y32,46  
 BV bnd       y32,47  
 BV bnd       y32,48  
 BV bnd       y32,49  
 BV bnd       y33,34  
 BV bnd       y33,36  
 BV bnd       y33,37  
 BV bnd       y33,38  
 BV bnd       y33,39  
 BV bnd       y33,42  
 BV bnd       y33,44  
 BV bnd       y33,45  
 BV bnd       y33,46  
 BV bnd       y33,48  
 BV bnd       y33,49  
 BV bnd       y34,36  
 BV bnd       y34,38  
 BV bnd       y34,40  
 BV bnd       y34,43  
 BV bnd       y34,44  
 BV bnd       y34,45  
 BV bnd       y34,46  
 BV bnd       y34,47  
 BV bnd       y34,49  
 BV bnd       y35,36  
 BV bnd       y35,37  
 BV bnd       y35,38  
 BV bnd       y35,39  
 BV bnd       y35,40  
 BV bnd       y35,43  
 BV bnd       y35,44  
 BV bnd       y35,46  
 BV bnd       y35,47  
 BV bnd       y35,49  
 BV bnd       y36,37  
 BV bnd       y36,38  
 BV bnd       y36,40  
 BV bnd       y36,41  
 BV bnd       y36,44  
 BV bnd       y36,45  
 BV bnd       y36,46  
 BV bnd       y36,47  
 BV bnd       y36,48  
 BV bnd       y36,49  
 BV bnd       y37,39  
 BV bnd       y37,40  
 BV bnd       y37,42  
 BV bnd       y37,43  
 BV bnd       y37,44  
 BV bnd       y37,45  
 BV bnd       y37,46  
 BV bnd       y37,47  
 BV bnd       y37,48  
 BV bnd       y37,49  
 BV bnd       y38,39  
 BV bnd       y38,40  
 BV bnd       y38,42  
 BV bnd       y38,43  
 BV bnd       y38,44  
 BV bnd       y38,45  
 BV bnd       y38,46  
 BV bnd       y38,48  
 BV bnd       y38,49  
 BV bnd       y39,41  
 BV bnd       y39,42  
 BV bnd       y39,44  
 BV bnd       y39,45  
 BV bnd       y39,49  
 BV bnd       y40,43  
 BV bnd       y40,45  
 BV bnd       y40,47  
 BV bnd       y40,48  
 BV bnd       y41,42  
 BV bnd       y41,43  
 BV bnd       y41,44  
 BV bnd       y41,45  
 BV bnd       y41,46  
 BV bnd       y41,47  
 BV bnd       y41,48  
 BV bnd       y42,43  
 BV bnd       y42,45  
 BV bnd       y42,46  
 BV bnd       y42,48  
 BV bnd       y42,49  
 BV bnd       y43,45  
 BV bnd       y43,46  
 BV bnd       y43,47  
 BV bnd       y43,49  
 BV bnd       y44,45  
 BV bnd       y44,46  
 BV bnd       y44,48  
 BV bnd       y44,49  
 BV bnd       y45,47  
 BV bnd       y46,47  
 BV bnd       y46,48  
 BV bnd       y46,49  
 BV bnd       y47,48  
 BV bnd       y47,49  
 BV bnd       x0      
 BV bnd       x1      
 BV bnd       x2      
 BV bnd       x3      
 BV bnd       x4      
 BV bnd       x5      
 BV bnd       x6      
 BV bnd       x7      
 BV bnd       x8      
 BV bnd       x9      
 BV bnd       x10     
 BV bnd       x11     
 BV bnd       x12     
 BV bnd       x13     
 BV bnd       x14     
 BV bnd       x15     
 BV bnd       x16     
 BV bnd       x17     
 BV bnd       x18     
 BV bnd       x19     
 BV bnd       x20     
 BV bnd       x21     
 BV bnd       x22     
 BV bnd       x23     
 BV bnd       x24     
 BV bnd       x25     
 BV bnd       x26     
 BV bnd       x27     
 BV bnd       x28     
 BV bnd       x29     
 BV bnd       x30     
 BV bnd       x31     
 BV bnd       x32     
 BV bnd       x33     
 BV bnd       x34     
 BV bnd       x35     
 BV bnd       x36     
 BV bnd       x37     
 BV bnd       x38     
 BV bnd       x39     
 BV bnd       x40     
 BV bnd       x41     
 BV bnd       x42     
 BV bnd       x43     
 BV bnd       x44     
 BV bnd       x45     
 BV bnd       x46     
 BV bnd       x47     
 BV bnd       x48     
 BV bnd       x49     
ENDATA
