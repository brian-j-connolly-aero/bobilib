* ENCODING=ISO-8859-1
NAME          normalClique60-70-1
ROWS
 N  cost    
 L  KL      
 L  C0,3    
 L  C0,5    
 L  C0,6    
 L  C0,19   
 L  C0,22   
 L  C0,24   
 L  C0,26   
 L  C0,36   
 L  C0,37   
 L  C0,38   
 L  C0,40   
 L  C0,43   
 L  C0,44   
 L  C0,47   
 L  C0,50   
 L  C0,51   
 L  C0,56   
 L  C0,58   
 L  C1,9    
 L  C1,11   
 L  C1,20   
 L  C1,21   
 L  C1,24   
 L  C1,27   
 L  C1,30   
 L  C1,33   
 L  C1,35   
 L  C1,38   
 L  C1,41   
 L  C1,43   
 L  C1,45   
 L  C1,46   
 L  C1,47   
 L  C1,50   
 L  C1,57   
 L  C2,5    
 L  C2,7    
 L  C2,8    
 L  C2,10   
 L  C2,13   
 L  C2,20   
 L  C2,26   
 L  C2,32   
 L  C2,36   
 L  C2,37   
 L  C2,43   
 L  C2,44   
 L  C2,45   
 L  C2,46   
 L  C2,47   
 L  C2,49   
 L  C2,54   
 L  C3,4    
 L  C3,7    
 L  C3,14   
 L  C3,16   
 L  C3,21   
 L  C3,23   
 L  C3,24   
 L  C3,30   
 L  C3,33   
 L  C3,36   
 L  C3,38   
 L  C3,40   
 L  C3,41   
 L  C3,44   
 L  C3,46   
 L  C3,58   
 L  C4,6    
 L  C4,9    
 L  C4,11   
 L  C4,12   
 L  C4,17   
 L  C4,18   
 L  C4,21   
 L  C4,23   
 L  C4,28   
 L  C4,29   
 L  C4,31   
 L  C4,32   
 L  C4,34   
 L  C4,35   
 L  C4,39   
 L  C4,42   
 L  C4,44   
 L  C4,45   
 L  C4,50   
 L  C4,52   
 L  C4,54   
 L  C4,59   
 L  C5,6    
 L  C5,11   
 L  C5,12   
 L  C5,16   
 L  C5,17   
 L  C5,19   
 L  C5,21   
 L  C5,33   
 L  C5,34   
 L  C5,35   
 L  C5,39   
 L  C5,41   
 L  C5,42   
 L  C5,44   
 L  C5,45   
 L  C5,55   
 L  C5,56   
 L  C5,57   
 L  C5,58   
 L  C5,59   
 L  C6,9    
 L  C6,11   
 L  C6,12   
 L  C6,13   
 L  C6,14   
 L  C6,16   
 L  C6,18   
 L  C6,20   
 L  C6,21   
 L  C6,25   
 L  C6,26   
 L  C6,28   
 L  C6,29   
 L  C6,31   
 L  C6,32   
 L  C6,33   
 L  C6,40   
 L  C6,42   
 L  C6,45   
 L  C6,47   
 L  C6,52   
 L  C6,55   
 L  C7,10   
 L  C7,11   
 L  C7,13   
 L  C7,14   
 L  C7,21   
 L  C7,22   
 L  C7,25   
 L  C7,29   
 L  C7,31   
 L  C7,37   
 L  C7,39   
 L  C7,48   
 L  C7,49   
 L  C7,55   
 L  C7,59   
 L  C8,9    
 L  C8,11   
 L  C8,17   
 L  C8,29   
 L  C8,35   
 L  C8,36   
 L  C8,38   
 L  C8,47   
 L  C8,48   
 L  C8,52   
 L  C8,59   
 L  C9,10   
 L  C9,11   
 L  C9,13   
 L  C9,14   
 L  C9,17   
 L  C9,18   
 L  C9,20   
 L  C9,24   
 L  C9,27   
 L  C9,47   
 L  C9,48   
 L  C9,51   
 L  C9,53   
 L  C9,56   
 L  C9,57   
 L  C10,12  
 L  C10,14  
 L  C10,17  
 L  C10,20  
 L  C10,22  
 L  C10,24  
 L  C10,33  
 L  C10,37  
 L  C10,43  
 L  C10,49  
 L  C10,55  
 L  C10,58  
 L  C11,13  
 L  C11,16  
 L  C11,18  
 L  C11,19  
 L  C11,20  
 L  C11,22  
 L  C11,24  
 L  C11,27  
 L  C11,28  
 L  C11,41  
 L  C11,43  
 L  C11,44  
 L  C11,50  
 L  C11,51  
 L  C11,55  
 L  C12,13  
 L  C12,18  
 L  C12,21  
 L  C12,24  
 L  C12,28  
 L  C12,41  
 L  C12,51  
 L  C12,57  
 L  C13,15  
 L  C13,18  
 L  C13,25  
 L  C13,26  
 L  C13,29  
 L  C13,30  
 L  C13,31  
 L  C13,35  
 L  C13,37  
 L  C13,44  
 L  C13,45  
 L  C13,47  
 L  C13,48  
 L  C13,49  
 L  C13,52  
 L  C13,54  
 L  C14,15  
 L  C14,16  
 L  C14,17  
 L  C14,22  
 L  C14,23  
 L  C14,24  
 L  C14,26  
 L  C14,30  
 L  C14,32  
 L  C14,34  
 L  C14,39  
 L  C14,41  
 L  C14,42  
 L  C14,55  
 L  C14,59  
 L  C15,19  
 L  C15,21  
 L  C15,22  
 L  C15,24  
 L  C15,27  
 L  C15,29  
 L  C15,30  
 L  C15,31  
 L  C15,34  
 L  C15,38  
 L  C15,40  
 L  C15,42  
 L  C15,43  
 L  C15,44  
 L  C15,48  
 L  C15,52  
 L  C15,53  
 L  C15,56  
 L  C16,22  
 L  C16,23  
 L  C16,24  
 L  C16,26  
 L  C16,27  
 L  C16,34  
 L  C16,39  
 L  C16,44  
 L  C16,45  
 L  C16,48  
 L  C16,50  
 L  C16,55  
 L  C16,56  
 L  C16,58  
 L  C17,19  
 L  C17,24  
 L  C17,27  
 L  C17,31  
 L  C17,34  
 L  C17,39  
 L  C17,40  
 L  C17,43  
 L  C17,50  
 L  C17,52  
 L  C17,56  
 L  C17,57  
 L  C18,20  
 L  C18,21  
 L  C18,24  
 L  C18,27  
 L  C18,46  
 L  C18,49  
 L  C18,58  
 L  C19,23  
 L  C19,25  
 L  C19,26  
 L  C19,27  
 L  C19,33  
 L  C19,34  
 L  C19,35  
 L  C19,38  
 L  C19,41  
 L  C19,46  
 L  C19,47  
 L  C19,48  
 L  C19,56  
 L  C19,57  
 L  C20,25  
 L  C20,31  
 L  C20,33  
 L  C20,37  
 L  C20,38  
 L  C20,40  
 L  C20,46  
 L  C20,51  
 L  C20,54  
 L  C20,58  
 L  C20,59  
 L  C21,22  
 L  C21,23  
 L  C21,28  
 L  C21,29  
 L  C21,31  
 L  C21,33  
 L  C21,40  
 L  C21,43  
 L  C21,46  
 L  C21,48  
 L  C21,51  
 L  C21,58  
 L  C21,59  
 L  C22,23  
 L  C22,24  
 L  C22,34  
 L  C22,35  
 L  C22,36  
 L  C22,40  
 L  C22,43  
 L  C22,52  
 L  C22,54  
 L  C22,55  
 L  C22,57  
 L  C23,27  
 L  C23,35  
 L  C23,44  
 L  C23,45  
 L  C23,46  
 L  C23,48  
 L  C23,53  
 L  C24,26  
 L  C24,31  
 L  C24,38  
 L  C24,40  
 L  C24,54  
 L  C24,55  
 L  C24,58  
 L  C25,27  
 L  C25,29  
 L  C25,30  
 L  C25,36  
 L  C25,41  
 L  C25,43  
 L  C25,46  
 L  C25,58  
 L  C26,27  
 L  C26,28  
 L  C26,33  
 L  C26,44  
 L  C26,47  
 L  C26,52  
 L  C26,53  
 L  C26,54  
 L  C27,29  
 L  C27,30  
 L  C27,37  
 L  C27,38  
 L  C27,45  
 L  C27,48  
 L  C27,54  
 L  C27,58  
 L  C28,31  
 L  C28,37  
 L  C28,39  
 L  C28,40  
 L  C28,41  
 L  C28,42  
 L  C28,43  
 L  C28,45  
 L  C28,46  
 L  C28,52  
 L  C28,55  
 L  C28,56  
 L  C28,59  
 L  C29,31  
 L  C29,32  
 L  C29,35  
 L  C29,36  
 L  C29,37  
 L  C29,39  
 L  C29,40  
 L  C29,41  
 L  C29,43  
 L  C29,45  
 L  C29,47  
 L  C29,48  
 L  C29,52  
 L  C30,32  
 L  C30,33  
 L  C30,34  
 L  C30,36  
 L  C30,37  
 L  C30,54  
 L  C30,55  
 L  C31,34  
 L  C31,41  
 L  C31,45  
 L  C31,50  
 L  C31,51  
 L  C31,55  
 L  C31,57  
 L  C31,59  
 L  C32,33  
 L  C32,35  
 L  C32,36  
 L  C32,42  
 L  C32,43  
 L  C32,44  
 L  C32,45  
 L  C32,49  
 L  C32,52  
 L  C32,56  
 L  C32,59  
 L  C33,35  
 L  C33,37  
 L  C33,39  
 L  C33,43  
 L  C33,45  
 L  C33,47  
 L  C33,51  
 L  C33,57  
 L  C34,37  
 L  C34,39  
 L  C34,42  
 L  C34,51  
 L  C34,53  
 L  C34,56  
 L  C35,37  
 L  C35,38  
 L  C35,42  
 L  C35,50  
 L  C35,56  
 L  C36,39  
 L  C36,43  
 L  C36,46  
 L  C36,56  
 L  C37,47  
 L  C37,54  
 L  C37,55  
 L  C37,59  
 L  C38,43  
 L  C38,46  
 L  C38,49  
 L  C38,53  
 L  C38,54  
 L  C38,57  
 L  C38,58  
 L  C39,43  
 L  C39,44  
 L  C39,48  
 L  C39,49  
 L  C39,55  
 L  C39,56  
 L  C39,57  
 L  C40,41  
 L  C40,44  
 L  C40,48  
 L  C40,51  
 L  C40,52  
 L  C40,57  
 L  C40,58  
 L  C41,44  
 L  C41,48  
 L  C41,49  
 L  C41,53  
 L  C41,57  
 L  C41,58  
 L  C41,59  
 L  C42,45  
 L  C42,51  
 L  C42,55  
 L  C42,57  
 L  C43,47  
 L  C43,49  
 L  C43,51  
 L  C43,53  
 L  C43,55  
 L  C43,57  
 L  C43,58  
 L  C44,45  
 L  C44,46  
 L  C44,49  
 L  C44,55  
 L  C44,58  
 L  C45,46  
 L  C45,48  
 L  C45,49  
 L  C45,51  
 L  C45,52  
 L  C45,53  
 L  C45,55  
 L  C45,57  
 L  C46,48  
 L  C46,52  
 L  C46,57  
 L  C47,54  
 L  C48,52  
 L  C49,51  
 L  C49,52  
 L  C49,54  
 L  C50,51  
 L  C50,53  
 L  C50,58  
 L  C51,54  
 L  C51,56  
 L  C51,57  
 L  C51,58  
 L  C52,55  
 L  C52,56  
 L  C52,57  
 L  C52,59  
 L  C53,54  
 L  C56,57  
 L  C56,59  
 L  C57,58  
 L  E0,1    
 L  E0,2    
 L  E0,4    
 L  E0,7    
 L  E0,8    
 L  E0,9    
 L  E0,10   
 L  E0,11   
 L  E0,12   
 L  E0,13   
 L  E0,14   
 L  E0,15   
 L  E0,16   
 L  E0,17   
 L  E0,18   
 L  E0,20   
 L  E0,21   
 L  E0,23   
 L  E0,25   
 L  E0,27   
 L  E0,28   
 L  E0,29   
 L  E0,30   
 L  E0,31   
 L  E0,32   
 L  E0,33   
 L  E0,34   
 L  E0,35   
 L  E0,39   
 L  E0,41   
 L  E0,42   
 L  E0,45   
 L  E0,46   
 L  E0,48   
 L  E0,49   
 L  E0,52   
 L  E0,53   
 L  E0,54   
 L  E0,55   
 L  E0,57   
 L  E0,59   
 L  E1,2    
 L  E1,3    
 L  E1,4    
 L  E1,5    
 L  E1,6    
 L  E1,7    
 L  E1,8    
 L  E1,10   
 L  E1,12   
 L  E1,13   
 L  E1,14   
 L  E1,15   
 L  E1,16   
 L  E1,17   
 L  E1,18   
 L  E1,19   
 L  E1,22   
 L  E1,23   
 L  E1,25   
 L  E1,26   
 L  E1,28   
 L  E1,29   
 L  E1,31   
 L  E1,32   
 L  E1,34   
 L  E1,36   
 L  E1,37   
 L  E1,39   
 L  E1,40   
 L  E1,42   
 L  E1,44   
 L  E1,48   
 L  E1,49   
 L  E1,51   
 L  E1,52   
 L  E1,53   
 L  E1,54   
 L  E1,55   
 L  E1,56   
 L  E1,58   
 L  E1,59   
 L  E2,3    
 L  E2,4    
 L  E2,6    
 L  E2,9    
 L  E2,11   
 L  E2,12   
 L  E2,14   
 L  E2,15   
 L  E2,16   
 L  E2,17   
 L  E2,18   
 L  E2,19   
 L  E2,21   
 L  E2,22   
 L  E2,23   
 L  E2,24   
 L  E2,25   
 L  E2,27   
 L  E2,28   
 L  E2,29   
 L  E2,30   
 L  E2,31   
 L  E2,33   
 L  E2,34   
 L  E2,35   
 L  E2,38   
 L  E2,39   
 L  E2,40   
 L  E2,41   
 L  E2,42   
 L  E2,48   
 L  E2,50   
 L  E2,51   
 L  E2,52   
 L  E2,53   
 L  E2,55   
 L  E2,56   
 L  E2,57   
 L  E2,58   
 L  E2,59   
 L  E3,5    
 L  E3,6    
 L  E3,8    
 L  E3,9    
 L  E3,10   
 L  E3,11   
 L  E3,12   
 L  E3,13   
 L  E3,15   
 L  E3,17   
 L  E3,18   
 L  E3,19   
 L  E3,20   
 L  E3,22   
 L  E3,25   
 L  E3,26   
 L  E3,27   
 L  E3,28   
 L  E3,29   
 L  E3,31   
 L  E3,32   
 L  E3,34   
 L  E3,35   
 L  E3,37   
 L  E3,39   
 L  E3,42   
 L  E3,43   
 L  E3,45   
 L  E3,47   
 L  E3,48   
 L  E3,49   
 L  E3,50   
 L  E3,51   
 L  E3,52   
 L  E3,53   
 L  E3,54   
 L  E3,55   
 L  E3,56   
 L  E3,57   
 L  E3,59   
 L  E4,5    
 L  E4,7    
 L  E4,8    
 L  E4,10   
 L  E4,13   
 L  E4,14   
 L  E4,15   
 L  E4,16   
 L  E4,19   
 L  E4,20   
 L  E4,22   
 L  E4,24   
 L  E4,25   
 L  E4,26   
 L  E4,27   
 L  E4,30   
 L  E4,33   
 L  E4,36   
 L  E4,37   
 L  E4,38   
 L  E4,40   
 L  E4,41   
 L  E4,43   
 L  E4,46   
 L  E4,47   
 L  E4,48   
 L  E4,49   
 L  E4,51   
 L  E4,53   
 L  E4,55   
 L  E4,56   
 L  E4,57   
 L  E4,58   
 L  E5,7    
 L  E5,8    
 L  E5,9    
 L  E5,10   
 L  E5,13   
 L  E5,14   
 L  E5,15   
 L  E5,18   
 L  E5,20   
 L  E5,22   
 L  E5,23   
 L  E5,24   
 L  E5,25   
 L  E5,26   
 L  E5,27   
 L  E5,28   
 L  E5,29   
 L  E5,30   
 L  E5,31   
 L  E5,32   
 L  E5,36   
 L  E5,37   
 L  E5,38   
 L  E5,40   
 L  E5,43   
 L  E5,46   
 L  E5,47   
 L  E5,48   
 L  E5,49   
 L  E5,50   
 L  E5,51   
 L  E5,52   
 L  E5,53   
 L  E5,54   
 L  E6,7    
 L  E6,8    
 L  E6,10   
 L  E6,15   
 L  E6,17   
 L  E6,19   
 L  E6,22   
 L  E6,23   
 L  E6,24   
 L  E6,27   
 L  E6,30   
 L  E6,34   
 L  E6,35   
 L  E6,36   
 L  E6,37   
 L  E6,38   
 L  E6,39   
 L  E6,41   
 L  E6,43   
 L  E6,44   
 L  E6,46   
 L  E6,48   
 L  E6,49   
 L  E6,50   
 L  E6,51   
 L  E6,53   
 L  E6,54   
 L  E6,56   
 L  E6,57   
 L  E6,58   
 L  E6,59   
 L  E7,8    
 L  E7,9    
 L  E7,12   
 L  E7,15   
 L  E7,16   
 L  E7,17   
 L  E7,18   
 L  E7,19   
 L  E7,20   
 L  E7,23   
 L  E7,24   
 L  E7,26   
 L  E7,27   
 L  E7,28   
 L  E7,30   
 L  E7,32   
 L  E7,33   
 L  E7,34   
 L  E7,35   
 L  E7,36   
 L  E7,38   
 L  E7,40   
 L  E7,41   
 L  E7,42   
 L  E7,43   
 L  E7,44   
 L  E7,45   
 L  E7,46   
 L  E7,47   
 L  E7,50   
 L  E7,51   
 L  E7,52   
 L  E7,53   
 L  E7,54   
 L  E7,56   
 L  E7,57   
 L  E7,58   
 L  E8,10   
 L  E8,12   
 L  E8,13   
 L  E8,14   
 L  E8,15   
 L  E8,16   
 L  E8,18   
 L  E8,19   
 L  E8,20   
 L  E8,21   
 L  E8,22   
 L  E8,23   
 L  E8,24   
 L  E8,25   
 L  E8,26   
 L  E8,27   
 L  E8,28   
 L  E8,30   
 L  E8,31   
 L  E8,32   
 L  E8,33   
 L  E8,34   
 L  E8,37   
 L  E8,39   
 L  E8,40   
 L  E8,41   
 L  E8,42   
 L  E8,43   
 L  E8,44   
 L  E8,45   
 L  E8,46   
 L  E8,49   
 L  E8,50   
 L  E8,51   
 L  E8,53   
 L  E8,54   
 L  E8,55   
 L  E8,56   
 L  E8,57   
 L  E8,58   
 L  E9,12   
 L  E9,15   
 L  E9,16   
 L  E9,19   
 L  E9,21   
 L  E9,22   
 L  E9,23   
 L  E9,25   
 L  E9,26   
 L  E9,28   
 L  E9,29   
 L  E9,30   
 L  E9,31   
 L  E9,32   
 L  E9,33   
 L  E9,34   
 L  E9,35   
 L  E9,36   
 L  E9,37   
 L  E9,38   
 L  E9,39   
 L  E9,40   
 L  E9,41   
 L  E9,42   
 L  E9,43   
 L  E9,44   
 L  E9,45   
 L  E9,46   
 L  E9,49   
 L  E9,50   
 L  E9,52   
 L  E9,54   
 L  E9,55   
 L  E9,58   
 L  E9,59   
 L  E10,11  
 L  E10,13  
 L  E10,15  
 L  E10,16  
 L  E10,18  
 L  E10,19  
 L  E10,21  
 L  E10,23  
 L  E10,25  
 L  E10,26  
 L  E10,27  
 L  E10,28  
 L  E10,29  
 L  E10,30  
 L  E10,31  
 L  E10,32  
 L  E10,34  
 L  E10,35  
 L  E10,36  
 L  E10,38  
 L  E10,39  
 L  E10,40  
 L  E10,41  
 L  E10,42  
 L  E10,44  
 L  E10,45  
 L  E10,46  
 L  E10,47  
 L  E10,48  
 L  E10,50  
 L  E10,51  
 L  E10,52  
 L  E10,53  
 L  E10,54  
 L  E10,56  
 L  E10,57  
 L  E10,59  
 L  E11,12  
 L  E11,14  
 L  E11,15  
 L  E11,17  
 L  E11,21  
 L  E11,23  
 L  E11,25  
 L  E11,26  
 L  E11,29  
 L  E11,30  
 L  E11,31  
 L  E11,32  
 L  E11,33  
 L  E11,34  
 L  E11,35  
 L  E11,36  
 L  E11,37  
 L  E11,38  
 L  E11,39  
 L  E11,40  
 L  E11,42  
 L  E11,45  
 L  E11,46  
 L  E11,47  
 L  E11,48  
 L  E11,49  
 L  E11,52  
 L  E11,53  
 L  E11,54  
 L  E11,56  
 L  E11,57  
 L  E11,58  
 L  E11,59  
 L  E12,14  
 L  E12,15  
 L  E12,16  
 L  E12,17  
 L  E12,19  
 L  E12,20  
 L  E12,22  
 L  E12,23  
 L  E12,25  
 L  E12,26  
 L  E12,27  
 L  E12,29  
 L  E12,30  
 L  E12,31  
 L  E12,32  
 L  E12,33  
 L  E12,34  
 L  E12,35  
 L  E12,36  
 L  E12,37  
 L  E12,38  
 L  E12,39  
 L  E12,40  
 L  E12,42  
 L  E12,43  
 L  E12,44  
 L  E12,45  
 L  E12,46  
 L  E12,47  
 L  E12,48  
 L  E12,49  
 L  E12,50  
 L  E12,52  
 L  E12,53  
 L  E12,54  
 L  E12,55  
 L  E12,56  
 L  E12,58  
 L  E12,59  
 L  E13,14  
 L  E13,16  
 L  E13,17  
 L  E13,19  
 L  E13,20  
 L  E13,21  
 L  E13,22  
 L  E13,23  
 L  E13,24  
 L  E13,27  
 L  E13,28  
 L  E13,32  
 L  E13,33  
 L  E13,34  
 L  E13,36  
 L  E13,38  
 L  E13,39  
 L  E13,40  
 L  E13,41  
 L  E13,42  
 L  E13,43  
 L  E13,46  
 L  E13,50  
 L  E13,51  
 L  E13,53  
 L  E13,55  
 L  E13,56  
 L  E13,57  
 L  E13,58  
 L  E13,59  
 L  E14,18  
 L  E14,19  
 L  E14,20  
 L  E14,21  
 L  E14,25  
 L  E14,27  
 L  E14,28  
 L  E14,29  
 L  E14,31  
 L  E14,33  
 L  E14,35  
 L  E14,36  
 L  E14,37  
 L  E14,38  
 L  E14,40  
 L  E14,43  
 L  E14,44  
 L  E14,45  
 L  E14,46  
 L  E14,47  
 L  E14,48  
 L  E14,49  
 L  E14,50  
 L  E14,51  
 L  E14,52  
 L  E14,53  
 L  E14,54  
 L  E14,56  
 L  E14,57  
 L  E14,58  
 L  E15,16  
 L  E15,17  
 L  E15,18  
 L  E15,20  
 L  E15,23  
 L  E15,25  
 L  E15,26  
 L  E15,28  
 L  E15,32  
 L  E15,33  
 L  E15,35  
 L  E15,36  
 L  E15,37  
 L  E15,39  
 L  E15,41  
 L  E15,45  
 L  E15,46  
 L  E15,47  
 L  E15,49  
 L  E15,50  
 L  E15,51  
 L  E15,54  
 L  E15,55  
 L  E15,57  
 L  E15,58  
 L  E15,59  
 L  E16,17  
 L  E16,18  
 L  E16,19  
 L  E16,20  
 L  E16,21  
 L  E16,25  
 L  E16,28  
 L  E16,29  
 L  E16,30  
 L  E16,31  
 L  E16,32  
 L  E16,33  
 L  E16,35  
 L  E16,36  
 L  E16,37  
 L  E16,38  
 L  E16,40  
 L  E16,41  
 L  E16,42  
 L  E16,43  
 L  E16,46  
 L  E16,47  
 L  E16,49  
 L  E16,51  
 L  E16,52  
 L  E16,53  
 L  E16,54  
 L  E16,57  
 L  E16,59  
 L  E17,18  
 L  E17,20  
 L  E17,21  
 L  E17,22  
 L  E17,23  
 L  E17,25  
 L  E17,26  
 L  E17,28  
 L  E17,29  
 L  E17,30  
 L  E17,32  
 L  E17,33  
 L  E17,35  
 L  E17,36  
 L  E17,37  
 L  E17,38  
 L  E17,41  
 L  E17,42  
 L  E17,44  
 L  E17,45  
 L  E17,46  
 L  E17,47  
 L  E17,48  
 L  E17,49  
 L  E17,51  
 L  E17,53  
 L  E17,54  
 L  E17,55  
 L  E17,58  
 L  E17,59  
 L  E18,19  
 L  E18,22  
 L  E18,23  
 L  E18,25  
 L  E18,26  
 L  E18,28  
 L  E18,29  
 L  E18,30  
 L  E18,31  
 L  E18,32  
 L  E18,33  
 L  E18,34  
 L  E18,35  
 L  E18,36  
 L  E18,37  
 L  E18,38  
 L  E18,39  
 L  E18,40  
 L  E18,41  
 L  E18,42  
 L  E18,43  
 L  E18,44  
 L  E18,45  
 L  E18,47  
 L  E18,48  
 L  E18,50  
 L  E18,51  
 L  E18,52  
 L  E18,53  
 L  E18,54  
 L  E18,55  
 L  E18,56  
 L  E18,57  
 L  E18,59  
 L  E19,20  
 L  E19,21  
 L  E19,22  
 L  E19,24  
 L  E19,28  
 L  E19,29  
 L  E19,30  
 L  E19,31  
 L  E19,32  
 L  E19,36  
 L  E19,37  
 L  E19,39  
 L  E19,40  
 L  E19,42  
 L  E19,43  
 L  E19,44  
 L  E19,45  
 L  E19,49  
 L  E19,50  
 L  E19,51  
 L  E19,52  
 L  E19,53  
 L  E19,54  
 L  E19,55  
 L  E19,58  
 L  E19,59  
 L  E20,21  
 L  E20,22  
 L  E20,23  
 L  E20,24  
 L  E20,26  
 L  E20,27  
 L  E20,28  
 L  E20,29  
 L  E20,30  
 L  E20,32  
 L  E20,34  
 L  E20,35  
 L  E20,36  
 L  E20,39  
 L  E20,41  
 L  E20,42  
 L  E20,43  
 L  E20,44  
 L  E20,45  
 L  E20,47  
 L  E20,48  
 L  E20,49  
 L  E20,50  
 L  E20,52  
 L  E20,53  
 L  E20,55  
 L  E20,56  
 L  E20,57  
 L  E21,24  
 L  E21,25  
 L  E21,26  
 L  E21,27  
 L  E21,30  
 L  E21,32  
 L  E21,34  
 L  E21,35  
 L  E21,36  
 L  E21,37  
 L  E21,38  
 L  E21,39  
 L  E21,41  
 L  E21,42  
 L  E21,44  
 L  E21,45  
 L  E21,47  
 L  E21,49  
 L  E21,50  
 L  E21,52  
 L  E21,53  
 L  E21,54  
 L  E21,55  
 L  E21,56  
 L  E21,57  
 L  E22,25  
 L  E22,26  
 L  E22,27  
 L  E22,28  
 L  E22,29  
 L  E22,30  
 L  E22,31  
 L  E22,32  
 L  E22,33  
 L  E22,37  
 L  E22,38  
 L  E22,39  
 L  E22,41  
 L  E22,42  
 L  E22,44  
 L  E22,45  
 L  E22,46  
 L  E22,47  
 L  E22,48  
 L  E22,49  
 L  E22,50  
 L  E22,51  
 L  E22,53  
 L  E22,56  
 L  E22,58  
 L  E22,59  
 L  E23,24  
 L  E23,25  
 L  E23,26  
 L  E23,28  
 L  E23,29  
 L  E23,30  
 L  E23,31  
 L  E23,32  
 L  E23,33  
 L  E23,34  
 L  E23,36  
 L  E23,37  
 L  E23,38  
 L  E23,39  
 L  E23,40  
 L  E23,41  
 L  E23,42  
 L  E23,43  
 L  E23,47  
 L  E23,49  
 L  E23,50  
 L  E23,51  
 L  E23,52  
 L  E23,54  
 L  E23,55  
 L  E23,56  
 L  E23,57  
 L  E23,58  
 L  E23,59  
 L  E24,25  
 L  E24,27  
 L  E24,28  
 L  E24,29  
 L  E24,30  
 L  E24,32  
 L  E24,33  
 L  E24,34  
 L  E24,35  
 L  E24,36  
 L  E24,37  
 L  E24,39  
 L  E24,41  
 L  E24,42  
 L  E24,43  
 L  E24,44  
 L  E24,45  
 L  E24,46  
 L  E24,47  
 L  E24,48  
 L  E24,49  
 L  E24,50  
 L  E24,51  
 L  E24,52  
 L  E24,53  
 L  E24,56  
 L  E24,57  
 L  E24,59  
 L  E25,26  
 L  E25,28  
 L  E25,31  
 L  E25,32  
 L  E25,33  
 L  E25,34  
 L  E25,35  
 L  E25,37  
 L  E25,38  
 L  E25,39  
 L  E25,40  
 L  E25,42  
 L  E25,44  
 L  E25,45  
 L  E25,47  
 L  E25,48  
 L  E25,49  
 L  E25,50  
 L  E25,51  
 L  E25,52  
 L  E25,53  
 L  E25,54  
 L  E25,55  
 L  E25,56  
 L  E25,57  
 L  E25,59  
 L  E26,29  
 L  E26,30  
 L  E26,31  
 L  E26,32  
 L  E26,34  
 L  E26,35  
 L  E26,36  
 L  E26,37  
 L  E26,38  
 L  E26,39  
 L  E26,40  
 L  E26,41  
 L  E26,42  
 L  E26,43  
 L  E26,45  
 L  E26,46  
 L  E26,48  
 L  E26,49  
 L  E26,50  
 L  E26,51  
 L  E26,55  
 L  E26,56  
 L  E26,57  
 L  E26,58  
 L  E26,59  
 L  E27,28  
 L  E27,31  
 L  E27,32  
 L  E27,33  
 L  E27,34  
 L  E27,35  
 L  E27,36  
 L  E27,39  
 L  E27,40  
 L  E27,41  
 L  E27,42  
 L  E27,43  
 L  E27,44  
 L  E27,46  
 L  E27,47  
 L  E27,49  
 L  E27,50  
 L  E27,51  
 L  E27,52  
 L  E27,53  
 L  E27,55  
 L  E27,56  
 L  E27,57  
 L  E27,59  
 L  E28,29  
 L  E28,30  
 L  E28,32  
 L  E28,33  
 L  E28,34  
 L  E28,35  
 L  E28,36  
 L  E28,38  
 L  E28,44  
 L  E28,47  
 L  E28,48  
 L  E28,49  
 L  E28,50  
 L  E28,51  
 L  E28,53  
 L  E28,54  
 L  E28,57  
 L  E28,58  
 L  E29,30  
 L  E29,33  
 L  E29,34  
 L  E29,38  
 L  E29,42  
 L  E29,44  
 L  E29,46  
 L  E29,49  
 L  E29,50  
 L  E29,51  
 L  E29,53  
 L  E29,54  
 L  E29,55  
 L  E29,56  
 L  E29,57  
 L  E29,58  
 L  E29,59  
 L  E30,31  
 L  E30,35  
 L  E30,38  
 L  E30,39  
 L  E30,40  
 L  E30,41  
 L  E30,42  
 L  E30,43  
 L  E30,44  
 L  E30,45  
 L  E30,46  
 L  E30,47  
 L  E30,48  
 L  E30,49  
 L  E30,50  
 L  E30,51  
 L  E30,52  
 L  E30,53  
 L  E30,56  
 L  E30,57  
 L  E30,58  
 L  E30,59  
 L  E31,32  
 L  E31,33  
 L  E31,35  
 L  E31,36  
 L  E31,37  
 L  E31,38  
 L  E31,39  
 L  E31,40  
 L  E31,42  
 L  E31,43  
 L  E31,44  
 L  E31,46  
 L  E31,47  
 L  E31,48  
 L  E31,49  
 L  E31,52  
 L  E31,53  
 L  E31,54  
 L  E31,56  
 L  E31,58  
 L  E32,34  
 L  E32,37  
 L  E32,38  
 L  E32,39  
 L  E32,40  
 L  E32,41  
 L  E32,46  
 L  E32,47  
 L  E32,48  
 L  E32,50  
 L  E32,51  
 L  E32,53  
 L  E32,54  
 L  E32,55  
 L  E32,57  
 L  E32,58  
 L  E33,34  
 L  E33,36  
 L  E33,38  
 L  E33,40  
 L  E33,41  
 L  E33,42  
 L  E33,44  
 L  E33,46  
 L  E33,48  
 L  E33,49  
 L  E33,50  
 L  E33,52  
 L  E33,53  
 L  E33,54  
 L  E33,55  
 L  E33,56  
 L  E33,58  
 L  E33,59  
 L  E34,35  
 L  E34,36  
 L  E34,38  
 L  E34,40  
 L  E34,41  
 L  E34,43  
 L  E34,44  
 L  E34,45  
 L  E34,46  
 L  E34,47  
 L  E34,48  
 L  E34,49  
 L  E34,50  
 L  E34,52  
 L  E34,54  
 L  E34,55  
 L  E34,57  
 L  E34,58  
 L  E34,59  
 L  E35,36  
 L  E35,39  
 L  E35,40  
 L  E35,41  
 L  E35,43  
 L  E35,44  
 L  E35,45  
 L  E35,46  
 L  E35,47  
 L  E35,48  
 L  E35,49  
 L  E35,51  
 L  E35,52  
 L  E35,53  
 L  E35,54  
 L  E35,55  
 L  E35,57  
 L  E35,58  
 L  E35,59  
 L  E36,37  
 L  E36,38  
 L  E36,40  
 L  E36,41  
 L  E36,42  
 L  E36,44  
 L  E36,45  
 L  E36,47  
 L  E36,48  
 L  E36,49  
 L  E36,50  
 L  E36,51  
 L  E36,52  
 L  E36,53  
 L  E36,54  
 L  E36,55  
 L  E36,57  
 L  E36,58  
 L  E36,59  
 L  E37,38  
 L  E37,39  
 L  E37,40  
 L  E37,41  
 L  E37,42  
 L  E37,43  
 L  E37,44  
 L  E37,45  
 L  E37,46  
 L  E37,48  
 L  E37,49  
 L  E37,50  
 L  E37,51  
 L  E37,52  
 L  E37,53  
 L  E37,56  
 L  E37,57  
 L  E37,58  
 L  E38,39  
 L  E38,40  
 L  E38,41  
 L  E38,42  
 L  E38,44  
 L  E38,45  
 L  E38,47  
 L  E38,48  
 L  E38,50  
 L  E38,51  
 L  E38,52  
 L  E38,55  
 L  E38,56  
 L  E38,59  
 L  E39,40  
 L  E39,41  
 L  E39,42  
 L  E39,45  
 L  E39,46  
 L  E39,47  
 L  E39,50  
 L  E39,51  
 L  E39,52  
 L  E39,53  
 L  E39,54  
 L  E39,58  
 L  E39,59  
 L  E40,42  
 L  E40,43  
 L  E40,45  
 L  E40,46  
 L  E40,47  
 L  E40,49  
 L  E40,50  
 L  E40,53  
 L  E40,54  
 L  E40,55  
 L  E40,56  
 L  E40,59  
 L  E41,42  
 L  E41,43  
 L  E41,45  
 L  E41,46  
 L  E41,47  
 L  E41,50  
 L  E41,51  
 L  E41,52  
 L  E41,54  
 L  E41,55  
 L  E41,56  
 L  E42,43  
 L  E42,44  
 L  E42,46  
 L  E42,47  
 L  E42,48  
 L  E42,49  
 L  E42,50  
 L  E42,52  
 L  E42,53  
 L  E42,54  
 L  E42,56  
 L  E42,58  
 L  E42,59  
 L  E43,44  
 L  E43,45  
 L  E43,46  
 L  E43,48  
 L  E43,50  
 L  E43,52  
 L  E43,54  
 L  E43,56  
 L  E43,59  
 L  E44,47  
 L  E44,48  
 L  E44,50  
 L  E44,51  
 L  E44,52  
 L  E44,53  
 L  E44,54  
 L  E44,56  
 L  E44,57  
 L  E44,59  
 L  E45,47  
 L  E45,50  
 L  E45,54  
 L  E45,56  
 L  E45,58  
 L  E45,59  
 L  E46,47  
 L  E46,49  
 L  E46,50  
 L  E46,51  
 L  E46,53  
 L  E46,54  
 L  E46,55  
 L  E46,56  
 L  E46,58  
 L  E46,59  
 L  E47,48  
 L  E47,49  
 L  E47,50  
 L  E47,51  
 L  E47,52  
 L  E47,53  
 L  E47,55  
 L  E47,56  
 L  E47,57  
 L  E47,58  
 L  E47,59  
 L  E48,49  
 L  E48,50  
 L  E48,51  
 L  E48,53  
 L  E48,54  
 L  E48,55  
 L  E48,56  
 L  E48,57  
 L  E48,58  
 L  E48,59  
 L  E49,50  
 L  E49,53  
 L  E49,55  
 L  E49,56  
 L  E49,57  
 L  E49,58  
 L  E49,59  
 L  E50,52  
 L  E50,54  
 L  E50,55  
 L  E50,56  
 L  E50,57  
 L  E50,59  
 L  E51,52  
 L  E51,53  
 L  E51,55  
 L  E51,59  
 L  E52,53  
 L  E52,54  
 L  E52,58  
 L  E53,55  
 L  E53,56  
 L  E53,57  
 L  E53,58  
 L  E53,59  
 L  E54,55  
 L  E54,56  
 L  E54,57  
 L  E54,58  
 L  E54,59  
 L  E55,56  
 L  E55,57  
 L  E55,58  
 L  E55,59  
 L  E56,58  
 L  E57,59  
 L  E58,59  
 L  I0,1    
 L  I0,2    
 L  I0,4    
 L  I0,7    
 L  I0,8    
 L  I0,9    
 L  I0,10   
 L  I0,11   
 L  I0,12   
 L  I0,13   
 L  I0,14   
 L  I0,15   
 L  I0,16   
 L  I0,17   
 L  I0,18   
 L  I0,20   
 L  I0,21   
 L  I0,23   
 L  I0,25   
 L  I0,27   
 L  I0,28   
 L  I0,29   
 L  I0,30   
 L  I0,31   
 L  I0,32   
 L  I0,33   
 L  I0,34   
 L  I0,35   
 L  I0,39   
 L  I0,41   
 L  I0,42   
 L  I0,45   
 L  I0,46   
 L  I0,48   
 L  I0,49   
 L  I0,52   
 L  I0,53   
 L  I0,54   
 L  I0,55   
 L  I0,57   
 L  I0,59   
 L  I1,2    
 L  I1,3    
 L  I1,4    
 L  I1,5    
 L  I1,6    
 L  I1,7    
 L  I1,8    
 L  I1,10   
 L  I1,12   
 L  I1,13   
 L  I1,14   
 L  I1,15   
 L  I1,16   
 L  I1,17   
 L  I1,18   
 L  I1,19   
 L  I1,22   
 L  I1,23   
 L  I1,25   
 L  I1,26   
 L  I1,28   
 L  I1,29   
 L  I1,31   
 L  I1,32   
 L  I1,34   
 L  I1,36   
 L  I1,37   
 L  I1,39   
 L  I1,40   
 L  I1,42   
 L  I1,44   
 L  I1,48   
 L  I1,49   
 L  I1,51   
 L  I1,52   
 L  I1,53   
 L  I1,54   
 L  I1,55   
 L  I1,56   
 L  I1,58   
 L  I1,59   
 L  I2,3    
 L  I2,4    
 L  I2,6    
 L  I2,9    
 L  I2,11   
 L  I2,12   
 L  I2,14   
 L  I2,15   
 L  I2,16   
 L  I2,17   
 L  I2,18   
 L  I2,19   
 L  I2,21   
 L  I2,22   
 L  I2,23   
 L  I2,24   
 L  I2,25   
 L  I2,27   
 L  I2,28   
 L  I2,29   
 L  I2,30   
 L  I2,31   
 L  I2,33   
 L  I2,34   
 L  I2,35   
 L  I2,38   
 L  I2,39   
 L  I2,40   
 L  I2,41   
 L  I2,42   
 L  I2,48   
 L  I2,50   
 L  I2,51   
 L  I2,52   
 L  I2,53   
 L  I2,55   
 L  I2,56   
 L  I2,57   
 L  I2,58   
 L  I2,59   
 L  I3,5    
 L  I3,6    
 L  I3,8    
 L  I3,9    
 L  I3,10   
 L  I3,11   
 L  I3,12   
 L  I3,13   
 L  I3,15   
 L  I3,17   
 L  I3,18   
 L  I3,19   
 L  I3,20   
 L  I3,22   
 L  I3,25   
 L  I3,26   
 L  I3,27   
 L  I3,28   
 L  I3,29   
 L  I3,31   
 L  I3,32   
 L  I3,34   
 L  I3,35   
 L  I3,37   
 L  I3,39   
 L  I3,42   
 L  I3,43   
 L  I3,45   
 L  I3,47   
 L  I3,48   
 L  I3,49   
 L  I3,50   
 L  I3,51   
 L  I3,52   
 L  I3,53   
 L  I3,54   
 L  I3,55   
 L  I3,56   
 L  I3,57   
 L  I3,59   
 L  I4,5    
 L  I4,7    
 L  I4,8    
 L  I4,10   
 L  I4,13   
 L  I4,14   
 L  I4,15   
 L  I4,16   
 L  I4,19   
 L  I4,20   
 L  I4,22   
 L  I4,24   
 L  I4,25   
 L  I4,26   
 L  I4,27   
 L  I4,30   
 L  I4,33   
 L  I4,36   
 L  I4,37   
 L  I4,38   
 L  I4,40   
 L  I4,41   
 L  I4,43   
 L  I4,46   
 L  I4,47   
 L  I4,48   
 L  I4,49   
 L  I4,51   
 L  I4,53   
 L  I4,55   
 L  I4,56   
 L  I4,57   
 L  I4,58   
 L  I5,7    
 L  I5,8    
 L  I5,9    
 L  I5,10   
 L  I5,13   
 L  I5,14   
 L  I5,15   
 L  I5,18   
 L  I5,20   
 L  I5,22   
 L  I5,23   
 L  I5,24   
 L  I5,25   
 L  I5,26   
 L  I5,27   
 L  I5,28   
 L  I5,29   
 L  I5,30   
 L  I5,31   
 L  I5,32   
 L  I5,36   
 L  I5,37   
 L  I5,38   
 L  I5,40   
 L  I5,43   
 L  I5,46   
 L  I5,47   
 L  I5,48   
 L  I5,49   
 L  I5,50   
 L  I5,51   
 L  I5,52   
 L  I5,53   
 L  I5,54   
 L  I6,7    
 L  I6,8    
 L  I6,10   
 L  I6,15   
 L  I6,17   
 L  I6,19   
 L  I6,22   
 L  I6,23   
 L  I6,24   
 L  I6,27   
 L  I6,30   
 L  I6,34   
 L  I6,35   
 L  I6,36   
 L  I6,37   
 L  I6,38   
 L  I6,39   
 L  I6,41   
 L  I6,43   
 L  I6,44   
 L  I6,46   
 L  I6,48   
 L  I6,49   
 L  I6,50   
 L  I6,51   
 L  I6,53   
 L  I6,54   
 L  I6,56   
 L  I6,57   
 L  I6,58   
 L  I6,59   
 L  I7,8    
 L  I7,9    
 L  I7,12   
 L  I7,15   
 L  I7,16   
 L  I7,17   
 L  I7,18   
 L  I7,19   
 L  I7,20   
 L  I7,23   
 L  I7,24   
 L  I7,26   
 L  I7,27   
 L  I7,28   
 L  I7,30   
 L  I7,32   
 L  I7,33   
 L  I7,34   
 L  I7,35   
 L  I7,36   
 L  I7,38   
 L  I7,40   
 L  I7,41   
 L  I7,42   
 L  I7,43   
 L  I7,44   
 L  I7,45   
 L  I7,46   
 L  I7,47   
 L  I7,50   
 L  I7,51   
 L  I7,52   
 L  I7,53   
 L  I7,54   
 L  I7,56   
 L  I7,57   
 L  I7,58   
 L  I8,10   
 L  I8,12   
 L  I8,13   
 L  I8,14   
 L  I8,15   
 L  I8,16   
 L  I8,18   
 L  I8,19   
 L  I8,20   
 L  I8,21   
 L  I8,22   
 L  I8,23   
 L  I8,24   
 L  I8,25   
 L  I8,26   
 L  I8,27   
 L  I8,28   
 L  I8,30   
 L  I8,31   
 L  I8,32   
 L  I8,33   
 L  I8,34   
 L  I8,37   
 L  I8,39   
 L  I8,40   
 L  I8,41   
 L  I8,42   
 L  I8,43   
 L  I8,44   
 L  I8,45   
 L  I8,46   
 L  I8,49   
 L  I8,50   
 L  I8,51   
 L  I8,53   
 L  I8,54   
 L  I8,55   
 L  I8,56   
 L  I8,57   
 L  I8,58   
 L  I9,12   
 L  I9,15   
 L  I9,16   
 L  I9,19   
 L  I9,21   
 L  I9,22   
 L  I9,23   
 L  I9,25   
 L  I9,26   
 L  I9,28   
 L  I9,29   
 L  I9,30   
 L  I9,31   
 L  I9,32   
 L  I9,33   
 L  I9,34   
 L  I9,35   
 L  I9,36   
 L  I9,37   
 L  I9,38   
 L  I9,39   
 L  I9,40   
 L  I9,41   
 L  I9,42   
 L  I9,43   
 L  I9,44   
 L  I9,45   
 L  I9,46   
 L  I9,49   
 L  I9,50   
 L  I9,52   
 L  I9,54   
 L  I9,55   
 L  I9,58   
 L  I9,59   
 L  I10,11  
 L  I10,13  
 L  I10,15  
 L  I10,16  
 L  I10,18  
 L  I10,19  
 L  I10,21  
 L  I10,23  
 L  I10,25  
 L  I10,26  
 L  I10,27  
 L  I10,28  
 L  I10,29  
 L  I10,30  
 L  I10,31  
 L  I10,32  
 L  I10,34  
 L  I10,35  
 L  I10,36  
 L  I10,38  
 L  I10,39  
 L  I10,40  
 L  I10,41  
 L  I10,42  
 L  I10,44  
 L  I10,45  
 L  I10,46  
 L  I10,47  
 L  I10,48  
 L  I10,50  
 L  I10,51  
 L  I10,52  
 L  I10,53  
 L  I10,54  
 L  I10,56  
 L  I10,57  
 L  I10,59  
 L  I11,12  
 L  I11,14  
 L  I11,15  
 L  I11,17  
 L  I11,21  
 L  I11,23  
 L  I11,25  
 L  I11,26  
 L  I11,29  
 L  I11,30  
 L  I11,31  
 L  I11,32  
 L  I11,33  
 L  I11,34  
 L  I11,35  
 L  I11,36  
 L  I11,37  
 L  I11,38  
 L  I11,39  
 L  I11,40  
 L  I11,42  
 L  I11,45  
 L  I11,46  
 L  I11,47  
 L  I11,48  
 L  I11,49  
 L  I11,52  
 L  I11,53  
 L  I11,54  
 L  I11,56  
 L  I11,57  
 L  I11,58  
 L  I11,59  
 L  I12,14  
 L  I12,15  
 L  I12,16  
 L  I12,17  
 L  I12,19  
 L  I12,20  
 L  I12,22  
 L  I12,23  
 L  I12,25  
 L  I12,26  
 L  I12,27  
 L  I12,29  
 L  I12,30  
 L  I12,31  
 L  I12,32  
 L  I12,33  
 L  I12,34  
 L  I12,35  
 L  I12,36  
 L  I12,37  
 L  I12,38  
 L  I12,39  
 L  I12,40  
 L  I12,42  
 L  I12,43  
 L  I12,44  
 L  I12,45  
 L  I12,46  
 L  I12,47  
 L  I12,48  
 L  I12,49  
 L  I12,50  
 L  I12,52  
 L  I12,53  
 L  I12,54  
 L  I12,55  
 L  I12,56  
 L  I12,58  
 L  I12,59  
 L  I13,14  
 L  I13,16  
 L  I13,17  
 L  I13,19  
 L  I13,20  
 L  I13,21  
 L  I13,22  
 L  I13,23  
 L  I13,24  
 L  I13,27  
 L  I13,28  
 L  I13,32  
 L  I13,33  
 L  I13,34  
 L  I13,36  
 L  I13,38  
 L  I13,39  
 L  I13,40  
 L  I13,41  
 L  I13,42  
 L  I13,43  
 L  I13,46  
 L  I13,50  
 L  I13,51  
 L  I13,53  
 L  I13,55  
 L  I13,56  
 L  I13,57  
 L  I13,58  
 L  I13,59  
 L  I14,18  
 L  I14,19  
 L  I14,20  
 L  I14,21  
 L  I14,25  
 L  I14,27  
 L  I14,28  
 L  I14,29  
 L  I14,31  
 L  I14,33  
 L  I14,35  
 L  I14,36  
 L  I14,37  
 L  I14,38  
 L  I14,40  
 L  I14,43  
 L  I14,44  
 L  I14,45  
 L  I14,46  
 L  I14,47  
 L  I14,48  
 L  I14,49  
 L  I14,50  
 L  I14,51  
 L  I14,52  
 L  I14,53  
 L  I14,54  
 L  I14,56  
 L  I14,57  
 L  I14,58  
 L  I15,16  
 L  I15,17  
 L  I15,18  
 L  I15,20  
 L  I15,23  
 L  I15,25  
 L  I15,26  
 L  I15,28  
 L  I15,32  
 L  I15,33  
 L  I15,35  
 L  I15,36  
 L  I15,37  
 L  I15,39  
 L  I15,41  
 L  I15,45  
 L  I15,46  
 L  I15,47  
 L  I15,49  
 L  I15,50  
 L  I15,51  
 L  I15,54  
 L  I15,55  
 L  I15,57  
 L  I15,58  
 L  I15,59  
 L  I16,17  
 L  I16,18  
 L  I16,19  
 L  I16,20  
 L  I16,21  
 L  I16,25  
 L  I16,28  
 L  I16,29  
 L  I16,30  
 L  I16,31  
 L  I16,32  
 L  I16,33  
 L  I16,35  
 L  I16,36  
 L  I16,37  
 L  I16,38  
 L  I16,40  
 L  I16,41  
 L  I16,42  
 L  I16,43  
 L  I16,46  
 L  I16,47  
 L  I16,49  
 L  I16,51  
 L  I16,52  
 L  I16,53  
 L  I16,54  
 L  I16,57  
 L  I16,59  
 L  I17,18  
 L  I17,20  
 L  I17,21  
 L  I17,22  
 L  I17,23  
 L  I17,25  
 L  I17,26  
 L  I17,28  
 L  I17,29  
 L  I17,30  
 L  I17,32  
 L  I17,33  
 L  I17,35  
 L  I17,36  
 L  I17,37  
 L  I17,38  
 L  I17,41  
 L  I17,42  
 L  I17,44  
 L  I17,45  
 L  I17,46  
 L  I17,47  
 L  I17,48  
 L  I17,49  
 L  I17,51  
 L  I17,53  
 L  I17,54  
 L  I17,55  
 L  I17,58  
 L  I17,59  
 L  I18,19  
 L  I18,22  
 L  I18,23  
 L  I18,25  
 L  I18,26  
 L  I18,28  
 L  I18,29  
 L  I18,30  
 L  I18,31  
 L  I18,32  
 L  I18,33  
 L  I18,34  
 L  I18,35  
 L  I18,36  
 L  I18,37  
 L  I18,38  
 L  I18,39  
 L  I18,40  
 L  I18,41  
 L  I18,42  
 L  I18,43  
 L  I18,44  
 L  I18,45  
 L  I18,47  
 L  I18,48  
 L  I18,50  
 L  I18,51  
 L  I18,52  
 L  I18,53  
 L  I18,54  
 L  I18,55  
 L  I18,56  
 L  I18,57  
 L  I18,59  
 L  I19,20  
 L  I19,21  
 L  I19,22  
 L  I19,24  
 L  I19,28  
 L  I19,29  
 L  I19,30  
 L  I19,31  
 L  I19,32  
 L  I19,36  
 L  I19,37  
 L  I19,39  
 L  I19,40  
 L  I19,42  
 L  I19,43  
 L  I19,44  
 L  I19,45  
 L  I19,49  
 L  I19,50  
 L  I19,51  
 L  I19,52  
 L  I19,53  
 L  I19,54  
 L  I19,55  
 L  I19,58  
 L  I19,59  
 L  I20,21  
 L  I20,22  
 L  I20,23  
 L  I20,24  
 L  I20,26  
 L  I20,27  
 L  I20,28  
 L  I20,29  
 L  I20,30  
 L  I20,32  
 L  I20,34  
 L  I20,35  
 L  I20,36  
 L  I20,39  
 L  I20,41  
 L  I20,42  
 L  I20,43  
 L  I20,44  
 L  I20,45  
 L  I20,47  
 L  I20,48  
 L  I20,49  
 L  I20,50  
 L  I20,52  
 L  I20,53  
 L  I20,55  
 L  I20,56  
 L  I20,57  
 L  I21,24  
 L  I21,25  
 L  I21,26  
 L  I21,27  
 L  I21,30  
 L  I21,32  
 L  I21,34  
 L  I21,35  
 L  I21,36  
 L  I21,37  
 L  I21,38  
 L  I21,39  
 L  I21,41  
 L  I21,42  
 L  I21,44  
 L  I21,45  
 L  I21,47  
 L  I21,49  
 L  I21,50  
 L  I21,52  
 L  I21,53  
 L  I21,54  
 L  I21,55  
 L  I21,56  
 L  I21,57  
 L  I22,25  
 L  I22,26  
 L  I22,27  
 L  I22,28  
 L  I22,29  
 L  I22,30  
 L  I22,31  
 L  I22,32  
 L  I22,33  
 L  I22,37  
 L  I22,38  
 L  I22,39  
 L  I22,41  
 L  I22,42  
 L  I22,44  
 L  I22,45  
 L  I22,46  
 L  I22,47  
 L  I22,48  
 L  I22,49  
 L  I22,50  
 L  I22,51  
 L  I22,53  
 L  I22,56  
 L  I22,58  
 L  I22,59  
 L  I23,24  
 L  I23,25  
 L  I23,26  
 L  I23,28  
 L  I23,29  
 L  I23,30  
 L  I23,31  
 L  I23,32  
 L  I23,33  
 L  I23,34  
 L  I23,36  
 L  I23,37  
 L  I23,38  
 L  I23,39  
 L  I23,40  
 L  I23,41  
 L  I23,42  
 L  I23,43  
 L  I23,47  
 L  I23,49  
 L  I23,50  
 L  I23,51  
 L  I23,52  
 L  I23,54  
 L  I23,55  
 L  I23,56  
 L  I23,57  
 L  I23,58  
 L  I23,59  
 L  I24,25  
 L  I24,27  
 L  I24,28  
 L  I24,29  
 L  I24,30  
 L  I24,32  
 L  I24,33  
 L  I24,34  
 L  I24,35  
 L  I24,36  
 L  I24,37  
 L  I24,39  
 L  I24,41  
 L  I24,42  
 L  I24,43  
 L  I24,44  
 L  I24,45  
 L  I24,46  
 L  I24,47  
 L  I24,48  
 L  I24,49  
 L  I24,50  
 L  I24,51  
 L  I24,52  
 L  I24,53  
 L  I24,56  
 L  I24,57  
 L  I24,59  
 L  I25,26  
 L  I25,28  
 L  I25,31  
 L  I25,32  
 L  I25,33  
 L  I25,34  
 L  I25,35  
 L  I25,37  
 L  I25,38  
 L  I25,39  
 L  I25,40  
 L  I25,42  
 L  I25,44  
 L  I25,45  
 L  I25,47  
 L  I25,48  
 L  I25,49  
 L  I25,50  
 L  I25,51  
 L  I25,52  
 L  I25,53  
 L  I25,54  
 L  I25,55  
 L  I25,56  
 L  I25,57  
 L  I25,59  
 L  I26,29  
 L  I26,30  
 L  I26,31  
 L  I26,32  
 L  I26,34  
 L  I26,35  
 L  I26,36  
 L  I26,37  
 L  I26,38  
 L  I26,39  
 L  I26,40  
 L  I26,41  
 L  I26,42  
 L  I26,43  
 L  I26,45  
 L  I26,46  
 L  I26,48  
 L  I26,49  
 L  I26,50  
 L  I26,51  
 L  I26,55  
 L  I26,56  
 L  I26,57  
 L  I26,58  
 L  I26,59  
 L  I27,28  
 L  I27,31  
 L  I27,32  
 L  I27,33  
 L  I27,34  
 L  I27,35  
 L  I27,36  
 L  I27,39  
 L  I27,40  
 L  I27,41  
 L  I27,42  
 L  I27,43  
 L  I27,44  
 L  I27,46  
 L  I27,47  
 L  I27,49  
 L  I27,50  
 L  I27,51  
 L  I27,52  
 L  I27,53  
 L  I27,55  
 L  I27,56  
 L  I27,57  
 L  I27,59  
 L  I28,29  
 L  I28,30  
 L  I28,32  
 L  I28,33  
 L  I28,34  
 L  I28,35  
 L  I28,36  
 L  I28,38  
 L  I28,44  
 L  I28,47  
 L  I28,48  
 L  I28,49  
 L  I28,50  
 L  I28,51  
 L  I28,53  
 L  I28,54  
 L  I28,57  
 L  I28,58  
 L  I29,30  
 L  I29,33  
 L  I29,34  
 L  I29,38  
 L  I29,42  
 L  I29,44  
 L  I29,46  
 L  I29,49  
 L  I29,50  
 L  I29,51  
 L  I29,53  
 L  I29,54  
 L  I29,55  
 L  I29,56  
 L  I29,57  
 L  I29,58  
 L  I29,59  
 L  I30,31  
 L  I30,35  
 L  I30,38  
 L  I30,39  
 L  I30,40  
 L  I30,41  
 L  I30,42  
 L  I30,43  
 L  I30,44  
 L  I30,45  
 L  I30,46  
 L  I30,47  
 L  I30,48  
 L  I30,49  
 L  I30,50  
 L  I30,51  
 L  I30,52  
 L  I30,53  
 L  I30,56  
 L  I30,57  
 L  I30,58  
 L  I30,59  
 L  I31,32  
 L  I31,33  
 L  I31,35  
 L  I31,36  
 L  I31,37  
 L  I31,38  
 L  I31,39  
 L  I31,40  
 L  I31,42  
 L  I31,43  
 L  I31,44  
 L  I31,46  
 L  I31,47  
 L  I31,48  
 L  I31,49  
 L  I31,52  
 L  I31,53  
 L  I31,54  
 L  I31,56  
 L  I31,58  
 L  I32,34  
 L  I32,37  
 L  I32,38  
 L  I32,39  
 L  I32,40  
 L  I32,41  
 L  I32,46  
 L  I32,47  
 L  I32,48  
 L  I32,50  
 L  I32,51  
 L  I32,53  
 L  I32,54  
 L  I32,55  
 L  I32,57  
 L  I32,58  
 L  I33,34  
 L  I33,36  
 L  I33,38  
 L  I33,40  
 L  I33,41  
 L  I33,42  
 L  I33,44  
 L  I33,46  
 L  I33,48  
 L  I33,49  
 L  I33,50  
 L  I33,52  
 L  I33,53  
 L  I33,54  
 L  I33,55  
 L  I33,56  
 L  I33,58  
 L  I33,59  
 L  I34,35  
 L  I34,36  
 L  I34,38  
 L  I34,40  
 L  I34,41  
 L  I34,43  
 L  I34,44  
 L  I34,45  
 L  I34,46  
 L  I34,47  
 L  I34,48  
 L  I34,49  
 L  I34,50  
 L  I34,52  
 L  I34,54  
 L  I34,55  
 L  I34,57  
 L  I34,58  
 L  I34,59  
 L  I35,36  
 L  I35,39  
 L  I35,40  
 L  I35,41  
 L  I35,43  
 L  I35,44  
 L  I35,45  
 L  I35,46  
 L  I35,47  
 L  I35,48  
 L  I35,49  
 L  I35,51  
 L  I35,52  
 L  I35,53  
 L  I35,54  
 L  I35,55  
 L  I35,57  
 L  I35,58  
 L  I35,59  
 L  I36,37  
 L  I36,38  
 L  I36,40  
 L  I36,41  
 L  I36,42  
 L  I36,44  
 L  I36,45  
 L  I36,47  
 L  I36,48  
 L  I36,49  
 L  I36,50  
 L  I36,51  
 L  I36,52  
 L  I36,53  
 L  I36,54  
 L  I36,55  
 L  I36,57  
 L  I36,58  
 L  I36,59  
 L  I37,38  
 L  I37,39  
 L  I37,40  
 L  I37,41  
 L  I37,42  
 L  I37,43  
 L  I37,44  
 L  I37,45  
 L  I37,46  
 L  I37,48  
 L  I37,49  
 L  I37,50  
 L  I37,51  
 L  I37,52  
 L  I37,53  
 L  I37,56  
 L  I37,57  
 L  I37,58  
 L  I38,39  
 L  I38,40  
 L  I38,41  
 L  I38,42  
 L  I38,44  
 L  I38,45  
 L  I38,47  
 L  I38,48  
 L  I38,50  
 L  I38,51  
 L  I38,52  
 L  I38,55  
 L  I38,56  
 L  I38,59  
 L  I39,40  
 L  I39,41  
 L  I39,42  
 L  I39,45  
 L  I39,46  
 L  I39,47  
 L  I39,50  
 L  I39,51  
 L  I39,52  
 L  I39,53  
 L  I39,54  
 L  I39,58  
 L  I39,59  
 L  I40,42  
 L  I40,43  
 L  I40,45  
 L  I40,46  
 L  I40,47  
 L  I40,49  
 L  I40,50  
 L  I40,53  
 L  I40,54  
 L  I40,55  
 L  I40,56  
 L  I40,59  
 L  I41,42  
 L  I41,43  
 L  I41,45  
 L  I41,46  
 L  I41,47  
 L  I41,50  
 L  I41,51  
 L  I41,52  
 L  I41,54  
 L  I41,55  
 L  I41,56  
 L  I42,43  
 L  I42,44  
 L  I42,46  
 L  I42,47  
 L  I42,48  
 L  I42,49  
 L  I42,50  
 L  I42,52  
 L  I42,53  
 L  I42,54  
 L  I42,56  
 L  I42,58  
 L  I42,59  
 L  I43,44  
 L  I43,45  
 L  I43,46  
 L  I43,48  
 L  I43,50  
 L  I43,52  
 L  I43,54  
 L  I43,56  
 L  I43,59  
 L  I44,47  
 L  I44,48  
 L  I44,50  
 L  I44,51  
 L  I44,52  
 L  I44,53  
 L  I44,54  
 L  I44,56  
 L  I44,57  
 L  I44,59  
 L  I45,47  
 L  I45,50  
 L  I45,54  
 L  I45,56  
 L  I45,58  
 L  I45,59  
 L  I46,47  
 L  I46,49  
 L  I46,50  
 L  I46,51  
 L  I46,53  
 L  I46,54  
 L  I46,55  
 L  I46,56  
 L  I46,58  
 L  I46,59  
 L  I47,48  
 L  I47,49  
 L  I47,50  
 L  I47,51  
 L  I47,52  
 L  I47,53  
 L  I47,55  
 L  I47,56  
 L  I47,57  
 L  I47,58  
 L  I47,59  
 L  I48,49  
 L  I48,50  
 L  I48,51  
 L  I48,53  
 L  I48,54  
 L  I48,55  
 L  I48,56  
 L  I48,57  
 L  I48,58  
 L  I48,59  
 L  I49,50  
 L  I49,53  
 L  I49,55  
 L  I49,56  
 L  I49,57  
 L  I49,58  
 L  I49,59  
 L  I50,52  
 L  I50,54  
 L  I50,55  
 L  I50,56  
 L  I50,57  
 L  I50,59  
 L  I51,52  
 L  I51,53  
 L  I51,55  
 L  I51,59  
 L  I52,53  
 L  I52,54  
 L  I52,58  
 L  I53,55  
 L  I53,56  
 L  I53,57  
 L  I53,58  
 L  I53,59  
 L  I54,55  
 L  I54,56  
 L  I54,57  
 L  I54,58  
 L  I54,59  
 L  I55,56  
 L  I55,57  
 L  I55,58  
 L  I55,59  
 L  I56,58  
 L  I57,59  
 L  I58,59  
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    w0,1      KL                              1
    w0,1      I0,1                            1
    w0,2      KL                              1
    w0,2      I0,2                            1
    w0,4      KL                              1
    w0,4      I0,4                            1
    w0,7      KL                              1
    w0,7      I0,7                            1
    w0,8      KL                              1
    w0,8      I0,8                            1
    w0,9      KL                              1
    w0,9      I0,9                            1
    w0,10     KL                              1
    w0,10     I0,10                           1
    w0,11     KL                              1
    w0,11     I0,11                           1
    w0,12     KL                              1
    w0,12     I0,12                           1
    w0,13     KL                              1
    w0,13     I0,13                           1
    w0,14     KL                              1
    w0,14     I0,14                           1
    w0,15     KL                              1
    w0,15     I0,15                           1
    w0,16     KL                              1
    w0,16     I0,16                           1
    w0,17     KL                              1
    w0,17     I0,17                           1
    w0,18     KL                              1
    w0,18     I0,18                           1
    w0,20     KL                              1
    w0,20     I0,20                           1
    w0,21     KL                              1
    w0,21     I0,21                           1
    w0,23     KL                              1
    w0,23     I0,23                           1
    w0,25     KL                              1
    w0,25     I0,25                           1
    w0,27     KL                              1
    w0,27     I0,27                           1
    w0,28     KL                              1
    w0,28     I0,28                           1
    w0,29     KL                              1
    w0,29     I0,29                           1
    w0,30     KL                              1
    w0,30     I0,30                           1
    w0,31     KL                              1
    w0,31     I0,31                           1
    w0,32     KL                              1
    w0,32     I0,32                           1
    w0,33     KL                              1
    w0,33     I0,33                           1
    w0,34     KL                              1
    w0,34     I0,34                           1
    w0,35     KL                              1
    w0,35     I0,35                           1
    w0,39     KL                              1
    w0,39     I0,39                           1
    w0,41     KL                              1
    w0,41     I0,41                           1
    w0,42     KL                              1
    w0,42     I0,42                           1
    w0,45     KL                              1
    w0,45     I0,45                           1
    w0,46     KL                              1
    w0,46     I0,46                           1
    w0,48     KL                              1
    w0,48     I0,48                           1
    w0,49     KL                              1
    w0,49     I0,49                           1
    w0,52     KL                              1
    w0,52     I0,52                           1
    w0,53     KL                              1
    w0,53     I0,53                           1
    w0,54     KL                              1
    w0,54     I0,54                           1
    w0,55     KL                              1
    w0,55     I0,55                           1
    w0,57     KL                              1
    w0,57     I0,57                           1
    w0,59     KL                              1
    w0,59     I0,59                           1
    w1,2      KL                              1
    w1,2      I1,2                            1
    w1,3      KL                              1
    w1,3      I1,3                            1
    w1,4      KL                              1
    w1,4      I1,4                            1
    w1,5      KL                              1
    w1,5      I1,5                            1
    w1,6      KL                              1
    w1,6      I1,6                            1
    w1,7      KL                              1
    w1,7      I1,7                            1
    w1,8      KL                              1
    w1,8      I1,8                            1
    w1,10     KL                              1
    w1,10     I1,10                           1
    w1,12     KL                              1
    w1,12     I1,12                           1
    w1,13     KL                              1
    w1,13     I1,13                           1
    w1,14     KL                              1
    w1,14     I1,14                           1
    w1,15     KL                              1
    w1,15     I1,15                           1
    w1,16     KL                              1
    w1,16     I1,16                           1
    w1,17     KL                              1
    w1,17     I1,17                           1
    w1,18     KL                              1
    w1,18     I1,18                           1
    w1,19     KL                              1
    w1,19     I1,19                           1
    w1,22     KL                              1
    w1,22     I1,22                           1
    w1,23     KL                              1
    w1,23     I1,23                           1
    w1,25     KL                              1
    w1,25     I1,25                           1
    w1,26     KL                              1
    w1,26     I1,26                           1
    w1,28     KL                              1
    w1,28     I1,28                           1
    w1,29     KL                              1
    w1,29     I1,29                           1
    w1,31     KL                              1
    w1,31     I1,31                           1
    w1,32     KL                              1
    w1,32     I1,32                           1
    w1,34     KL                              1
    w1,34     I1,34                           1
    w1,36     KL                              1
    w1,36     I1,36                           1
    w1,37     KL                              1
    w1,37     I1,37                           1
    w1,39     KL                              1
    w1,39     I1,39                           1
    w1,40     KL                              1
    w1,40     I1,40                           1
    w1,42     KL                              1
    w1,42     I1,42                           1
    w1,44     KL                              1
    w1,44     I1,44                           1
    w1,48     KL                              1
    w1,48     I1,48                           1
    w1,49     KL                              1
    w1,49     I1,49                           1
    w1,51     KL                              1
    w1,51     I1,51                           1
    w1,52     KL                              1
    w1,52     I1,52                           1
    w1,53     KL                              1
    w1,53     I1,53                           1
    w1,54     KL                              1
    w1,54     I1,54                           1
    w1,55     KL                              1
    w1,55     I1,55                           1
    w1,56     KL                              1
    w1,56     I1,56                           1
    w1,58     KL                              1
    w1,58     I1,58                           1
    w1,59     KL                              1
    w1,59     I1,59                           1
    w2,3      KL                              1
    w2,3      I2,3                            1
    w2,4      KL                              1
    w2,4      I2,4                            1
    w2,6      KL                              1
    w2,6      I2,6                            1
    w2,9      KL                              1
    w2,9      I2,9                            1
    w2,11     KL                              1
    w2,11     I2,11                           1
    w2,12     KL                              1
    w2,12     I2,12                           1
    w2,14     KL                              1
    w2,14     I2,14                           1
    w2,15     KL                              1
    w2,15     I2,15                           1
    w2,16     KL                              1
    w2,16     I2,16                           1
    w2,17     KL                              1
    w2,17     I2,17                           1
    w2,18     KL                              1
    w2,18     I2,18                           1
    w2,19     KL                              1
    w2,19     I2,19                           1
    w2,21     KL                              1
    w2,21     I2,21                           1
    w2,22     KL                              1
    w2,22     I2,22                           1
    w2,23     KL                              1
    w2,23     I2,23                           1
    w2,24     KL                              1
    w2,24     I2,24                           1
    w2,25     KL                              1
    w2,25     I2,25                           1
    w2,27     KL                              1
    w2,27     I2,27                           1
    w2,28     KL                              1
    w2,28     I2,28                           1
    w2,29     KL                              1
    w2,29     I2,29                           1
    w2,30     KL                              1
    w2,30     I2,30                           1
    w2,31     KL                              1
    w2,31     I2,31                           1
    w2,33     KL                              1
    w2,33     I2,33                           1
    w2,34     KL                              1
    w2,34     I2,34                           1
    w2,35     KL                              1
    w2,35     I2,35                           1
    w2,38     KL                              1
    w2,38     I2,38                           1
    w2,39     KL                              1
    w2,39     I2,39                           1
    w2,40     KL                              1
    w2,40     I2,40                           1
    w2,41     KL                              1
    w2,41     I2,41                           1
    w2,42     KL                              1
    w2,42     I2,42                           1
    w2,48     KL                              1
    w2,48     I2,48                           1
    w2,50     KL                              1
    w2,50     I2,50                           1
    w2,51     KL                              1
    w2,51     I2,51                           1
    w2,52     KL                              1
    w2,52     I2,52                           1
    w2,53     KL                              1
    w2,53     I2,53                           1
    w2,55     KL                              1
    w2,55     I2,55                           1
    w2,56     KL                              1
    w2,56     I2,56                           1
    w2,57     KL                              1
    w2,57     I2,57                           1
    w2,58     KL                              1
    w2,58     I2,58                           1
    w2,59     KL                              1
    w2,59     I2,59                           1
    w3,5      KL                              1
    w3,5      I3,5                            1
    w3,6      KL                              1
    w3,6      I3,6                            1
    w3,8      KL                              1
    w3,8      I3,8                            1
    w3,9      KL                              1
    w3,9      I3,9                            1
    w3,10     KL                              1
    w3,10     I3,10                           1
    w3,11     KL                              1
    w3,11     I3,11                           1
    w3,12     KL                              1
    w3,12     I3,12                           1
    w3,13     KL                              1
    w3,13     I3,13                           1
    w3,15     KL                              1
    w3,15     I3,15                           1
    w3,17     KL                              1
    w3,17     I3,17                           1
    w3,18     KL                              1
    w3,18     I3,18                           1
    w3,19     KL                              1
    w3,19     I3,19                           1
    w3,20     KL                              1
    w3,20     I3,20                           1
    w3,22     KL                              1
    w3,22     I3,22                           1
    w3,25     KL                              1
    w3,25     I3,25                           1
    w3,26     KL                              1
    w3,26     I3,26                           1
    w3,27     KL                              1
    w3,27     I3,27                           1
    w3,28     KL                              1
    w3,28     I3,28                           1
    w3,29     KL                              1
    w3,29     I3,29                           1
    w3,31     KL                              1
    w3,31     I3,31                           1
    w3,32     KL                              1
    w3,32     I3,32                           1
    w3,34     KL                              1
    w3,34     I3,34                           1
    w3,35     KL                              1
    w3,35     I3,35                           1
    w3,37     KL                              1
    w3,37     I3,37                           1
    w3,39     KL                              1
    w3,39     I3,39                           1
    w3,42     KL                              1
    w3,42     I3,42                           1
    w3,43     KL                              1
    w3,43     I3,43                           1
    w3,45     KL                              1
    w3,45     I3,45                           1
    w3,47     KL                              1
    w3,47     I3,47                           1
    w3,48     KL                              1
    w3,48     I3,48                           1
    w3,49     KL                              1
    w3,49     I3,49                           1
    w3,50     KL                              1
    w3,50     I3,50                           1
    w3,51     KL                              1
    w3,51     I3,51                           1
    w3,52     KL                              1
    w3,52     I3,52                           1
    w3,53     KL                              1
    w3,53     I3,53                           1
    w3,54     KL                              1
    w3,54     I3,54                           1
    w3,55     KL                              1
    w3,55     I3,55                           1
    w3,56     KL                              1
    w3,56     I3,56                           1
    w3,57     KL                              1
    w3,57     I3,57                           1
    w3,59     KL                              1
    w3,59     I3,59                           1
    w4,5      KL                              1
    w4,5      I4,5                            1
    w4,7      KL                              1
    w4,7      I4,7                            1
    w4,8      KL                              1
    w4,8      I4,8                            1
    w4,10     KL                              1
    w4,10     I4,10                           1
    w4,13     KL                              1
    w4,13     I4,13                           1
    w4,14     KL                              1
    w4,14     I4,14                           1
    w4,15     KL                              1
    w4,15     I4,15                           1
    w4,16     KL                              1
    w4,16     I4,16                           1
    w4,19     KL                              1
    w4,19     I4,19                           1
    w4,20     KL                              1
    w4,20     I4,20                           1
    w4,22     KL                              1
    w4,22     I4,22                           1
    w4,24     KL                              1
    w4,24     I4,24                           1
    w4,25     KL                              1
    w4,25     I4,25                           1
    w4,26     KL                              1
    w4,26     I4,26                           1
    w4,27     KL                              1
    w4,27     I4,27                           1
    w4,30     KL                              1
    w4,30     I4,30                           1
    w4,33     KL                              1
    w4,33     I4,33                           1
    w4,36     KL                              1
    w4,36     I4,36                           1
    w4,37     KL                              1
    w4,37     I4,37                           1
    w4,38     KL                              1
    w4,38     I4,38                           1
    w4,40     KL                              1
    w4,40     I4,40                           1
    w4,41     KL                              1
    w4,41     I4,41                           1
    w4,43     KL                              1
    w4,43     I4,43                           1
    w4,46     KL                              1
    w4,46     I4,46                           1
    w4,47     KL                              1
    w4,47     I4,47                           1
    w4,48     KL                              1
    w4,48     I4,48                           1
    w4,49     KL                              1
    w4,49     I4,49                           1
    w4,51     KL                              1
    w4,51     I4,51                           1
    w4,53     KL                              1
    w4,53     I4,53                           1
    w4,55     KL                              1
    w4,55     I4,55                           1
    w4,56     KL                              1
    w4,56     I4,56                           1
    w4,57     KL                              1
    w4,57     I4,57                           1
    w4,58     KL                              1
    w4,58     I4,58                           1
    w5,7      KL                              1
    w5,7      I5,7                            1
    w5,8      KL                              1
    w5,8      I5,8                            1
    w5,9      KL                              1
    w5,9      I5,9                            1
    w5,10     KL                              1
    w5,10     I5,10                           1
    w5,13     KL                              1
    w5,13     I5,13                           1
    w5,14     KL                              1
    w5,14     I5,14                           1
    w5,15     KL                              1
    w5,15     I5,15                           1
    w5,18     KL                              1
    w5,18     I5,18                           1
    w5,20     KL                              1
    w5,20     I5,20                           1
    w5,22     KL                              1
    w5,22     I5,22                           1
    w5,23     KL                              1
    w5,23     I5,23                           1
    w5,24     KL                              1
    w5,24     I5,24                           1
    w5,25     KL                              1
    w5,25     I5,25                           1
    w5,26     KL                              1
    w5,26     I5,26                           1
    w5,27     KL                              1
    w5,27     I5,27                           1
    w5,28     KL                              1
    w5,28     I5,28                           1
    w5,29     KL                              1
    w5,29     I5,29                           1
    w5,30     KL                              1
    w5,30     I5,30                           1
    w5,31     KL                              1
    w5,31     I5,31                           1
    w5,32     KL                              1
    w5,32     I5,32                           1
    w5,36     KL                              1
    w5,36     I5,36                           1
    w5,37     KL                              1
    w5,37     I5,37                           1
    w5,38     KL                              1
    w5,38     I5,38                           1
    w5,40     KL                              1
    w5,40     I5,40                           1
    w5,43     KL                              1
    w5,43     I5,43                           1
    w5,46     KL                              1
    w5,46     I5,46                           1
    w5,47     KL                              1
    w5,47     I5,47                           1
    w5,48     KL                              1
    w5,48     I5,48                           1
    w5,49     KL                              1
    w5,49     I5,49                           1
    w5,50     KL                              1
    w5,50     I5,50                           1
    w5,51     KL                              1
    w5,51     I5,51                           1
    w5,52     KL                              1
    w5,52     I5,52                           1
    w5,53     KL                              1
    w5,53     I5,53                           1
    w5,54     KL                              1
    w5,54     I5,54                           1
    w6,7      KL                              1
    w6,7      I6,7                            1
    w6,8      KL                              1
    w6,8      I6,8                            1
    w6,10     KL                              1
    w6,10     I6,10                           1
    w6,15     KL                              1
    w6,15     I6,15                           1
    w6,17     KL                              1
    w6,17     I6,17                           1
    w6,19     KL                              1
    w6,19     I6,19                           1
    w6,22     KL                              1
    w6,22     I6,22                           1
    w6,23     KL                              1
    w6,23     I6,23                           1
    w6,24     KL                              1
    w6,24     I6,24                           1
    w6,27     KL                              1
    w6,27     I6,27                           1
    w6,30     KL                              1
    w6,30     I6,30                           1
    w6,34     KL                              1
    w6,34     I6,34                           1
    w6,35     KL                              1
    w6,35     I6,35                           1
    w6,36     KL                              1
    w6,36     I6,36                           1
    w6,37     KL                              1
    w6,37     I6,37                           1
    w6,38     KL                              1
    w6,38     I6,38                           1
    w6,39     KL                              1
    w6,39     I6,39                           1
    w6,41     KL                              1
    w6,41     I6,41                           1
    w6,43     KL                              1
    w6,43     I6,43                           1
    w6,44     KL                              1
    w6,44     I6,44                           1
    w6,46     KL                              1
    w6,46     I6,46                           1
    w6,48     KL                              1
    w6,48     I6,48                           1
    w6,49     KL                              1
    w6,49     I6,49                           1
    w6,50     KL                              1
    w6,50     I6,50                           1
    w6,51     KL                              1
    w6,51     I6,51                           1
    w6,53     KL                              1
    w6,53     I6,53                           1
    w6,54     KL                              1
    w6,54     I6,54                           1
    w6,56     KL                              1
    w6,56     I6,56                           1
    w6,57     KL                              1
    w6,57     I6,57                           1
    w6,58     KL                              1
    w6,58     I6,58                           1
    w6,59     KL                              1
    w6,59     I6,59                           1
    w7,8      KL                              1
    w7,8      I7,8                            1
    w7,9      KL                              1
    w7,9      I7,9                            1
    w7,12     KL                              1
    w7,12     I7,12                           1
    w7,15     KL                              1
    w7,15     I7,15                           1
    w7,16     KL                              1
    w7,16     I7,16                           1
    w7,17     KL                              1
    w7,17     I7,17                           1
    w7,18     KL                              1
    w7,18     I7,18                           1
    w7,19     KL                              1
    w7,19     I7,19                           1
    w7,20     KL                              1
    w7,20     I7,20                           1
    w7,23     KL                              1
    w7,23     I7,23                           1
    w7,24     KL                              1
    w7,24     I7,24                           1
    w7,26     KL                              1
    w7,26     I7,26                           1
    w7,27     KL                              1
    w7,27     I7,27                           1
    w7,28     KL                              1
    w7,28     I7,28                           1
    w7,30     KL                              1
    w7,30     I7,30                           1
    w7,32     KL                              1
    w7,32     I7,32                           1
    w7,33     KL                              1
    w7,33     I7,33                           1
    w7,34     KL                              1
    w7,34     I7,34                           1
    w7,35     KL                              1
    w7,35     I7,35                           1
    w7,36     KL                              1
    w7,36     I7,36                           1
    w7,38     KL                              1
    w7,38     I7,38                           1
    w7,40     KL                              1
    w7,40     I7,40                           1
    w7,41     KL                              1
    w7,41     I7,41                           1
    w7,42     KL                              1
    w7,42     I7,42                           1
    w7,43     KL                              1
    w7,43     I7,43                           1
    w7,44     KL                              1
    w7,44     I7,44                           1
    w7,45     KL                              1
    w7,45     I7,45                           1
    w7,46     KL                              1
    w7,46     I7,46                           1
    w7,47     KL                              1
    w7,47     I7,47                           1
    w7,50     KL                              1
    w7,50     I7,50                           1
    w7,51     KL                              1
    w7,51     I7,51                           1
    w7,52     KL                              1
    w7,52     I7,52                           1
    w7,53     KL                              1
    w7,53     I7,53                           1
    w7,54     KL                              1
    w7,54     I7,54                           1
    w7,56     KL                              1
    w7,56     I7,56                           1
    w7,57     KL                              1
    w7,57     I7,57                           1
    w7,58     KL                              1
    w7,58     I7,58                           1
    w8,10     KL                              1
    w8,10     I8,10                           1
    w8,12     KL                              1
    w8,12     I8,12                           1
    w8,13     KL                              1
    w8,13     I8,13                           1
    w8,14     KL                              1
    w8,14     I8,14                           1
    w8,15     KL                              1
    w8,15     I8,15                           1
    w8,16     KL                              1
    w8,16     I8,16                           1
    w8,18     KL                              1
    w8,18     I8,18                           1
    w8,19     KL                              1
    w8,19     I8,19                           1
    w8,20     KL                              1
    w8,20     I8,20                           1
    w8,21     KL                              1
    w8,21     I8,21                           1
    w8,22     KL                              1
    w8,22     I8,22                           1
    w8,23     KL                              1
    w8,23     I8,23                           1
    w8,24     KL                              1
    w8,24     I8,24                           1
    w8,25     KL                              1
    w8,25     I8,25                           1
    w8,26     KL                              1
    w8,26     I8,26                           1
    w8,27     KL                              1
    w8,27     I8,27                           1
    w8,28     KL                              1
    w8,28     I8,28                           1
    w8,30     KL                              1
    w8,30     I8,30                           1
    w8,31     KL                              1
    w8,31     I8,31                           1
    w8,32     KL                              1
    w8,32     I8,32                           1
    w8,33     KL                              1
    w8,33     I8,33                           1
    w8,34     KL                              1
    w8,34     I8,34                           1
    w8,37     KL                              1
    w8,37     I8,37                           1
    w8,39     KL                              1
    w8,39     I8,39                           1
    w8,40     KL                              1
    w8,40     I8,40                           1
    w8,41     KL                              1
    w8,41     I8,41                           1
    w8,42     KL                              1
    w8,42     I8,42                           1
    w8,43     KL                              1
    w8,43     I8,43                           1
    w8,44     KL                              1
    w8,44     I8,44                           1
    w8,45     KL                              1
    w8,45     I8,45                           1
    w8,46     KL                              1
    w8,46     I8,46                           1
    w8,49     KL                              1
    w8,49     I8,49                           1
    w8,50     KL                              1
    w8,50     I8,50                           1
    w8,51     KL                              1
    w8,51     I8,51                           1
    w8,53     KL                              1
    w8,53     I8,53                           1
    w8,54     KL                              1
    w8,54     I8,54                           1
    w8,55     KL                              1
    w8,55     I8,55                           1
    w8,56     KL                              1
    w8,56     I8,56                           1
    w8,57     KL                              1
    w8,57     I8,57                           1
    w8,58     KL                              1
    w8,58     I8,58                           1
    w9,12     KL                              1
    w9,12     I9,12                           1
    w9,15     KL                              1
    w9,15     I9,15                           1
    w9,16     KL                              1
    w9,16     I9,16                           1
    w9,19     KL                              1
    w9,19     I9,19                           1
    w9,21     KL                              1
    w9,21     I9,21                           1
    w9,22     KL                              1
    w9,22     I9,22                           1
    w9,23     KL                              1
    w9,23     I9,23                           1
    w9,25     KL                              1
    w9,25     I9,25                           1
    w9,26     KL                              1
    w9,26     I9,26                           1
    w9,28     KL                              1
    w9,28     I9,28                           1
    w9,29     KL                              1
    w9,29     I9,29                           1
    w9,30     KL                              1
    w9,30     I9,30                           1
    w9,31     KL                              1
    w9,31     I9,31                           1
    w9,32     KL                              1
    w9,32     I9,32                           1
    w9,33     KL                              1
    w9,33     I9,33                           1
    w9,34     KL                              1
    w9,34     I9,34                           1
    w9,35     KL                              1
    w9,35     I9,35                           1
    w9,36     KL                              1
    w9,36     I9,36                           1
    w9,37     KL                              1
    w9,37     I9,37                           1
    w9,38     KL                              1
    w9,38     I9,38                           1
    w9,39     KL                              1
    w9,39     I9,39                           1
    w9,40     KL                              1
    w9,40     I9,40                           1
    w9,41     KL                              1
    w9,41     I9,41                           1
    w9,42     KL                              1
    w9,42     I9,42                           1
    w9,43     KL                              1
    w9,43     I9,43                           1
    w9,44     KL                              1
    w9,44     I9,44                           1
    w9,45     KL                              1
    w9,45     I9,45                           1
    w9,46     KL                              1
    w9,46     I9,46                           1
    w9,49     KL                              1
    w9,49     I9,49                           1
    w9,50     KL                              1
    w9,50     I9,50                           1
    w9,52     KL                              1
    w9,52     I9,52                           1
    w9,54     KL                              1
    w9,54     I9,54                           1
    w9,55     KL                              1
    w9,55     I9,55                           1
    w9,58     KL                              1
    w9,58     I9,58                           1
    w9,59     KL                              1
    w9,59     I9,59                           1
    w10,11    KL                              1
    w10,11    I10,11                          1
    w10,13    KL                              1
    w10,13    I10,13                          1
    w10,15    KL                              1
    w10,15    I10,15                          1
    w10,16    KL                              1
    w10,16    I10,16                          1
    w10,18    KL                              1
    w10,18    I10,18                          1
    w10,19    KL                              1
    w10,19    I10,19                          1
    w10,21    KL                              1
    w10,21    I10,21                          1
    w10,23    KL                              1
    w10,23    I10,23                          1
    w10,25    KL                              1
    w10,25    I10,25                          1
    w10,26    KL                              1
    w10,26    I10,26                          1
    w10,27    KL                              1
    w10,27    I10,27                          1
    w10,28    KL                              1
    w10,28    I10,28                          1
    w10,29    KL                              1
    w10,29    I10,29                          1
    w10,30    KL                              1
    w10,30    I10,30                          1
    w10,31    KL                              1
    w10,31    I10,31                          1
    w10,32    KL                              1
    w10,32    I10,32                          1
    w10,34    KL                              1
    w10,34    I10,34                          1
    w10,35    KL                              1
    w10,35    I10,35                          1
    w10,36    KL                              1
    w10,36    I10,36                          1
    w10,38    KL                              1
    w10,38    I10,38                          1
    w10,39    KL                              1
    w10,39    I10,39                          1
    w10,40    KL                              1
    w10,40    I10,40                          1
    w10,41    KL                              1
    w10,41    I10,41                          1
    w10,42    KL                              1
    w10,42    I10,42                          1
    w10,44    KL                              1
    w10,44    I10,44                          1
    w10,45    KL                              1
    w10,45    I10,45                          1
    w10,46    KL                              1
    w10,46    I10,46                          1
    w10,47    KL                              1
    w10,47    I10,47                          1
    w10,48    KL                              1
    w10,48    I10,48                          1
    w10,50    KL                              1
    w10,50    I10,50                          1
    w10,51    KL                              1
    w10,51    I10,51                          1
    w10,52    KL                              1
    w10,52    I10,52                          1
    w10,53    KL                              1
    w10,53    I10,53                          1
    w10,54    KL                              1
    w10,54    I10,54                          1
    w10,56    KL                              1
    w10,56    I10,56                          1
    w10,57    KL                              1
    w10,57    I10,57                          1
    w10,59    KL                              1
    w10,59    I10,59                          1
    w11,12    KL                              1
    w11,12    I11,12                          1
    w11,14    KL                              1
    w11,14    I11,14                          1
    w11,15    KL                              1
    w11,15    I11,15                          1
    w11,17    KL                              1
    w11,17    I11,17                          1
    w11,21    KL                              1
    w11,21    I11,21                          1
    w11,23    KL                              1
    w11,23    I11,23                          1
    w11,25    KL                              1
    w11,25    I11,25                          1
    w11,26    KL                              1
    w11,26    I11,26                          1
    w11,29    KL                              1
    w11,29    I11,29                          1
    w11,30    KL                              1
    w11,30    I11,30                          1
    w11,31    KL                              1
    w11,31    I11,31                          1
    w11,32    KL                              1
    w11,32    I11,32                          1
    w11,33    KL                              1
    w11,33    I11,33                          1
    w11,34    KL                              1
    w11,34    I11,34                          1
    w11,35    KL                              1
    w11,35    I11,35                          1
    w11,36    KL                              1
    w11,36    I11,36                          1
    w11,37    KL                              1
    w11,37    I11,37                          1
    w11,38    KL                              1
    w11,38    I11,38                          1
    w11,39    KL                              1
    w11,39    I11,39                          1
    w11,40    KL                              1
    w11,40    I11,40                          1
    w11,42    KL                              1
    w11,42    I11,42                          1
    w11,45    KL                              1
    w11,45    I11,45                          1
    w11,46    KL                              1
    w11,46    I11,46                          1
    w11,47    KL                              1
    w11,47    I11,47                          1
    w11,48    KL                              1
    w11,48    I11,48                          1
    w11,49    KL                              1
    w11,49    I11,49                          1
    w11,52    KL                              1
    w11,52    I11,52                          1
    w11,53    KL                              1
    w11,53    I11,53                          1
    w11,54    KL                              1
    w11,54    I11,54                          1
    w11,56    KL                              1
    w11,56    I11,56                          1
    w11,57    KL                              1
    w11,57    I11,57                          1
    w11,58    KL                              1
    w11,58    I11,58                          1
    w11,59    KL                              1
    w11,59    I11,59                          1
    w12,14    KL                              1
    w12,14    I12,14                          1
    w12,15    KL                              1
    w12,15    I12,15                          1
    w12,16    KL                              1
    w12,16    I12,16                          1
    w12,17    KL                              1
    w12,17    I12,17                          1
    w12,19    KL                              1
    w12,19    I12,19                          1
    w12,20    KL                              1
    w12,20    I12,20                          1
    w12,22    KL                              1
    w12,22    I12,22                          1
    w12,23    KL                              1
    w12,23    I12,23                          1
    w12,25    KL                              1
    w12,25    I12,25                          1
    w12,26    KL                              1
    w12,26    I12,26                          1
    w12,27    KL                              1
    w12,27    I12,27                          1
    w12,29    KL                              1
    w12,29    I12,29                          1
    w12,30    KL                              1
    w12,30    I12,30                          1
    w12,31    KL                              1
    w12,31    I12,31                          1
    w12,32    KL                              1
    w12,32    I12,32                          1
    w12,33    KL                              1
    w12,33    I12,33                          1
    w12,34    KL                              1
    w12,34    I12,34                          1
    w12,35    KL                              1
    w12,35    I12,35                          1
    w12,36    KL                              1
    w12,36    I12,36                          1
    w12,37    KL                              1
    w12,37    I12,37                          1
    w12,38    KL                              1
    w12,38    I12,38                          1
    w12,39    KL                              1
    w12,39    I12,39                          1
    w12,40    KL                              1
    w12,40    I12,40                          1
    w12,42    KL                              1
    w12,42    I12,42                          1
    w12,43    KL                              1
    w12,43    I12,43                          1
    w12,44    KL                              1
    w12,44    I12,44                          1
    w12,45    KL                              1
    w12,45    I12,45                          1
    w12,46    KL                              1
    w12,46    I12,46                          1
    w12,47    KL                              1
    w12,47    I12,47                          1
    w12,48    KL                              1
    w12,48    I12,48                          1
    w12,49    KL                              1
    w12,49    I12,49                          1
    w12,50    KL                              1
    w12,50    I12,50                          1
    w12,52    KL                              1
    w12,52    I12,52                          1
    w12,53    KL                              1
    w12,53    I12,53                          1
    w12,54    KL                              1
    w12,54    I12,54                          1
    w12,55    KL                              1
    w12,55    I12,55                          1
    w12,56    KL                              1
    w12,56    I12,56                          1
    w12,58    KL                              1
    w12,58    I12,58                          1
    w12,59    KL                              1
    w12,59    I12,59                          1
    w13,14    KL                              1
    w13,14    I13,14                          1
    w13,16    KL                              1
    w13,16    I13,16                          1
    w13,17    KL                              1
    w13,17    I13,17                          1
    w13,19    KL                              1
    w13,19    I13,19                          1
    w13,20    KL                              1
    w13,20    I13,20                          1
    w13,21    KL                              1
    w13,21    I13,21                          1
    w13,22    KL                              1
    w13,22    I13,22                          1
    w13,23    KL                              1
    w13,23    I13,23                          1
    w13,24    KL                              1
    w13,24    I13,24                          1
    w13,27    KL                              1
    w13,27    I13,27                          1
    w13,28    KL                              1
    w13,28    I13,28                          1
    w13,32    KL                              1
    w13,32    I13,32                          1
    w13,33    KL                              1
    w13,33    I13,33                          1
    w13,34    KL                              1
    w13,34    I13,34                          1
    w13,36    KL                              1
    w13,36    I13,36                          1
    w13,38    KL                              1
    w13,38    I13,38                          1
    w13,39    KL                              1
    w13,39    I13,39                          1
    w13,40    KL                              1
    w13,40    I13,40                          1
    w13,41    KL                              1
    w13,41    I13,41                          1
    w13,42    KL                              1
    w13,42    I13,42                          1
    w13,43    KL                              1
    w13,43    I13,43                          1
    w13,46    KL                              1
    w13,46    I13,46                          1
    w13,50    KL                              1
    w13,50    I13,50                          1
    w13,51    KL                              1
    w13,51    I13,51                          1
    w13,53    KL                              1
    w13,53    I13,53                          1
    w13,55    KL                              1
    w13,55    I13,55                          1
    w13,56    KL                              1
    w13,56    I13,56                          1
    w13,57    KL                              1
    w13,57    I13,57                          1
    w13,58    KL                              1
    w13,58    I13,58                          1
    w13,59    KL                              1
    w13,59    I13,59                          1
    w14,18    KL                              1
    w14,18    I14,18                          1
    w14,19    KL                              1
    w14,19    I14,19                          1
    w14,20    KL                              1
    w14,20    I14,20                          1
    w14,21    KL                              1
    w14,21    I14,21                          1
    w14,25    KL                              1
    w14,25    I14,25                          1
    w14,27    KL                              1
    w14,27    I14,27                          1
    w14,28    KL                              1
    w14,28    I14,28                          1
    w14,29    KL                              1
    w14,29    I14,29                          1
    w14,31    KL                              1
    w14,31    I14,31                          1
    w14,33    KL                              1
    w14,33    I14,33                          1
    w14,35    KL                              1
    w14,35    I14,35                          1
    w14,36    KL                              1
    w14,36    I14,36                          1
    w14,37    KL                              1
    w14,37    I14,37                          1
    w14,38    KL                              1
    w14,38    I14,38                          1
    w14,40    KL                              1
    w14,40    I14,40                          1
    w14,43    KL                              1
    w14,43    I14,43                          1
    w14,44    KL                              1
    w14,44    I14,44                          1
    w14,45    KL                              1
    w14,45    I14,45                          1
    w14,46    KL                              1
    w14,46    I14,46                          1
    w14,47    KL                              1
    w14,47    I14,47                          1
    w14,48    KL                              1
    w14,48    I14,48                          1
    w14,49    KL                              1
    w14,49    I14,49                          1
    w14,50    KL                              1
    w14,50    I14,50                          1
    w14,51    KL                              1
    w14,51    I14,51                          1
    w14,52    KL                              1
    w14,52    I14,52                          1
    w14,53    KL                              1
    w14,53    I14,53                          1
    w14,54    KL                              1
    w14,54    I14,54                          1
    w14,56    KL                              1
    w14,56    I14,56                          1
    w14,57    KL                              1
    w14,57    I14,57                          1
    w14,58    KL                              1
    w14,58    I14,58                          1
    w15,16    KL                              1
    w15,16    I15,16                          1
    w15,17    KL                              1
    w15,17    I15,17                          1
    w15,18    KL                              1
    w15,18    I15,18                          1
    w15,20    KL                              1
    w15,20    I15,20                          1
    w15,23    KL                              1
    w15,23    I15,23                          1
    w15,25    KL                              1
    w15,25    I15,25                          1
    w15,26    KL                              1
    w15,26    I15,26                          1
    w15,28    KL                              1
    w15,28    I15,28                          1
    w15,32    KL                              1
    w15,32    I15,32                          1
    w15,33    KL                              1
    w15,33    I15,33                          1
    w15,35    KL                              1
    w15,35    I15,35                          1
    w15,36    KL                              1
    w15,36    I15,36                          1
    w15,37    KL                              1
    w15,37    I15,37                          1
    w15,39    KL                              1
    w15,39    I15,39                          1
    w15,41    KL                              1
    w15,41    I15,41                          1
    w15,45    KL                              1
    w15,45    I15,45                          1
    w15,46    KL                              1
    w15,46    I15,46                          1
    w15,47    KL                              1
    w15,47    I15,47                          1
    w15,49    KL                              1
    w15,49    I15,49                          1
    w15,50    KL                              1
    w15,50    I15,50                          1
    w15,51    KL                              1
    w15,51    I15,51                          1
    w15,54    KL                              1
    w15,54    I15,54                          1
    w15,55    KL                              1
    w15,55    I15,55                          1
    w15,57    KL                              1
    w15,57    I15,57                          1
    w15,58    KL                              1
    w15,58    I15,58                          1
    w15,59    KL                              1
    w15,59    I15,59                          1
    w16,17    KL                              1
    w16,17    I16,17                          1
    w16,18    KL                              1
    w16,18    I16,18                          1
    w16,19    KL                              1
    w16,19    I16,19                          1
    w16,20    KL                              1
    w16,20    I16,20                          1
    w16,21    KL                              1
    w16,21    I16,21                          1
    w16,25    KL                              1
    w16,25    I16,25                          1
    w16,28    KL                              1
    w16,28    I16,28                          1
    w16,29    KL                              1
    w16,29    I16,29                          1
    w16,30    KL                              1
    w16,30    I16,30                          1
    w16,31    KL                              1
    w16,31    I16,31                          1
    w16,32    KL                              1
    w16,32    I16,32                          1
    w16,33    KL                              1
    w16,33    I16,33                          1
    w16,35    KL                              1
    w16,35    I16,35                          1
    w16,36    KL                              1
    w16,36    I16,36                          1
    w16,37    KL                              1
    w16,37    I16,37                          1
    w16,38    KL                              1
    w16,38    I16,38                          1
    w16,40    KL                              1
    w16,40    I16,40                          1
    w16,41    KL                              1
    w16,41    I16,41                          1
    w16,42    KL                              1
    w16,42    I16,42                          1
    w16,43    KL                              1
    w16,43    I16,43                          1
    w16,46    KL                              1
    w16,46    I16,46                          1
    w16,47    KL                              1
    w16,47    I16,47                          1
    w16,49    KL                              1
    w16,49    I16,49                          1
    w16,51    KL                              1
    w16,51    I16,51                          1
    w16,52    KL                              1
    w16,52    I16,52                          1
    w16,53    KL                              1
    w16,53    I16,53                          1
    w16,54    KL                              1
    w16,54    I16,54                          1
    w16,57    KL                              1
    w16,57    I16,57                          1
    w16,59    KL                              1
    w16,59    I16,59                          1
    w17,18    KL                              1
    w17,18    I17,18                          1
    w17,20    KL                              1
    w17,20    I17,20                          1
    w17,21    KL                              1
    w17,21    I17,21                          1
    w17,22    KL                              1
    w17,22    I17,22                          1
    w17,23    KL                              1
    w17,23    I17,23                          1
    w17,25    KL                              1
    w17,25    I17,25                          1
    w17,26    KL                              1
    w17,26    I17,26                          1
    w17,28    KL                              1
    w17,28    I17,28                          1
    w17,29    KL                              1
    w17,29    I17,29                          1
    w17,30    KL                              1
    w17,30    I17,30                          1
    w17,32    KL                              1
    w17,32    I17,32                          1
    w17,33    KL                              1
    w17,33    I17,33                          1
    w17,35    KL                              1
    w17,35    I17,35                          1
    w17,36    KL                              1
    w17,36    I17,36                          1
    w17,37    KL                              1
    w17,37    I17,37                          1
    w17,38    KL                              1
    w17,38    I17,38                          1
    w17,41    KL                              1
    w17,41    I17,41                          1
    w17,42    KL                              1
    w17,42    I17,42                          1
    w17,44    KL                              1
    w17,44    I17,44                          1
    w17,45    KL                              1
    w17,45    I17,45                          1
    w17,46    KL                              1
    w17,46    I17,46                          1
    w17,47    KL                              1
    w17,47    I17,47                          1
    w17,48    KL                              1
    w17,48    I17,48                          1
    w17,49    KL                              1
    w17,49    I17,49                          1
    w17,51    KL                              1
    w17,51    I17,51                          1
    w17,53    KL                              1
    w17,53    I17,53                          1
    w17,54    KL                              1
    w17,54    I17,54                          1
    w17,55    KL                              1
    w17,55    I17,55                          1
    w17,58    KL                              1
    w17,58    I17,58                          1
    w17,59    KL                              1
    w17,59    I17,59                          1
    w18,19    KL                              1
    w18,19    I18,19                          1
    w18,22    KL                              1
    w18,22    I18,22                          1
    w18,23    KL                              1
    w18,23    I18,23                          1
    w18,25    KL                              1
    w18,25    I18,25                          1
    w18,26    KL                              1
    w18,26    I18,26                          1
    w18,28    KL                              1
    w18,28    I18,28                          1
    w18,29    KL                              1
    w18,29    I18,29                          1
    w18,30    KL                              1
    w18,30    I18,30                          1
    w18,31    KL                              1
    w18,31    I18,31                          1
    w18,32    KL                              1
    w18,32    I18,32                          1
    w18,33    KL                              1
    w18,33    I18,33                          1
    w18,34    KL                              1
    w18,34    I18,34                          1
    w18,35    KL                              1
    w18,35    I18,35                          1
    w18,36    KL                              1
    w18,36    I18,36                          1
    w18,37    KL                              1
    w18,37    I18,37                          1
    w18,38    KL                              1
    w18,38    I18,38                          1
    w18,39    KL                              1
    w18,39    I18,39                          1
    w18,40    KL                              1
    w18,40    I18,40                          1
    w18,41    KL                              1
    w18,41    I18,41                          1
    w18,42    KL                              1
    w18,42    I18,42                          1
    w18,43    KL                              1
    w18,43    I18,43                          1
    w18,44    KL                              1
    w18,44    I18,44                          1
    w18,45    KL                              1
    w18,45    I18,45                          1
    w18,47    KL                              1
    w18,47    I18,47                          1
    w18,48    KL                              1
    w18,48    I18,48                          1
    w18,50    KL                              1
    w18,50    I18,50                          1
    w18,51    KL                              1
    w18,51    I18,51                          1
    w18,52    KL                              1
    w18,52    I18,52                          1
    w18,53    KL                              1
    w18,53    I18,53                          1
    w18,54    KL                              1
    w18,54    I18,54                          1
    w18,55    KL                              1
    w18,55    I18,55                          1
    w18,56    KL                              1
    w18,56    I18,56                          1
    w18,57    KL                              1
    w18,57    I18,57                          1
    w18,59    KL                              1
    w18,59    I18,59                          1
    w19,20    KL                              1
    w19,20    I19,20                          1
    w19,21    KL                              1
    w19,21    I19,21                          1
    w19,22    KL                              1
    w19,22    I19,22                          1
    w19,24    KL                              1
    w19,24    I19,24                          1
    w19,28    KL                              1
    w19,28    I19,28                          1
    w19,29    KL                              1
    w19,29    I19,29                          1
    w19,30    KL                              1
    w19,30    I19,30                          1
    w19,31    KL                              1
    w19,31    I19,31                          1
    w19,32    KL                              1
    w19,32    I19,32                          1
    w19,36    KL                              1
    w19,36    I19,36                          1
    w19,37    KL                              1
    w19,37    I19,37                          1
    w19,39    KL                              1
    w19,39    I19,39                          1
    w19,40    KL                              1
    w19,40    I19,40                          1
    w19,42    KL                              1
    w19,42    I19,42                          1
    w19,43    KL                              1
    w19,43    I19,43                          1
    w19,44    KL                              1
    w19,44    I19,44                          1
    w19,45    KL                              1
    w19,45    I19,45                          1
    w19,49    KL                              1
    w19,49    I19,49                          1
    w19,50    KL                              1
    w19,50    I19,50                          1
    w19,51    KL                              1
    w19,51    I19,51                          1
    w19,52    KL                              1
    w19,52    I19,52                          1
    w19,53    KL                              1
    w19,53    I19,53                          1
    w19,54    KL                              1
    w19,54    I19,54                          1
    w19,55    KL                              1
    w19,55    I19,55                          1
    w19,58    KL                              1
    w19,58    I19,58                          1
    w19,59    KL                              1
    w19,59    I19,59                          1
    w20,21    KL                              1
    w20,21    I20,21                          1
    w20,22    KL                              1
    w20,22    I20,22                          1
    w20,23    KL                              1
    w20,23    I20,23                          1
    w20,24    KL                              1
    w20,24    I20,24                          1
    w20,26    KL                              1
    w20,26    I20,26                          1
    w20,27    KL                              1
    w20,27    I20,27                          1
    w20,28    KL                              1
    w20,28    I20,28                          1
    w20,29    KL                              1
    w20,29    I20,29                          1
    w20,30    KL                              1
    w20,30    I20,30                          1
    w20,32    KL                              1
    w20,32    I20,32                          1
    w20,34    KL                              1
    w20,34    I20,34                          1
    w20,35    KL                              1
    w20,35    I20,35                          1
    w20,36    KL                              1
    w20,36    I20,36                          1
    w20,39    KL                              1
    w20,39    I20,39                          1
    w20,41    KL                              1
    w20,41    I20,41                          1
    w20,42    KL                              1
    w20,42    I20,42                          1
    w20,43    KL                              1
    w20,43    I20,43                          1
    w20,44    KL                              1
    w20,44    I20,44                          1
    w20,45    KL                              1
    w20,45    I20,45                          1
    w20,47    KL                              1
    w20,47    I20,47                          1
    w20,48    KL                              1
    w20,48    I20,48                          1
    w20,49    KL                              1
    w20,49    I20,49                          1
    w20,50    KL                              1
    w20,50    I20,50                          1
    w20,52    KL                              1
    w20,52    I20,52                          1
    w20,53    KL                              1
    w20,53    I20,53                          1
    w20,55    KL                              1
    w20,55    I20,55                          1
    w20,56    KL                              1
    w20,56    I20,56                          1
    w20,57    KL                              1
    w20,57    I20,57                          1
    w21,24    KL                              1
    w21,24    I21,24                          1
    w21,25    KL                              1
    w21,25    I21,25                          1
    w21,26    KL                              1
    w21,26    I21,26                          1
    w21,27    KL                              1
    w21,27    I21,27                          1
    w21,30    KL                              1
    w21,30    I21,30                          1
    w21,32    KL                              1
    w21,32    I21,32                          1
    w21,34    KL                              1
    w21,34    I21,34                          1
    w21,35    KL                              1
    w21,35    I21,35                          1
    w21,36    KL                              1
    w21,36    I21,36                          1
    w21,37    KL                              1
    w21,37    I21,37                          1
    w21,38    KL                              1
    w21,38    I21,38                          1
    w21,39    KL                              1
    w21,39    I21,39                          1
    w21,41    KL                              1
    w21,41    I21,41                          1
    w21,42    KL                              1
    w21,42    I21,42                          1
    w21,44    KL                              1
    w21,44    I21,44                          1
    w21,45    KL                              1
    w21,45    I21,45                          1
    w21,47    KL                              1
    w21,47    I21,47                          1
    w21,49    KL                              1
    w21,49    I21,49                          1
    w21,50    KL                              1
    w21,50    I21,50                          1
    w21,52    KL                              1
    w21,52    I21,52                          1
    w21,53    KL                              1
    w21,53    I21,53                          1
    w21,54    KL                              1
    w21,54    I21,54                          1
    w21,55    KL                              1
    w21,55    I21,55                          1
    w21,56    KL                              1
    w21,56    I21,56                          1
    w21,57    KL                              1
    w21,57    I21,57                          1
    w22,25    KL                              1
    w22,25    I22,25                          1
    w22,26    KL                              1
    w22,26    I22,26                          1
    w22,27    KL                              1
    w22,27    I22,27                          1
    w22,28    KL                              1
    w22,28    I22,28                          1
    w22,29    KL                              1
    w22,29    I22,29                          1
    w22,30    KL                              1
    w22,30    I22,30                          1
    w22,31    KL                              1
    w22,31    I22,31                          1
    w22,32    KL                              1
    w22,32    I22,32                          1
    w22,33    KL                              1
    w22,33    I22,33                          1
    w22,37    KL                              1
    w22,37    I22,37                          1
    w22,38    KL                              1
    w22,38    I22,38                          1
    w22,39    KL                              1
    w22,39    I22,39                          1
    w22,41    KL                              1
    w22,41    I22,41                          1
    w22,42    KL                              1
    w22,42    I22,42                          1
    w22,44    KL                              1
    w22,44    I22,44                          1
    w22,45    KL                              1
    w22,45    I22,45                          1
    w22,46    KL                              1
    w22,46    I22,46                          1
    w22,47    KL                              1
    w22,47    I22,47                          1
    w22,48    KL                              1
    w22,48    I22,48                          1
    w22,49    KL                              1
    w22,49    I22,49                          1
    w22,50    KL                              1
    w22,50    I22,50                          1
    w22,51    KL                              1
    w22,51    I22,51                          1
    w22,53    KL                              1
    w22,53    I22,53                          1
    w22,56    KL                              1
    w22,56    I22,56                          1
    w22,58    KL                              1
    w22,58    I22,58                          1
    w22,59    KL                              1
    w22,59    I22,59                          1
    w23,24    KL                              1
    w23,24    I23,24                          1
    w23,25    KL                              1
    w23,25    I23,25                          1
    w23,26    KL                              1
    w23,26    I23,26                          1
    w23,28    KL                              1
    w23,28    I23,28                          1
    w23,29    KL                              1
    w23,29    I23,29                          1
    w23,30    KL                              1
    w23,30    I23,30                          1
    w23,31    KL                              1
    w23,31    I23,31                          1
    w23,32    KL                              1
    w23,32    I23,32                          1
    w23,33    KL                              1
    w23,33    I23,33                          1
    w23,34    KL                              1
    w23,34    I23,34                          1
    w23,36    KL                              1
    w23,36    I23,36                          1
    w23,37    KL                              1
    w23,37    I23,37                          1
    w23,38    KL                              1
    w23,38    I23,38                          1
    w23,39    KL                              1
    w23,39    I23,39                          1
    w23,40    KL                              1
    w23,40    I23,40                          1
    w23,41    KL                              1
    w23,41    I23,41                          1
    w23,42    KL                              1
    w23,42    I23,42                          1
    w23,43    KL                              1
    w23,43    I23,43                          1
    w23,47    KL                              1
    w23,47    I23,47                          1
    w23,49    KL                              1
    w23,49    I23,49                          1
    w23,50    KL                              1
    w23,50    I23,50                          1
    w23,51    KL                              1
    w23,51    I23,51                          1
    w23,52    KL                              1
    w23,52    I23,52                          1
    w23,54    KL                              1
    w23,54    I23,54                          1
    w23,55    KL                              1
    w23,55    I23,55                          1
    w23,56    KL                              1
    w23,56    I23,56                          1
    w23,57    KL                              1
    w23,57    I23,57                          1
    w23,58    KL                              1
    w23,58    I23,58                          1
    w23,59    KL                              1
    w23,59    I23,59                          1
    w24,25    KL                              1
    w24,25    I24,25                          1
    w24,27    KL                              1
    w24,27    I24,27                          1
    w24,28    KL                              1
    w24,28    I24,28                          1
    w24,29    KL                              1
    w24,29    I24,29                          1
    w24,30    KL                              1
    w24,30    I24,30                          1
    w24,32    KL                              1
    w24,32    I24,32                          1
    w24,33    KL                              1
    w24,33    I24,33                          1
    w24,34    KL                              1
    w24,34    I24,34                          1
    w24,35    KL                              1
    w24,35    I24,35                          1
    w24,36    KL                              1
    w24,36    I24,36                          1
    w24,37    KL                              1
    w24,37    I24,37                          1
    w24,39    KL                              1
    w24,39    I24,39                          1
    w24,41    KL                              1
    w24,41    I24,41                          1
    w24,42    KL                              1
    w24,42    I24,42                          1
    w24,43    KL                              1
    w24,43    I24,43                          1
    w24,44    KL                              1
    w24,44    I24,44                          1
    w24,45    KL                              1
    w24,45    I24,45                          1
    w24,46    KL                              1
    w24,46    I24,46                          1
    w24,47    KL                              1
    w24,47    I24,47                          1
    w24,48    KL                              1
    w24,48    I24,48                          1
    w24,49    KL                              1
    w24,49    I24,49                          1
    w24,50    KL                              1
    w24,50    I24,50                          1
    w24,51    KL                              1
    w24,51    I24,51                          1
    w24,52    KL                              1
    w24,52    I24,52                          1
    w24,53    KL                              1
    w24,53    I24,53                          1
    w24,56    KL                              1
    w24,56    I24,56                          1
    w24,57    KL                              1
    w24,57    I24,57                          1
    w24,59    KL                              1
    w24,59    I24,59                          1
    w25,26    KL                              1
    w25,26    I25,26                          1
    w25,28    KL                              1
    w25,28    I25,28                          1
    w25,31    KL                              1
    w25,31    I25,31                          1
    w25,32    KL                              1
    w25,32    I25,32                          1
    w25,33    KL                              1
    w25,33    I25,33                          1
    w25,34    KL                              1
    w25,34    I25,34                          1
    w25,35    KL                              1
    w25,35    I25,35                          1
    w25,37    KL                              1
    w25,37    I25,37                          1
    w25,38    KL                              1
    w25,38    I25,38                          1
    w25,39    KL                              1
    w25,39    I25,39                          1
    w25,40    KL                              1
    w25,40    I25,40                          1
    w25,42    KL                              1
    w25,42    I25,42                          1
    w25,44    KL                              1
    w25,44    I25,44                          1
    w25,45    KL                              1
    w25,45    I25,45                          1
    w25,47    KL                              1
    w25,47    I25,47                          1
    w25,48    KL                              1
    w25,48    I25,48                          1
    w25,49    KL                              1
    w25,49    I25,49                          1
    w25,50    KL                              1
    w25,50    I25,50                          1
    w25,51    KL                              1
    w25,51    I25,51                          1
    w25,52    KL                              1
    w25,52    I25,52                          1
    w25,53    KL                              1
    w25,53    I25,53                          1
    w25,54    KL                              1
    w25,54    I25,54                          1
    w25,55    KL                              1
    w25,55    I25,55                          1
    w25,56    KL                              1
    w25,56    I25,56                          1
    w25,57    KL                              1
    w25,57    I25,57                          1
    w25,59    KL                              1
    w25,59    I25,59                          1
    w26,29    KL                              1
    w26,29    I26,29                          1
    w26,30    KL                              1
    w26,30    I26,30                          1
    w26,31    KL                              1
    w26,31    I26,31                          1
    w26,32    KL                              1
    w26,32    I26,32                          1
    w26,34    KL                              1
    w26,34    I26,34                          1
    w26,35    KL                              1
    w26,35    I26,35                          1
    w26,36    KL                              1
    w26,36    I26,36                          1
    w26,37    KL                              1
    w26,37    I26,37                          1
    w26,38    KL                              1
    w26,38    I26,38                          1
    w26,39    KL                              1
    w26,39    I26,39                          1
    w26,40    KL                              1
    w26,40    I26,40                          1
    w26,41    KL                              1
    w26,41    I26,41                          1
    w26,42    KL                              1
    w26,42    I26,42                          1
    w26,43    KL                              1
    w26,43    I26,43                          1
    w26,45    KL                              1
    w26,45    I26,45                          1
    w26,46    KL                              1
    w26,46    I26,46                          1
    w26,48    KL                              1
    w26,48    I26,48                          1
    w26,49    KL                              1
    w26,49    I26,49                          1
    w26,50    KL                              1
    w26,50    I26,50                          1
    w26,51    KL                              1
    w26,51    I26,51                          1
    w26,55    KL                              1
    w26,55    I26,55                          1
    w26,56    KL                              1
    w26,56    I26,56                          1
    w26,57    KL                              1
    w26,57    I26,57                          1
    w26,58    KL                              1
    w26,58    I26,58                          1
    w26,59    KL                              1
    w26,59    I26,59                          1
    w27,28    KL                              1
    w27,28    I27,28                          1
    w27,31    KL                              1
    w27,31    I27,31                          1
    w27,32    KL                              1
    w27,32    I27,32                          1
    w27,33    KL                              1
    w27,33    I27,33                          1
    w27,34    KL                              1
    w27,34    I27,34                          1
    w27,35    KL                              1
    w27,35    I27,35                          1
    w27,36    KL                              1
    w27,36    I27,36                          1
    w27,39    KL                              1
    w27,39    I27,39                          1
    w27,40    KL                              1
    w27,40    I27,40                          1
    w27,41    KL                              1
    w27,41    I27,41                          1
    w27,42    KL                              1
    w27,42    I27,42                          1
    w27,43    KL                              1
    w27,43    I27,43                          1
    w27,44    KL                              1
    w27,44    I27,44                          1
    w27,46    KL                              1
    w27,46    I27,46                          1
    w27,47    KL                              1
    w27,47    I27,47                          1
    w27,49    KL                              1
    w27,49    I27,49                          1
    w27,50    KL                              1
    w27,50    I27,50                          1
    w27,51    KL                              1
    w27,51    I27,51                          1
    w27,52    KL                              1
    w27,52    I27,52                          1
    w27,53    KL                              1
    w27,53    I27,53                          1
    w27,55    KL                              1
    w27,55    I27,55                          1
    w27,56    KL                              1
    w27,56    I27,56                          1
    w27,57    KL                              1
    w27,57    I27,57                          1
    w27,59    KL                              1
    w27,59    I27,59                          1
    w28,29    KL                              1
    w28,29    I28,29                          1
    w28,30    KL                              1
    w28,30    I28,30                          1
    w28,32    KL                              1
    w28,32    I28,32                          1
    w28,33    KL                              1
    w28,33    I28,33                          1
    w28,34    KL                              1
    w28,34    I28,34                          1
    w28,35    KL                              1
    w28,35    I28,35                          1
    w28,36    KL                              1
    w28,36    I28,36                          1
    w28,38    KL                              1
    w28,38    I28,38                          1
    w28,44    KL                              1
    w28,44    I28,44                          1
    w28,47    KL                              1
    w28,47    I28,47                          1
    w28,48    KL                              1
    w28,48    I28,48                          1
    w28,49    KL                              1
    w28,49    I28,49                          1
    w28,50    KL                              1
    w28,50    I28,50                          1
    w28,51    KL                              1
    w28,51    I28,51                          1
    w28,53    KL                              1
    w28,53    I28,53                          1
    w28,54    KL                              1
    w28,54    I28,54                          1
    w28,57    KL                              1
    w28,57    I28,57                          1
    w28,58    KL                              1
    w28,58    I28,58                          1
    w29,30    KL                              1
    w29,30    I29,30                          1
    w29,33    KL                              1
    w29,33    I29,33                          1
    w29,34    KL                              1
    w29,34    I29,34                          1
    w29,38    KL                              1
    w29,38    I29,38                          1
    w29,42    KL                              1
    w29,42    I29,42                          1
    w29,44    KL                              1
    w29,44    I29,44                          1
    w29,46    KL                              1
    w29,46    I29,46                          1
    w29,49    KL                              1
    w29,49    I29,49                          1
    w29,50    KL                              1
    w29,50    I29,50                          1
    w29,51    KL                              1
    w29,51    I29,51                          1
    w29,53    KL                              1
    w29,53    I29,53                          1
    w29,54    KL                              1
    w29,54    I29,54                          1
    w29,55    KL                              1
    w29,55    I29,55                          1
    w29,56    KL                              1
    w29,56    I29,56                          1
    w29,57    KL                              1
    w29,57    I29,57                          1
    w29,58    KL                              1
    w29,58    I29,58                          1
    w29,59    KL                              1
    w29,59    I29,59                          1
    w30,31    KL                              1
    w30,31    I30,31                          1
    w30,35    KL                              1
    w30,35    I30,35                          1
    w30,38    KL                              1
    w30,38    I30,38                          1
    w30,39    KL                              1
    w30,39    I30,39                          1
    w30,40    KL                              1
    w30,40    I30,40                          1
    w30,41    KL                              1
    w30,41    I30,41                          1
    w30,42    KL                              1
    w30,42    I30,42                          1
    w30,43    KL                              1
    w30,43    I30,43                          1
    w30,44    KL                              1
    w30,44    I30,44                          1
    w30,45    KL                              1
    w30,45    I30,45                          1
    w30,46    KL                              1
    w30,46    I30,46                          1
    w30,47    KL                              1
    w30,47    I30,47                          1
    w30,48    KL                              1
    w30,48    I30,48                          1
    w30,49    KL                              1
    w30,49    I30,49                          1
    w30,50    KL                              1
    w30,50    I30,50                          1
    w30,51    KL                              1
    w30,51    I30,51                          1
    w30,52    KL                              1
    w30,52    I30,52                          1
    w30,53    KL                              1
    w30,53    I30,53                          1
    w30,56    KL                              1
    w30,56    I30,56                          1
    w30,57    KL                              1
    w30,57    I30,57                          1
    w30,58    KL                              1
    w30,58    I30,58                          1
    w30,59    KL                              1
    w30,59    I30,59                          1
    w31,32    KL                              1
    w31,32    I31,32                          1
    w31,33    KL                              1
    w31,33    I31,33                          1
    w31,35    KL                              1
    w31,35    I31,35                          1
    w31,36    KL                              1
    w31,36    I31,36                          1
    w31,37    KL                              1
    w31,37    I31,37                          1
    w31,38    KL                              1
    w31,38    I31,38                          1
    w31,39    KL                              1
    w31,39    I31,39                          1
    w31,40    KL                              1
    w31,40    I31,40                          1
    w31,42    KL                              1
    w31,42    I31,42                          1
    w31,43    KL                              1
    w31,43    I31,43                          1
    w31,44    KL                              1
    w31,44    I31,44                          1
    w31,46    KL                              1
    w31,46    I31,46                          1
    w31,47    KL                              1
    w31,47    I31,47                          1
    w31,48    KL                              1
    w31,48    I31,48                          1
    w31,49    KL                              1
    w31,49    I31,49                          1
    w31,52    KL                              1
    w31,52    I31,52                          1
    w31,53    KL                              1
    w31,53    I31,53                          1
    w31,54    KL                              1
    w31,54    I31,54                          1
    w31,56    KL                              1
    w31,56    I31,56                          1
    w31,58    KL                              1
    w31,58    I31,58                          1
    w32,34    KL                              1
    w32,34    I32,34                          1
    w32,37    KL                              1
    w32,37    I32,37                          1
    w32,38    KL                              1
    w32,38    I32,38                          1
    w32,39    KL                              1
    w32,39    I32,39                          1
    w32,40    KL                              1
    w32,40    I32,40                          1
    w32,41    KL                              1
    w32,41    I32,41                          1
    w32,46    KL                              1
    w32,46    I32,46                          1
    w32,47    KL                              1
    w32,47    I32,47                          1
    w32,48    KL                              1
    w32,48    I32,48                          1
    w32,50    KL                              1
    w32,50    I32,50                          1
    w32,51    KL                              1
    w32,51    I32,51                          1
    w32,53    KL                              1
    w32,53    I32,53                          1
    w32,54    KL                              1
    w32,54    I32,54                          1
    w32,55    KL                              1
    w32,55    I32,55                          1
    w32,57    KL                              1
    w32,57    I32,57                          1
    w32,58    KL                              1
    w32,58    I32,58                          1
    w33,34    KL                              1
    w33,34    I33,34                          1
    w33,36    KL                              1
    w33,36    I33,36                          1
    w33,38    KL                              1
    w33,38    I33,38                          1
    w33,40    KL                              1
    w33,40    I33,40                          1
    w33,41    KL                              1
    w33,41    I33,41                          1
    w33,42    KL                              1
    w33,42    I33,42                          1
    w33,44    KL                              1
    w33,44    I33,44                          1
    w33,46    KL                              1
    w33,46    I33,46                          1
    w33,48    KL                              1
    w33,48    I33,48                          1
    w33,49    KL                              1
    w33,49    I33,49                          1
    w33,50    KL                              1
    w33,50    I33,50                          1
    w33,52    KL                              1
    w33,52    I33,52                          1
    w33,53    KL                              1
    w33,53    I33,53                          1
    w33,54    KL                              1
    w33,54    I33,54                          1
    w33,55    KL                              1
    w33,55    I33,55                          1
    w33,56    KL                              1
    w33,56    I33,56                          1
    w33,58    KL                              1
    w33,58    I33,58                          1
    w33,59    KL                              1
    w33,59    I33,59                          1
    w34,35    KL                              1
    w34,35    I34,35                          1
    w34,36    KL                              1
    w34,36    I34,36                          1
    w34,38    KL                              1
    w34,38    I34,38                          1
    w34,40    KL                              1
    w34,40    I34,40                          1
    w34,41    KL                              1
    w34,41    I34,41                          1
    w34,43    KL                              1
    w34,43    I34,43                          1
    w34,44    KL                              1
    w34,44    I34,44                          1
    w34,45    KL                              1
    w34,45    I34,45                          1
    w34,46    KL                              1
    w34,46    I34,46                          1
    w34,47    KL                              1
    w34,47    I34,47                          1
    w34,48    KL                              1
    w34,48    I34,48                          1
    w34,49    KL                              1
    w34,49    I34,49                          1
    w34,50    KL                              1
    w34,50    I34,50                          1
    w34,52    KL                              1
    w34,52    I34,52                          1
    w34,54    KL                              1
    w34,54    I34,54                          1
    w34,55    KL                              1
    w34,55    I34,55                          1
    w34,57    KL                              1
    w34,57    I34,57                          1
    w34,58    KL                              1
    w34,58    I34,58                          1
    w34,59    KL                              1
    w34,59    I34,59                          1
    w35,36    KL                              1
    w35,36    I35,36                          1
    w35,39    KL                              1
    w35,39    I35,39                          1
    w35,40    KL                              1
    w35,40    I35,40                          1
    w35,41    KL                              1
    w35,41    I35,41                          1
    w35,43    KL                              1
    w35,43    I35,43                          1
    w35,44    KL                              1
    w35,44    I35,44                          1
    w35,45    KL                              1
    w35,45    I35,45                          1
    w35,46    KL                              1
    w35,46    I35,46                          1
    w35,47    KL                              1
    w35,47    I35,47                          1
    w35,48    KL                              1
    w35,48    I35,48                          1
    w35,49    KL                              1
    w35,49    I35,49                          1
    w35,51    KL                              1
    w35,51    I35,51                          1
    w35,52    KL                              1
    w35,52    I35,52                          1
    w35,53    KL                              1
    w35,53    I35,53                          1
    w35,54    KL                              1
    w35,54    I35,54                          1
    w35,55    KL                              1
    w35,55    I35,55                          1
    w35,57    KL                              1
    w35,57    I35,57                          1
    w35,58    KL                              1
    w35,58    I35,58                          1
    w35,59    KL                              1
    w35,59    I35,59                          1
    w36,37    KL                              1
    w36,37    I36,37                          1
    w36,38    KL                              1
    w36,38    I36,38                          1
    w36,40    KL                              1
    w36,40    I36,40                          1
    w36,41    KL                              1
    w36,41    I36,41                          1
    w36,42    KL                              1
    w36,42    I36,42                          1
    w36,44    KL                              1
    w36,44    I36,44                          1
    w36,45    KL                              1
    w36,45    I36,45                          1
    w36,47    KL                              1
    w36,47    I36,47                          1
    w36,48    KL                              1
    w36,48    I36,48                          1
    w36,49    KL                              1
    w36,49    I36,49                          1
    w36,50    KL                              1
    w36,50    I36,50                          1
    w36,51    KL                              1
    w36,51    I36,51                          1
    w36,52    KL                              1
    w36,52    I36,52                          1
    w36,53    KL                              1
    w36,53    I36,53                          1
    w36,54    KL                              1
    w36,54    I36,54                          1
    w36,55    KL                              1
    w36,55    I36,55                          1
    w36,57    KL                              1
    w36,57    I36,57                          1
    w36,58    KL                              1
    w36,58    I36,58                          1
    w36,59    KL                              1
    w36,59    I36,59                          1
    w37,38    KL                              1
    w37,38    I37,38                          1
    w37,39    KL                              1
    w37,39    I37,39                          1
    w37,40    KL                              1
    w37,40    I37,40                          1
    w37,41    KL                              1
    w37,41    I37,41                          1
    w37,42    KL                              1
    w37,42    I37,42                          1
    w37,43    KL                              1
    w37,43    I37,43                          1
    w37,44    KL                              1
    w37,44    I37,44                          1
    w37,45    KL                              1
    w37,45    I37,45                          1
    w37,46    KL                              1
    w37,46    I37,46                          1
    w37,48    KL                              1
    w37,48    I37,48                          1
    w37,49    KL                              1
    w37,49    I37,49                          1
    w37,50    KL                              1
    w37,50    I37,50                          1
    w37,51    KL                              1
    w37,51    I37,51                          1
    w37,52    KL                              1
    w37,52    I37,52                          1
    w37,53    KL                              1
    w37,53    I37,53                          1
    w37,56    KL                              1
    w37,56    I37,56                          1
    w37,57    KL                              1
    w37,57    I37,57                          1
    w37,58    KL                              1
    w37,58    I37,58                          1
    w38,39    KL                              1
    w38,39    I38,39                          1
    w38,40    KL                              1
    w38,40    I38,40                          1
    w38,41    KL                              1
    w38,41    I38,41                          1
    w38,42    KL                              1
    w38,42    I38,42                          1
    w38,44    KL                              1
    w38,44    I38,44                          1
    w38,45    KL                              1
    w38,45    I38,45                          1
    w38,47    KL                              1
    w38,47    I38,47                          1
    w38,48    KL                              1
    w38,48    I38,48                          1
    w38,50    KL                              1
    w38,50    I38,50                          1
    w38,51    KL                              1
    w38,51    I38,51                          1
    w38,52    KL                              1
    w38,52    I38,52                          1
    w38,55    KL                              1
    w38,55    I38,55                          1
    w38,56    KL                              1
    w38,56    I38,56                          1
    w38,59    KL                              1
    w38,59    I38,59                          1
    w39,40    KL                              1
    w39,40    I39,40                          1
    w39,41    KL                              1
    w39,41    I39,41                          1
    w39,42    KL                              1
    w39,42    I39,42                          1
    w39,45    KL                              1
    w39,45    I39,45                          1
    w39,46    KL                              1
    w39,46    I39,46                          1
    w39,47    KL                              1
    w39,47    I39,47                          1
    w39,50    KL                              1
    w39,50    I39,50                          1
    w39,51    KL                              1
    w39,51    I39,51                          1
    w39,52    KL                              1
    w39,52    I39,52                          1
    w39,53    KL                              1
    w39,53    I39,53                          1
    w39,54    KL                              1
    w39,54    I39,54                          1
    w39,58    KL                              1
    w39,58    I39,58                          1
    w39,59    KL                              1
    w39,59    I39,59                          1
    w40,42    KL                              1
    w40,42    I40,42                          1
    w40,43    KL                              1
    w40,43    I40,43                          1
    w40,45    KL                              1
    w40,45    I40,45                          1
    w40,46    KL                              1
    w40,46    I40,46                          1
    w40,47    KL                              1
    w40,47    I40,47                          1
    w40,49    KL                              1
    w40,49    I40,49                          1
    w40,50    KL                              1
    w40,50    I40,50                          1
    w40,53    KL                              1
    w40,53    I40,53                          1
    w40,54    KL                              1
    w40,54    I40,54                          1
    w40,55    KL                              1
    w40,55    I40,55                          1
    w40,56    KL                              1
    w40,56    I40,56                          1
    w40,59    KL                              1
    w40,59    I40,59                          1
    w41,42    KL                              1
    w41,42    I41,42                          1
    w41,43    KL                              1
    w41,43    I41,43                          1
    w41,45    KL                              1
    w41,45    I41,45                          1
    w41,46    KL                              1
    w41,46    I41,46                          1
    w41,47    KL                              1
    w41,47    I41,47                          1
    w41,50    KL                              1
    w41,50    I41,50                          1
    w41,51    KL                              1
    w41,51    I41,51                          1
    w41,52    KL                              1
    w41,52    I41,52                          1
    w41,54    KL                              1
    w41,54    I41,54                          1
    w41,55    KL                              1
    w41,55    I41,55                          1
    w41,56    KL                              1
    w41,56    I41,56                          1
    w42,43    KL                              1
    w42,43    I42,43                          1
    w42,44    KL                              1
    w42,44    I42,44                          1
    w42,46    KL                              1
    w42,46    I42,46                          1
    w42,47    KL                              1
    w42,47    I42,47                          1
    w42,48    KL                              1
    w42,48    I42,48                          1
    w42,49    KL                              1
    w42,49    I42,49                          1
    w42,50    KL                              1
    w42,50    I42,50                          1
    w42,52    KL                              1
    w42,52    I42,52                          1
    w42,53    KL                              1
    w42,53    I42,53                          1
    w42,54    KL                              1
    w42,54    I42,54                          1
    w42,56    KL                              1
    w42,56    I42,56                          1
    w42,58    KL                              1
    w42,58    I42,58                          1
    w42,59    KL                              1
    w42,59    I42,59                          1
    w43,44    KL                              1
    w43,44    I43,44                          1
    w43,45    KL                              1
    w43,45    I43,45                          1
    w43,46    KL                              1
    w43,46    I43,46                          1
    w43,48    KL                              1
    w43,48    I43,48                          1
    w43,50    KL                              1
    w43,50    I43,50                          1
    w43,52    KL                              1
    w43,52    I43,52                          1
    w43,54    KL                              1
    w43,54    I43,54                          1
    w43,56    KL                              1
    w43,56    I43,56                          1
    w43,59    KL                              1
    w43,59    I43,59                          1
    w44,47    KL                              1
    w44,47    I44,47                          1
    w44,48    KL                              1
    w44,48    I44,48                          1
    w44,50    KL                              1
    w44,50    I44,50                          1
    w44,51    KL                              1
    w44,51    I44,51                          1
    w44,52    KL                              1
    w44,52    I44,52                          1
    w44,53    KL                              1
    w44,53    I44,53                          1
    w44,54    KL                              1
    w44,54    I44,54                          1
    w44,56    KL                              1
    w44,56    I44,56                          1
    w44,57    KL                              1
    w44,57    I44,57                          1
    w44,59    KL                              1
    w44,59    I44,59                          1
    w45,47    KL                              1
    w45,47    I45,47                          1
    w45,50    KL                              1
    w45,50    I45,50                          1
    w45,54    KL                              1
    w45,54    I45,54                          1
    w45,56    KL                              1
    w45,56    I45,56                          1
    w45,58    KL                              1
    w45,58    I45,58                          1
    w45,59    KL                              1
    w45,59    I45,59                          1
    w46,47    KL                              1
    w46,47    I46,47                          1
    w46,49    KL                              1
    w46,49    I46,49                          1
    w46,50    KL                              1
    w46,50    I46,50                          1
    w46,51    KL                              1
    w46,51    I46,51                          1
    w46,53    KL                              1
    w46,53    I46,53                          1
    w46,54    KL                              1
    w46,54    I46,54                          1
    w46,55    KL                              1
    w46,55    I46,55                          1
    w46,56    KL                              1
    w46,56    I46,56                          1
    w46,58    KL                              1
    w46,58    I46,58                          1
    w46,59    KL                              1
    w46,59    I46,59                          1
    w47,48    KL                              1
    w47,48    I47,48                          1
    w47,49    KL                              1
    w47,49    I47,49                          1
    w47,50    KL                              1
    w47,50    I47,50                          1
    w47,51    KL                              1
    w47,51    I47,51                          1
    w47,52    KL                              1
    w47,52    I47,52                          1
    w47,53    KL                              1
    w47,53    I47,53                          1
    w47,55    KL                              1
    w47,55    I47,55                          1
    w47,56    KL                              1
    w47,56    I47,56                          1
    w47,57    KL                              1
    w47,57    I47,57                          1
    w47,58    KL                              1
    w47,58    I47,58                          1
    w47,59    KL                              1
    w47,59    I47,59                          1
    w48,49    KL                              1
    w48,49    I48,49                          1
    w48,50    KL                              1
    w48,50    I48,50                          1
    w48,51    KL                              1
    w48,51    I48,51                          1
    w48,53    KL                              1
    w48,53    I48,53                          1
    w48,54    KL                              1
    w48,54    I48,54                          1
    w48,55    KL                              1
    w48,55    I48,55                          1
    w48,56    KL                              1
    w48,56    I48,56                          1
    w48,57    KL                              1
    w48,57    I48,57                          1
    w48,58    KL                              1
    w48,58    I48,58                          1
    w48,59    KL                              1
    w48,59    I48,59                          1
    w49,50    KL                              1
    w49,50    I49,50                          1
    w49,53    KL                              1
    w49,53    I49,53                          1
    w49,55    KL                              1
    w49,55    I49,55                          1
    w49,56    KL                              1
    w49,56    I49,56                          1
    w49,57    KL                              1
    w49,57    I49,57                          1
    w49,58    KL                              1
    w49,58    I49,58                          1
    w49,59    KL                              1
    w49,59    I49,59                          1
    w50,52    KL                              1
    w50,52    I50,52                          1
    w50,54    KL                              1
    w50,54    I50,54                          1
    w50,55    KL                              1
    w50,55    I50,55                          1
    w50,56    KL                              1
    w50,56    I50,56                          1
    w50,57    KL                              1
    w50,57    I50,57                          1
    w50,59    KL                              1
    w50,59    I50,59                          1
    w51,52    KL                              1
    w51,52    I51,52                          1
    w51,53    KL                              1
    w51,53    I51,53                          1
    w51,55    KL                              1
    w51,55    I51,55                          1
    w51,59    KL                              1
    w51,59    I51,59                          1
    w52,53    KL                              1
    w52,53    I52,53                          1
    w52,54    KL                              1
    w52,54    I52,54                          1
    w52,58    KL                              1
    w52,58    I52,58                          1
    w53,55    KL                              1
    w53,55    I53,55                          1
    w53,56    KL                              1
    w53,56    I53,56                          1
    w53,57    KL                              1
    w53,57    I53,57                          1
    w53,58    KL                              1
    w53,58    I53,58                          1
    w53,59    KL                              1
    w53,59    I53,59                          1
    w54,55    KL                              1
    w54,55    I54,55                          1
    w54,56    KL                              1
    w54,56    I54,56                          1
    w54,57    KL                              1
    w54,57    I54,57                          1
    w54,58    KL                              1
    w54,58    I54,58                          1
    w54,59    KL                              1
    w54,59    I54,59                          1
    w55,56    KL                              1
    w55,56    I55,56                          1
    w55,57    KL                              1
    w55,57    I55,57                          1
    w55,58    KL                              1
    w55,58    I55,58                          1
    w55,59    KL                              1
    w55,59    I55,59                          1
    w56,58    KL                              1
    w56,58    I56,58                          1
    w57,59    KL                              1
    w57,59    I57,59                          1
    w58,59    KL                              1
    w58,59    I58,59                          1
    y0,1      E0,1                           -1
    y0,1      I0,1                            1
    y0,2      E0,2                           -1
    y0,2      I0,2                            1
    y0,4      E0,4                           -1
    y0,4      I0,4                            1
    y0,7      E0,7                           -1
    y0,7      I0,7                            1
    y0,8      E0,8                           -1
    y0,8      I0,8                            1
    y0,9      E0,9                           -1
    y0,9      I0,9                            1
    y0,10     E0,10                          -1
    y0,10     I0,10                           1
    y0,11     E0,11                          -1
    y0,11     I0,11                           1
    y0,12     E0,12                          -1
    y0,12     I0,12                           1
    y0,13     E0,13                          -1
    y0,13     I0,13                           1
    y0,14     E0,14                          -1
    y0,14     I0,14                           1
    y0,15     E0,15                          -1
    y0,15     I0,15                           1
    y0,16     E0,16                          -1
    y0,16     I0,16                           1
    y0,17     E0,17                          -1
    y0,17     I0,17                           1
    y0,18     E0,18                          -1
    y0,18     I0,18                           1
    y0,20     E0,20                          -1
    y0,20     I0,20                           1
    y0,21     E0,21                          -1
    y0,21     I0,21                           1
    y0,23     E0,23                          -1
    y0,23     I0,23                           1
    y0,25     E0,25                          -1
    y0,25     I0,25                           1
    y0,27     E0,27                          -1
    y0,27     I0,27                           1
    y0,28     E0,28                          -1
    y0,28     I0,28                           1
    y0,29     E0,29                          -1
    y0,29     I0,29                           1
    y0,30     E0,30                          -1
    y0,30     I0,30                           1
    y0,31     E0,31                          -1
    y0,31     I0,31                           1
    y0,32     E0,32                          -1
    y0,32     I0,32                           1
    y0,33     E0,33                          -1
    y0,33     I0,33                           1
    y0,34     E0,34                          -1
    y0,34     I0,34                           1
    y0,35     E0,35                          -1
    y0,35     I0,35                           1
    y0,39     E0,39                          -1
    y0,39     I0,39                           1
    y0,41     E0,41                          -1
    y0,41     I0,41                           1
    y0,42     E0,42                          -1
    y0,42     I0,42                           1
    y0,45     E0,45                          -1
    y0,45     I0,45                           1
    y0,46     E0,46                          -1
    y0,46     I0,46                           1
    y0,48     E0,48                          -1
    y0,48     I0,48                           1
    y0,49     E0,49                          -1
    y0,49     I0,49                           1
    y0,52     E0,52                          -1
    y0,52     I0,52                           1
    y0,53     E0,53                          -1
    y0,53     I0,53                           1
    y0,54     E0,54                          -1
    y0,54     I0,54                           1
    y0,55     E0,55                          -1
    y0,55     I0,55                           1
    y0,57     E0,57                          -1
    y0,57     I0,57                           1
    y0,59     E0,59                          -1
    y0,59     I0,59                           1
    y1,2      E1,2                           -1
    y1,2      I1,2                            1
    y1,3      E1,3                           -1
    y1,3      I1,3                            1
    y1,4      E1,4                           -1
    y1,4      I1,4                            1
    y1,5      E1,5                           -1
    y1,5      I1,5                            1
    y1,6      E1,6                           -1
    y1,6      I1,6                            1
    y1,7      E1,7                           -1
    y1,7      I1,7                            1
    y1,8      E1,8                           -1
    y1,8      I1,8                            1
    y1,10     E1,10                          -1
    y1,10     I1,10                           1
    y1,12     E1,12                          -1
    y1,12     I1,12                           1
    y1,13     E1,13                          -1
    y1,13     I1,13                           1
    y1,14     E1,14                          -1
    y1,14     I1,14                           1
    y1,15     E1,15                          -1
    y1,15     I1,15                           1
    y1,16     E1,16                          -1
    y1,16     I1,16                           1
    y1,17     E1,17                          -1
    y1,17     I1,17                           1
    y1,18     E1,18                          -1
    y1,18     I1,18                           1
    y1,19     E1,19                          -1
    y1,19     I1,19                           1
    y1,22     E1,22                          -1
    y1,22     I1,22                           1
    y1,23     E1,23                          -1
    y1,23     I1,23                           1
    y1,25     E1,25                          -1
    y1,25     I1,25                           1
    y1,26     E1,26                          -1
    y1,26     I1,26                           1
    y1,28     E1,28                          -1
    y1,28     I1,28                           1
    y1,29     E1,29                          -1
    y1,29     I1,29                           1
    y1,31     E1,31                          -1
    y1,31     I1,31                           1
    y1,32     E1,32                          -1
    y1,32     I1,32                           1
    y1,34     E1,34                          -1
    y1,34     I1,34                           1
    y1,36     E1,36                          -1
    y1,36     I1,36                           1
    y1,37     E1,37                          -1
    y1,37     I1,37                           1
    y1,39     E1,39                          -1
    y1,39     I1,39                           1
    y1,40     E1,40                          -1
    y1,40     I1,40                           1
    y1,42     E1,42                          -1
    y1,42     I1,42                           1
    y1,44     E1,44                          -1
    y1,44     I1,44                           1
    y1,48     E1,48                          -1
    y1,48     I1,48                           1
    y1,49     E1,49                          -1
    y1,49     I1,49                           1
    y1,51     E1,51                          -1
    y1,51     I1,51                           1
    y1,52     E1,52                          -1
    y1,52     I1,52                           1
    y1,53     E1,53                          -1
    y1,53     I1,53                           1
    y1,54     E1,54                          -1
    y1,54     I1,54                           1
    y1,55     E1,55                          -1
    y1,55     I1,55                           1
    y1,56     E1,56                          -1
    y1,56     I1,56                           1
    y1,58     E1,58                          -1
    y1,58     I1,58                           1
    y1,59     E1,59                          -1
    y1,59     I1,59                           1
    y2,3      E2,3                           -1
    y2,3      I2,3                            1
    y2,4      E2,4                           -1
    y2,4      I2,4                            1
    y2,6      E2,6                           -1
    y2,6      I2,6                            1
    y2,9      E2,9                           -1
    y2,9      I2,9                            1
    y2,11     E2,11                          -1
    y2,11     I2,11                           1
    y2,12     E2,12                          -1
    y2,12     I2,12                           1
    y2,14     E2,14                          -1
    y2,14     I2,14                           1
    y2,15     E2,15                          -1
    y2,15     I2,15                           1
    y2,16     E2,16                          -1
    y2,16     I2,16                           1
    y2,17     E2,17                          -1
    y2,17     I2,17                           1
    y2,18     E2,18                          -1
    y2,18     I2,18                           1
    y2,19     E2,19                          -1
    y2,19     I2,19                           1
    y2,21     E2,21                          -1
    y2,21     I2,21                           1
    y2,22     E2,22                          -1
    y2,22     I2,22                           1
    y2,23     E2,23                          -1
    y2,23     I2,23                           1
    y2,24     E2,24                          -1
    y2,24     I2,24                           1
    y2,25     E2,25                          -1
    y2,25     I2,25                           1
    y2,27     E2,27                          -1
    y2,27     I2,27                           1
    y2,28     E2,28                          -1
    y2,28     I2,28                           1
    y2,29     E2,29                          -1
    y2,29     I2,29                           1
    y2,30     E2,30                          -1
    y2,30     I2,30                           1
    y2,31     E2,31                          -1
    y2,31     I2,31                           1
    y2,33     E2,33                          -1
    y2,33     I2,33                           1
    y2,34     E2,34                          -1
    y2,34     I2,34                           1
    y2,35     E2,35                          -1
    y2,35     I2,35                           1
    y2,38     E2,38                          -1
    y2,38     I2,38                           1
    y2,39     E2,39                          -1
    y2,39     I2,39                           1
    y2,40     E2,40                          -1
    y2,40     I2,40                           1
    y2,41     E2,41                          -1
    y2,41     I2,41                           1
    y2,42     E2,42                          -1
    y2,42     I2,42                           1
    y2,48     E2,48                          -1
    y2,48     I2,48                           1
    y2,50     E2,50                          -1
    y2,50     I2,50                           1
    y2,51     E2,51                          -1
    y2,51     I2,51                           1
    y2,52     E2,52                          -1
    y2,52     I2,52                           1
    y2,53     E2,53                          -1
    y2,53     I2,53                           1
    y2,55     E2,55                          -1
    y2,55     I2,55                           1
    y2,56     E2,56                          -1
    y2,56     I2,56                           1
    y2,57     E2,57                          -1
    y2,57     I2,57                           1
    y2,58     E2,58                          -1
    y2,58     I2,58                           1
    y2,59     E2,59                          -1
    y2,59     I2,59                           1
    y3,5      E3,5                           -1
    y3,5      I3,5                            1
    y3,6      E3,6                           -1
    y3,6      I3,6                            1
    y3,8      E3,8                           -1
    y3,8      I3,8                            1
    y3,9      E3,9                           -1
    y3,9      I3,9                            1
    y3,10     E3,10                          -1
    y3,10     I3,10                           1
    y3,11     E3,11                          -1
    y3,11     I3,11                           1
    y3,12     E3,12                          -1
    y3,12     I3,12                           1
    y3,13     E3,13                          -1
    y3,13     I3,13                           1
    y3,15     E3,15                          -1
    y3,15     I3,15                           1
    y3,17     E3,17                          -1
    y3,17     I3,17                           1
    y3,18     E3,18                          -1
    y3,18     I3,18                           1
    y3,19     E3,19                          -1
    y3,19     I3,19                           1
    y3,20     E3,20                          -1
    y3,20     I3,20                           1
    y3,22     E3,22                          -1
    y3,22     I3,22                           1
    y3,25     E3,25                          -1
    y3,25     I3,25                           1
    y3,26     E3,26                          -1
    y3,26     I3,26                           1
    y3,27     E3,27                          -1
    y3,27     I3,27                           1
    y3,28     E3,28                          -1
    y3,28     I3,28                           1
    y3,29     E3,29                          -1
    y3,29     I3,29                           1
    y3,31     E3,31                          -1
    y3,31     I3,31                           1
    y3,32     E3,32                          -1
    y3,32     I3,32                           1
    y3,34     E3,34                          -1
    y3,34     I3,34                           1
    y3,35     E3,35                          -1
    y3,35     I3,35                           1
    y3,37     E3,37                          -1
    y3,37     I3,37                           1
    y3,39     E3,39                          -1
    y3,39     I3,39                           1
    y3,42     E3,42                          -1
    y3,42     I3,42                           1
    y3,43     E3,43                          -1
    y3,43     I3,43                           1
    y3,45     E3,45                          -1
    y3,45     I3,45                           1
    y3,47     E3,47                          -1
    y3,47     I3,47                           1
    y3,48     E3,48                          -1
    y3,48     I3,48                           1
    y3,49     E3,49                          -1
    y3,49     I3,49                           1
    y3,50     E3,50                          -1
    y3,50     I3,50                           1
    y3,51     E3,51                          -1
    y3,51     I3,51                           1
    y3,52     E3,52                          -1
    y3,52     I3,52                           1
    y3,53     E3,53                          -1
    y3,53     I3,53                           1
    y3,54     E3,54                          -1
    y3,54     I3,54                           1
    y3,55     E3,55                          -1
    y3,55     I3,55                           1
    y3,56     E3,56                          -1
    y3,56     I3,56                           1
    y3,57     E3,57                          -1
    y3,57     I3,57                           1
    y3,59     E3,59                          -1
    y3,59     I3,59                           1
    y4,5      E4,5                           -1
    y4,5      I4,5                            1
    y4,7      E4,7                           -1
    y4,7      I4,7                            1
    y4,8      E4,8                           -1
    y4,8      I4,8                            1
    y4,10     E4,10                          -1
    y4,10     I4,10                           1
    y4,13     E4,13                          -1
    y4,13     I4,13                           1
    y4,14     E4,14                          -1
    y4,14     I4,14                           1
    y4,15     E4,15                          -1
    y4,15     I4,15                           1
    y4,16     E4,16                          -1
    y4,16     I4,16                           1
    y4,19     E4,19                          -1
    y4,19     I4,19                           1
    y4,20     E4,20                          -1
    y4,20     I4,20                           1
    y4,22     E4,22                          -1
    y4,22     I4,22                           1
    y4,24     E4,24                          -1
    y4,24     I4,24                           1
    y4,25     E4,25                          -1
    y4,25     I4,25                           1
    y4,26     E4,26                          -1
    y4,26     I4,26                           1
    y4,27     E4,27                          -1
    y4,27     I4,27                           1
    y4,30     E4,30                          -1
    y4,30     I4,30                           1
    y4,33     E4,33                          -1
    y4,33     I4,33                           1
    y4,36     E4,36                          -1
    y4,36     I4,36                           1
    y4,37     E4,37                          -1
    y4,37     I4,37                           1
    y4,38     E4,38                          -1
    y4,38     I4,38                           1
    y4,40     E4,40                          -1
    y4,40     I4,40                           1
    y4,41     E4,41                          -1
    y4,41     I4,41                           1
    y4,43     E4,43                          -1
    y4,43     I4,43                           1
    y4,46     E4,46                          -1
    y4,46     I4,46                           1
    y4,47     E4,47                          -1
    y4,47     I4,47                           1
    y4,48     E4,48                          -1
    y4,48     I4,48                           1
    y4,49     E4,49                          -1
    y4,49     I4,49                           1
    y4,51     E4,51                          -1
    y4,51     I4,51                           1
    y4,53     E4,53                          -1
    y4,53     I4,53                           1
    y4,55     E4,55                          -1
    y4,55     I4,55                           1
    y4,56     E4,56                          -1
    y4,56     I4,56                           1
    y4,57     E4,57                          -1
    y4,57     I4,57                           1
    y4,58     E4,58                          -1
    y4,58     I4,58                           1
    y5,7      E5,7                           -1
    y5,7      I5,7                            1
    y5,8      E5,8                           -1
    y5,8      I5,8                            1
    y5,9      E5,9                           -1
    y5,9      I5,9                            1
    y5,10     E5,10                          -1
    y5,10     I5,10                           1
    y5,13     E5,13                          -1
    y5,13     I5,13                           1
    y5,14     E5,14                          -1
    y5,14     I5,14                           1
    y5,15     E5,15                          -1
    y5,15     I5,15                           1
    y5,18     E5,18                          -1
    y5,18     I5,18                           1
    y5,20     E5,20                          -1
    y5,20     I5,20                           1
    y5,22     E5,22                          -1
    y5,22     I5,22                           1
    y5,23     E5,23                          -1
    y5,23     I5,23                           1
    y5,24     E5,24                          -1
    y5,24     I5,24                           1
    y5,25     E5,25                          -1
    y5,25     I5,25                           1
    y5,26     E5,26                          -1
    y5,26     I5,26                           1
    y5,27     E5,27                          -1
    y5,27     I5,27                           1
    y5,28     E5,28                          -1
    y5,28     I5,28                           1
    y5,29     E5,29                          -1
    y5,29     I5,29                           1
    y5,30     E5,30                          -1
    y5,30     I5,30                           1
    y5,31     E5,31                          -1
    y5,31     I5,31                           1
    y5,32     E5,32                          -1
    y5,32     I5,32                           1
    y5,36     E5,36                          -1
    y5,36     I5,36                           1
    y5,37     E5,37                          -1
    y5,37     I5,37                           1
    y5,38     E5,38                          -1
    y5,38     I5,38                           1
    y5,40     E5,40                          -1
    y5,40     I5,40                           1
    y5,43     E5,43                          -1
    y5,43     I5,43                           1
    y5,46     E5,46                          -1
    y5,46     I5,46                           1
    y5,47     E5,47                          -1
    y5,47     I5,47                           1
    y5,48     E5,48                          -1
    y5,48     I5,48                           1
    y5,49     E5,49                          -1
    y5,49     I5,49                           1
    y5,50     E5,50                          -1
    y5,50     I5,50                           1
    y5,51     E5,51                          -1
    y5,51     I5,51                           1
    y5,52     E5,52                          -1
    y5,52     I5,52                           1
    y5,53     E5,53                          -1
    y5,53     I5,53                           1
    y5,54     E5,54                          -1
    y5,54     I5,54                           1
    y6,7      E6,7                           -1
    y6,7      I6,7                            1
    y6,8      E6,8                           -1
    y6,8      I6,8                            1
    y6,10     E6,10                          -1
    y6,10     I6,10                           1
    y6,15     E6,15                          -1
    y6,15     I6,15                           1
    y6,17     E6,17                          -1
    y6,17     I6,17                           1
    y6,19     E6,19                          -1
    y6,19     I6,19                           1
    y6,22     E6,22                          -1
    y6,22     I6,22                           1
    y6,23     E6,23                          -1
    y6,23     I6,23                           1
    y6,24     E6,24                          -1
    y6,24     I6,24                           1
    y6,27     E6,27                          -1
    y6,27     I6,27                           1
    y6,30     E6,30                          -1
    y6,30     I6,30                           1
    y6,34     E6,34                          -1
    y6,34     I6,34                           1
    y6,35     E6,35                          -1
    y6,35     I6,35                           1
    y6,36     E6,36                          -1
    y6,36     I6,36                           1
    y6,37     E6,37                          -1
    y6,37     I6,37                           1
    y6,38     E6,38                          -1
    y6,38     I6,38                           1
    y6,39     E6,39                          -1
    y6,39     I6,39                           1
    y6,41     E6,41                          -1
    y6,41     I6,41                           1
    y6,43     E6,43                          -1
    y6,43     I6,43                           1
    y6,44     E6,44                          -1
    y6,44     I6,44                           1
    y6,46     E6,46                          -1
    y6,46     I6,46                           1
    y6,48     E6,48                          -1
    y6,48     I6,48                           1
    y6,49     E6,49                          -1
    y6,49     I6,49                           1
    y6,50     E6,50                          -1
    y6,50     I6,50                           1
    y6,51     E6,51                          -1
    y6,51     I6,51                           1
    y6,53     E6,53                          -1
    y6,53     I6,53                           1
    y6,54     E6,54                          -1
    y6,54     I6,54                           1
    y6,56     E6,56                          -1
    y6,56     I6,56                           1
    y6,57     E6,57                          -1
    y6,57     I6,57                           1
    y6,58     E6,58                          -1
    y6,58     I6,58                           1
    y6,59     E6,59                          -1
    y6,59     I6,59                           1
    y7,8      E7,8                           -1
    y7,8      I7,8                            1
    y7,9      E7,9                           -1
    y7,9      I7,9                            1
    y7,12     E7,12                          -1
    y7,12     I7,12                           1
    y7,15     E7,15                          -1
    y7,15     I7,15                           1
    y7,16     E7,16                          -1
    y7,16     I7,16                           1
    y7,17     E7,17                          -1
    y7,17     I7,17                           1
    y7,18     E7,18                          -1
    y7,18     I7,18                           1
    y7,19     E7,19                          -1
    y7,19     I7,19                           1
    y7,20     E7,20                          -1
    y7,20     I7,20                           1
    y7,23     E7,23                          -1
    y7,23     I7,23                           1
    y7,24     E7,24                          -1
    y7,24     I7,24                           1
    y7,26     E7,26                          -1
    y7,26     I7,26                           1
    y7,27     E7,27                          -1
    y7,27     I7,27                           1
    y7,28     E7,28                          -1
    y7,28     I7,28                           1
    y7,30     E7,30                          -1
    y7,30     I7,30                           1
    y7,32     E7,32                          -1
    y7,32     I7,32                           1
    y7,33     E7,33                          -1
    y7,33     I7,33                           1
    y7,34     E7,34                          -1
    y7,34     I7,34                           1
    y7,35     E7,35                          -1
    y7,35     I7,35                           1
    y7,36     E7,36                          -1
    y7,36     I7,36                           1
    y7,38     E7,38                          -1
    y7,38     I7,38                           1
    y7,40     E7,40                          -1
    y7,40     I7,40                           1
    y7,41     E7,41                          -1
    y7,41     I7,41                           1
    y7,42     E7,42                          -1
    y7,42     I7,42                           1
    y7,43     E7,43                          -1
    y7,43     I7,43                           1
    y7,44     E7,44                          -1
    y7,44     I7,44                           1
    y7,45     E7,45                          -1
    y7,45     I7,45                           1
    y7,46     E7,46                          -1
    y7,46     I7,46                           1
    y7,47     E7,47                          -1
    y7,47     I7,47                           1
    y7,50     E7,50                          -1
    y7,50     I7,50                           1
    y7,51     E7,51                          -1
    y7,51     I7,51                           1
    y7,52     E7,52                          -1
    y7,52     I7,52                           1
    y7,53     E7,53                          -1
    y7,53     I7,53                           1
    y7,54     E7,54                          -1
    y7,54     I7,54                           1
    y7,56     E7,56                          -1
    y7,56     I7,56                           1
    y7,57     E7,57                          -1
    y7,57     I7,57                           1
    y7,58     E7,58                          -1
    y7,58     I7,58                           1
    y8,10     E8,10                          -1
    y8,10     I8,10                           1
    y8,12     E8,12                          -1
    y8,12     I8,12                           1
    y8,13     E8,13                          -1
    y8,13     I8,13                           1
    y8,14     E8,14                          -1
    y8,14     I8,14                           1
    y8,15     E8,15                          -1
    y8,15     I8,15                           1
    y8,16     E8,16                          -1
    y8,16     I8,16                           1
    y8,18     E8,18                          -1
    y8,18     I8,18                           1
    y8,19     E8,19                          -1
    y8,19     I8,19                           1
    y8,20     E8,20                          -1
    y8,20     I8,20                           1
    y8,21     E8,21                          -1
    y8,21     I8,21                           1
    y8,22     E8,22                          -1
    y8,22     I8,22                           1
    y8,23     E8,23                          -1
    y8,23     I8,23                           1
    y8,24     E8,24                          -1
    y8,24     I8,24                           1
    y8,25     E8,25                          -1
    y8,25     I8,25                           1
    y8,26     E8,26                          -1
    y8,26     I8,26                           1
    y8,27     E8,27                          -1
    y8,27     I8,27                           1
    y8,28     E8,28                          -1
    y8,28     I8,28                           1
    y8,30     E8,30                          -1
    y8,30     I8,30                           1
    y8,31     E8,31                          -1
    y8,31     I8,31                           1
    y8,32     E8,32                          -1
    y8,32     I8,32                           1
    y8,33     E8,33                          -1
    y8,33     I8,33                           1
    y8,34     E8,34                          -1
    y8,34     I8,34                           1
    y8,37     E8,37                          -1
    y8,37     I8,37                           1
    y8,39     E8,39                          -1
    y8,39     I8,39                           1
    y8,40     E8,40                          -1
    y8,40     I8,40                           1
    y8,41     E8,41                          -1
    y8,41     I8,41                           1
    y8,42     E8,42                          -1
    y8,42     I8,42                           1
    y8,43     E8,43                          -1
    y8,43     I8,43                           1
    y8,44     E8,44                          -1
    y8,44     I8,44                           1
    y8,45     E8,45                          -1
    y8,45     I8,45                           1
    y8,46     E8,46                          -1
    y8,46     I8,46                           1
    y8,49     E8,49                          -1
    y8,49     I8,49                           1
    y8,50     E8,50                          -1
    y8,50     I8,50                           1
    y8,51     E8,51                          -1
    y8,51     I8,51                           1
    y8,53     E8,53                          -1
    y8,53     I8,53                           1
    y8,54     E8,54                          -1
    y8,54     I8,54                           1
    y8,55     E8,55                          -1
    y8,55     I8,55                           1
    y8,56     E8,56                          -1
    y8,56     I8,56                           1
    y8,57     E8,57                          -1
    y8,57     I8,57                           1
    y8,58     E8,58                          -1
    y8,58     I8,58                           1
    y9,12     E9,12                          -1
    y9,12     I9,12                           1
    y9,15     E9,15                          -1
    y9,15     I9,15                           1
    y9,16     E9,16                          -1
    y9,16     I9,16                           1
    y9,19     E9,19                          -1
    y9,19     I9,19                           1
    y9,21     E9,21                          -1
    y9,21     I9,21                           1
    y9,22     E9,22                          -1
    y9,22     I9,22                           1
    y9,23     E9,23                          -1
    y9,23     I9,23                           1
    y9,25     E9,25                          -1
    y9,25     I9,25                           1
    y9,26     E9,26                          -1
    y9,26     I9,26                           1
    y9,28     E9,28                          -1
    y9,28     I9,28                           1
    y9,29     E9,29                          -1
    y9,29     I9,29                           1
    y9,30     E9,30                          -1
    y9,30     I9,30                           1
    y9,31     E9,31                          -1
    y9,31     I9,31                           1
    y9,32     E9,32                          -1
    y9,32     I9,32                           1
    y9,33     E9,33                          -1
    y9,33     I9,33                           1
    y9,34     E9,34                          -1
    y9,34     I9,34                           1
    y9,35     E9,35                          -1
    y9,35     I9,35                           1
    y9,36     E9,36                          -1
    y9,36     I9,36                           1
    y9,37     E9,37                          -1
    y9,37     I9,37                           1
    y9,38     E9,38                          -1
    y9,38     I9,38                           1
    y9,39     E9,39                          -1
    y9,39     I9,39                           1
    y9,40     E9,40                          -1
    y9,40     I9,40                           1
    y9,41     E9,41                          -1
    y9,41     I9,41                           1
    y9,42     E9,42                          -1
    y9,42     I9,42                           1
    y9,43     E9,43                          -1
    y9,43     I9,43                           1
    y9,44     E9,44                          -1
    y9,44     I9,44                           1
    y9,45     E9,45                          -1
    y9,45     I9,45                           1
    y9,46     E9,46                          -1
    y9,46     I9,46                           1
    y9,49     E9,49                          -1
    y9,49     I9,49                           1
    y9,50     E9,50                          -1
    y9,50     I9,50                           1
    y9,52     E9,52                          -1
    y9,52     I9,52                           1
    y9,54     E9,54                          -1
    y9,54     I9,54                           1
    y9,55     E9,55                          -1
    y9,55     I9,55                           1
    y9,58     E9,58                          -1
    y9,58     I9,58                           1
    y9,59     E9,59                          -1
    y9,59     I9,59                           1
    y10,11    E10,11                         -1
    y10,11    I10,11                          1
    y10,13    E10,13                         -1
    y10,13    I10,13                          1
    y10,15    E10,15                         -1
    y10,15    I10,15                          1
    y10,16    E10,16                         -1
    y10,16    I10,16                          1
    y10,18    E10,18                         -1
    y10,18    I10,18                          1
    y10,19    E10,19                         -1
    y10,19    I10,19                          1
    y10,21    E10,21                         -1
    y10,21    I10,21                          1
    y10,23    E10,23                         -1
    y10,23    I10,23                          1
    y10,25    E10,25                         -1
    y10,25    I10,25                          1
    y10,26    E10,26                         -1
    y10,26    I10,26                          1
    y10,27    E10,27                         -1
    y10,27    I10,27                          1
    y10,28    E10,28                         -1
    y10,28    I10,28                          1
    y10,29    E10,29                         -1
    y10,29    I10,29                          1
    y10,30    E10,30                         -1
    y10,30    I10,30                          1
    y10,31    E10,31                         -1
    y10,31    I10,31                          1
    y10,32    E10,32                         -1
    y10,32    I10,32                          1
    y10,34    E10,34                         -1
    y10,34    I10,34                          1
    y10,35    E10,35                         -1
    y10,35    I10,35                          1
    y10,36    E10,36                         -1
    y10,36    I10,36                          1
    y10,38    E10,38                         -1
    y10,38    I10,38                          1
    y10,39    E10,39                         -1
    y10,39    I10,39                          1
    y10,40    E10,40                         -1
    y10,40    I10,40                          1
    y10,41    E10,41                         -1
    y10,41    I10,41                          1
    y10,42    E10,42                         -1
    y10,42    I10,42                          1
    y10,44    E10,44                         -1
    y10,44    I10,44                          1
    y10,45    E10,45                         -1
    y10,45    I10,45                          1
    y10,46    E10,46                         -1
    y10,46    I10,46                          1
    y10,47    E10,47                         -1
    y10,47    I10,47                          1
    y10,48    E10,48                         -1
    y10,48    I10,48                          1
    y10,50    E10,50                         -1
    y10,50    I10,50                          1
    y10,51    E10,51                         -1
    y10,51    I10,51                          1
    y10,52    E10,52                         -1
    y10,52    I10,52                          1
    y10,53    E10,53                         -1
    y10,53    I10,53                          1
    y10,54    E10,54                         -1
    y10,54    I10,54                          1
    y10,56    E10,56                         -1
    y10,56    I10,56                          1
    y10,57    E10,57                         -1
    y10,57    I10,57                          1
    y10,59    E10,59                         -1
    y10,59    I10,59                          1
    y11,12    E11,12                         -1
    y11,12    I11,12                          1
    y11,14    E11,14                         -1
    y11,14    I11,14                          1
    y11,15    E11,15                         -1
    y11,15    I11,15                          1
    y11,17    E11,17                         -1
    y11,17    I11,17                          1
    y11,21    E11,21                         -1
    y11,21    I11,21                          1
    y11,23    E11,23                         -1
    y11,23    I11,23                          1
    y11,25    E11,25                         -1
    y11,25    I11,25                          1
    y11,26    E11,26                         -1
    y11,26    I11,26                          1
    y11,29    E11,29                         -1
    y11,29    I11,29                          1
    y11,30    E11,30                         -1
    y11,30    I11,30                          1
    y11,31    E11,31                         -1
    y11,31    I11,31                          1
    y11,32    E11,32                         -1
    y11,32    I11,32                          1
    y11,33    E11,33                         -1
    y11,33    I11,33                          1
    y11,34    E11,34                         -1
    y11,34    I11,34                          1
    y11,35    E11,35                         -1
    y11,35    I11,35                          1
    y11,36    E11,36                         -1
    y11,36    I11,36                          1
    y11,37    E11,37                         -1
    y11,37    I11,37                          1
    y11,38    E11,38                         -1
    y11,38    I11,38                          1
    y11,39    E11,39                         -1
    y11,39    I11,39                          1
    y11,40    E11,40                         -1
    y11,40    I11,40                          1
    y11,42    E11,42                         -1
    y11,42    I11,42                          1
    y11,45    E11,45                         -1
    y11,45    I11,45                          1
    y11,46    E11,46                         -1
    y11,46    I11,46                          1
    y11,47    E11,47                         -1
    y11,47    I11,47                          1
    y11,48    E11,48                         -1
    y11,48    I11,48                          1
    y11,49    E11,49                         -1
    y11,49    I11,49                          1
    y11,52    E11,52                         -1
    y11,52    I11,52                          1
    y11,53    E11,53                         -1
    y11,53    I11,53                          1
    y11,54    E11,54                         -1
    y11,54    I11,54                          1
    y11,56    E11,56                         -1
    y11,56    I11,56                          1
    y11,57    E11,57                         -1
    y11,57    I11,57                          1
    y11,58    E11,58                         -1
    y11,58    I11,58                          1
    y11,59    E11,59                         -1
    y11,59    I11,59                          1
    y12,14    E12,14                         -1
    y12,14    I12,14                          1
    y12,15    E12,15                         -1
    y12,15    I12,15                          1
    y12,16    E12,16                         -1
    y12,16    I12,16                          1
    y12,17    E12,17                         -1
    y12,17    I12,17                          1
    y12,19    E12,19                         -1
    y12,19    I12,19                          1
    y12,20    E12,20                         -1
    y12,20    I12,20                          1
    y12,22    E12,22                         -1
    y12,22    I12,22                          1
    y12,23    E12,23                         -1
    y12,23    I12,23                          1
    y12,25    E12,25                         -1
    y12,25    I12,25                          1
    y12,26    E12,26                         -1
    y12,26    I12,26                          1
    y12,27    E12,27                         -1
    y12,27    I12,27                          1
    y12,29    E12,29                         -1
    y12,29    I12,29                          1
    y12,30    E12,30                         -1
    y12,30    I12,30                          1
    y12,31    E12,31                         -1
    y12,31    I12,31                          1
    y12,32    E12,32                         -1
    y12,32    I12,32                          1
    y12,33    E12,33                         -1
    y12,33    I12,33                          1
    y12,34    E12,34                         -1
    y12,34    I12,34                          1
    y12,35    E12,35                         -1
    y12,35    I12,35                          1
    y12,36    E12,36                         -1
    y12,36    I12,36                          1
    y12,37    E12,37                         -1
    y12,37    I12,37                          1
    y12,38    E12,38                         -1
    y12,38    I12,38                          1
    y12,39    E12,39                         -1
    y12,39    I12,39                          1
    y12,40    E12,40                         -1
    y12,40    I12,40                          1
    y12,42    E12,42                         -1
    y12,42    I12,42                          1
    y12,43    E12,43                         -1
    y12,43    I12,43                          1
    y12,44    E12,44                         -1
    y12,44    I12,44                          1
    y12,45    E12,45                         -1
    y12,45    I12,45                          1
    y12,46    E12,46                         -1
    y12,46    I12,46                          1
    y12,47    E12,47                         -1
    y12,47    I12,47                          1
    y12,48    E12,48                         -1
    y12,48    I12,48                          1
    y12,49    E12,49                         -1
    y12,49    I12,49                          1
    y12,50    E12,50                         -1
    y12,50    I12,50                          1
    y12,52    E12,52                         -1
    y12,52    I12,52                          1
    y12,53    E12,53                         -1
    y12,53    I12,53                          1
    y12,54    E12,54                         -1
    y12,54    I12,54                          1
    y12,55    E12,55                         -1
    y12,55    I12,55                          1
    y12,56    E12,56                         -1
    y12,56    I12,56                          1
    y12,58    E12,58                         -1
    y12,58    I12,58                          1
    y12,59    E12,59                         -1
    y12,59    I12,59                          1
    y13,14    E13,14                         -1
    y13,14    I13,14                          1
    y13,16    E13,16                         -1
    y13,16    I13,16                          1
    y13,17    E13,17                         -1
    y13,17    I13,17                          1
    y13,19    E13,19                         -1
    y13,19    I13,19                          1
    y13,20    E13,20                         -1
    y13,20    I13,20                          1
    y13,21    E13,21                         -1
    y13,21    I13,21                          1
    y13,22    E13,22                         -1
    y13,22    I13,22                          1
    y13,23    E13,23                         -1
    y13,23    I13,23                          1
    y13,24    E13,24                         -1
    y13,24    I13,24                          1
    y13,27    E13,27                         -1
    y13,27    I13,27                          1
    y13,28    E13,28                         -1
    y13,28    I13,28                          1
    y13,32    E13,32                         -1
    y13,32    I13,32                          1
    y13,33    E13,33                         -1
    y13,33    I13,33                          1
    y13,34    E13,34                         -1
    y13,34    I13,34                          1
    y13,36    E13,36                         -1
    y13,36    I13,36                          1
    y13,38    E13,38                         -1
    y13,38    I13,38                          1
    y13,39    E13,39                         -1
    y13,39    I13,39                          1
    y13,40    E13,40                         -1
    y13,40    I13,40                          1
    y13,41    E13,41                         -1
    y13,41    I13,41                          1
    y13,42    E13,42                         -1
    y13,42    I13,42                          1
    y13,43    E13,43                         -1
    y13,43    I13,43                          1
    y13,46    E13,46                         -1
    y13,46    I13,46                          1
    y13,50    E13,50                         -1
    y13,50    I13,50                          1
    y13,51    E13,51                         -1
    y13,51    I13,51                          1
    y13,53    E13,53                         -1
    y13,53    I13,53                          1
    y13,55    E13,55                         -1
    y13,55    I13,55                          1
    y13,56    E13,56                         -1
    y13,56    I13,56                          1
    y13,57    E13,57                         -1
    y13,57    I13,57                          1
    y13,58    E13,58                         -1
    y13,58    I13,58                          1
    y13,59    E13,59                         -1
    y13,59    I13,59                          1
    y14,18    E14,18                         -1
    y14,18    I14,18                          1
    y14,19    E14,19                         -1
    y14,19    I14,19                          1
    y14,20    E14,20                         -1
    y14,20    I14,20                          1
    y14,21    E14,21                         -1
    y14,21    I14,21                          1
    y14,25    E14,25                         -1
    y14,25    I14,25                          1
    y14,27    E14,27                         -1
    y14,27    I14,27                          1
    y14,28    E14,28                         -1
    y14,28    I14,28                          1
    y14,29    E14,29                         -1
    y14,29    I14,29                          1
    y14,31    E14,31                         -1
    y14,31    I14,31                          1
    y14,33    E14,33                         -1
    y14,33    I14,33                          1
    y14,35    E14,35                         -1
    y14,35    I14,35                          1
    y14,36    E14,36                         -1
    y14,36    I14,36                          1
    y14,37    E14,37                         -1
    y14,37    I14,37                          1
    y14,38    E14,38                         -1
    y14,38    I14,38                          1
    y14,40    E14,40                         -1
    y14,40    I14,40                          1
    y14,43    E14,43                         -1
    y14,43    I14,43                          1
    y14,44    E14,44                         -1
    y14,44    I14,44                          1
    y14,45    E14,45                         -1
    y14,45    I14,45                          1
    y14,46    E14,46                         -1
    y14,46    I14,46                          1
    y14,47    E14,47                         -1
    y14,47    I14,47                          1
    y14,48    E14,48                         -1
    y14,48    I14,48                          1
    y14,49    E14,49                         -1
    y14,49    I14,49                          1
    y14,50    E14,50                         -1
    y14,50    I14,50                          1
    y14,51    E14,51                         -1
    y14,51    I14,51                          1
    y14,52    E14,52                         -1
    y14,52    I14,52                          1
    y14,53    E14,53                         -1
    y14,53    I14,53                          1
    y14,54    E14,54                         -1
    y14,54    I14,54                          1
    y14,56    E14,56                         -1
    y14,56    I14,56                          1
    y14,57    E14,57                         -1
    y14,57    I14,57                          1
    y14,58    E14,58                         -1
    y14,58    I14,58                          1
    y15,16    E15,16                         -1
    y15,16    I15,16                          1
    y15,17    E15,17                         -1
    y15,17    I15,17                          1
    y15,18    E15,18                         -1
    y15,18    I15,18                          1
    y15,20    E15,20                         -1
    y15,20    I15,20                          1
    y15,23    E15,23                         -1
    y15,23    I15,23                          1
    y15,25    E15,25                         -1
    y15,25    I15,25                          1
    y15,26    E15,26                         -1
    y15,26    I15,26                          1
    y15,28    E15,28                         -1
    y15,28    I15,28                          1
    y15,32    E15,32                         -1
    y15,32    I15,32                          1
    y15,33    E15,33                         -1
    y15,33    I15,33                          1
    y15,35    E15,35                         -1
    y15,35    I15,35                          1
    y15,36    E15,36                         -1
    y15,36    I15,36                          1
    y15,37    E15,37                         -1
    y15,37    I15,37                          1
    y15,39    E15,39                         -1
    y15,39    I15,39                          1
    y15,41    E15,41                         -1
    y15,41    I15,41                          1
    y15,45    E15,45                         -1
    y15,45    I15,45                          1
    y15,46    E15,46                         -1
    y15,46    I15,46                          1
    y15,47    E15,47                         -1
    y15,47    I15,47                          1
    y15,49    E15,49                         -1
    y15,49    I15,49                          1
    y15,50    E15,50                         -1
    y15,50    I15,50                          1
    y15,51    E15,51                         -1
    y15,51    I15,51                          1
    y15,54    E15,54                         -1
    y15,54    I15,54                          1
    y15,55    E15,55                         -1
    y15,55    I15,55                          1
    y15,57    E15,57                         -1
    y15,57    I15,57                          1
    y15,58    E15,58                         -1
    y15,58    I15,58                          1
    y15,59    E15,59                         -1
    y15,59    I15,59                          1
    y16,17    E16,17                         -1
    y16,17    I16,17                          1
    y16,18    E16,18                         -1
    y16,18    I16,18                          1
    y16,19    E16,19                         -1
    y16,19    I16,19                          1
    y16,20    E16,20                         -1
    y16,20    I16,20                          1
    y16,21    E16,21                         -1
    y16,21    I16,21                          1
    y16,25    E16,25                         -1
    y16,25    I16,25                          1
    y16,28    E16,28                         -1
    y16,28    I16,28                          1
    y16,29    E16,29                         -1
    y16,29    I16,29                          1
    y16,30    E16,30                         -1
    y16,30    I16,30                          1
    y16,31    E16,31                         -1
    y16,31    I16,31                          1
    y16,32    E16,32                         -1
    y16,32    I16,32                          1
    y16,33    E16,33                         -1
    y16,33    I16,33                          1
    y16,35    E16,35                         -1
    y16,35    I16,35                          1
    y16,36    E16,36                         -1
    y16,36    I16,36                          1
    y16,37    E16,37                         -1
    y16,37    I16,37                          1
    y16,38    E16,38                         -1
    y16,38    I16,38                          1
    y16,40    E16,40                         -1
    y16,40    I16,40                          1
    y16,41    E16,41                         -1
    y16,41    I16,41                          1
    y16,42    E16,42                         -1
    y16,42    I16,42                          1
    y16,43    E16,43                         -1
    y16,43    I16,43                          1
    y16,46    E16,46                         -1
    y16,46    I16,46                          1
    y16,47    E16,47                         -1
    y16,47    I16,47                          1
    y16,49    E16,49                         -1
    y16,49    I16,49                          1
    y16,51    E16,51                         -1
    y16,51    I16,51                          1
    y16,52    E16,52                         -1
    y16,52    I16,52                          1
    y16,53    E16,53                         -1
    y16,53    I16,53                          1
    y16,54    E16,54                         -1
    y16,54    I16,54                          1
    y16,57    E16,57                         -1
    y16,57    I16,57                          1
    y16,59    E16,59                         -1
    y16,59    I16,59                          1
    y17,18    E17,18                         -1
    y17,18    I17,18                          1
    y17,20    E17,20                         -1
    y17,20    I17,20                          1
    y17,21    E17,21                         -1
    y17,21    I17,21                          1
    y17,22    E17,22                         -1
    y17,22    I17,22                          1
    y17,23    E17,23                         -1
    y17,23    I17,23                          1
    y17,25    E17,25                         -1
    y17,25    I17,25                          1
    y17,26    E17,26                         -1
    y17,26    I17,26                          1
    y17,28    E17,28                         -1
    y17,28    I17,28                          1
    y17,29    E17,29                         -1
    y17,29    I17,29                          1
    y17,30    E17,30                         -1
    y17,30    I17,30                          1
    y17,32    E17,32                         -1
    y17,32    I17,32                          1
    y17,33    E17,33                         -1
    y17,33    I17,33                          1
    y17,35    E17,35                         -1
    y17,35    I17,35                          1
    y17,36    E17,36                         -1
    y17,36    I17,36                          1
    y17,37    E17,37                         -1
    y17,37    I17,37                          1
    y17,38    E17,38                         -1
    y17,38    I17,38                          1
    y17,41    E17,41                         -1
    y17,41    I17,41                          1
    y17,42    E17,42                         -1
    y17,42    I17,42                          1
    y17,44    E17,44                         -1
    y17,44    I17,44                          1
    y17,45    E17,45                         -1
    y17,45    I17,45                          1
    y17,46    E17,46                         -1
    y17,46    I17,46                          1
    y17,47    E17,47                         -1
    y17,47    I17,47                          1
    y17,48    E17,48                         -1
    y17,48    I17,48                          1
    y17,49    E17,49                         -1
    y17,49    I17,49                          1
    y17,51    E17,51                         -1
    y17,51    I17,51                          1
    y17,53    E17,53                         -1
    y17,53    I17,53                          1
    y17,54    E17,54                         -1
    y17,54    I17,54                          1
    y17,55    E17,55                         -1
    y17,55    I17,55                          1
    y17,58    E17,58                         -1
    y17,58    I17,58                          1
    y17,59    E17,59                         -1
    y17,59    I17,59                          1
    y18,19    E18,19                         -1
    y18,19    I18,19                          1
    y18,22    E18,22                         -1
    y18,22    I18,22                          1
    y18,23    E18,23                         -1
    y18,23    I18,23                          1
    y18,25    E18,25                         -1
    y18,25    I18,25                          1
    y18,26    E18,26                         -1
    y18,26    I18,26                          1
    y18,28    E18,28                         -1
    y18,28    I18,28                          1
    y18,29    E18,29                         -1
    y18,29    I18,29                          1
    y18,30    E18,30                         -1
    y18,30    I18,30                          1
    y18,31    E18,31                         -1
    y18,31    I18,31                          1
    y18,32    E18,32                         -1
    y18,32    I18,32                          1
    y18,33    E18,33                         -1
    y18,33    I18,33                          1
    y18,34    E18,34                         -1
    y18,34    I18,34                          1
    y18,35    E18,35                         -1
    y18,35    I18,35                          1
    y18,36    E18,36                         -1
    y18,36    I18,36                          1
    y18,37    E18,37                         -1
    y18,37    I18,37                          1
    y18,38    E18,38                         -1
    y18,38    I18,38                          1
    y18,39    E18,39                         -1
    y18,39    I18,39                          1
    y18,40    E18,40                         -1
    y18,40    I18,40                          1
    y18,41    E18,41                         -1
    y18,41    I18,41                          1
    y18,42    E18,42                         -1
    y18,42    I18,42                          1
    y18,43    E18,43                         -1
    y18,43    I18,43                          1
    y18,44    E18,44                         -1
    y18,44    I18,44                          1
    y18,45    E18,45                         -1
    y18,45    I18,45                          1
    y18,47    E18,47                         -1
    y18,47    I18,47                          1
    y18,48    E18,48                         -1
    y18,48    I18,48                          1
    y18,50    E18,50                         -1
    y18,50    I18,50                          1
    y18,51    E18,51                         -1
    y18,51    I18,51                          1
    y18,52    E18,52                         -1
    y18,52    I18,52                          1
    y18,53    E18,53                         -1
    y18,53    I18,53                          1
    y18,54    E18,54                         -1
    y18,54    I18,54                          1
    y18,55    E18,55                         -1
    y18,55    I18,55                          1
    y18,56    E18,56                         -1
    y18,56    I18,56                          1
    y18,57    E18,57                         -1
    y18,57    I18,57                          1
    y18,59    E18,59                         -1
    y18,59    I18,59                          1
    y19,20    E19,20                         -1
    y19,20    I19,20                          1
    y19,21    E19,21                         -1
    y19,21    I19,21                          1
    y19,22    E19,22                         -1
    y19,22    I19,22                          1
    y19,24    E19,24                         -1
    y19,24    I19,24                          1
    y19,28    E19,28                         -1
    y19,28    I19,28                          1
    y19,29    E19,29                         -1
    y19,29    I19,29                          1
    y19,30    E19,30                         -1
    y19,30    I19,30                          1
    y19,31    E19,31                         -1
    y19,31    I19,31                          1
    y19,32    E19,32                         -1
    y19,32    I19,32                          1
    y19,36    E19,36                         -1
    y19,36    I19,36                          1
    y19,37    E19,37                         -1
    y19,37    I19,37                          1
    y19,39    E19,39                         -1
    y19,39    I19,39                          1
    y19,40    E19,40                         -1
    y19,40    I19,40                          1
    y19,42    E19,42                         -1
    y19,42    I19,42                          1
    y19,43    E19,43                         -1
    y19,43    I19,43                          1
    y19,44    E19,44                         -1
    y19,44    I19,44                          1
    y19,45    E19,45                         -1
    y19,45    I19,45                          1
    y19,49    E19,49                         -1
    y19,49    I19,49                          1
    y19,50    E19,50                         -1
    y19,50    I19,50                          1
    y19,51    E19,51                         -1
    y19,51    I19,51                          1
    y19,52    E19,52                         -1
    y19,52    I19,52                          1
    y19,53    E19,53                         -1
    y19,53    I19,53                          1
    y19,54    E19,54                         -1
    y19,54    I19,54                          1
    y19,55    E19,55                         -1
    y19,55    I19,55                          1
    y19,58    E19,58                         -1
    y19,58    I19,58                          1
    y19,59    E19,59                         -1
    y19,59    I19,59                          1
    y20,21    E20,21                         -1
    y20,21    I20,21                          1
    y20,22    E20,22                         -1
    y20,22    I20,22                          1
    y20,23    E20,23                         -1
    y20,23    I20,23                          1
    y20,24    E20,24                         -1
    y20,24    I20,24                          1
    y20,26    E20,26                         -1
    y20,26    I20,26                          1
    y20,27    E20,27                         -1
    y20,27    I20,27                          1
    y20,28    E20,28                         -1
    y20,28    I20,28                          1
    y20,29    E20,29                         -1
    y20,29    I20,29                          1
    y20,30    E20,30                         -1
    y20,30    I20,30                          1
    y20,32    E20,32                         -1
    y20,32    I20,32                          1
    y20,34    E20,34                         -1
    y20,34    I20,34                          1
    y20,35    E20,35                         -1
    y20,35    I20,35                          1
    y20,36    E20,36                         -1
    y20,36    I20,36                          1
    y20,39    E20,39                         -1
    y20,39    I20,39                          1
    y20,41    E20,41                         -1
    y20,41    I20,41                          1
    y20,42    E20,42                         -1
    y20,42    I20,42                          1
    y20,43    E20,43                         -1
    y20,43    I20,43                          1
    y20,44    E20,44                         -1
    y20,44    I20,44                          1
    y20,45    E20,45                         -1
    y20,45    I20,45                          1
    y20,47    E20,47                         -1
    y20,47    I20,47                          1
    y20,48    E20,48                         -1
    y20,48    I20,48                          1
    y20,49    E20,49                         -1
    y20,49    I20,49                          1
    y20,50    E20,50                         -1
    y20,50    I20,50                          1
    y20,52    E20,52                         -1
    y20,52    I20,52                          1
    y20,53    E20,53                         -1
    y20,53    I20,53                          1
    y20,55    E20,55                         -1
    y20,55    I20,55                          1
    y20,56    E20,56                         -1
    y20,56    I20,56                          1
    y20,57    E20,57                         -1
    y20,57    I20,57                          1
    y21,24    E21,24                         -1
    y21,24    I21,24                          1
    y21,25    E21,25                         -1
    y21,25    I21,25                          1
    y21,26    E21,26                         -1
    y21,26    I21,26                          1
    y21,27    E21,27                         -1
    y21,27    I21,27                          1
    y21,30    E21,30                         -1
    y21,30    I21,30                          1
    y21,32    E21,32                         -1
    y21,32    I21,32                          1
    y21,34    E21,34                         -1
    y21,34    I21,34                          1
    y21,35    E21,35                         -1
    y21,35    I21,35                          1
    y21,36    E21,36                         -1
    y21,36    I21,36                          1
    y21,37    E21,37                         -1
    y21,37    I21,37                          1
    y21,38    E21,38                         -1
    y21,38    I21,38                          1
    y21,39    E21,39                         -1
    y21,39    I21,39                          1
    y21,41    E21,41                         -1
    y21,41    I21,41                          1
    y21,42    E21,42                         -1
    y21,42    I21,42                          1
    y21,44    E21,44                         -1
    y21,44    I21,44                          1
    y21,45    E21,45                         -1
    y21,45    I21,45                          1
    y21,47    E21,47                         -1
    y21,47    I21,47                          1
    y21,49    E21,49                         -1
    y21,49    I21,49                          1
    y21,50    E21,50                         -1
    y21,50    I21,50                          1
    y21,52    E21,52                         -1
    y21,52    I21,52                          1
    y21,53    E21,53                         -1
    y21,53    I21,53                          1
    y21,54    E21,54                         -1
    y21,54    I21,54                          1
    y21,55    E21,55                         -1
    y21,55    I21,55                          1
    y21,56    E21,56                         -1
    y21,56    I21,56                          1
    y21,57    E21,57                         -1
    y21,57    I21,57                          1
    y22,25    E22,25                         -1
    y22,25    I22,25                          1
    y22,26    E22,26                         -1
    y22,26    I22,26                          1
    y22,27    E22,27                         -1
    y22,27    I22,27                          1
    y22,28    E22,28                         -1
    y22,28    I22,28                          1
    y22,29    E22,29                         -1
    y22,29    I22,29                          1
    y22,30    E22,30                         -1
    y22,30    I22,30                          1
    y22,31    E22,31                         -1
    y22,31    I22,31                          1
    y22,32    E22,32                         -1
    y22,32    I22,32                          1
    y22,33    E22,33                         -1
    y22,33    I22,33                          1
    y22,37    E22,37                         -1
    y22,37    I22,37                          1
    y22,38    E22,38                         -1
    y22,38    I22,38                          1
    y22,39    E22,39                         -1
    y22,39    I22,39                          1
    y22,41    E22,41                         -1
    y22,41    I22,41                          1
    y22,42    E22,42                         -1
    y22,42    I22,42                          1
    y22,44    E22,44                         -1
    y22,44    I22,44                          1
    y22,45    E22,45                         -1
    y22,45    I22,45                          1
    y22,46    E22,46                         -1
    y22,46    I22,46                          1
    y22,47    E22,47                         -1
    y22,47    I22,47                          1
    y22,48    E22,48                         -1
    y22,48    I22,48                          1
    y22,49    E22,49                         -1
    y22,49    I22,49                          1
    y22,50    E22,50                         -1
    y22,50    I22,50                          1
    y22,51    E22,51                         -1
    y22,51    I22,51                          1
    y22,53    E22,53                         -1
    y22,53    I22,53                          1
    y22,56    E22,56                         -1
    y22,56    I22,56                          1
    y22,58    E22,58                         -1
    y22,58    I22,58                          1
    y22,59    E22,59                         -1
    y22,59    I22,59                          1
    y23,24    E23,24                         -1
    y23,24    I23,24                          1
    y23,25    E23,25                         -1
    y23,25    I23,25                          1
    y23,26    E23,26                         -1
    y23,26    I23,26                          1
    y23,28    E23,28                         -1
    y23,28    I23,28                          1
    y23,29    E23,29                         -1
    y23,29    I23,29                          1
    y23,30    E23,30                         -1
    y23,30    I23,30                          1
    y23,31    E23,31                         -1
    y23,31    I23,31                          1
    y23,32    E23,32                         -1
    y23,32    I23,32                          1
    y23,33    E23,33                         -1
    y23,33    I23,33                          1
    y23,34    E23,34                         -1
    y23,34    I23,34                          1
    y23,36    E23,36                         -1
    y23,36    I23,36                          1
    y23,37    E23,37                         -1
    y23,37    I23,37                          1
    y23,38    E23,38                         -1
    y23,38    I23,38                          1
    y23,39    E23,39                         -1
    y23,39    I23,39                          1
    y23,40    E23,40                         -1
    y23,40    I23,40                          1
    y23,41    E23,41                         -1
    y23,41    I23,41                          1
    y23,42    E23,42                         -1
    y23,42    I23,42                          1
    y23,43    E23,43                         -1
    y23,43    I23,43                          1
    y23,47    E23,47                         -1
    y23,47    I23,47                          1
    y23,49    E23,49                         -1
    y23,49    I23,49                          1
    y23,50    E23,50                         -1
    y23,50    I23,50                          1
    y23,51    E23,51                         -1
    y23,51    I23,51                          1
    y23,52    E23,52                         -1
    y23,52    I23,52                          1
    y23,54    E23,54                         -1
    y23,54    I23,54                          1
    y23,55    E23,55                         -1
    y23,55    I23,55                          1
    y23,56    E23,56                         -1
    y23,56    I23,56                          1
    y23,57    E23,57                         -1
    y23,57    I23,57                          1
    y23,58    E23,58                         -1
    y23,58    I23,58                          1
    y23,59    E23,59                         -1
    y23,59    I23,59                          1
    y24,25    E24,25                         -1
    y24,25    I24,25                          1
    y24,27    E24,27                         -1
    y24,27    I24,27                          1
    y24,28    E24,28                         -1
    y24,28    I24,28                          1
    y24,29    E24,29                         -1
    y24,29    I24,29                          1
    y24,30    E24,30                         -1
    y24,30    I24,30                          1
    y24,32    E24,32                         -1
    y24,32    I24,32                          1
    y24,33    E24,33                         -1
    y24,33    I24,33                          1
    y24,34    E24,34                         -1
    y24,34    I24,34                          1
    y24,35    E24,35                         -1
    y24,35    I24,35                          1
    y24,36    E24,36                         -1
    y24,36    I24,36                          1
    y24,37    E24,37                         -1
    y24,37    I24,37                          1
    y24,39    E24,39                         -1
    y24,39    I24,39                          1
    y24,41    E24,41                         -1
    y24,41    I24,41                          1
    y24,42    E24,42                         -1
    y24,42    I24,42                          1
    y24,43    E24,43                         -1
    y24,43    I24,43                          1
    y24,44    E24,44                         -1
    y24,44    I24,44                          1
    y24,45    E24,45                         -1
    y24,45    I24,45                          1
    y24,46    E24,46                         -1
    y24,46    I24,46                          1
    y24,47    E24,47                         -1
    y24,47    I24,47                          1
    y24,48    E24,48                         -1
    y24,48    I24,48                          1
    y24,49    E24,49                         -1
    y24,49    I24,49                          1
    y24,50    E24,50                         -1
    y24,50    I24,50                          1
    y24,51    E24,51                         -1
    y24,51    I24,51                          1
    y24,52    E24,52                         -1
    y24,52    I24,52                          1
    y24,53    E24,53                         -1
    y24,53    I24,53                          1
    y24,56    E24,56                         -1
    y24,56    I24,56                          1
    y24,57    E24,57                         -1
    y24,57    I24,57                          1
    y24,59    E24,59                         -1
    y24,59    I24,59                          1
    y25,26    E25,26                         -1
    y25,26    I25,26                          1
    y25,28    E25,28                         -1
    y25,28    I25,28                          1
    y25,31    E25,31                         -1
    y25,31    I25,31                          1
    y25,32    E25,32                         -1
    y25,32    I25,32                          1
    y25,33    E25,33                         -1
    y25,33    I25,33                          1
    y25,34    E25,34                         -1
    y25,34    I25,34                          1
    y25,35    E25,35                         -1
    y25,35    I25,35                          1
    y25,37    E25,37                         -1
    y25,37    I25,37                          1
    y25,38    E25,38                         -1
    y25,38    I25,38                          1
    y25,39    E25,39                         -1
    y25,39    I25,39                          1
    y25,40    E25,40                         -1
    y25,40    I25,40                          1
    y25,42    E25,42                         -1
    y25,42    I25,42                          1
    y25,44    E25,44                         -1
    y25,44    I25,44                          1
    y25,45    E25,45                         -1
    y25,45    I25,45                          1
    y25,47    E25,47                         -1
    y25,47    I25,47                          1
    y25,48    E25,48                         -1
    y25,48    I25,48                          1
    y25,49    E25,49                         -1
    y25,49    I25,49                          1
    y25,50    E25,50                         -1
    y25,50    I25,50                          1
    y25,51    E25,51                         -1
    y25,51    I25,51                          1
    y25,52    E25,52                         -1
    y25,52    I25,52                          1
    y25,53    E25,53                         -1
    y25,53    I25,53                          1
    y25,54    E25,54                         -1
    y25,54    I25,54                          1
    y25,55    E25,55                         -1
    y25,55    I25,55                          1
    y25,56    E25,56                         -1
    y25,56    I25,56                          1
    y25,57    E25,57                         -1
    y25,57    I25,57                          1
    y25,59    E25,59                         -1
    y25,59    I25,59                          1
    y26,29    E26,29                         -1
    y26,29    I26,29                          1
    y26,30    E26,30                         -1
    y26,30    I26,30                          1
    y26,31    E26,31                         -1
    y26,31    I26,31                          1
    y26,32    E26,32                         -1
    y26,32    I26,32                          1
    y26,34    E26,34                         -1
    y26,34    I26,34                          1
    y26,35    E26,35                         -1
    y26,35    I26,35                          1
    y26,36    E26,36                         -1
    y26,36    I26,36                          1
    y26,37    E26,37                         -1
    y26,37    I26,37                          1
    y26,38    E26,38                         -1
    y26,38    I26,38                          1
    y26,39    E26,39                         -1
    y26,39    I26,39                          1
    y26,40    E26,40                         -1
    y26,40    I26,40                          1
    y26,41    E26,41                         -1
    y26,41    I26,41                          1
    y26,42    E26,42                         -1
    y26,42    I26,42                          1
    y26,43    E26,43                         -1
    y26,43    I26,43                          1
    y26,45    E26,45                         -1
    y26,45    I26,45                          1
    y26,46    E26,46                         -1
    y26,46    I26,46                          1
    y26,48    E26,48                         -1
    y26,48    I26,48                          1
    y26,49    E26,49                         -1
    y26,49    I26,49                          1
    y26,50    E26,50                         -1
    y26,50    I26,50                          1
    y26,51    E26,51                         -1
    y26,51    I26,51                          1
    y26,55    E26,55                         -1
    y26,55    I26,55                          1
    y26,56    E26,56                         -1
    y26,56    I26,56                          1
    y26,57    E26,57                         -1
    y26,57    I26,57                          1
    y26,58    E26,58                         -1
    y26,58    I26,58                          1
    y26,59    E26,59                         -1
    y26,59    I26,59                          1
    y27,28    E27,28                         -1
    y27,28    I27,28                          1
    y27,31    E27,31                         -1
    y27,31    I27,31                          1
    y27,32    E27,32                         -1
    y27,32    I27,32                          1
    y27,33    E27,33                         -1
    y27,33    I27,33                          1
    y27,34    E27,34                         -1
    y27,34    I27,34                          1
    y27,35    E27,35                         -1
    y27,35    I27,35                          1
    y27,36    E27,36                         -1
    y27,36    I27,36                          1
    y27,39    E27,39                         -1
    y27,39    I27,39                          1
    y27,40    E27,40                         -1
    y27,40    I27,40                          1
    y27,41    E27,41                         -1
    y27,41    I27,41                          1
    y27,42    E27,42                         -1
    y27,42    I27,42                          1
    y27,43    E27,43                         -1
    y27,43    I27,43                          1
    y27,44    E27,44                         -1
    y27,44    I27,44                          1
    y27,46    E27,46                         -1
    y27,46    I27,46                          1
    y27,47    E27,47                         -1
    y27,47    I27,47                          1
    y27,49    E27,49                         -1
    y27,49    I27,49                          1
    y27,50    E27,50                         -1
    y27,50    I27,50                          1
    y27,51    E27,51                         -1
    y27,51    I27,51                          1
    y27,52    E27,52                         -1
    y27,52    I27,52                          1
    y27,53    E27,53                         -1
    y27,53    I27,53                          1
    y27,55    E27,55                         -1
    y27,55    I27,55                          1
    y27,56    E27,56                         -1
    y27,56    I27,56                          1
    y27,57    E27,57                         -1
    y27,57    I27,57                          1
    y27,59    E27,59                         -1
    y27,59    I27,59                          1
    y28,29    E28,29                         -1
    y28,29    I28,29                          1
    y28,30    E28,30                         -1
    y28,30    I28,30                          1
    y28,32    E28,32                         -1
    y28,32    I28,32                          1
    y28,33    E28,33                         -1
    y28,33    I28,33                          1
    y28,34    E28,34                         -1
    y28,34    I28,34                          1
    y28,35    E28,35                         -1
    y28,35    I28,35                          1
    y28,36    E28,36                         -1
    y28,36    I28,36                          1
    y28,38    E28,38                         -1
    y28,38    I28,38                          1
    y28,44    E28,44                         -1
    y28,44    I28,44                          1
    y28,47    E28,47                         -1
    y28,47    I28,47                          1
    y28,48    E28,48                         -1
    y28,48    I28,48                          1
    y28,49    E28,49                         -1
    y28,49    I28,49                          1
    y28,50    E28,50                         -1
    y28,50    I28,50                          1
    y28,51    E28,51                         -1
    y28,51    I28,51                          1
    y28,53    E28,53                         -1
    y28,53    I28,53                          1
    y28,54    E28,54                         -1
    y28,54    I28,54                          1
    y28,57    E28,57                         -1
    y28,57    I28,57                          1
    y28,58    E28,58                         -1
    y28,58    I28,58                          1
    y29,30    E29,30                         -1
    y29,30    I29,30                          1
    y29,33    E29,33                         -1
    y29,33    I29,33                          1
    y29,34    E29,34                         -1
    y29,34    I29,34                          1
    y29,38    E29,38                         -1
    y29,38    I29,38                          1
    y29,42    E29,42                         -1
    y29,42    I29,42                          1
    y29,44    E29,44                         -1
    y29,44    I29,44                          1
    y29,46    E29,46                         -1
    y29,46    I29,46                          1
    y29,49    E29,49                         -1
    y29,49    I29,49                          1
    y29,50    E29,50                         -1
    y29,50    I29,50                          1
    y29,51    E29,51                         -1
    y29,51    I29,51                          1
    y29,53    E29,53                         -1
    y29,53    I29,53                          1
    y29,54    E29,54                         -1
    y29,54    I29,54                          1
    y29,55    E29,55                         -1
    y29,55    I29,55                          1
    y29,56    E29,56                         -1
    y29,56    I29,56                          1
    y29,57    E29,57                         -1
    y29,57    I29,57                          1
    y29,58    E29,58                         -1
    y29,58    I29,58                          1
    y29,59    E29,59                         -1
    y29,59    I29,59                          1
    y30,31    E30,31                         -1
    y30,31    I30,31                          1
    y30,35    E30,35                         -1
    y30,35    I30,35                          1
    y30,38    E30,38                         -1
    y30,38    I30,38                          1
    y30,39    E30,39                         -1
    y30,39    I30,39                          1
    y30,40    E30,40                         -1
    y30,40    I30,40                          1
    y30,41    E30,41                         -1
    y30,41    I30,41                          1
    y30,42    E30,42                         -1
    y30,42    I30,42                          1
    y30,43    E30,43                         -1
    y30,43    I30,43                          1
    y30,44    E30,44                         -1
    y30,44    I30,44                          1
    y30,45    E30,45                         -1
    y30,45    I30,45                          1
    y30,46    E30,46                         -1
    y30,46    I30,46                          1
    y30,47    E30,47                         -1
    y30,47    I30,47                          1
    y30,48    E30,48                         -1
    y30,48    I30,48                          1
    y30,49    E30,49                         -1
    y30,49    I30,49                          1
    y30,50    E30,50                         -1
    y30,50    I30,50                          1
    y30,51    E30,51                         -1
    y30,51    I30,51                          1
    y30,52    E30,52                         -1
    y30,52    I30,52                          1
    y30,53    E30,53                         -1
    y30,53    I30,53                          1
    y30,56    E30,56                         -1
    y30,56    I30,56                          1
    y30,57    E30,57                         -1
    y30,57    I30,57                          1
    y30,58    E30,58                         -1
    y30,58    I30,58                          1
    y30,59    E30,59                         -1
    y30,59    I30,59                          1
    y31,32    E31,32                         -1
    y31,32    I31,32                          1
    y31,33    E31,33                         -1
    y31,33    I31,33                          1
    y31,35    E31,35                         -1
    y31,35    I31,35                          1
    y31,36    E31,36                         -1
    y31,36    I31,36                          1
    y31,37    E31,37                         -1
    y31,37    I31,37                          1
    y31,38    E31,38                         -1
    y31,38    I31,38                          1
    y31,39    E31,39                         -1
    y31,39    I31,39                          1
    y31,40    E31,40                         -1
    y31,40    I31,40                          1
    y31,42    E31,42                         -1
    y31,42    I31,42                          1
    y31,43    E31,43                         -1
    y31,43    I31,43                          1
    y31,44    E31,44                         -1
    y31,44    I31,44                          1
    y31,46    E31,46                         -1
    y31,46    I31,46                          1
    y31,47    E31,47                         -1
    y31,47    I31,47                          1
    y31,48    E31,48                         -1
    y31,48    I31,48                          1
    y31,49    E31,49                         -1
    y31,49    I31,49                          1
    y31,52    E31,52                         -1
    y31,52    I31,52                          1
    y31,53    E31,53                         -1
    y31,53    I31,53                          1
    y31,54    E31,54                         -1
    y31,54    I31,54                          1
    y31,56    E31,56                         -1
    y31,56    I31,56                          1
    y31,58    E31,58                         -1
    y31,58    I31,58                          1
    y32,34    E32,34                         -1
    y32,34    I32,34                          1
    y32,37    E32,37                         -1
    y32,37    I32,37                          1
    y32,38    E32,38                         -1
    y32,38    I32,38                          1
    y32,39    E32,39                         -1
    y32,39    I32,39                          1
    y32,40    E32,40                         -1
    y32,40    I32,40                          1
    y32,41    E32,41                         -1
    y32,41    I32,41                          1
    y32,46    E32,46                         -1
    y32,46    I32,46                          1
    y32,47    E32,47                         -1
    y32,47    I32,47                          1
    y32,48    E32,48                         -1
    y32,48    I32,48                          1
    y32,50    E32,50                         -1
    y32,50    I32,50                          1
    y32,51    E32,51                         -1
    y32,51    I32,51                          1
    y32,53    E32,53                         -1
    y32,53    I32,53                          1
    y32,54    E32,54                         -1
    y32,54    I32,54                          1
    y32,55    E32,55                         -1
    y32,55    I32,55                          1
    y32,57    E32,57                         -1
    y32,57    I32,57                          1
    y32,58    E32,58                         -1
    y32,58    I32,58                          1
    y33,34    E33,34                         -1
    y33,34    I33,34                          1
    y33,36    E33,36                         -1
    y33,36    I33,36                          1
    y33,38    E33,38                         -1
    y33,38    I33,38                          1
    y33,40    E33,40                         -1
    y33,40    I33,40                          1
    y33,41    E33,41                         -1
    y33,41    I33,41                          1
    y33,42    E33,42                         -1
    y33,42    I33,42                          1
    y33,44    E33,44                         -1
    y33,44    I33,44                          1
    y33,46    E33,46                         -1
    y33,46    I33,46                          1
    y33,48    E33,48                         -1
    y33,48    I33,48                          1
    y33,49    E33,49                         -1
    y33,49    I33,49                          1
    y33,50    E33,50                         -1
    y33,50    I33,50                          1
    y33,52    E33,52                         -1
    y33,52    I33,52                          1
    y33,53    E33,53                         -1
    y33,53    I33,53                          1
    y33,54    E33,54                         -1
    y33,54    I33,54                          1
    y33,55    E33,55                         -1
    y33,55    I33,55                          1
    y33,56    E33,56                         -1
    y33,56    I33,56                          1
    y33,58    E33,58                         -1
    y33,58    I33,58                          1
    y33,59    E33,59                         -1
    y33,59    I33,59                          1
    y34,35    E34,35                         -1
    y34,35    I34,35                          1
    y34,36    E34,36                         -1
    y34,36    I34,36                          1
    y34,38    E34,38                         -1
    y34,38    I34,38                          1
    y34,40    E34,40                         -1
    y34,40    I34,40                          1
    y34,41    E34,41                         -1
    y34,41    I34,41                          1
    y34,43    E34,43                         -1
    y34,43    I34,43                          1
    y34,44    E34,44                         -1
    y34,44    I34,44                          1
    y34,45    E34,45                         -1
    y34,45    I34,45                          1
    y34,46    E34,46                         -1
    y34,46    I34,46                          1
    y34,47    E34,47                         -1
    y34,47    I34,47                          1
    y34,48    E34,48                         -1
    y34,48    I34,48                          1
    y34,49    E34,49                         -1
    y34,49    I34,49                          1
    y34,50    E34,50                         -1
    y34,50    I34,50                          1
    y34,52    E34,52                         -1
    y34,52    I34,52                          1
    y34,54    E34,54                         -1
    y34,54    I34,54                          1
    y34,55    E34,55                         -1
    y34,55    I34,55                          1
    y34,57    E34,57                         -1
    y34,57    I34,57                          1
    y34,58    E34,58                         -1
    y34,58    I34,58                          1
    y34,59    E34,59                         -1
    y34,59    I34,59                          1
    y35,36    E35,36                         -1
    y35,36    I35,36                          1
    y35,39    E35,39                         -1
    y35,39    I35,39                          1
    y35,40    E35,40                         -1
    y35,40    I35,40                          1
    y35,41    E35,41                         -1
    y35,41    I35,41                          1
    y35,43    E35,43                         -1
    y35,43    I35,43                          1
    y35,44    E35,44                         -1
    y35,44    I35,44                          1
    y35,45    E35,45                         -1
    y35,45    I35,45                          1
    y35,46    E35,46                         -1
    y35,46    I35,46                          1
    y35,47    E35,47                         -1
    y35,47    I35,47                          1
    y35,48    E35,48                         -1
    y35,48    I35,48                          1
    y35,49    E35,49                         -1
    y35,49    I35,49                          1
    y35,51    E35,51                         -1
    y35,51    I35,51                          1
    y35,52    E35,52                         -1
    y35,52    I35,52                          1
    y35,53    E35,53                         -1
    y35,53    I35,53                          1
    y35,54    E35,54                         -1
    y35,54    I35,54                          1
    y35,55    E35,55                         -1
    y35,55    I35,55                          1
    y35,57    E35,57                         -1
    y35,57    I35,57                          1
    y35,58    E35,58                         -1
    y35,58    I35,58                          1
    y35,59    E35,59                         -1
    y35,59    I35,59                          1
    y36,37    E36,37                         -1
    y36,37    I36,37                          1
    y36,38    E36,38                         -1
    y36,38    I36,38                          1
    y36,40    E36,40                         -1
    y36,40    I36,40                          1
    y36,41    E36,41                         -1
    y36,41    I36,41                          1
    y36,42    E36,42                         -1
    y36,42    I36,42                          1
    y36,44    E36,44                         -1
    y36,44    I36,44                          1
    y36,45    E36,45                         -1
    y36,45    I36,45                          1
    y36,47    E36,47                         -1
    y36,47    I36,47                          1
    y36,48    E36,48                         -1
    y36,48    I36,48                          1
    y36,49    E36,49                         -1
    y36,49    I36,49                          1
    y36,50    E36,50                         -1
    y36,50    I36,50                          1
    y36,51    E36,51                         -1
    y36,51    I36,51                          1
    y36,52    E36,52                         -1
    y36,52    I36,52                          1
    y36,53    E36,53                         -1
    y36,53    I36,53                          1
    y36,54    E36,54                         -1
    y36,54    I36,54                          1
    y36,55    E36,55                         -1
    y36,55    I36,55                          1
    y36,57    E36,57                         -1
    y36,57    I36,57                          1
    y36,58    E36,58                         -1
    y36,58    I36,58                          1
    y36,59    E36,59                         -1
    y36,59    I36,59                          1
    y37,38    E37,38                         -1
    y37,38    I37,38                          1
    y37,39    E37,39                         -1
    y37,39    I37,39                          1
    y37,40    E37,40                         -1
    y37,40    I37,40                          1
    y37,41    E37,41                         -1
    y37,41    I37,41                          1
    y37,42    E37,42                         -1
    y37,42    I37,42                          1
    y37,43    E37,43                         -1
    y37,43    I37,43                          1
    y37,44    E37,44                         -1
    y37,44    I37,44                          1
    y37,45    E37,45                         -1
    y37,45    I37,45                          1
    y37,46    E37,46                         -1
    y37,46    I37,46                          1
    y37,48    E37,48                         -1
    y37,48    I37,48                          1
    y37,49    E37,49                         -1
    y37,49    I37,49                          1
    y37,50    E37,50                         -1
    y37,50    I37,50                          1
    y37,51    E37,51                         -1
    y37,51    I37,51                          1
    y37,52    E37,52                         -1
    y37,52    I37,52                          1
    y37,53    E37,53                         -1
    y37,53    I37,53                          1
    y37,56    E37,56                         -1
    y37,56    I37,56                          1
    y37,57    E37,57                         -1
    y37,57    I37,57                          1
    y37,58    E37,58                         -1
    y37,58    I37,58                          1
    y38,39    E38,39                         -1
    y38,39    I38,39                          1
    y38,40    E38,40                         -1
    y38,40    I38,40                          1
    y38,41    E38,41                         -1
    y38,41    I38,41                          1
    y38,42    E38,42                         -1
    y38,42    I38,42                          1
    y38,44    E38,44                         -1
    y38,44    I38,44                          1
    y38,45    E38,45                         -1
    y38,45    I38,45                          1
    y38,47    E38,47                         -1
    y38,47    I38,47                          1
    y38,48    E38,48                         -1
    y38,48    I38,48                          1
    y38,50    E38,50                         -1
    y38,50    I38,50                          1
    y38,51    E38,51                         -1
    y38,51    I38,51                          1
    y38,52    E38,52                         -1
    y38,52    I38,52                          1
    y38,55    E38,55                         -1
    y38,55    I38,55                          1
    y38,56    E38,56                         -1
    y38,56    I38,56                          1
    y38,59    E38,59                         -1
    y38,59    I38,59                          1
    y39,40    E39,40                         -1
    y39,40    I39,40                          1
    y39,41    E39,41                         -1
    y39,41    I39,41                          1
    y39,42    E39,42                         -1
    y39,42    I39,42                          1
    y39,45    E39,45                         -1
    y39,45    I39,45                          1
    y39,46    E39,46                         -1
    y39,46    I39,46                          1
    y39,47    E39,47                         -1
    y39,47    I39,47                          1
    y39,50    E39,50                         -1
    y39,50    I39,50                          1
    y39,51    E39,51                         -1
    y39,51    I39,51                          1
    y39,52    E39,52                         -1
    y39,52    I39,52                          1
    y39,53    E39,53                         -1
    y39,53    I39,53                          1
    y39,54    E39,54                         -1
    y39,54    I39,54                          1
    y39,58    E39,58                         -1
    y39,58    I39,58                          1
    y39,59    E39,59                         -1
    y39,59    I39,59                          1
    y40,42    E40,42                         -1
    y40,42    I40,42                          1
    y40,43    E40,43                         -1
    y40,43    I40,43                          1
    y40,45    E40,45                         -1
    y40,45    I40,45                          1
    y40,46    E40,46                         -1
    y40,46    I40,46                          1
    y40,47    E40,47                         -1
    y40,47    I40,47                          1
    y40,49    E40,49                         -1
    y40,49    I40,49                          1
    y40,50    E40,50                         -1
    y40,50    I40,50                          1
    y40,53    E40,53                         -1
    y40,53    I40,53                          1
    y40,54    E40,54                         -1
    y40,54    I40,54                          1
    y40,55    E40,55                         -1
    y40,55    I40,55                          1
    y40,56    E40,56                         -1
    y40,56    I40,56                          1
    y40,59    E40,59                         -1
    y40,59    I40,59                          1
    y41,42    E41,42                         -1
    y41,42    I41,42                          1
    y41,43    E41,43                         -1
    y41,43    I41,43                          1
    y41,45    E41,45                         -1
    y41,45    I41,45                          1
    y41,46    E41,46                         -1
    y41,46    I41,46                          1
    y41,47    E41,47                         -1
    y41,47    I41,47                          1
    y41,50    E41,50                         -1
    y41,50    I41,50                          1
    y41,51    E41,51                         -1
    y41,51    I41,51                          1
    y41,52    E41,52                         -1
    y41,52    I41,52                          1
    y41,54    E41,54                         -1
    y41,54    I41,54                          1
    y41,55    E41,55                         -1
    y41,55    I41,55                          1
    y41,56    E41,56                         -1
    y41,56    I41,56                          1
    y42,43    E42,43                         -1
    y42,43    I42,43                          1
    y42,44    E42,44                         -1
    y42,44    I42,44                          1
    y42,46    E42,46                         -1
    y42,46    I42,46                          1
    y42,47    E42,47                         -1
    y42,47    I42,47                          1
    y42,48    E42,48                         -1
    y42,48    I42,48                          1
    y42,49    E42,49                         -1
    y42,49    I42,49                          1
    y42,50    E42,50                         -1
    y42,50    I42,50                          1
    y42,52    E42,52                         -1
    y42,52    I42,52                          1
    y42,53    E42,53                         -1
    y42,53    I42,53                          1
    y42,54    E42,54                         -1
    y42,54    I42,54                          1
    y42,56    E42,56                         -1
    y42,56    I42,56                          1
    y42,58    E42,58                         -1
    y42,58    I42,58                          1
    y42,59    E42,59                         -1
    y42,59    I42,59                          1
    y43,44    E43,44                         -1
    y43,44    I43,44                          1
    y43,45    E43,45                         -1
    y43,45    I43,45                          1
    y43,46    E43,46                         -1
    y43,46    I43,46                          1
    y43,48    E43,48                         -1
    y43,48    I43,48                          1
    y43,50    E43,50                         -1
    y43,50    I43,50                          1
    y43,52    E43,52                         -1
    y43,52    I43,52                          1
    y43,54    E43,54                         -1
    y43,54    I43,54                          1
    y43,56    E43,56                         -1
    y43,56    I43,56                          1
    y43,59    E43,59                         -1
    y43,59    I43,59                          1
    y44,47    E44,47                         -1
    y44,47    I44,47                          1
    y44,48    E44,48                         -1
    y44,48    I44,48                          1
    y44,50    E44,50                         -1
    y44,50    I44,50                          1
    y44,51    E44,51                         -1
    y44,51    I44,51                          1
    y44,52    E44,52                         -1
    y44,52    I44,52                          1
    y44,53    E44,53                         -1
    y44,53    I44,53                          1
    y44,54    E44,54                         -1
    y44,54    I44,54                          1
    y44,56    E44,56                         -1
    y44,56    I44,56                          1
    y44,57    E44,57                         -1
    y44,57    I44,57                          1
    y44,59    E44,59                         -1
    y44,59    I44,59                          1
    y45,47    E45,47                         -1
    y45,47    I45,47                          1
    y45,50    E45,50                         -1
    y45,50    I45,50                          1
    y45,54    E45,54                         -1
    y45,54    I45,54                          1
    y45,56    E45,56                         -1
    y45,56    I45,56                          1
    y45,58    E45,58                         -1
    y45,58    I45,58                          1
    y45,59    E45,59                         -1
    y45,59    I45,59                          1
    y46,47    E46,47                         -1
    y46,47    I46,47                          1
    y46,49    E46,49                         -1
    y46,49    I46,49                          1
    y46,50    E46,50                         -1
    y46,50    I46,50                          1
    y46,51    E46,51                         -1
    y46,51    I46,51                          1
    y46,53    E46,53                         -1
    y46,53    I46,53                          1
    y46,54    E46,54                         -1
    y46,54    I46,54                          1
    y46,55    E46,55                         -1
    y46,55    I46,55                          1
    y46,56    E46,56                         -1
    y46,56    I46,56                          1
    y46,58    E46,58                         -1
    y46,58    I46,58                          1
    y46,59    E46,59                         -1
    y46,59    I46,59                          1
    y47,48    E47,48                         -1
    y47,48    I47,48                          1
    y47,49    E47,49                         -1
    y47,49    I47,49                          1
    y47,50    E47,50                         -1
    y47,50    I47,50                          1
    y47,51    E47,51                         -1
    y47,51    I47,51                          1
    y47,52    E47,52                         -1
    y47,52    I47,52                          1
    y47,53    E47,53                         -1
    y47,53    I47,53                          1
    y47,55    E47,55                         -1
    y47,55    I47,55                          1
    y47,56    E47,56                         -1
    y47,56    I47,56                          1
    y47,57    E47,57                         -1
    y47,57    I47,57                          1
    y47,58    E47,58                         -1
    y47,58    I47,58                          1
    y47,59    E47,59                         -1
    y47,59    I47,59                          1
    y48,49    E48,49                         -1
    y48,49    I48,49                          1
    y48,50    E48,50                         -1
    y48,50    I48,50                          1
    y48,51    E48,51                         -1
    y48,51    I48,51                          1
    y48,53    E48,53                         -1
    y48,53    I48,53                          1
    y48,54    E48,54                         -1
    y48,54    I48,54                          1
    y48,55    E48,55                         -1
    y48,55    I48,55                          1
    y48,56    E48,56                         -1
    y48,56    I48,56                          1
    y48,57    E48,57                         -1
    y48,57    I48,57                          1
    y48,58    E48,58                         -1
    y48,58    I48,58                          1
    y48,59    E48,59                         -1
    y48,59    I48,59                          1
    y49,50    E49,50                         -1
    y49,50    I49,50                          1
    y49,53    E49,53                         -1
    y49,53    I49,53                          1
    y49,55    E49,55                         -1
    y49,55    I49,55                          1
    y49,56    E49,56                         -1
    y49,56    I49,56                          1
    y49,57    E49,57                         -1
    y49,57    I49,57                          1
    y49,58    E49,58                         -1
    y49,58    I49,58                          1
    y49,59    E49,59                         -1
    y49,59    I49,59                          1
    y50,52    E50,52                         -1
    y50,52    I50,52                          1
    y50,54    E50,54                         -1
    y50,54    I50,54                          1
    y50,55    E50,55                         -1
    y50,55    I50,55                          1
    y50,56    E50,56                         -1
    y50,56    I50,56                          1
    y50,57    E50,57                         -1
    y50,57    I50,57                          1
    y50,59    E50,59                         -1
    y50,59    I50,59                          1
    y51,52    E51,52                         -1
    y51,52    I51,52                          1
    y51,53    E51,53                         -1
    y51,53    I51,53                          1
    y51,55    E51,55                         -1
    y51,55    I51,55                          1
    y51,59    E51,59                         -1
    y51,59    I51,59                          1
    y52,53    E52,53                         -1
    y52,53    I52,53                          1
    y52,54    E52,54                         -1
    y52,54    I52,54                          1
    y52,58    E52,58                         -1
    y52,58    I52,58                          1
    y53,55    E53,55                         -1
    y53,55    I53,55                          1
    y53,56    E53,56                         -1
    y53,56    I53,56                          1
    y53,57    E53,57                         -1
    y53,57    I53,57                          1
    y53,58    E53,58                         -1
    y53,58    I53,58                          1
    y53,59    E53,59                         -1
    y53,59    I53,59                          1
    y54,55    E54,55                         -1
    y54,55    I54,55                          1
    y54,56    E54,56                         -1
    y54,56    I54,56                          1
    y54,57    E54,57                         -1
    y54,57    I54,57                          1
    y54,58    E54,58                         -1
    y54,58    I54,58                          1
    y54,59    E54,59                         -1
    y54,59    I54,59                          1
    y55,56    E55,56                         -1
    y55,56    I55,56                          1
    y55,57    E55,57                         -1
    y55,57    I55,57                          1
    y55,58    E55,58                         -1
    y55,58    I55,58                          1
    y55,59    E55,59                         -1
    y55,59    I55,59                          1
    y56,58    E56,58                         -1
    y56,58    I56,58                          1
    y57,59    E57,59                         -1
    y57,59    I57,59                          1
    y58,59    E58,59                         -1
    y58,59    I58,59                          1
    x0        cost                            1
    x0        C0,3                            1
    x0        C0,5                            1
    x0        C0,6                            1
    x0        C0,19                           1
    x0        C0,22                           1
    x0        C0,24                           1
    x0        C0,26                           1
    x0        C0,36                           1
    x0        C0,37                           1
    x0        C0,38                           1
    x0        C0,40                           1
    x0        C0,43                           1
    x0        C0,44                           1
    x0        C0,47                           1
    x0        C0,50                           1
    x0        C0,51                           1
    x0        C0,56                           1
    x0        C0,58                           1
    x0        E0,1                            1
    x0        E0,2                            1
    x0        E0,4                            1
    x0        E0,7                            1
    x0        E0,8                            1
    x0        E0,9                            1
    x0        E0,10                           1
    x0        E0,11                           1
    x0        E0,12                           1
    x0        E0,13                           1
    x0        E0,14                           1
    x0        E0,15                           1
    x0        E0,16                           1
    x0        E0,17                           1
    x0        E0,18                           1
    x0        E0,20                           1
    x0        E0,21                           1
    x0        E0,23                           1
    x0        E0,25                           1
    x0        E0,27                           1
    x0        E0,28                           1
    x0        E0,29                           1
    x0        E0,30                           1
    x0        E0,31                           1
    x0        E0,32                           1
    x0        E0,33                           1
    x0        E0,34                           1
    x0        E0,35                           1
    x0        E0,39                           1
    x0        E0,41                           1
    x0        E0,42                           1
    x0        E0,45                           1
    x0        E0,46                           1
    x0        E0,48                           1
    x0        E0,49                           1
    x0        E0,52                           1
    x0        E0,53                           1
    x0        E0,54                           1
    x0        E0,55                           1
    x0        E0,57                           1
    x0        E0,59                           1
    x1        cost                            1
    x1        C1,9                            1
    x1        C1,11                           1
    x1        C1,20                           1
    x1        C1,21                           1
    x1        C1,24                           1
    x1        C1,27                           1
    x1        C1,30                           1
    x1        C1,33                           1
    x1        C1,35                           1
    x1        C1,38                           1
    x1        C1,41                           1
    x1        C1,43                           1
    x1        C1,45                           1
    x1        C1,46                           1
    x1        C1,47                           1
    x1        C1,50                           1
    x1        C1,57                           1
    x1        E0,1                            1
    x1        E1,2                            1
    x1        E1,3                            1
    x1        E1,4                            1
    x1        E1,5                            1
    x1        E1,6                            1
    x1        E1,7                            1
    x1        E1,8                            1
    x1        E1,10                           1
    x1        E1,12                           1
    x1        E1,13                           1
    x1        E1,14                           1
    x1        E1,15                           1
    x1        E1,16                           1
    x1        E1,17                           1
    x1        E1,18                           1
    x1        E1,19                           1
    x1        E1,22                           1
    x1        E1,23                           1
    x1        E1,25                           1
    x1        E1,26                           1
    x1        E1,28                           1
    x1        E1,29                           1
    x1        E1,31                           1
    x1        E1,32                           1
    x1        E1,34                           1
    x1        E1,36                           1
    x1        E1,37                           1
    x1        E1,39                           1
    x1        E1,40                           1
    x1        E1,42                           1
    x1        E1,44                           1
    x1        E1,48                           1
    x1        E1,49                           1
    x1        E1,51                           1
    x1        E1,52                           1
    x1        E1,53                           1
    x1        E1,54                           1
    x1        E1,55                           1
    x1        E1,56                           1
    x1        E1,58                           1
    x1        E1,59                           1
    x2        cost                            1
    x2        C2,5                            1
    x2        C2,7                            1
    x2        C2,8                            1
    x2        C2,10                           1
    x2        C2,13                           1
    x2        C2,20                           1
    x2        C2,26                           1
    x2        C2,32                           1
    x2        C2,36                           1
    x2        C2,37                           1
    x2        C2,43                           1
    x2        C2,44                           1
    x2        C2,45                           1
    x2        C2,46                           1
    x2        C2,47                           1
    x2        C2,49                           1
    x2        C2,54                           1
    x2        E0,2                            1
    x2        E1,2                            1
    x2        E2,3                            1
    x2        E2,4                            1
    x2        E2,6                            1
    x2        E2,9                            1
    x2        E2,11                           1
    x2        E2,12                           1
    x2        E2,14                           1
    x2        E2,15                           1
    x2        E2,16                           1
    x2        E2,17                           1
    x2        E2,18                           1
    x2        E2,19                           1
    x2        E2,21                           1
    x2        E2,22                           1
    x2        E2,23                           1
    x2        E2,24                           1
    x2        E2,25                           1
    x2        E2,27                           1
    x2        E2,28                           1
    x2        E2,29                           1
    x2        E2,30                           1
    x2        E2,31                           1
    x2        E2,33                           1
    x2        E2,34                           1
    x2        E2,35                           1
    x2        E2,38                           1
    x2        E2,39                           1
    x2        E2,40                           1
    x2        E2,41                           1
    x2        E2,42                           1
    x2        E2,48                           1
    x2        E2,50                           1
    x2        E2,51                           1
    x2        E2,52                           1
    x2        E2,53                           1
    x2        E2,55                           1
    x2        E2,56                           1
    x2        E2,57                           1
    x2        E2,58                           1
    x2        E2,59                           1
    x3        cost                            1
    x3        C0,3                            1
    x3        C3,4                            1
    x3        C3,7                            1
    x3        C3,14                           1
    x3        C3,16                           1
    x3        C3,21                           1
    x3        C3,23                           1
    x3        C3,24                           1
    x3        C3,30                           1
    x3        C3,33                           1
    x3        C3,36                           1
    x3        C3,38                           1
    x3        C3,40                           1
    x3        C3,41                           1
    x3        C3,44                           1
    x3        C3,46                           1
    x3        C3,58                           1
    x3        E1,3                            1
    x3        E2,3                            1
    x3        E3,5                            1
    x3        E3,6                            1
    x3        E3,8                            1
    x3        E3,9                            1
    x3        E3,10                           1
    x3        E3,11                           1
    x3        E3,12                           1
    x3        E3,13                           1
    x3        E3,15                           1
    x3        E3,17                           1
    x3        E3,18                           1
    x3        E3,19                           1
    x3        E3,20                           1
    x3        E3,22                           1
    x3        E3,25                           1
    x3        E3,26                           1
    x3        E3,27                           1
    x3        E3,28                           1
    x3        E3,29                           1
    x3        E3,31                           1
    x3        E3,32                           1
    x3        E3,34                           1
    x3        E3,35                           1
    x3        E3,37                           1
    x3        E3,39                           1
    x3        E3,42                           1
    x3        E3,43                           1
    x3        E3,45                           1
    x3        E3,47                           1
    x3        E3,48                           1
    x3        E3,49                           1
    x3        E3,50                           1
    x3        E3,51                           1
    x3        E3,52                           1
    x3        E3,53                           1
    x3        E3,54                           1
    x3        E3,55                           1
    x3        E3,56                           1
    x3        E3,57                           1
    x3        E3,59                           1
    x4        cost                            1
    x4        C3,4                            1
    x4        C4,6                            1
    x4        C4,9                            1
    x4        C4,11                           1
    x4        C4,12                           1
    x4        C4,17                           1
    x4        C4,18                           1
    x4        C4,21                           1
    x4        C4,23                           1
    x4        C4,28                           1
    x4        C4,29                           1
    x4        C4,31                           1
    x4        C4,32                           1
    x4        C4,34                           1
    x4        C4,35                           1
    x4        C4,39                           1
    x4        C4,42                           1
    x4        C4,44                           1
    x4        C4,45                           1
    x4        C4,50                           1
    x4        C4,52                           1
    x4        C4,54                           1
    x4        C4,59                           1
    x4        E0,4                            1
    x4        E1,4                            1
    x4        E2,4                            1
    x4        E4,5                            1
    x4        E4,7                            1
    x4        E4,8                            1
    x4        E4,10                           1
    x4        E4,13                           1
    x4        E4,14                           1
    x4        E4,15                           1
    x4        E4,16                           1
    x4        E4,19                           1
    x4        E4,20                           1
    x4        E4,22                           1
    x4        E4,24                           1
    x4        E4,25                           1
    x4        E4,26                           1
    x4        E4,27                           1
    x4        E4,30                           1
    x4        E4,33                           1
    x4        E4,36                           1
    x4        E4,37                           1
    x4        E4,38                           1
    x4        E4,40                           1
    x4        E4,41                           1
    x4        E4,43                           1
    x4        E4,46                           1
    x4        E4,47                           1
    x4        E4,48                           1
    x4        E4,49                           1
    x4        E4,51                           1
    x4        E4,53                           1
    x4        E4,55                           1
    x4        E4,56                           1
    x4        E4,57                           1
    x4        E4,58                           1
    x5        cost                            1
    x5        C0,5                            1
    x5        C2,5                            1
    x5        C5,6                            1
    x5        C5,11                           1
    x5        C5,12                           1
    x5        C5,16                           1
    x5        C5,17                           1
    x5        C5,19                           1
    x5        C5,21                           1
    x5        C5,33                           1
    x5        C5,34                           1
    x5        C5,35                           1
    x5        C5,39                           1
    x5        C5,41                           1
    x5        C5,42                           1
    x5        C5,44                           1
    x5        C5,45                           1
    x5        C5,55                           1
    x5        C5,56                           1
    x5        C5,57                           1
    x5        C5,58                           1
    x5        C5,59                           1
    x5        E1,5                            1
    x5        E3,5                            1
    x5        E4,5                            1
    x5        E5,7                            1
    x5        E5,8                            1
    x5        E5,9                            1
    x5        E5,10                           1
    x5        E5,13                           1
    x5        E5,14                           1
    x5        E5,15                           1
    x5        E5,18                           1
    x5        E5,20                           1
    x5        E5,22                           1
    x5        E5,23                           1
    x5        E5,24                           1
    x5        E5,25                           1
    x5        E5,26                           1
    x5        E5,27                           1
    x5        E5,28                           1
    x5        E5,29                           1
    x5        E5,30                           1
    x5        E5,31                           1
    x5        E5,32                           1
    x5        E5,36                           1
    x5        E5,37                           1
    x5        E5,38                           1
    x5        E5,40                           1
    x5        E5,43                           1
    x5        E5,46                           1
    x5        E5,47                           1
    x5        E5,48                           1
    x5        E5,49                           1
    x5        E5,50                           1
    x5        E5,51                           1
    x5        E5,52                           1
    x5        E5,53                           1
    x5        E5,54                           1
    x6        cost                            1
    x6        C0,6                            1
    x6        C4,6                            1
    x6        C5,6                            1
    x6        C6,9                            1
    x6        C6,11                           1
    x6        C6,12                           1
    x6        C6,13                           1
    x6        C6,14                           1
    x6        C6,16                           1
    x6        C6,18                           1
    x6        C6,20                           1
    x6        C6,21                           1
    x6        C6,25                           1
    x6        C6,26                           1
    x6        C6,28                           1
    x6        C6,29                           1
    x6        C6,31                           1
    x6        C6,32                           1
    x6        C6,33                           1
    x6        C6,40                           1
    x6        C6,42                           1
    x6        C6,45                           1
    x6        C6,47                           1
    x6        C6,52                           1
    x6        C6,55                           1
    x6        E1,6                            1
    x6        E2,6                            1
    x6        E3,6                            1
    x6        E6,7                            1
    x6        E6,8                            1
    x6        E6,10                           1
    x6        E6,15                           1
    x6        E6,17                           1
    x6        E6,19                           1
    x6        E6,22                           1
    x6        E6,23                           1
    x6        E6,24                           1
    x6        E6,27                           1
    x6        E6,30                           1
    x6        E6,34                           1
    x6        E6,35                           1
    x6        E6,36                           1
    x6        E6,37                           1
    x6        E6,38                           1
    x6        E6,39                           1
    x6        E6,41                           1
    x6        E6,43                           1
    x6        E6,44                           1
    x6        E6,46                           1
    x6        E6,48                           1
    x6        E6,49                           1
    x6        E6,50                           1
    x6        E6,51                           1
    x6        E6,53                           1
    x6        E6,54                           1
    x6        E6,56                           1
    x6        E6,57                           1
    x6        E6,58                           1
    x6        E6,59                           1
    x7        cost                            1
    x7        C2,7                            1
    x7        C3,7                            1
    x7        C7,10                           1
    x7        C7,11                           1
    x7        C7,13                           1
    x7        C7,14                           1
    x7        C7,21                           1
    x7        C7,22                           1
    x7        C7,25                           1
    x7        C7,29                           1
    x7        C7,31                           1
    x7        C7,37                           1
    x7        C7,39                           1
    x7        C7,48                           1
    x7        C7,49                           1
    x7        C7,55                           1
    x7        C7,59                           1
    x7        E0,7                            1
    x7        E1,7                            1
    x7        E4,7                            1
    x7        E5,7                            1
    x7        E6,7                            1
    x7        E7,8                            1
    x7        E7,9                            1
    x7        E7,12                           1
    x7        E7,15                           1
    x7        E7,16                           1
    x7        E7,17                           1
    x7        E7,18                           1
    x7        E7,19                           1
    x7        E7,20                           1
    x7        E7,23                           1
    x7        E7,24                           1
    x7        E7,26                           1
    x7        E7,27                           1
    x7        E7,28                           1
    x7        E7,30                           1
    x7        E7,32                           1
    x7        E7,33                           1
    x7        E7,34                           1
    x7        E7,35                           1
    x7        E7,36                           1
    x7        E7,38                           1
    x7        E7,40                           1
    x7        E7,41                           1
    x7        E7,42                           1
    x7        E7,43                           1
    x7        E7,44                           1
    x7        E7,45                           1
    x7        E7,46                           1
    x7        E7,47                           1
    x7        E7,50                           1
    x7        E7,51                           1
    x7        E7,52                           1
    x7        E7,53                           1
    x7        E7,54                           1
    x7        E7,56                           1
    x7        E7,57                           1
    x7        E7,58                           1
    x8        cost                            1
    x8        C2,8                            1
    x8        C8,9                            1
    x8        C8,11                           1
    x8        C8,17                           1
    x8        C8,29                           1
    x8        C8,35                           1
    x8        C8,36                           1
    x8        C8,38                           1
    x8        C8,47                           1
    x8        C8,48                           1
    x8        C8,52                           1
    x8        C8,59                           1
    x8        E0,8                            1
    x8        E1,8                            1
    x8        E3,8                            1
    x8        E4,8                            1
    x8        E5,8                            1
    x8        E6,8                            1
    x8        E7,8                            1
    x8        E8,10                           1
    x8        E8,12                           1
    x8        E8,13                           1
    x8        E8,14                           1
    x8        E8,15                           1
    x8        E8,16                           1
    x8        E8,18                           1
    x8        E8,19                           1
    x8        E8,20                           1
    x8        E8,21                           1
    x8        E8,22                           1
    x8        E8,23                           1
    x8        E8,24                           1
    x8        E8,25                           1
    x8        E8,26                           1
    x8        E8,27                           1
    x8        E8,28                           1
    x8        E8,30                           1
    x8        E8,31                           1
    x8        E8,32                           1
    x8        E8,33                           1
    x8        E8,34                           1
    x8        E8,37                           1
    x8        E8,39                           1
    x8        E8,40                           1
    x8        E8,41                           1
    x8        E8,42                           1
    x8        E8,43                           1
    x8        E8,44                           1
    x8        E8,45                           1
    x8        E8,46                           1
    x8        E8,49                           1
    x8        E8,50                           1
    x8        E8,51                           1
    x8        E8,53                           1
    x8        E8,54                           1
    x8        E8,55                           1
    x8        E8,56                           1
    x8        E8,57                           1
    x8        E8,58                           1
    x9        cost                            1
    x9        C1,9                            1
    x9        C4,9                            1
    x9        C6,9                            1
    x9        C8,9                            1
    x9        C9,10                           1
    x9        C9,11                           1
    x9        C9,13                           1
    x9        C9,14                           1
    x9        C9,17                           1
    x9        C9,18                           1
    x9        C9,20                           1
    x9        C9,24                           1
    x9        C9,27                           1
    x9        C9,47                           1
    x9        C9,48                           1
    x9        C9,51                           1
    x9        C9,53                           1
    x9        C9,56                           1
    x9        C9,57                           1
    x9        E0,9                            1
    x9        E2,9                            1
    x9        E3,9                            1
    x9        E5,9                            1
    x9        E7,9                            1
    x9        E9,12                           1
    x9        E9,15                           1
    x9        E9,16                           1
    x9        E9,19                           1
    x9        E9,21                           1
    x9        E9,22                           1
    x9        E9,23                           1
    x9        E9,25                           1
    x9        E9,26                           1
    x9        E9,28                           1
    x9        E9,29                           1
    x9        E9,30                           1
    x9        E9,31                           1
    x9        E9,32                           1
    x9        E9,33                           1
    x9        E9,34                           1
    x9        E9,35                           1
    x9        E9,36                           1
    x9        E9,37                           1
    x9        E9,38                           1
    x9        E9,39                           1
    x9        E9,40                           1
    x9        E9,41                           1
    x9        E9,42                           1
    x9        E9,43                           1
    x9        E9,44                           1
    x9        E9,45                           1
    x9        E9,46                           1
    x9        E9,49                           1
    x9        E9,50                           1
    x9        E9,52                           1
    x9        E9,54                           1
    x9        E9,55                           1
    x9        E9,58                           1
    x9        E9,59                           1
    x10       cost                            1
    x10       C2,10                           1
    x10       C7,10                           1
    x10       C9,10                           1
    x10       C10,12                          1
    x10       C10,14                          1
    x10       C10,17                          1
    x10       C10,20                          1
    x10       C10,22                          1
    x10       C10,24                          1
    x10       C10,33                          1
    x10       C10,37                          1
    x10       C10,43                          1
    x10       C10,49                          1
    x10       C10,55                          1
    x10       C10,58                          1
    x10       E0,10                           1
    x10       E1,10                           1
    x10       E3,10                           1
    x10       E4,10                           1
    x10       E5,10                           1
    x10       E6,10                           1
    x10       E8,10                           1
    x10       E10,11                          1
    x10       E10,13                          1
    x10       E10,15                          1
    x10       E10,16                          1
    x10       E10,18                          1
    x10       E10,19                          1
    x10       E10,21                          1
    x10       E10,23                          1
    x10       E10,25                          1
    x10       E10,26                          1
    x10       E10,27                          1
    x10       E10,28                          1
    x10       E10,29                          1
    x10       E10,30                          1
    x10       E10,31                          1
    x10       E10,32                          1
    x10       E10,34                          1
    x10       E10,35                          1
    x10       E10,36                          1
    x10       E10,38                          1
    x10       E10,39                          1
    x10       E10,40                          1
    x10       E10,41                          1
    x10       E10,42                          1
    x10       E10,44                          1
    x10       E10,45                          1
    x10       E10,46                          1
    x10       E10,47                          1
    x10       E10,48                          1
    x10       E10,50                          1
    x10       E10,51                          1
    x10       E10,52                          1
    x10       E10,53                          1
    x10       E10,54                          1
    x10       E10,56                          1
    x10       E10,57                          1
    x10       E10,59                          1
    x11       cost                            1
    x11       C1,11                           1
    x11       C4,11                           1
    x11       C5,11                           1
    x11       C6,11                           1
    x11       C7,11                           1
    x11       C8,11                           1
    x11       C9,11                           1
    x11       C11,13                          1
    x11       C11,16                          1
    x11       C11,18                          1
    x11       C11,19                          1
    x11       C11,20                          1
    x11       C11,22                          1
    x11       C11,24                          1
    x11       C11,27                          1
    x11       C11,28                          1
    x11       C11,41                          1
    x11       C11,43                          1
    x11       C11,44                          1
    x11       C11,50                          1
    x11       C11,51                          1
    x11       C11,55                          1
    x11       E0,11                           1
    x11       E2,11                           1
    x11       E3,11                           1
    x11       E10,11                          1
    x11       E11,12                          1
    x11       E11,14                          1
    x11       E11,15                          1
    x11       E11,17                          1
    x11       E11,21                          1
    x11       E11,23                          1
    x11       E11,25                          1
    x11       E11,26                          1
    x11       E11,29                          1
    x11       E11,30                          1
    x11       E11,31                          1
    x11       E11,32                          1
    x11       E11,33                          1
    x11       E11,34                          1
    x11       E11,35                          1
    x11       E11,36                          1
    x11       E11,37                          1
    x11       E11,38                          1
    x11       E11,39                          1
    x11       E11,40                          1
    x11       E11,42                          1
    x11       E11,45                          1
    x11       E11,46                          1
    x11       E11,47                          1
    x11       E11,48                          1
    x11       E11,49                          1
    x11       E11,52                          1
    x11       E11,53                          1
    x11       E11,54                          1
    x11       E11,56                          1
    x11       E11,57                          1
    x11       E11,58                          1
    x11       E11,59                          1
    x12       cost                            1
    x12       C4,12                           1
    x12       C5,12                           1
    x12       C6,12                           1
    x12       C10,12                          1
    x12       C12,13                          1
    x12       C12,18                          1
    x12       C12,21                          1
    x12       C12,24                          1
    x12       C12,28                          1
    x12       C12,41                          1
    x12       C12,51                          1
    x12       C12,57                          1
    x12       E0,12                           1
    x12       E1,12                           1
    x12       E2,12                           1
    x12       E3,12                           1
    x12       E7,12                           1
    x12       E8,12                           1
    x12       E9,12                           1
    x12       E11,12                          1
    x12       E12,14                          1
    x12       E12,15                          1
    x12       E12,16                          1
    x12       E12,17                          1
    x12       E12,19                          1
    x12       E12,20                          1
    x12       E12,22                          1
    x12       E12,23                          1
    x12       E12,25                          1
    x12       E12,26                          1
    x12       E12,27                          1
    x12       E12,29                          1
    x12       E12,30                          1
    x12       E12,31                          1
    x12       E12,32                          1
    x12       E12,33                          1
    x12       E12,34                          1
    x12       E12,35                          1
    x12       E12,36                          1
    x12       E12,37                          1
    x12       E12,38                          1
    x12       E12,39                          1
    x12       E12,40                          1
    x12       E12,42                          1
    x12       E12,43                          1
    x12       E12,44                          1
    x12       E12,45                          1
    x12       E12,46                          1
    x12       E12,47                          1
    x12       E12,48                          1
    x12       E12,49                          1
    x12       E12,50                          1
    x12       E12,52                          1
    x12       E12,53                          1
    x12       E12,54                          1
    x12       E12,55                          1
    x12       E12,56                          1
    x12       E12,58                          1
    x12       E12,59                          1
    x13       cost                            1
    x13       C2,13                           1
    x13       C6,13                           1
    x13       C7,13                           1
    x13       C9,13                           1
    x13       C11,13                          1
    x13       C12,13                          1
    x13       C13,15                          1
    x13       C13,18                          1
    x13       C13,25                          1
    x13       C13,26                          1
    x13       C13,29                          1
    x13       C13,30                          1
    x13       C13,31                          1
    x13       C13,35                          1
    x13       C13,37                          1
    x13       C13,44                          1
    x13       C13,45                          1
    x13       C13,47                          1
    x13       C13,48                          1
    x13       C13,49                          1
    x13       C13,52                          1
    x13       C13,54                          1
    x13       E0,13                           1
    x13       E1,13                           1
    x13       E3,13                           1
    x13       E4,13                           1
    x13       E5,13                           1
    x13       E8,13                           1
    x13       E10,13                          1
    x13       E13,14                          1
    x13       E13,16                          1
    x13       E13,17                          1
    x13       E13,19                          1
    x13       E13,20                          1
    x13       E13,21                          1
    x13       E13,22                          1
    x13       E13,23                          1
    x13       E13,24                          1
    x13       E13,27                          1
    x13       E13,28                          1
    x13       E13,32                          1
    x13       E13,33                          1
    x13       E13,34                          1
    x13       E13,36                          1
    x13       E13,38                          1
    x13       E13,39                          1
    x13       E13,40                          1
    x13       E13,41                          1
    x13       E13,42                          1
    x13       E13,43                          1
    x13       E13,46                          1
    x13       E13,50                          1
    x13       E13,51                          1
    x13       E13,53                          1
    x13       E13,55                          1
    x13       E13,56                          1
    x13       E13,57                          1
    x13       E13,58                          1
    x13       E13,59                          1
    x14       cost                            1
    x14       C3,14                           1
    x14       C6,14                           1
    x14       C7,14                           1
    x14       C9,14                           1
    x14       C10,14                          1
    x14       C14,15                          1
    x14       C14,16                          1
    x14       C14,17                          1
    x14       C14,22                          1
    x14       C14,23                          1
    x14       C14,24                          1
    x14       C14,26                          1
    x14       C14,30                          1
    x14       C14,32                          1
    x14       C14,34                          1
    x14       C14,39                          1
    x14       C14,41                          1
    x14       C14,42                          1
    x14       C14,55                          1
    x14       C14,59                          1
    x14       E0,14                           1
    x14       E1,14                           1
    x14       E2,14                           1
    x14       E4,14                           1
    x14       E5,14                           1
    x14       E8,14                           1
    x14       E11,14                          1
    x14       E12,14                          1
    x14       E13,14                          1
    x14       E14,18                          1
    x14       E14,19                          1
    x14       E14,20                          1
    x14       E14,21                          1
    x14       E14,25                          1
    x14       E14,27                          1
    x14       E14,28                          1
    x14       E14,29                          1
    x14       E14,31                          1
    x14       E14,33                          1
    x14       E14,35                          1
    x14       E14,36                          1
    x14       E14,37                          1
    x14       E14,38                          1
    x14       E14,40                          1
    x14       E14,43                          1
    x14       E14,44                          1
    x14       E14,45                          1
    x14       E14,46                          1
    x14       E14,47                          1
    x14       E14,48                          1
    x14       E14,49                          1
    x14       E14,50                          1
    x14       E14,51                          1
    x14       E14,52                          1
    x14       E14,53                          1
    x14       E14,54                          1
    x14       E14,56                          1
    x14       E14,57                          1
    x14       E14,58                          1
    x15       cost                            1
    x15       C13,15                          1
    x15       C14,15                          1
    x15       C15,19                          1
    x15       C15,21                          1
    x15       C15,22                          1
    x15       C15,24                          1
    x15       C15,27                          1
    x15       C15,29                          1
    x15       C15,30                          1
    x15       C15,31                          1
    x15       C15,34                          1
    x15       C15,38                          1
    x15       C15,40                          1
    x15       C15,42                          1
    x15       C15,43                          1
    x15       C15,44                          1
    x15       C15,48                          1
    x15       C15,52                          1
    x15       C15,53                          1
    x15       C15,56                          1
    x15       E0,15                           1
    x15       E1,15                           1
    x15       E2,15                           1
    x15       E3,15                           1
    x15       E4,15                           1
    x15       E5,15                           1
    x15       E6,15                           1
    x15       E7,15                           1
    x15       E8,15                           1
    x15       E9,15                           1
    x15       E10,15                          1
    x15       E11,15                          1
    x15       E12,15                          1
    x15       E15,16                          1
    x15       E15,17                          1
    x15       E15,18                          1
    x15       E15,20                          1
    x15       E15,23                          1
    x15       E15,25                          1
    x15       E15,26                          1
    x15       E15,28                          1
    x15       E15,32                          1
    x15       E15,33                          1
    x15       E15,35                          1
    x15       E15,36                          1
    x15       E15,37                          1
    x15       E15,39                          1
    x15       E15,41                          1
    x15       E15,45                          1
    x15       E15,46                          1
    x15       E15,47                          1
    x15       E15,49                          1
    x15       E15,50                          1
    x15       E15,51                          1
    x15       E15,54                          1
    x15       E15,55                          1
    x15       E15,57                          1
    x15       E15,58                          1
    x15       E15,59                          1
    x16       cost                            1
    x16       C3,16                           1
    x16       C5,16                           1
    x16       C6,16                           1
    x16       C11,16                          1
    x16       C14,16                          1
    x16       C16,22                          1
    x16       C16,23                          1
    x16       C16,24                          1
    x16       C16,26                          1
    x16       C16,27                          1
    x16       C16,34                          1
    x16       C16,39                          1
    x16       C16,44                          1
    x16       C16,45                          1
    x16       C16,48                          1
    x16       C16,50                          1
    x16       C16,55                          1
    x16       C16,56                          1
    x16       C16,58                          1
    x16       E0,16                           1
    x16       E1,16                           1
    x16       E2,16                           1
    x16       E4,16                           1
    x16       E7,16                           1
    x16       E8,16                           1
    x16       E9,16                           1
    x16       E10,16                          1
    x16       E12,16                          1
    x16       E13,16                          1
    x16       E15,16                          1
    x16       E16,17                          1
    x16       E16,18                          1
    x16       E16,19                          1
    x16       E16,20                          1
    x16       E16,21                          1
    x16       E16,25                          1
    x16       E16,28                          1
    x16       E16,29                          1
    x16       E16,30                          1
    x16       E16,31                          1
    x16       E16,32                          1
    x16       E16,33                          1
    x16       E16,35                          1
    x16       E16,36                          1
    x16       E16,37                          1
    x16       E16,38                          1
    x16       E16,40                          1
    x16       E16,41                          1
    x16       E16,42                          1
    x16       E16,43                          1
    x16       E16,46                          1
    x16       E16,47                          1
    x16       E16,49                          1
    x16       E16,51                          1
    x16       E16,52                          1
    x16       E16,53                          1
    x16       E16,54                          1
    x16       E16,57                          1
    x16       E16,59                          1
    x17       cost                            1
    x17       C4,17                           1
    x17       C5,17                           1
    x17       C8,17                           1
    x17       C9,17                           1
    x17       C10,17                          1
    x17       C14,17                          1
    x17       C17,19                          1
    x17       C17,24                          1
    x17       C17,27                          1
    x17       C17,31                          1
    x17       C17,34                          1
    x17       C17,39                          1
    x17       C17,40                          1
    x17       C17,43                          1
    x17       C17,50                          1
    x17       C17,52                          1
    x17       C17,56                          1
    x17       C17,57                          1
    x17       E0,17                           1
    x17       E1,17                           1
    x17       E2,17                           1
    x17       E3,17                           1
    x17       E6,17                           1
    x17       E7,17                           1
    x17       E11,17                          1
    x17       E12,17                          1
    x17       E13,17                          1
    x17       E15,17                          1
    x17       E16,17                          1
    x17       E17,18                          1
    x17       E17,20                          1
    x17       E17,21                          1
    x17       E17,22                          1
    x17       E17,23                          1
    x17       E17,25                          1
    x17       E17,26                          1
    x17       E17,28                          1
    x17       E17,29                          1
    x17       E17,30                          1
    x17       E17,32                          1
    x17       E17,33                          1
    x17       E17,35                          1
    x17       E17,36                          1
    x17       E17,37                          1
    x17       E17,38                          1
    x17       E17,41                          1
    x17       E17,42                          1
    x17       E17,44                          1
    x17       E17,45                          1
    x17       E17,46                          1
    x17       E17,47                          1
    x17       E17,48                          1
    x17       E17,49                          1
    x17       E17,51                          1
    x17       E17,53                          1
    x17       E17,54                          1
    x17       E17,55                          1
    x17       E17,58                          1
    x17       E17,59                          1
    x18       cost                            1
    x18       C4,18                           1
    x18       C6,18                           1
    x18       C9,18                           1
    x18       C11,18                          1
    x18       C12,18                          1
    x18       C13,18                          1
    x18       C18,20                          1
    x18       C18,21                          1
    x18       C18,24                          1
    x18       C18,27                          1
    x18       C18,46                          1
    x18       C18,49                          1
    x18       C18,58                          1
    x18       E0,18                           1
    x18       E1,18                           1
    x18       E2,18                           1
    x18       E3,18                           1
    x18       E5,18                           1
    x18       E7,18                           1
    x18       E8,18                           1
    x18       E10,18                          1
    x18       E14,18                          1
    x18       E15,18                          1
    x18       E16,18                          1
    x18       E17,18                          1
    x18       E18,19                          1
    x18       E18,22                          1
    x18       E18,23                          1
    x18       E18,25                          1
    x18       E18,26                          1
    x18       E18,28                          1
    x18       E18,29                          1
    x18       E18,30                          1
    x18       E18,31                          1
    x18       E18,32                          1
    x18       E18,33                          1
    x18       E18,34                          1
    x18       E18,35                          1
    x18       E18,36                          1
    x18       E18,37                          1
    x18       E18,38                          1
    x18       E18,39                          1
    x18       E18,40                          1
    x18       E18,41                          1
    x18       E18,42                          1
    x18       E18,43                          1
    x18       E18,44                          1
    x18       E18,45                          1
    x18       E18,47                          1
    x18       E18,48                          1
    x18       E18,50                          1
    x18       E18,51                          1
    x18       E18,52                          1
    x18       E18,53                          1
    x18       E18,54                          1
    x18       E18,55                          1
    x18       E18,56                          1
    x18       E18,57                          1
    x18       E18,59                          1
    x19       cost                            1
    x19       C0,19                           1
    x19       C5,19                           1
    x19       C11,19                          1
    x19       C15,19                          1
    x19       C17,19                          1
    x19       C19,23                          1
    x19       C19,25                          1
    x19       C19,26                          1
    x19       C19,27                          1
    x19       C19,33                          1
    x19       C19,34                          1
    x19       C19,35                          1
    x19       C19,38                          1
    x19       C19,41                          1
    x19       C19,46                          1
    x19       C19,47                          1
    x19       C19,48                          1
    x19       C19,56                          1
    x19       C19,57                          1
    x19       E1,19                           1
    x19       E2,19                           1
    x19       E3,19                           1
    x19       E4,19                           1
    x19       E6,19                           1
    x19       E7,19                           1
    x19       E8,19                           1
    x19       E9,19                           1
    x19       E10,19                          1
    x19       E12,19                          1
    x19       E13,19                          1
    x19       E14,19                          1
    x19       E16,19                          1
    x19       E18,19                          1
    x19       E19,20                          1
    x19       E19,21                          1
    x19       E19,22                          1
    x19       E19,24                          1
    x19       E19,28                          1
    x19       E19,29                          1
    x19       E19,30                          1
    x19       E19,31                          1
    x19       E19,32                          1
    x19       E19,36                          1
    x19       E19,37                          1
    x19       E19,39                          1
    x19       E19,40                          1
    x19       E19,42                          1
    x19       E19,43                          1
    x19       E19,44                          1
    x19       E19,45                          1
    x19       E19,49                          1
    x19       E19,50                          1
    x19       E19,51                          1
    x19       E19,52                          1
    x19       E19,53                          1
    x19       E19,54                          1
    x19       E19,55                          1
    x19       E19,58                          1
    x19       E19,59                          1
    x20       cost                            1
    x20       C1,20                           1
    x20       C2,20                           1
    x20       C6,20                           1
    x20       C9,20                           1
    x20       C10,20                          1
    x20       C11,20                          1
    x20       C18,20                          1
    x20       C20,25                          1
    x20       C20,31                          1
    x20       C20,33                          1
    x20       C20,37                          1
    x20       C20,38                          1
    x20       C20,40                          1
    x20       C20,46                          1
    x20       C20,51                          1
    x20       C20,54                          1
    x20       C20,58                          1
    x20       C20,59                          1
    x20       E0,20                           1
    x20       E3,20                           1
    x20       E4,20                           1
    x20       E5,20                           1
    x20       E7,20                           1
    x20       E8,20                           1
    x20       E12,20                          1
    x20       E13,20                          1
    x20       E14,20                          1
    x20       E15,20                          1
    x20       E16,20                          1
    x20       E17,20                          1
    x20       E19,20                          1
    x20       E20,21                          1
    x20       E20,22                          1
    x20       E20,23                          1
    x20       E20,24                          1
    x20       E20,26                          1
    x20       E20,27                          1
    x20       E20,28                          1
    x20       E20,29                          1
    x20       E20,30                          1
    x20       E20,32                          1
    x20       E20,34                          1
    x20       E20,35                          1
    x20       E20,36                          1
    x20       E20,39                          1
    x20       E20,41                          1
    x20       E20,42                          1
    x20       E20,43                          1
    x20       E20,44                          1
    x20       E20,45                          1
    x20       E20,47                          1
    x20       E20,48                          1
    x20       E20,49                          1
    x20       E20,50                          1
    x20       E20,52                          1
    x20       E20,53                          1
    x20       E20,55                          1
    x20       E20,56                          1
    x20       E20,57                          1
    x21       cost                            1
    x21       C1,21                           1
    x21       C3,21                           1
    x21       C4,21                           1
    x21       C5,21                           1
    x21       C6,21                           1
    x21       C7,21                           1
    x21       C12,21                          1
    x21       C15,21                          1
    x21       C18,21                          1
    x21       C21,22                          1
    x21       C21,23                          1
    x21       C21,28                          1
    x21       C21,29                          1
    x21       C21,31                          1
    x21       C21,33                          1
    x21       C21,40                          1
    x21       C21,43                          1
    x21       C21,46                          1
    x21       C21,48                          1
    x21       C21,51                          1
    x21       C21,58                          1
    x21       C21,59                          1
    x21       E0,21                           1
    x21       E2,21                           1
    x21       E8,21                           1
    x21       E9,21                           1
    x21       E10,21                          1
    x21       E11,21                          1
    x21       E13,21                          1
    x21       E14,21                          1
    x21       E16,21                          1
    x21       E17,21                          1
    x21       E19,21                          1
    x21       E20,21                          1
    x21       E21,24                          1
    x21       E21,25                          1
    x21       E21,26                          1
    x21       E21,27                          1
    x21       E21,30                          1
    x21       E21,32                          1
    x21       E21,34                          1
    x21       E21,35                          1
    x21       E21,36                          1
    x21       E21,37                          1
    x21       E21,38                          1
    x21       E21,39                          1
    x21       E21,41                          1
    x21       E21,42                          1
    x21       E21,44                          1
    x21       E21,45                          1
    x21       E21,47                          1
    x21       E21,49                          1
    x21       E21,50                          1
    x21       E21,52                          1
    x21       E21,53                          1
    x21       E21,54                          1
    x21       E21,55                          1
    x21       E21,56                          1
    x21       E21,57                          1
    x22       cost                            1
    x22       C0,22                           1
    x22       C7,22                           1
    x22       C10,22                          1
    x22       C11,22                          1
    x22       C14,22                          1
    x22       C15,22                          1
    x22       C16,22                          1
    x22       C21,22                          1
    x22       C22,23                          1
    x22       C22,24                          1
    x22       C22,34                          1
    x22       C22,35                          1
    x22       C22,36                          1
    x22       C22,40                          1
    x22       C22,43                          1
    x22       C22,52                          1
    x22       C22,54                          1
    x22       C22,55                          1
    x22       C22,57                          1
    x22       E1,22                           1
    x22       E2,22                           1
    x22       E3,22                           1
    x22       E4,22                           1
    x22       E5,22                           1
    x22       E6,22                           1
    x22       E8,22                           1
    x22       E9,22                           1
    x22       E12,22                          1
    x22       E13,22                          1
    x22       E17,22                          1
    x22       E18,22                          1
    x22       E19,22                          1
    x22       E20,22                          1
    x22       E22,25                          1
    x22       E22,26                          1
    x22       E22,27                          1
    x22       E22,28                          1
    x22       E22,29                          1
    x22       E22,30                          1
    x22       E22,31                          1
    x22       E22,32                          1
    x22       E22,33                          1
    x22       E22,37                          1
    x22       E22,38                          1
    x22       E22,39                          1
    x22       E22,41                          1
    x22       E22,42                          1
    x22       E22,44                          1
    x22       E22,45                          1
    x22       E22,46                          1
    x22       E22,47                          1
    x22       E22,48                          1
    x22       E22,49                          1
    x22       E22,50                          1
    x22       E22,51                          1
    x22       E22,53                          1
    x22       E22,56                          1
    x22       E22,58                          1
    x22       E22,59                          1
    x23       cost                            1
    x23       C3,23                           1
    x23       C4,23                           1
    x23       C14,23                          1
    x23       C16,23                          1
    x23       C19,23                          1
    x23       C21,23                          1
    x23       C22,23                          1
    x23       C23,27                          1
    x23       C23,35                          1
    x23       C23,44                          1
    x23       C23,45                          1
    x23       C23,46                          1
    x23       C23,48                          1
    x23       C23,53                          1
    x23       E0,23                           1
    x23       E1,23                           1
    x23       E2,23                           1
    x23       E5,23                           1
    x23       E6,23                           1
    x23       E7,23                           1
    x23       E8,23                           1
    x23       E9,23                           1
    x23       E10,23                          1
    x23       E11,23                          1
    x23       E12,23                          1
    x23       E13,23                          1
    x23       E15,23                          1
    x23       E17,23                          1
    x23       E18,23                          1
    x23       E20,23                          1
    x23       E23,24                          1
    x23       E23,25                          1
    x23       E23,26                          1
    x23       E23,28                          1
    x23       E23,29                          1
    x23       E23,30                          1
    x23       E23,31                          1
    x23       E23,32                          1
    x23       E23,33                          1
    x23       E23,34                          1
    x23       E23,36                          1
    x23       E23,37                          1
    x23       E23,38                          1
    x23       E23,39                          1
    x23       E23,40                          1
    x23       E23,41                          1
    x23       E23,42                          1
    x23       E23,43                          1
    x23       E23,47                          1
    x23       E23,49                          1
    x23       E23,50                          1
    x23       E23,51                          1
    x23       E23,52                          1
    x23       E23,54                          1
    x23       E23,55                          1
    x23       E23,56                          1
    x23       E23,57                          1
    x23       E23,58                          1
    x23       E23,59                          1
    x24       cost                            1
    x24       C0,24                           1
    x24       C1,24                           1
    x24       C3,24                           1
    x24       C9,24                           1
    x24       C10,24                          1
    x24       C11,24                          1
    x24       C12,24                          1
    x24       C14,24                          1
    x24       C15,24                          1
    x24       C16,24                          1
    x24       C17,24                          1
    x24       C18,24                          1
    x24       C22,24                          1
    x24       C24,26                          1
    x24       C24,31                          1
    x24       C24,38                          1
    x24       C24,40                          1
    x24       C24,54                          1
    x24       C24,55                          1
    x24       C24,58                          1
    x24       E2,24                           1
    x24       E4,24                           1
    x24       E5,24                           1
    x24       E6,24                           1
    x24       E7,24                           1
    x24       E8,24                           1
    x24       E13,24                          1
    x24       E19,24                          1
    x24       E20,24                          1
    x24       E21,24                          1
    x24       E23,24                          1
    x24       E24,25                          1
    x24       E24,27                          1
    x24       E24,28                          1
    x24       E24,29                          1
    x24       E24,30                          1
    x24       E24,32                          1
    x24       E24,33                          1
    x24       E24,34                          1
    x24       E24,35                          1
    x24       E24,36                          1
    x24       E24,37                          1
    x24       E24,39                          1
    x24       E24,41                          1
    x24       E24,42                          1
    x24       E24,43                          1
    x24       E24,44                          1
    x24       E24,45                          1
    x24       E24,46                          1
    x24       E24,47                          1
    x24       E24,48                          1
    x24       E24,49                          1
    x24       E24,50                          1
    x24       E24,51                          1
    x24       E24,52                          1
    x24       E24,53                          1
    x24       E24,56                          1
    x24       E24,57                          1
    x24       E24,59                          1
    x25       cost                            1
    x25       C6,25                           1
    x25       C7,25                           1
    x25       C13,25                          1
    x25       C19,25                          1
    x25       C20,25                          1
    x25       C25,27                          1
    x25       C25,29                          1
    x25       C25,30                          1
    x25       C25,36                          1
    x25       C25,41                          1
    x25       C25,43                          1
    x25       C25,46                          1
    x25       C25,58                          1
    x25       E0,25                           1
    x25       E1,25                           1
    x25       E2,25                           1
    x25       E3,25                           1
    x25       E4,25                           1
    x25       E5,25                           1
    x25       E8,25                           1
    x25       E9,25                           1
    x25       E10,25                          1
    x25       E11,25                          1
    x25       E12,25                          1
    x25       E14,25                          1
    x25       E15,25                          1
    x25       E16,25                          1
    x25       E17,25                          1
    x25       E18,25                          1
    x25       E21,25                          1
    x25       E22,25                          1
    x25       E23,25                          1
    x25       E24,25                          1
    x25       E25,26                          1
    x25       E25,28                          1
    x25       E25,31                          1
    x25       E25,32                          1
    x25       E25,33                          1
    x25       E25,34                          1
    x25       E25,35                          1
    x25       E25,37                          1
    x25       E25,38                          1
    x25       E25,39                          1
    x25       E25,40                          1
    x25       E25,42                          1
    x25       E25,44                          1
    x25       E25,45                          1
    x25       E25,47                          1
    x25       E25,48                          1
    x25       E25,49                          1
    x25       E25,50                          1
    x25       E25,51                          1
    x25       E25,52                          1
    x25       E25,53                          1
    x25       E25,54                          1
    x25       E25,55                          1
    x25       E25,56                          1
    x25       E25,57                          1
    x25       E25,59                          1
    x26       cost                            1
    x26       C0,26                           1
    x26       C2,26                           1
    x26       C6,26                           1
    x26       C13,26                          1
    x26       C14,26                          1
    x26       C16,26                          1
    x26       C19,26                          1
    x26       C24,26                          1
    x26       C26,27                          1
    x26       C26,28                          1
    x26       C26,33                          1
    x26       C26,44                          1
    x26       C26,47                          1
    x26       C26,52                          1
    x26       C26,53                          1
    x26       C26,54                          1
    x26       E1,26                           1
    x26       E3,26                           1
    x26       E4,26                           1
    x26       E5,26                           1
    x26       E7,26                           1
    x26       E8,26                           1
    x26       E9,26                           1
    x26       E10,26                          1
    x26       E11,26                          1
    x26       E12,26                          1
    x26       E15,26                          1
    x26       E17,26                          1
    x26       E18,26                          1
    x26       E20,26                          1
    x26       E21,26                          1
    x26       E22,26                          1
    x26       E23,26                          1
    x26       E25,26                          1
    x26       E26,29                          1
    x26       E26,30                          1
    x26       E26,31                          1
    x26       E26,32                          1
    x26       E26,34                          1
    x26       E26,35                          1
    x26       E26,36                          1
    x26       E26,37                          1
    x26       E26,38                          1
    x26       E26,39                          1
    x26       E26,40                          1
    x26       E26,41                          1
    x26       E26,42                          1
    x26       E26,43                          1
    x26       E26,45                          1
    x26       E26,46                          1
    x26       E26,48                          1
    x26       E26,49                          1
    x26       E26,50                          1
    x26       E26,51                          1
    x26       E26,55                          1
    x26       E26,56                          1
    x26       E26,57                          1
    x26       E26,58                          1
    x26       E26,59                          1
    x27       cost                            1
    x27       C1,27                           1
    x27       C9,27                           1
    x27       C11,27                          1
    x27       C15,27                          1
    x27       C16,27                          1
    x27       C17,27                          1
    x27       C18,27                          1
    x27       C19,27                          1
    x27       C23,27                          1
    x27       C25,27                          1
    x27       C26,27                          1
    x27       C27,29                          1
    x27       C27,30                          1
    x27       C27,37                          1
    x27       C27,38                          1
    x27       C27,45                          1
    x27       C27,48                          1
    x27       C27,54                          1
    x27       C27,58                          1
    x27       E0,27                           1
    x27       E2,27                           1
    x27       E3,27                           1
    x27       E4,27                           1
    x27       E5,27                           1
    x27       E6,27                           1
    x27       E7,27                           1
    x27       E8,27                           1
    x27       E10,27                          1
    x27       E12,27                          1
    x27       E13,27                          1
    x27       E14,27                          1
    x27       E20,27                          1
    x27       E21,27                          1
    x27       E22,27                          1
    x27       E24,27                          1
    x27       E27,28                          1
    x27       E27,31                          1
    x27       E27,32                          1
    x27       E27,33                          1
    x27       E27,34                          1
    x27       E27,35                          1
    x27       E27,36                          1
    x27       E27,39                          1
    x27       E27,40                          1
    x27       E27,41                          1
    x27       E27,42                          1
    x27       E27,43                          1
    x27       E27,44                          1
    x27       E27,46                          1
    x27       E27,47                          1
    x27       E27,49                          1
    x27       E27,50                          1
    x27       E27,51                          1
    x27       E27,52                          1
    x27       E27,53                          1
    x27       E27,55                          1
    x27       E27,56                          1
    x27       E27,57                          1
    x27       E27,59                          1
    x28       cost                            1
    x28       C4,28                           1
    x28       C6,28                           1
    x28       C11,28                          1
    x28       C12,28                          1
    x28       C21,28                          1
    x28       C26,28                          1
    x28       C28,31                          1
    x28       C28,37                          1
    x28       C28,39                          1
    x28       C28,40                          1
    x28       C28,41                          1
    x28       C28,42                          1
    x28       C28,43                          1
    x28       C28,45                          1
    x28       C28,46                          1
    x28       C28,52                          1
    x28       C28,55                          1
    x28       C28,56                          1
    x28       C28,59                          1
    x28       E0,28                           1
    x28       E1,28                           1
    x28       E2,28                           1
    x28       E3,28                           1
    x28       E5,28                           1
    x28       E7,28                           1
    x28       E8,28                           1
    x28       E9,28                           1
    x28       E10,28                          1
    x28       E13,28                          1
    x28       E14,28                          1
    x28       E15,28                          1
    x28       E16,28                          1
    x28       E17,28                          1
    x28       E18,28                          1
    x28       E19,28                          1
    x28       E20,28                          1
    x28       E22,28                          1
    x28       E23,28                          1
    x28       E24,28                          1
    x28       E25,28                          1
    x28       E27,28                          1
    x28       E28,29                          1
    x28       E28,30                          1
    x28       E28,32                          1
    x28       E28,33                          1
    x28       E28,34                          1
    x28       E28,35                          1
    x28       E28,36                          1
    x28       E28,38                          1
    x28       E28,44                          1
    x28       E28,47                          1
    x28       E28,48                          1
    x28       E28,49                          1
    x28       E28,50                          1
    x28       E28,51                          1
    x28       E28,53                          1
    x28       E28,54                          1
    x28       E28,57                          1
    x28       E28,58                          1
    x29       cost                            1
    x29       C4,29                           1
    x29       C6,29                           1
    x29       C7,29                           1
    x29       C8,29                           1
    x29       C13,29                          1
    x29       C15,29                          1
    x29       C21,29                          1
    x29       C25,29                          1
    x29       C27,29                          1
    x29       C29,31                          1
    x29       C29,32                          1
    x29       C29,35                          1
    x29       C29,36                          1
    x29       C29,37                          1
    x29       C29,39                          1
    x29       C29,40                          1
    x29       C29,41                          1
    x29       C29,43                          1
    x29       C29,45                          1
    x29       C29,47                          1
    x29       C29,48                          1
    x29       C29,52                          1
    x29       E0,29                           1
    x29       E1,29                           1
    x29       E2,29                           1
    x29       E3,29                           1
    x29       E5,29                           1
    x29       E9,29                           1
    x29       E10,29                          1
    x29       E11,29                          1
    x29       E12,29                          1
    x29       E14,29                          1
    x29       E16,29                          1
    x29       E17,29                          1
    x29       E18,29                          1
    x29       E19,29                          1
    x29       E20,29                          1
    x29       E22,29                          1
    x29       E23,29                          1
    x29       E24,29                          1
    x29       E26,29                          1
    x29       E28,29                          1
    x29       E29,30                          1
    x29       E29,33                          1
    x29       E29,34                          1
    x29       E29,38                          1
    x29       E29,42                          1
    x29       E29,44                          1
    x29       E29,46                          1
    x29       E29,49                          1
    x29       E29,50                          1
    x29       E29,51                          1
    x29       E29,53                          1
    x29       E29,54                          1
    x29       E29,55                          1
    x29       E29,56                          1
    x29       E29,57                          1
    x29       E29,58                          1
    x29       E29,59                          1
    x30       cost                            1
    x30       C1,30                           1
    x30       C3,30                           1
    x30       C13,30                          1
    x30       C14,30                          1
    x30       C15,30                          1
    x30       C25,30                          1
    x30       C27,30                          1
    x30       C30,32                          1
    x30       C30,33                          1
    x30       C30,34                          1
    x30       C30,36                          1
    x30       C30,37                          1
    x30       C30,54                          1
    x30       C30,55                          1
    x30       E0,30                           1
    x30       E2,30                           1
    x30       E4,30                           1
    x30       E5,30                           1
    x30       E6,30                           1
    x30       E7,30                           1
    x30       E8,30                           1
    x30       E9,30                           1
    x30       E10,30                          1
    x30       E11,30                          1
    x30       E12,30                          1
    x30       E16,30                          1
    x30       E17,30                          1
    x30       E18,30                          1
    x30       E19,30                          1
    x30       E20,30                          1
    x30       E21,30                          1
    x30       E22,30                          1
    x30       E23,30                          1
    x30       E24,30                          1
    x30       E26,30                          1
    x30       E28,30                          1
    x30       E29,30                          1
    x30       E30,31                          1
    x30       E30,35                          1
    x30       E30,38                          1
    x30       E30,39                          1
    x30       E30,40                          1
    x30       E30,41                          1
    x30       E30,42                          1
    x30       E30,43                          1
    x30       E30,44                          1
    x30       E30,45                          1
    x30       E30,46                          1
    x30       E30,47                          1
    x30       E30,48                          1
    x30       E30,49                          1
    x30       E30,50                          1
    x30       E30,51                          1
    x30       E30,52                          1
    x30       E30,53                          1
    x30       E30,56                          1
    x30       E30,57                          1
    x30       E30,58                          1
    x30       E30,59                          1
    x31       cost                            1
    x31       C4,31                           1
    x31       C6,31                           1
    x31       C7,31                           1
    x31       C13,31                          1
    x31       C15,31                          1
    x31       C17,31                          1
    x31       C20,31                          1
    x31       C21,31                          1
    x31       C24,31                          1
    x31       C28,31                          1
    x31       C29,31                          1
    x31       C31,34                          1
    x31       C31,41                          1
    x31       C31,45                          1
    x31       C31,50                          1
    x31       C31,51                          1
    x31       C31,55                          1
    x31       C31,57                          1
    x31       C31,59                          1
    x31       E0,31                           1
    x31       E1,31                           1
    x31       E2,31                           1
    x31       E3,31                           1
    x31       E5,31                           1
    x31       E8,31                           1
    x31       E9,31                           1
    x31       E10,31                          1
    x31       E11,31                          1
    x31       E12,31                          1
    x31       E14,31                          1
    x31       E16,31                          1
    x31       E18,31                          1
    x31       E19,31                          1
    x31       E22,31                          1
    x31       E23,31                          1
    x31       E25,31                          1
    x31       E26,31                          1
    x31       E27,31                          1
    x31       E30,31                          1
    x31       E31,32                          1
    x31       E31,33                          1
    x31       E31,35                          1
    x31       E31,36                          1
    x31       E31,37                          1
    x31       E31,38                          1
    x31       E31,39                          1
    x31       E31,40                          1
    x31       E31,42                          1
    x31       E31,43                          1
    x31       E31,44                          1
    x31       E31,46                          1
    x31       E31,47                          1
    x31       E31,48                          1
    x31       E31,49                          1
    x31       E31,52                          1
    x31       E31,53                          1
    x31       E31,54                          1
    x31       E31,56                          1
    x31       E31,58                          1
    x32       cost                            1
    x32       C2,32                           1
    x32       C4,32                           1
    x32       C6,32                           1
    x32       C14,32                          1
    x32       C29,32                          1
    x32       C30,32                          1
    x32       C32,33                          1
    x32       C32,35                          1
    x32       C32,36                          1
    x32       C32,42                          1
    x32       C32,43                          1
    x32       C32,44                          1
    x32       C32,45                          1
    x32       C32,49                          1
    x32       C32,52                          1
    x32       C32,56                          1
    x32       C32,59                          1
    x32       E0,32                           1
    x32       E1,32                           1
    x32       E3,32                           1
    x32       E5,32                           1
    x32       E7,32                           1
    x32       E8,32                           1
    x32       E9,32                           1
    x32       E10,32                          1
    x32       E11,32                          1
    x32       E12,32                          1
    x32       E13,32                          1
    x32       E15,32                          1
    x32       E16,32                          1
    x32       E17,32                          1
    x32       E18,32                          1
    x32       E19,32                          1
    x32       E20,32                          1
    x32       E21,32                          1
    x32       E22,32                          1
    x32       E23,32                          1
    x32       E24,32                          1
    x32       E25,32                          1
    x32       E26,32                          1
    x32       E27,32                          1
    x32       E28,32                          1
    x32       E31,32                          1
    x32       E32,34                          1
    x32       E32,37                          1
    x32       E32,38                          1
    x32       E32,39                          1
    x32       E32,40                          1
    x32       E32,41                          1
    x32       E32,46                          1
    x32       E32,47                          1
    x32       E32,48                          1
    x32       E32,50                          1
    x32       E32,51                          1
    x32       E32,53                          1
    x32       E32,54                          1
    x32       E32,55                          1
    x32       E32,57                          1
    x32       E32,58                          1
    x33       cost                            1
    x33       C1,33                           1
    x33       C3,33                           1
    x33       C5,33                           1
    x33       C6,33                           1
    x33       C10,33                          1
    x33       C19,33                          1
    x33       C20,33                          1
    x33       C21,33                          1
    x33       C26,33                          1
    x33       C30,33                          1
    x33       C32,33                          1
    x33       C33,35                          1
    x33       C33,37                          1
    x33       C33,39                          1
    x33       C33,43                          1
    x33       C33,45                          1
    x33       C33,47                          1
    x33       C33,51                          1
    x33       C33,57                          1
    x33       E0,33                           1
    x33       E2,33                           1
    x33       E4,33                           1
    x33       E7,33                           1
    x33       E8,33                           1
    x33       E9,33                           1
    x33       E11,33                          1
    x33       E12,33                          1
    x33       E13,33                          1
    x33       E14,33                          1
    x33       E15,33                          1
    x33       E16,33                          1
    x33       E17,33                          1
    x33       E18,33                          1
    x33       E22,33                          1
    x33       E23,33                          1
    x33       E24,33                          1
    x33       E25,33                          1
    x33       E27,33                          1
    x33       E28,33                          1
    x33       E29,33                          1
    x33       E31,33                          1
    x33       E33,34                          1
    x33       E33,36                          1
    x33       E33,38                          1
    x33       E33,40                          1
    x33       E33,41                          1
    x33       E33,42                          1
    x33       E33,44                          1
    x33       E33,46                          1
    x33       E33,48                          1
    x33       E33,49                          1
    x33       E33,50                          1
    x33       E33,52                          1
    x33       E33,53                          1
    x33       E33,54                          1
    x33       E33,55                          1
    x33       E33,56                          1
    x33       E33,58                          1
    x33       E33,59                          1
    x34       cost                            1
    x34       C4,34                           1
    x34       C5,34                           1
    x34       C14,34                          1
    x34       C15,34                          1
    x34       C16,34                          1
    x34       C17,34                          1
    x34       C19,34                          1
    x34       C22,34                          1
    x34       C30,34                          1
    x34       C31,34                          1
    x34       C34,37                          1
    x34       C34,39                          1
    x34       C34,42                          1
    x34       C34,51                          1
    x34       C34,53                          1
    x34       C34,56                          1
    x34       E0,34                           1
    x34       E1,34                           1
    x34       E2,34                           1
    x34       E3,34                           1
    x34       E6,34                           1
    x34       E7,34                           1
    x34       E8,34                           1
    x34       E9,34                           1
    x34       E10,34                          1
    x34       E11,34                          1
    x34       E12,34                          1
    x34       E13,34                          1
    x34       E18,34                          1
    x34       E20,34                          1
    x34       E21,34                          1
    x34       E23,34                          1
    x34       E24,34                          1
    x34       E25,34                          1
    x34       E26,34                          1
    x34       E27,34                          1
    x34       E28,34                          1
    x34       E29,34                          1
    x34       E32,34                          1
    x34       E33,34                          1
    x34       E34,35                          1
    x34       E34,36                          1
    x34       E34,38                          1
    x34       E34,40                          1
    x34       E34,41                          1
    x34       E34,43                          1
    x34       E34,44                          1
    x34       E34,45                          1
    x34       E34,46                          1
    x34       E34,47                          1
    x34       E34,48                          1
    x34       E34,49                          1
    x34       E34,50                          1
    x34       E34,52                          1
    x34       E34,54                          1
    x34       E34,55                          1
    x34       E34,57                          1
    x34       E34,58                          1
    x34       E34,59                          1
    x35       cost                            1
    x35       C1,35                           1
    x35       C4,35                           1
    x35       C5,35                           1
    x35       C8,35                           1
    x35       C13,35                          1
    x35       C19,35                          1
    x35       C22,35                          1
    x35       C23,35                          1
    x35       C29,35                          1
    x35       C32,35                          1
    x35       C33,35                          1
    x35       C35,37                          1
    x35       C35,38                          1
    x35       C35,42                          1
    x35       C35,50                          1
    x35       C35,56                          1
    x35       E0,35                           1
    x35       E2,35                           1
    x35       E3,35                           1
    x35       E6,35                           1
    x35       E7,35                           1
    x35       E9,35                           1
    x35       E10,35                          1
    x35       E11,35                          1
    x35       E12,35                          1
    x35       E14,35                          1
    x35       E15,35                          1
    x35       E16,35                          1
    x35       E17,35                          1
    x35       E18,35                          1
    x35       E20,35                          1
    x35       E21,35                          1
    x35       E24,35                          1
    x35       E25,35                          1
    x35       E26,35                          1
    x35       E27,35                          1
    x35       E28,35                          1
    x35       E30,35                          1
    x35       E31,35                          1
    x35       E34,35                          1
    x35       E35,36                          1
    x35       E35,39                          1
    x35       E35,40                          1
    x35       E35,41                          1
    x35       E35,43                          1
    x35       E35,44                          1
    x35       E35,45                          1
    x35       E35,46                          1
    x35       E35,47                          1
    x35       E35,48                          1
    x35       E35,49                          1
    x35       E35,51                          1
    x35       E35,52                          1
    x35       E35,53                          1
    x35       E35,54                          1
    x35       E35,55                          1
    x35       E35,57                          1
    x35       E35,58                          1
    x35       E35,59                          1
    x36       cost                            1
    x36       C0,36                           1
    x36       C2,36                           1
    x36       C3,36                           1
    x36       C8,36                           1
    x36       C22,36                          1
    x36       C25,36                          1
    x36       C29,36                          1
    x36       C30,36                          1
    x36       C32,36                          1
    x36       C36,39                          1
    x36       C36,43                          1
    x36       C36,46                          1
    x36       C36,56                          1
    x36       E1,36                           1
    x36       E4,36                           1
    x36       E5,36                           1
    x36       E6,36                           1
    x36       E7,36                           1
    x36       E9,36                           1
    x36       E10,36                          1
    x36       E11,36                          1
    x36       E12,36                          1
    x36       E13,36                          1
    x36       E14,36                          1
    x36       E15,36                          1
    x36       E16,36                          1
    x36       E17,36                          1
    x36       E18,36                          1
    x36       E19,36                          1
    x36       E20,36                          1
    x36       E21,36                          1
    x36       E23,36                          1
    x36       E24,36                          1
    x36       E26,36                          1
    x36       E27,36                          1
    x36       E28,36                          1
    x36       E31,36                          1
    x36       E33,36                          1
    x36       E34,36                          1
    x36       E35,36                          1
    x36       E36,37                          1
    x36       E36,38                          1
    x36       E36,40                          1
    x36       E36,41                          1
    x36       E36,42                          1
    x36       E36,44                          1
    x36       E36,45                          1
    x36       E36,47                          1
    x36       E36,48                          1
    x36       E36,49                          1
    x36       E36,50                          1
    x36       E36,51                          1
    x36       E36,52                          1
    x36       E36,53                          1
    x36       E36,54                          1
    x36       E36,55                          1
    x36       E36,57                          1
    x36       E36,58                          1
    x36       E36,59                          1
    x37       cost                            1
    x37       C0,37                           1
    x37       C2,37                           1
    x37       C7,37                           1
    x37       C10,37                          1
    x37       C13,37                          1
    x37       C20,37                          1
    x37       C27,37                          1
    x37       C28,37                          1
    x37       C29,37                          1
    x37       C30,37                          1
    x37       C33,37                          1
    x37       C34,37                          1
    x37       C35,37                          1
    x37       C37,47                          1
    x37       C37,54                          1
    x37       C37,55                          1
    x37       C37,59                          1
    x37       E1,37                           1
    x37       E3,37                           1
    x37       E4,37                           1
    x37       E5,37                           1
    x37       E6,37                           1
    x37       E8,37                           1
    x37       E9,37                           1
    x37       E11,37                          1
    x37       E12,37                          1
    x37       E14,37                          1
    x37       E15,37                          1
    x37       E16,37                          1
    x37       E17,37                          1
    x37       E18,37                          1
    x37       E19,37                          1
    x37       E21,37                          1
    x37       E22,37                          1
    x37       E23,37                          1
    x37       E24,37                          1
    x37       E25,37                          1
    x37       E26,37                          1
    x37       E31,37                          1
    x37       E32,37                          1
    x37       E36,37                          1
    x37       E37,38                          1
    x37       E37,39                          1
    x37       E37,40                          1
    x37       E37,41                          1
    x37       E37,42                          1
    x37       E37,43                          1
    x37       E37,44                          1
    x37       E37,45                          1
    x37       E37,46                          1
    x37       E37,48                          1
    x37       E37,49                          1
    x37       E37,50                          1
    x37       E37,51                          1
    x37       E37,52                          1
    x37       E37,53                          1
    x37       E37,56                          1
    x37       E37,57                          1
    x37       E37,58                          1
    x38       cost                            1
    x38       C0,38                           1
    x38       C1,38                           1
    x38       C3,38                           1
    x38       C8,38                           1
    x38       C15,38                          1
    x38       C19,38                          1
    x38       C20,38                          1
    x38       C24,38                          1
    x38       C27,38                          1
    x38       C35,38                          1
    x38       C38,43                          1
    x38       C38,46                          1
    x38       C38,49                          1
    x38       C38,53                          1
    x38       C38,54                          1
    x38       C38,57                          1
    x38       C38,58                          1
    x38       E2,38                           1
    x38       E4,38                           1
    x38       E5,38                           1
    x38       E6,38                           1
    x38       E7,38                           1
    x38       E9,38                           1
    x38       E10,38                          1
    x38       E11,38                          1
    x38       E12,38                          1
    x38       E13,38                          1
    x38       E14,38                          1
    x38       E16,38                          1
    x38       E17,38                          1
    x38       E18,38                          1
    x38       E21,38                          1
    x38       E22,38                          1
    x38       E23,38                          1
    x38       E25,38                          1
    x38       E26,38                          1
    x38       E28,38                          1
    x38       E29,38                          1
    x38       E30,38                          1
    x38       E31,38                          1
    x38       E32,38                          1
    x38       E33,38                          1
    x38       E34,38                          1
    x38       E36,38                          1
    x38       E37,38                          1
    x38       E38,39                          1
    x38       E38,40                          1
    x38       E38,41                          1
    x38       E38,42                          1
    x38       E38,44                          1
    x38       E38,45                          1
    x38       E38,47                          1
    x38       E38,48                          1
    x38       E38,50                          1
    x38       E38,51                          1
    x38       E38,52                          1
    x38       E38,55                          1
    x38       E38,56                          1
    x38       E38,59                          1
    x39       cost                            1
    x39       C4,39                           1
    x39       C5,39                           1
    x39       C7,39                           1
    x39       C14,39                          1
    x39       C16,39                          1
    x39       C17,39                          1
    x39       C28,39                          1
    x39       C29,39                          1
    x39       C33,39                          1
    x39       C34,39                          1
    x39       C36,39                          1
    x39       C39,43                          1
    x39       C39,44                          1
    x39       C39,48                          1
    x39       C39,49                          1
    x39       C39,55                          1
    x39       C39,56                          1
    x39       C39,57                          1
    x39       E0,39                           1
    x39       E1,39                           1
    x39       E2,39                           1
    x39       E3,39                           1
    x39       E6,39                           1
    x39       E8,39                           1
    x39       E9,39                           1
    x39       E10,39                          1
    x39       E11,39                          1
    x39       E12,39                          1
    x39       E13,39                          1
    x39       E15,39                          1
    x39       E18,39                          1
    x39       E19,39                          1
    x39       E20,39                          1
    x39       E21,39                          1
    x39       E22,39                          1
    x39       E23,39                          1
    x39       E24,39                          1
    x39       E25,39                          1
    x39       E26,39                          1
    x39       E27,39                          1
    x39       E30,39                          1
    x39       E31,39                          1
    x39       E32,39                          1
    x39       E35,39                          1
    x39       E37,39                          1
    x39       E38,39                          1
    x39       E39,40                          1
    x39       E39,41                          1
    x39       E39,42                          1
    x39       E39,45                          1
    x39       E39,46                          1
    x39       E39,47                          1
    x39       E39,50                          1
    x39       E39,51                          1
    x39       E39,52                          1
    x39       E39,53                          1
    x39       E39,54                          1
    x39       E39,58                          1
    x39       E39,59                          1
    x40       cost                            1
    x40       C0,40                           1
    x40       C3,40                           1
    x40       C6,40                           1
    x40       C15,40                          1
    x40       C17,40                          1
    x40       C20,40                          1
    x40       C21,40                          1
    x40       C22,40                          1
    x40       C24,40                          1
    x40       C28,40                          1
    x40       C29,40                          1
    x40       C40,41                          1
    x40       C40,44                          1
    x40       C40,48                          1
    x40       C40,51                          1
    x40       C40,52                          1
    x40       C40,57                          1
    x40       C40,58                          1
    x40       E1,40                           1
    x40       E2,40                           1
    x40       E4,40                           1
    x40       E5,40                           1
    x40       E7,40                           1
    x40       E8,40                           1
    x40       E9,40                           1
    x40       E10,40                          1
    x40       E11,40                          1
    x40       E12,40                          1
    x40       E13,40                          1
    x40       E14,40                          1
    x40       E16,40                          1
    x40       E18,40                          1
    x40       E19,40                          1
    x40       E23,40                          1
    x40       E25,40                          1
    x40       E26,40                          1
    x40       E27,40                          1
    x40       E30,40                          1
    x40       E31,40                          1
    x40       E32,40                          1
    x40       E33,40                          1
    x40       E34,40                          1
    x40       E35,40                          1
    x40       E36,40                          1
    x40       E37,40                          1
    x40       E38,40                          1
    x40       E39,40                          1
    x40       E40,42                          1
    x40       E40,43                          1
    x40       E40,45                          1
    x40       E40,46                          1
    x40       E40,47                          1
    x40       E40,49                          1
    x40       E40,50                          1
    x40       E40,53                          1
    x40       E40,54                          1
    x40       E40,55                          1
    x40       E40,56                          1
    x40       E40,59                          1
    x41       cost                            1
    x41       C1,41                           1
    x41       C3,41                           1
    x41       C5,41                           1
    x41       C11,41                          1
    x41       C12,41                          1
    x41       C14,41                          1
    x41       C19,41                          1
    x41       C25,41                          1
    x41       C28,41                          1
    x41       C29,41                          1
    x41       C31,41                          1
    x41       C40,41                          1
    x41       C41,44                          1
    x41       C41,48                          1
    x41       C41,49                          1
    x41       C41,53                          1
    x41       C41,57                          1
    x41       C41,58                          1
    x41       C41,59                          1
    x41       E0,41                           1
    x41       E2,41                           1
    x41       E4,41                           1
    x41       E6,41                           1
    x41       E7,41                           1
    x41       E8,41                           1
    x41       E9,41                           1
    x41       E10,41                          1
    x41       E13,41                          1
    x41       E15,41                          1
    x41       E16,41                          1
    x41       E17,41                          1
    x41       E18,41                          1
    x41       E20,41                          1
    x41       E21,41                          1
    x41       E22,41                          1
    x41       E23,41                          1
    x41       E24,41                          1
    x41       E26,41                          1
    x41       E27,41                          1
    x41       E30,41                          1
    x41       E32,41                          1
    x41       E33,41                          1
    x41       E34,41                          1
    x41       E35,41                          1
    x41       E36,41                          1
    x41       E37,41                          1
    x41       E38,41                          1
    x41       E39,41                          1
    x41       E41,42                          1
    x41       E41,43                          1
    x41       E41,45                          1
    x41       E41,46                          1
    x41       E41,47                          1
    x41       E41,50                          1
    x41       E41,51                          1
    x41       E41,52                          1
    x41       E41,54                          1
    x41       E41,55                          1
    x41       E41,56                          1
    x42       cost                            1
    x42       C4,42                           1
    x42       C5,42                           1
    x42       C6,42                           1
    x42       C14,42                          1
    x42       C15,42                          1
    x42       C28,42                          1
    x42       C32,42                          1
    x42       C34,42                          1
    x42       C35,42                          1
    x42       C42,45                          1
    x42       C42,51                          1
    x42       C42,55                          1
    x42       C42,57                          1
    x42       E0,42                           1
    x42       E1,42                           1
    x42       E2,42                           1
    x42       E3,42                           1
    x42       E7,42                           1
    x42       E8,42                           1
    x42       E9,42                           1
    x42       E10,42                          1
    x42       E11,42                          1
    x42       E12,42                          1
    x42       E13,42                          1
    x42       E16,42                          1
    x42       E17,42                          1
    x42       E18,42                          1
    x42       E19,42                          1
    x42       E20,42                          1
    x42       E21,42                          1
    x42       E22,42                          1
    x42       E23,42                          1
    x42       E24,42                          1
    x42       E25,42                          1
    x42       E26,42                          1
    x42       E27,42                          1
    x42       E29,42                          1
    x42       E30,42                          1
    x42       E31,42                          1
    x42       E33,42                          1
    x42       E36,42                          1
    x42       E37,42                          1
    x42       E38,42                          1
    x42       E39,42                          1
    x42       E40,42                          1
    x42       E41,42                          1
    x42       E42,43                          1
    x42       E42,44                          1
    x42       E42,46                          1
    x42       E42,47                          1
    x42       E42,48                          1
    x42       E42,49                          1
    x42       E42,50                          1
    x42       E42,52                          1
    x42       E42,53                          1
    x42       E42,54                          1
    x42       E42,56                          1
    x42       E42,58                          1
    x42       E42,59                          1
    x43       cost                            1
    x43       C0,43                           1
    x43       C1,43                           1
    x43       C2,43                           1
    x43       C10,43                          1
    x43       C11,43                          1
    x43       C15,43                          1
    x43       C17,43                          1
    x43       C21,43                          1
    x43       C22,43                          1
    x43       C25,43                          1
    x43       C28,43                          1
    x43       C29,43                          1
    x43       C32,43                          1
    x43       C33,43                          1
    x43       C36,43                          1
    x43       C38,43                          1
    x43       C39,43                          1
    x43       C43,47                          1
    x43       C43,49                          1
    x43       C43,51                          1
    x43       C43,53                          1
    x43       C43,55                          1
    x43       C43,57                          1
    x43       C43,58                          1
    x43       E3,43                           1
    x43       E4,43                           1
    x43       E5,43                           1
    x43       E6,43                           1
    x43       E7,43                           1
    x43       E8,43                           1
    x43       E9,43                           1
    x43       E12,43                          1
    x43       E13,43                          1
    x43       E14,43                          1
    x43       E16,43                          1
    x43       E18,43                          1
    x43       E19,43                          1
    x43       E20,43                          1
    x43       E23,43                          1
    x43       E24,43                          1
    x43       E26,43                          1
    x43       E27,43                          1
    x43       E30,43                          1
    x43       E31,43                          1
    x43       E34,43                          1
    x43       E35,43                          1
    x43       E37,43                          1
    x43       E40,43                          1
    x43       E41,43                          1
    x43       E42,43                          1
    x43       E43,44                          1
    x43       E43,45                          1
    x43       E43,46                          1
    x43       E43,48                          1
    x43       E43,50                          1
    x43       E43,52                          1
    x43       E43,54                          1
    x43       E43,56                          1
    x43       E43,59                          1
    x44       cost                            1
    x44       C0,44                           1
    x44       C2,44                           1
    x44       C3,44                           1
    x44       C4,44                           1
    x44       C5,44                           1
    x44       C11,44                          1
    x44       C13,44                          1
    x44       C15,44                          1
    x44       C16,44                          1
    x44       C23,44                          1
    x44       C26,44                          1
    x44       C32,44                          1
    x44       C39,44                          1
    x44       C40,44                          1
    x44       C41,44                          1
    x44       C44,45                          1
    x44       C44,46                          1
    x44       C44,49                          1
    x44       C44,55                          1
    x44       C44,58                          1
    x44       E1,44                           1
    x44       E6,44                           1
    x44       E7,44                           1
    x44       E8,44                           1
    x44       E9,44                           1
    x44       E10,44                          1
    x44       E12,44                          1
    x44       E14,44                          1
    x44       E17,44                          1
    x44       E18,44                          1
    x44       E19,44                          1
    x44       E20,44                          1
    x44       E21,44                          1
    x44       E22,44                          1
    x44       E24,44                          1
    x44       E25,44                          1
    x44       E27,44                          1
    x44       E28,44                          1
    x44       E29,44                          1
    x44       E30,44                          1
    x44       E31,44                          1
    x44       E33,44                          1
    x44       E34,44                          1
    x44       E35,44                          1
    x44       E36,44                          1
    x44       E37,44                          1
    x44       E38,44                          1
    x44       E42,44                          1
    x44       E43,44                          1
    x44       E44,47                          1
    x44       E44,48                          1
    x44       E44,50                          1
    x44       E44,51                          1
    x44       E44,52                          1
    x44       E44,53                          1
    x44       E44,54                          1
    x44       E44,56                          1
    x44       E44,57                          1
    x44       E44,59                          1
    x45       cost                            1
    x45       C1,45                           1
    x45       C2,45                           1
    x45       C4,45                           1
    x45       C5,45                           1
    x45       C6,45                           1
    x45       C13,45                          1
    x45       C16,45                          1
    x45       C23,45                          1
    x45       C27,45                          1
    x45       C28,45                          1
    x45       C29,45                          1
    x45       C31,45                          1
    x45       C32,45                          1
    x45       C33,45                          1
    x45       C42,45                          1
    x45       C44,45                          1
    x45       C45,46                          1
    x45       C45,48                          1
    x45       C45,49                          1
    x45       C45,51                          1
    x45       C45,52                          1
    x45       C45,53                          1
    x45       C45,55                          1
    x45       C45,57                          1
    x45       E0,45                           1
    x45       E3,45                           1
    x45       E7,45                           1
    x45       E8,45                           1
    x45       E9,45                           1
    x45       E10,45                          1
    x45       E11,45                          1
    x45       E12,45                          1
    x45       E14,45                          1
    x45       E15,45                          1
    x45       E17,45                          1
    x45       E18,45                          1
    x45       E19,45                          1
    x45       E20,45                          1
    x45       E21,45                          1
    x45       E22,45                          1
    x45       E24,45                          1
    x45       E25,45                          1
    x45       E26,45                          1
    x45       E30,45                          1
    x45       E34,45                          1
    x45       E35,45                          1
    x45       E36,45                          1
    x45       E37,45                          1
    x45       E38,45                          1
    x45       E39,45                          1
    x45       E40,45                          1
    x45       E41,45                          1
    x45       E43,45                          1
    x45       E45,47                          1
    x45       E45,50                          1
    x45       E45,54                          1
    x45       E45,56                          1
    x45       E45,58                          1
    x45       E45,59                          1
    x46       cost                            1
    x46       C1,46                           1
    x46       C2,46                           1
    x46       C3,46                           1
    x46       C18,46                          1
    x46       C19,46                          1
    x46       C20,46                          1
    x46       C21,46                          1
    x46       C23,46                          1
    x46       C25,46                          1
    x46       C28,46                          1
    x46       C36,46                          1
    x46       C38,46                          1
    x46       C44,46                          1
    x46       C45,46                          1
    x46       C46,48                          1
    x46       C46,52                          1
    x46       C46,57                          1
    x46       E0,46                           1
    x46       E4,46                           1
    x46       E5,46                           1
    x46       E6,46                           1
    x46       E7,46                           1
    x46       E8,46                           1
    x46       E9,46                           1
    x46       E10,46                          1
    x46       E11,46                          1
    x46       E12,46                          1
    x46       E13,46                          1
    x46       E14,46                          1
    x46       E15,46                          1
    x46       E16,46                          1
    x46       E17,46                          1
    x46       E22,46                          1
    x46       E24,46                          1
    x46       E26,46                          1
    x46       E27,46                          1
    x46       E29,46                          1
    x46       E30,46                          1
    x46       E31,46                          1
    x46       E32,46                          1
    x46       E33,46                          1
    x46       E34,46                          1
    x46       E35,46                          1
    x46       E37,46                          1
    x46       E39,46                          1
    x46       E40,46                          1
    x46       E41,46                          1
    x46       E42,46                          1
    x46       E43,46                          1
    x46       E46,47                          1
    x46       E46,49                          1
    x46       E46,50                          1
    x46       E46,51                          1
    x46       E46,53                          1
    x46       E46,54                          1
    x46       E46,55                          1
    x46       E46,56                          1
    x46       E46,58                          1
    x46       E46,59                          1
    x47       cost                            1
    x47       C0,47                           1
    x47       C1,47                           1
    x47       C2,47                           1
    x47       C6,47                           1
    x47       C8,47                           1
    x47       C9,47                           1
    x47       C13,47                          1
    x47       C19,47                          1
    x47       C26,47                          1
    x47       C29,47                          1
    x47       C33,47                          1
    x47       C37,47                          1
    x47       C43,47                          1
    x47       C47,54                          1
    x47       E3,47                           1
    x47       E4,47                           1
    x47       E5,47                           1
    x47       E7,47                           1
    x47       E10,47                          1
    x47       E11,47                          1
    x47       E12,47                          1
    x47       E14,47                          1
    x47       E15,47                          1
    x47       E16,47                          1
    x47       E17,47                          1
    x47       E18,47                          1
    x47       E20,47                          1
    x47       E21,47                          1
    x47       E22,47                          1
    x47       E23,47                          1
    x47       E24,47                          1
    x47       E25,47                          1
    x47       E27,47                          1
    x47       E28,47                          1
    x47       E30,47                          1
    x47       E31,47                          1
    x47       E32,47                          1
    x47       E34,47                          1
    x47       E35,47                          1
    x47       E36,47                          1
    x47       E38,47                          1
    x47       E39,47                          1
    x47       E40,47                          1
    x47       E41,47                          1
    x47       E42,47                          1
    x47       E44,47                          1
    x47       E45,47                          1
    x47       E46,47                          1
    x47       E47,48                          1
    x47       E47,49                          1
    x47       E47,50                          1
    x47       E47,51                          1
    x47       E47,52                          1
    x47       E47,53                          1
    x47       E47,55                          1
    x47       E47,56                          1
    x47       E47,57                          1
    x47       E47,58                          1
    x47       E47,59                          1
    x48       cost                            1
    x48       C7,48                           1
    x48       C8,48                           1
    x48       C9,48                           1
    x48       C13,48                          1
    x48       C15,48                          1
    x48       C16,48                          1
    x48       C19,48                          1
    x48       C21,48                          1
    x48       C23,48                          1
    x48       C27,48                          1
    x48       C29,48                          1
    x48       C39,48                          1
    x48       C40,48                          1
    x48       C41,48                          1
    x48       C45,48                          1
    x48       C46,48                          1
    x48       C48,52                          1
    x48       E0,48                           1
    x48       E1,48                           1
    x48       E2,48                           1
    x48       E3,48                           1
    x48       E4,48                           1
    x48       E5,48                           1
    x48       E6,48                           1
    x48       E10,48                          1
    x48       E11,48                          1
    x48       E12,48                          1
    x48       E14,48                          1
    x48       E17,48                          1
    x48       E18,48                          1
    x48       E20,48                          1
    x48       E22,48                          1
    x48       E24,48                          1
    x48       E25,48                          1
    x48       E26,48                          1
    x48       E28,48                          1
    x48       E30,48                          1
    x48       E31,48                          1
    x48       E32,48                          1
    x48       E33,48                          1
    x48       E34,48                          1
    x48       E35,48                          1
    x48       E36,48                          1
    x48       E37,48                          1
    x48       E38,48                          1
    x48       E42,48                          1
    x48       E43,48                          1
    x48       E44,48                          1
    x48       E47,48                          1
    x48       E48,49                          1
    x48       E48,50                          1
    x48       E48,51                          1
    x48       E48,53                          1
    x48       E48,54                          1
    x48       E48,55                          1
    x48       E48,56                          1
    x48       E48,57                          1
    x48       E48,58                          1
    x48       E48,59                          1
    x49       cost                            1
    x49       C2,49                           1
    x49       C7,49                           1
    x49       C10,49                          1
    x49       C13,49                          1
    x49       C18,49                          1
    x49       C32,49                          1
    x49       C38,49                          1
    x49       C39,49                          1
    x49       C41,49                          1
    x49       C43,49                          1
    x49       C44,49                          1
    x49       C45,49                          1
    x49       C49,51                          1
    x49       C49,52                          1
    x49       C49,54                          1
    x49       E0,49                           1
    x49       E1,49                           1
    x49       E3,49                           1
    x49       E4,49                           1
    x49       E5,49                           1
    x49       E6,49                           1
    x49       E8,49                           1
    x49       E9,49                           1
    x49       E11,49                          1
    x49       E12,49                          1
    x49       E14,49                          1
    x49       E15,49                          1
    x49       E16,49                          1
    x49       E17,49                          1
    x49       E19,49                          1
    x49       E20,49                          1
    x49       E21,49                          1
    x49       E22,49                          1
    x49       E23,49                          1
    x49       E24,49                          1
    x49       E25,49                          1
    x49       E26,49                          1
    x49       E27,49                          1
    x49       E28,49                          1
    x49       E29,49                          1
    x49       E30,49                          1
    x49       E31,49                          1
    x49       E33,49                          1
    x49       E34,49                          1
    x49       E35,49                          1
    x49       E36,49                          1
    x49       E37,49                          1
    x49       E40,49                          1
    x49       E42,49                          1
    x49       E46,49                          1
    x49       E47,49                          1
    x49       E48,49                          1
    x49       E49,50                          1
    x49       E49,53                          1
    x49       E49,55                          1
    x49       E49,56                          1
    x49       E49,57                          1
    x49       E49,58                          1
    x49       E49,59                          1
    x50       cost                            1
    x50       C0,50                           1
    x50       C1,50                           1
    x50       C4,50                           1
    x50       C11,50                          1
    x50       C16,50                          1
    x50       C17,50                          1
    x50       C31,50                          1
    x50       C35,50                          1
    x50       C50,51                          1
    x50       C50,53                          1
    x50       C50,58                          1
    x50       E2,50                           1
    x50       E3,50                           1
    x50       E5,50                           1
    x50       E6,50                           1
    x50       E7,50                           1
    x50       E8,50                           1
    x50       E9,50                           1
    x50       E10,50                          1
    x50       E12,50                          1
    x50       E13,50                          1
    x50       E14,50                          1
    x50       E15,50                          1
    x50       E18,50                          1
    x50       E19,50                          1
    x50       E20,50                          1
    x50       E21,50                          1
    x50       E22,50                          1
    x50       E23,50                          1
    x50       E24,50                          1
    x50       E25,50                          1
    x50       E26,50                          1
    x50       E27,50                          1
    x50       E28,50                          1
    x50       E29,50                          1
    x50       E30,50                          1
    x50       E32,50                          1
    x50       E33,50                          1
    x50       E34,50                          1
    x50       E36,50                          1
    x50       E37,50                          1
    x50       E38,50                          1
    x50       E39,50                          1
    x50       E40,50                          1
    x50       E41,50                          1
    x50       E42,50                          1
    x50       E43,50                          1
    x50       E44,50                          1
    x50       E45,50                          1
    x50       E46,50                          1
    x50       E47,50                          1
    x50       E48,50                          1
    x50       E49,50                          1
    x50       E50,52                          1
    x50       E50,54                          1
    x50       E50,55                          1
    x50       E50,56                          1
    x50       E50,57                          1
    x50       E50,59                          1
    x51       cost                            1
    x51       C0,51                           1
    x51       C9,51                           1
    x51       C11,51                          1
    x51       C12,51                          1
    x51       C20,51                          1
    x51       C21,51                          1
    x51       C31,51                          1
    x51       C33,51                          1
    x51       C34,51                          1
    x51       C40,51                          1
    x51       C42,51                          1
    x51       C43,51                          1
    x51       C45,51                          1
    x51       C49,51                          1
    x51       C50,51                          1
    x51       C51,54                          1
    x51       C51,56                          1
    x51       C51,57                          1
    x51       C51,58                          1
    x51       E1,51                           1
    x51       E2,51                           1
    x51       E3,51                           1
    x51       E4,51                           1
    x51       E5,51                           1
    x51       E6,51                           1
    x51       E7,51                           1
    x51       E8,51                           1
    x51       E10,51                          1
    x51       E13,51                          1
    x51       E14,51                          1
    x51       E15,51                          1
    x51       E16,51                          1
    x51       E17,51                          1
    x51       E18,51                          1
    x51       E19,51                          1
    x51       E22,51                          1
    x51       E23,51                          1
    x51       E24,51                          1
    x51       E25,51                          1
    x51       E26,51                          1
    x51       E27,51                          1
    x51       E28,51                          1
    x51       E29,51                          1
    x51       E30,51                          1
    x51       E32,51                          1
    x51       E35,51                          1
    x51       E36,51                          1
    x51       E37,51                          1
    x51       E38,51                          1
    x51       E39,51                          1
    x51       E41,51                          1
    x51       E44,51                          1
    x51       E46,51                          1
    x51       E47,51                          1
    x51       E48,51                          1
    x51       E51,52                          1
    x51       E51,53                          1
    x51       E51,55                          1
    x51       E51,59                          1
    x52       cost                            1
    x52       C4,52                           1
    x52       C6,52                           1
    x52       C8,52                           1
    x52       C13,52                          1
    x52       C15,52                          1
    x52       C17,52                          1
    x52       C22,52                          1
    x52       C26,52                          1
    x52       C28,52                          1
    x52       C29,52                          1
    x52       C32,52                          1
    x52       C40,52                          1
    x52       C45,52                          1
    x52       C46,52                          1
    x52       C48,52                          1
    x52       C49,52                          1
    x52       C52,55                          1
    x52       C52,56                          1
    x52       C52,57                          1
    x52       C52,59                          1
    x52       E0,52                           1
    x52       E1,52                           1
    x52       E2,52                           1
    x52       E3,52                           1
    x52       E5,52                           1
    x52       E7,52                           1
    x52       E9,52                           1
    x52       E10,52                          1
    x52       E11,52                          1
    x52       E12,52                          1
    x52       E14,52                          1
    x52       E16,52                          1
    x52       E18,52                          1
    x52       E19,52                          1
    x52       E20,52                          1
    x52       E21,52                          1
    x52       E23,52                          1
    x52       E24,52                          1
    x52       E25,52                          1
    x52       E27,52                          1
    x52       E30,52                          1
    x52       E31,52                          1
    x52       E33,52                          1
    x52       E34,52                          1
    x52       E35,52                          1
    x52       E36,52                          1
    x52       E37,52                          1
    x52       E38,52                          1
    x52       E39,52                          1
    x52       E41,52                          1
    x52       E42,52                          1
    x52       E43,52                          1
    x52       E44,52                          1
    x52       E47,52                          1
    x52       E50,52                          1
    x52       E51,52                          1
    x52       E52,53                          1
    x52       E52,54                          1
    x52       E52,58                          1
    x53       cost                            1
    x53       C9,53                           1
    x53       C15,53                          1
    x53       C23,53                          1
    x53       C26,53                          1
    x53       C34,53                          1
    x53       C38,53                          1
    x53       C41,53                          1
    x53       C43,53                          1
    x53       C45,53                          1
    x53       C50,53                          1
    x53       C53,54                          1
    x53       E0,53                           1
    x53       E1,53                           1
    x53       E2,53                           1
    x53       E3,53                           1
    x53       E4,53                           1
    x53       E5,53                           1
    x53       E6,53                           1
    x53       E7,53                           1
    x53       E8,53                           1
    x53       E10,53                          1
    x53       E11,53                          1
    x53       E12,53                          1
    x53       E13,53                          1
    x53       E14,53                          1
    x53       E16,53                          1
    x53       E17,53                          1
    x53       E18,53                          1
    x53       E19,53                          1
    x53       E20,53                          1
    x53       E21,53                          1
    x53       E22,53                          1
    x53       E24,53                          1
    x53       E25,53                          1
    x53       E27,53                          1
    x53       E28,53                          1
    x53       E29,53                          1
    x53       E30,53                          1
    x53       E31,53                          1
    x53       E32,53                          1
    x53       E33,53                          1
    x53       E35,53                          1
    x53       E36,53                          1
    x53       E37,53                          1
    x53       E39,53                          1
    x53       E40,53                          1
    x53       E42,53                          1
    x53       E44,53                          1
    x53       E46,53                          1
    x53       E47,53                          1
    x53       E48,53                          1
    x53       E49,53                          1
    x53       E51,53                          1
    x53       E52,53                          1
    x53       E53,55                          1
    x53       E53,56                          1
    x53       E53,57                          1
    x53       E53,58                          1
    x53       E53,59                          1
    x54       cost                            1
    x54       C2,54                           1
    x54       C4,54                           1
    x54       C13,54                          1
    x54       C20,54                          1
    x54       C22,54                          1
    x54       C24,54                          1
    x54       C26,54                          1
    x54       C27,54                          1
    x54       C30,54                          1
    x54       C37,54                          1
    x54       C38,54                          1
    x54       C47,54                          1
    x54       C49,54                          1
    x54       C51,54                          1
    x54       C53,54                          1
    x54       E0,54                           1
    x54       E1,54                           1
    x54       E3,54                           1
    x54       E5,54                           1
    x54       E6,54                           1
    x54       E7,54                           1
    x54       E8,54                           1
    x54       E9,54                           1
    x54       E10,54                          1
    x54       E11,54                          1
    x54       E12,54                          1
    x54       E14,54                          1
    x54       E15,54                          1
    x54       E16,54                          1
    x54       E17,54                          1
    x54       E18,54                          1
    x54       E19,54                          1
    x54       E21,54                          1
    x54       E23,54                          1
    x54       E25,54                          1
    x54       E28,54                          1
    x54       E29,54                          1
    x54       E31,54                          1
    x54       E32,54                          1
    x54       E33,54                          1
    x54       E34,54                          1
    x54       E35,54                          1
    x54       E36,54                          1
    x54       E39,54                          1
    x54       E40,54                          1
    x54       E41,54                          1
    x54       E42,54                          1
    x54       E43,54                          1
    x54       E44,54                          1
    x54       E45,54                          1
    x54       E46,54                          1
    x54       E48,54                          1
    x54       E50,54                          1
    x54       E52,54                          1
    x54       E54,55                          1
    x54       E54,56                          1
    x54       E54,57                          1
    x54       E54,58                          1
    x54       E54,59                          1
    x55       cost                            1
    x55       C5,55                           1
    x55       C6,55                           1
    x55       C7,55                           1
    x55       C10,55                          1
    x55       C11,55                          1
    x55       C14,55                          1
    x55       C16,55                          1
    x55       C22,55                          1
    x55       C24,55                          1
    x55       C28,55                          1
    x55       C30,55                          1
    x55       C31,55                          1
    x55       C37,55                          1
    x55       C39,55                          1
    x55       C42,55                          1
    x55       C43,55                          1
    x55       C44,55                          1
    x55       C45,55                          1
    x55       C52,55                          1
    x55       E0,55                           1
    x55       E1,55                           1
    x55       E2,55                           1
    x55       E3,55                           1
    x55       E4,55                           1
    x55       E8,55                           1
    x55       E9,55                           1
    x55       E12,55                          1
    x55       E13,55                          1
    x55       E15,55                          1
    x55       E17,55                          1
    x55       E18,55                          1
    x55       E19,55                          1
    x55       E20,55                          1
    x55       E21,55                          1
    x55       E23,55                          1
    x55       E25,55                          1
    x55       E26,55                          1
    x55       E27,55                          1
    x55       E29,55                          1
    x55       E32,55                          1
    x55       E33,55                          1
    x55       E34,55                          1
    x55       E35,55                          1
    x55       E36,55                          1
    x55       E38,55                          1
    x55       E40,55                          1
    x55       E41,55                          1
    x55       E46,55                          1
    x55       E47,55                          1
    x55       E48,55                          1
    x55       E49,55                          1
    x55       E50,55                          1
    x55       E51,55                          1
    x55       E53,55                          1
    x55       E54,55                          1
    x55       E55,56                          1
    x55       E55,57                          1
    x55       E55,58                          1
    x55       E55,59                          1
    x56       cost                            1
    x56       C0,56                           1
    x56       C5,56                           1
    x56       C9,56                           1
    x56       C15,56                          1
    x56       C16,56                          1
    x56       C17,56                          1
    x56       C19,56                          1
    x56       C28,56                          1
    x56       C32,56                          1
    x56       C34,56                          1
    x56       C35,56                          1
    x56       C36,56                          1
    x56       C39,56                          1
    x56       C51,56                          1
    x56       C52,56                          1
    x56       C56,57                          1
    x56       C56,59                          1
    x56       E1,56                           1
    x56       E2,56                           1
    x56       E3,56                           1
    x56       E4,56                           1
    x56       E6,56                           1
    x56       E7,56                           1
    x56       E8,56                           1
    x56       E10,56                          1
    x56       E11,56                          1
    x56       E12,56                          1
    x56       E13,56                          1
    x56       E14,56                          1
    x56       E18,56                          1
    x56       E20,56                          1
    x56       E21,56                          1
    x56       E22,56                          1
    x56       E23,56                          1
    x56       E24,56                          1
    x56       E25,56                          1
    x56       E26,56                          1
    x56       E27,56                          1
    x56       E29,56                          1
    x56       E30,56                          1
    x56       E31,56                          1
    x56       E33,56                          1
    x56       E37,56                          1
    x56       E38,56                          1
    x56       E40,56                          1
    x56       E41,56                          1
    x56       E42,56                          1
    x56       E43,56                          1
    x56       E44,56                          1
    x56       E45,56                          1
    x56       E46,56                          1
    x56       E47,56                          1
    x56       E48,56                          1
    x56       E49,56                          1
    x56       E50,56                          1
    x56       E53,56                          1
    x56       E54,56                          1
    x56       E55,56                          1
    x56       E56,58                          1
    x57       cost                            1
    x57       C1,57                           1
    x57       C5,57                           1
    x57       C9,57                           1
    x57       C12,57                          1
    x57       C17,57                          1
    x57       C19,57                          1
    x57       C22,57                          1
    x57       C31,57                          1
    x57       C33,57                          1
    x57       C38,57                          1
    x57       C39,57                          1
    x57       C40,57                          1
    x57       C41,57                          1
    x57       C42,57                          1
    x57       C43,57                          1
    x57       C45,57                          1
    x57       C46,57                          1
    x57       C51,57                          1
    x57       C52,57                          1
    x57       C56,57                          1
    x57       C57,58                          1
    x57       E0,57                           1
    x57       E2,57                           1
    x57       E3,57                           1
    x57       E4,57                           1
    x57       E6,57                           1
    x57       E7,57                           1
    x57       E8,57                           1
    x57       E10,57                          1
    x57       E11,57                          1
    x57       E13,57                          1
    x57       E14,57                          1
    x57       E15,57                          1
    x57       E16,57                          1
    x57       E18,57                          1
    x57       E20,57                          1
    x57       E21,57                          1
    x57       E23,57                          1
    x57       E24,57                          1
    x57       E25,57                          1
    x57       E26,57                          1
    x57       E27,57                          1
    x57       E28,57                          1
    x57       E29,57                          1
    x57       E30,57                          1
    x57       E32,57                          1
    x57       E34,57                          1
    x57       E35,57                          1
    x57       E36,57                          1
    x57       E37,57                          1
    x57       E44,57                          1
    x57       E47,57                          1
    x57       E48,57                          1
    x57       E49,57                          1
    x57       E50,57                          1
    x57       E53,57                          1
    x57       E54,57                          1
    x57       E55,57                          1
    x57       E57,59                          1
    x58       cost                            1
    x58       C0,58                           1
    x58       C3,58                           1
    x58       C5,58                           1
    x58       C10,58                          1
    x58       C16,58                          1
    x58       C18,58                          1
    x58       C20,58                          1
    x58       C21,58                          1
    x58       C24,58                          1
    x58       C25,58                          1
    x58       C27,58                          1
    x58       C38,58                          1
    x58       C40,58                          1
    x58       C41,58                          1
    x58       C43,58                          1
    x58       C44,58                          1
    x58       C50,58                          1
    x58       C51,58                          1
    x58       C57,58                          1
    x58       E1,58                           1
    x58       E2,58                           1
    x58       E4,58                           1
    x58       E6,58                           1
    x58       E7,58                           1
    x58       E8,58                           1
    x58       E9,58                           1
    x58       E11,58                          1
    x58       E12,58                          1
    x58       E13,58                          1
    x58       E14,58                          1
    x58       E15,58                          1
    x58       E17,58                          1
    x58       E19,58                          1
    x58       E22,58                          1
    x58       E23,58                          1
    x58       E26,58                          1
    x58       E28,58                          1
    x58       E29,58                          1
    x58       E30,58                          1
    x58       E31,58                          1
    x58       E32,58                          1
    x58       E33,58                          1
    x58       E34,58                          1
    x58       E35,58                          1
    x58       E36,58                          1
    x58       E37,58                          1
    x58       E39,58                          1
    x58       E42,58                          1
    x58       E45,58                          1
    x58       E46,58                          1
    x58       E47,58                          1
    x58       E48,58                          1
    x58       E49,58                          1
    x58       E52,58                          1
    x58       E53,58                          1
    x58       E54,58                          1
    x58       E55,58                          1
    x58       E56,58                          1
    x58       E58,59                          1
    x59       cost                            1
    x59       C4,59                           1
    x59       C5,59                           1
    x59       C7,59                           1
    x59       C8,59                           1
    x59       C14,59                          1
    x59       C20,59                          1
    x59       C21,59                          1
    x59       C28,59                          1
    x59       C31,59                          1
    x59       C32,59                          1
    x59       C37,59                          1
    x59       C41,59                          1
    x59       C52,59                          1
    x59       C56,59                          1
    x59       E0,59                           1
    x59       E1,59                           1
    x59       E2,59                           1
    x59       E3,59                           1
    x59       E6,59                           1
    x59       E9,59                           1
    x59       E10,59                          1
    x59       E11,59                          1
    x59       E12,59                          1
    x59       E13,59                          1
    x59       E15,59                          1
    x59       E16,59                          1
    x59       E17,59                          1
    x59       E18,59                          1
    x59       E19,59                          1
    x59       E22,59                          1
    x59       E23,59                          1
    x59       E24,59                          1
    x59       E25,59                          1
    x59       E26,59                          1
    x59       E27,59                          1
    x59       E29,59                          1
    x59       E30,59                          1
    x59       E33,59                          1
    x59       E34,59                          1
    x59       E35,59                          1
    x59       E36,59                          1
    x59       E38,59                          1
    x59       E39,59                          1
    x59       E40,59                          1
    x59       E42,59                          1
    x59       E43,59                          1
    x59       E44,59                          1
    x59       E45,59                          1
    x59       E46,59                          1
    x59       E47,59                          1
    x59       E48,59                          1
    x59       E49,59                          1
    x59       E50,59                          1
    x59       E51,59                          1
    x59       E53,59                          1
    x59       E54,59                          1
    x59       E55,59                          1
    x59       E57,59                          1
    x59       E58,59                          1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       KL                            309
    rhs       C0,3                            1
    rhs       C0,5                            1
    rhs       C0,6                            1
    rhs       C0,19                           1
    rhs       C0,22                           1
    rhs       C0,24                           1
    rhs       C0,26                           1
    rhs       C0,36                           1
    rhs       C0,37                           1
    rhs       C0,38                           1
    rhs       C0,40                           1
    rhs       C0,43                           1
    rhs       C0,44                           1
    rhs       C0,47                           1
    rhs       C0,50                           1
    rhs       C0,51                           1
    rhs       C0,56                           1
    rhs       C0,58                           1
    rhs       C1,9                            1
    rhs       C1,11                           1
    rhs       C1,20                           1
    rhs       C1,21                           1
    rhs       C1,24                           1
    rhs       C1,27                           1
    rhs       C1,30                           1
    rhs       C1,33                           1
    rhs       C1,35                           1
    rhs       C1,38                           1
    rhs       C1,41                           1
    rhs       C1,43                           1
    rhs       C1,45                           1
    rhs       C1,46                           1
    rhs       C1,47                           1
    rhs       C1,50                           1
    rhs       C1,57                           1
    rhs       C2,5                            1
    rhs       C2,7                            1
    rhs       C2,8                            1
    rhs       C2,10                           1
    rhs       C2,13                           1
    rhs       C2,20                           1
    rhs       C2,26                           1
    rhs       C2,32                           1
    rhs       C2,36                           1
    rhs       C2,37                           1
    rhs       C2,43                           1
    rhs       C2,44                           1
    rhs       C2,45                           1
    rhs       C2,46                           1
    rhs       C2,47                           1
    rhs       C2,49                           1
    rhs       C2,54                           1
    rhs       C3,4                            1
    rhs       C3,7                            1
    rhs       C3,14                           1
    rhs       C3,16                           1
    rhs       C3,21                           1
    rhs       C3,23                           1
    rhs       C3,24                           1
    rhs       C3,30                           1
    rhs       C3,33                           1
    rhs       C3,36                           1
    rhs       C3,38                           1
    rhs       C3,40                           1
    rhs       C3,41                           1
    rhs       C3,44                           1
    rhs       C3,46                           1
    rhs       C3,58                           1
    rhs       C4,6                            1
    rhs       C4,9                            1
    rhs       C4,11                           1
    rhs       C4,12                           1
    rhs       C4,17                           1
    rhs       C4,18                           1
    rhs       C4,21                           1
    rhs       C4,23                           1
    rhs       C4,28                           1
    rhs       C4,29                           1
    rhs       C4,31                           1
    rhs       C4,32                           1
    rhs       C4,34                           1
    rhs       C4,35                           1
    rhs       C4,39                           1
    rhs       C4,42                           1
    rhs       C4,44                           1
    rhs       C4,45                           1
    rhs       C4,50                           1
    rhs       C4,52                           1
    rhs       C4,54                           1
    rhs       C4,59                           1
    rhs       C5,6                            1
    rhs       C5,11                           1
    rhs       C5,12                           1
    rhs       C5,16                           1
    rhs       C5,17                           1
    rhs       C5,19                           1
    rhs       C5,21                           1
    rhs       C5,33                           1
    rhs       C5,34                           1
    rhs       C5,35                           1
    rhs       C5,39                           1
    rhs       C5,41                           1
    rhs       C5,42                           1
    rhs       C5,44                           1
    rhs       C5,45                           1
    rhs       C5,55                           1
    rhs       C5,56                           1
    rhs       C5,57                           1
    rhs       C5,58                           1
    rhs       C5,59                           1
    rhs       C6,9                            1
    rhs       C6,11                           1
    rhs       C6,12                           1
    rhs       C6,13                           1
    rhs       C6,14                           1
    rhs       C6,16                           1
    rhs       C6,18                           1
    rhs       C6,20                           1
    rhs       C6,21                           1
    rhs       C6,25                           1
    rhs       C6,26                           1
    rhs       C6,28                           1
    rhs       C6,29                           1
    rhs       C6,31                           1
    rhs       C6,32                           1
    rhs       C6,33                           1
    rhs       C6,40                           1
    rhs       C6,42                           1
    rhs       C6,45                           1
    rhs       C6,47                           1
    rhs       C6,52                           1
    rhs       C6,55                           1
    rhs       C7,10                           1
    rhs       C7,11                           1
    rhs       C7,13                           1
    rhs       C7,14                           1
    rhs       C7,21                           1
    rhs       C7,22                           1
    rhs       C7,25                           1
    rhs       C7,29                           1
    rhs       C7,31                           1
    rhs       C7,37                           1
    rhs       C7,39                           1
    rhs       C7,48                           1
    rhs       C7,49                           1
    rhs       C7,55                           1
    rhs       C7,59                           1
    rhs       C8,9                            1
    rhs       C8,11                           1
    rhs       C8,17                           1
    rhs       C8,29                           1
    rhs       C8,35                           1
    rhs       C8,36                           1
    rhs       C8,38                           1
    rhs       C8,47                           1
    rhs       C8,48                           1
    rhs       C8,52                           1
    rhs       C8,59                           1
    rhs       C9,10                           1
    rhs       C9,11                           1
    rhs       C9,13                           1
    rhs       C9,14                           1
    rhs       C9,17                           1
    rhs       C9,18                           1
    rhs       C9,20                           1
    rhs       C9,24                           1
    rhs       C9,27                           1
    rhs       C9,47                           1
    rhs       C9,48                           1
    rhs       C9,51                           1
    rhs       C9,53                           1
    rhs       C9,56                           1
    rhs       C9,57                           1
    rhs       C10,12                          1
    rhs       C10,14                          1
    rhs       C10,17                          1
    rhs       C10,20                          1
    rhs       C10,22                          1
    rhs       C10,24                          1
    rhs       C10,33                          1
    rhs       C10,37                          1
    rhs       C10,43                          1
    rhs       C10,49                          1
    rhs       C10,55                          1
    rhs       C10,58                          1
    rhs       C11,13                          1
    rhs       C11,16                          1
    rhs       C11,18                          1
    rhs       C11,19                          1
    rhs       C11,20                          1
    rhs       C11,22                          1
    rhs       C11,24                          1
    rhs       C11,27                          1
    rhs       C11,28                          1
    rhs       C11,41                          1
    rhs       C11,43                          1
    rhs       C11,44                          1
    rhs       C11,50                          1
    rhs       C11,51                          1
    rhs       C11,55                          1
    rhs       C12,13                          1
    rhs       C12,18                          1
    rhs       C12,21                          1
    rhs       C12,24                          1
    rhs       C12,28                          1
    rhs       C12,41                          1
    rhs       C12,51                          1
    rhs       C12,57                          1
    rhs       C13,15                          1
    rhs       C13,18                          1
    rhs       C13,25                          1
    rhs       C13,26                          1
    rhs       C13,29                          1
    rhs       C13,30                          1
    rhs       C13,31                          1
    rhs       C13,35                          1
    rhs       C13,37                          1
    rhs       C13,44                          1
    rhs       C13,45                          1
    rhs       C13,47                          1
    rhs       C13,48                          1
    rhs       C13,49                          1
    rhs       C13,52                          1
    rhs       C13,54                          1
    rhs       C14,15                          1
    rhs       C14,16                          1
    rhs       C14,17                          1
    rhs       C14,22                          1
    rhs       C14,23                          1
    rhs       C14,24                          1
    rhs       C14,26                          1
    rhs       C14,30                          1
    rhs       C14,32                          1
    rhs       C14,34                          1
    rhs       C14,39                          1
    rhs       C14,41                          1
    rhs       C14,42                          1
    rhs       C14,55                          1
    rhs       C14,59                          1
    rhs       C15,19                          1
    rhs       C15,21                          1
    rhs       C15,22                          1
    rhs       C15,24                          1
    rhs       C15,27                          1
    rhs       C15,29                          1
    rhs       C15,30                          1
    rhs       C15,31                          1
    rhs       C15,34                          1
    rhs       C15,38                          1
    rhs       C15,40                          1
    rhs       C15,42                          1
    rhs       C15,43                          1
    rhs       C15,44                          1
    rhs       C15,48                          1
    rhs       C15,52                          1
    rhs       C15,53                          1
    rhs       C15,56                          1
    rhs       C16,22                          1
    rhs       C16,23                          1
    rhs       C16,24                          1
    rhs       C16,26                          1
    rhs       C16,27                          1
    rhs       C16,34                          1
    rhs       C16,39                          1
    rhs       C16,44                          1
    rhs       C16,45                          1
    rhs       C16,48                          1
    rhs       C16,50                          1
    rhs       C16,55                          1
    rhs       C16,56                          1
    rhs       C16,58                          1
    rhs       C17,19                          1
    rhs       C17,24                          1
    rhs       C17,27                          1
    rhs       C17,31                          1
    rhs       C17,34                          1
    rhs       C17,39                          1
    rhs       C17,40                          1
    rhs       C17,43                          1
    rhs       C17,50                          1
    rhs       C17,52                          1
    rhs       C17,56                          1
    rhs       C17,57                          1
    rhs       C18,20                          1
    rhs       C18,21                          1
    rhs       C18,24                          1
    rhs       C18,27                          1
    rhs       C18,46                          1
    rhs       C18,49                          1
    rhs       C18,58                          1
    rhs       C19,23                          1
    rhs       C19,25                          1
    rhs       C19,26                          1
    rhs       C19,27                          1
    rhs       C19,33                          1
    rhs       C19,34                          1
    rhs       C19,35                          1
    rhs       C19,38                          1
    rhs       C19,41                          1
    rhs       C19,46                          1
    rhs       C19,47                          1
    rhs       C19,48                          1
    rhs       C19,56                          1
    rhs       C19,57                          1
    rhs       C20,25                          1
    rhs       C20,31                          1
    rhs       C20,33                          1
    rhs       C20,37                          1
    rhs       C20,38                          1
    rhs       C20,40                          1
    rhs       C20,46                          1
    rhs       C20,51                          1
    rhs       C20,54                          1
    rhs       C20,58                          1
    rhs       C20,59                          1
    rhs       C21,22                          1
    rhs       C21,23                          1
    rhs       C21,28                          1
    rhs       C21,29                          1
    rhs       C21,31                          1
    rhs       C21,33                          1
    rhs       C21,40                          1
    rhs       C21,43                          1
    rhs       C21,46                          1
    rhs       C21,48                          1
    rhs       C21,51                          1
    rhs       C21,58                          1
    rhs       C21,59                          1
    rhs       C22,23                          1
    rhs       C22,24                          1
    rhs       C22,34                          1
    rhs       C22,35                          1
    rhs       C22,36                          1
    rhs       C22,40                          1
    rhs       C22,43                          1
    rhs       C22,52                          1
    rhs       C22,54                          1
    rhs       C22,55                          1
    rhs       C22,57                          1
    rhs       C23,27                          1
    rhs       C23,35                          1
    rhs       C23,44                          1
    rhs       C23,45                          1
    rhs       C23,46                          1
    rhs       C23,48                          1
    rhs       C23,53                          1
    rhs       C24,26                          1
    rhs       C24,31                          1
    rhs       C24,38                          1
    rhs       C24,40                          1
    rhs       C24,54                          1
    rhs       C24,55                          1
    rhs       C24,58                          1
    rhs       C25,27                          1
    rhs       C25,29                          1
    rhs       C25,30                          1
    rhs       C25,36                          1
    rhs       C25,41                          1
    rhs       C25,43                          1
    rhs       C25,46                          1
    rhs       C25,58                          1
    rhs       C26,27                          1
    rhs       C26,28                          1
    rhs       C26,33                          1
    rhs       C26,44                          1
    rhs       C26,47                          1
    rhs       C26,52                          1
    rhs       C26,53                          1
    rhs       C26,54                          1
    rhs       C27,29                          1
    rhs       C27,30                          1
    rhs       C27,37                          1
    rhs       C27,38                          1
    rhs       C27,45                          1
    rhs       C27,48                          1
    rhs       C27,54                          1
    rhs       C27,58                          1
    rhs       C28,31                          1
    rhs       C28,37                          1
    rhs       C28,39                          1
    rhs       C28,40                          1
    rhs       C28,41                          1
    rhs       C28,42                          1
    rhs       C28,43                          1
    rhs       C28,45                          1
    rhs       C28,46                          1
    rhs       C28,52                          1
    rhs       C28,55                          1
    rhs       C28,56                          1
    rhs       C28,59                          1
    rhs       C29,31                          1
    rhs       C29,32                          1
    rhs       C29,35                          1
    rhs       C29,36                          1
    rhs       C29,37                          1
    rhs       C29,39                          1
    rhs       C29,40                          1
    rhs       C29,41                          1
    rhs       C29,43                          1
    rhs       C29,45                          1
    rhs       C29,47                          1
    rhs       C29,48                          1
    rhs       C29,52                          1
    rhs       C30,32                          1
    rhs       C30,33                          1
    rhs       C30,34                          1
    rhs       C30,36                          1
    rhs       C30,37                          1
    rhs       C30,54                          1
    rhs       C30,55                          1
    rhs       C31,34                          1
    rhs       C31,41                          1
    rhs       C31,45                          1
    rhs       C31,50                          1
    rhs       C31,51                          1
    rhs       C31,55                          1
    rhs       C31,57                          1
    rhs       C31,59                          1
    rhs       C32,33                          1
    rhs       C32,35                          1
    rhs       C32,36                          1
    rhs       C32,42                          1
    rhs       C32,43                          1
    rhs       C32,44                          1
    rhs       C32,45                          1
    rhs       C32,49                          1
    rhs       C32,52                          1
    rhs       C32,56                          1
    rhs       C32,59                          1
    rhs       C33,35                          1
    rhs       C33,37                          1
    rhs       C33,39                          1
    rhs       C33,43                          1
    rhs       C33,45                          1
    rhs       C33,47                          1
    rhs       C33,51                          1
    rhs       C33,57                          1
    rhs       C34,37                          1
    rhs       C34,39                          1
    rhs       C34,42                          1
    rhs       C34,51                          1
    rhs       C34,53                          1
    rhs       C34,56                          1
    rhs       C35,37                          1
    rhs       C35,38                          1
    rhs       C35,42                          1
    rhs       C35,50                          1
    rhs       C35,56                          1
    rhs       C36,39                          1
    rhs       C36,43                          1
    rhs       C36,46                          1
    rhs       C36,56                          1
    rhs       C37,47                          1
    rhs       C37,54                          1
    rhs       C37,55                          1
    rhs       C37,59                          1
    rhs       C38,43                          1
    rhs       C38,46                          1
    rhs       C38,49                          1
    rhs       C38,53                          1
    rhs       C38,54                          1
    rhs       C38,57                          1
    rhs       C38,58                          1
    rhs       C39,43                          1
    rhs       C39,44                          1
    rhs       C39,48                          1
    rhs       C39,49                          1
    rhs       C39,55                          1
    rhs       C39,56                          1
    rhs       C39,57                          1
    rhs       C40,41                          1
    rhs       C40,44                          1
    rhs       C40,48                          1
    rhs       C40,51                          1
    rhs       C40,52                          1
    rhs       C40,57                          1
    rhs       C40,58                          1
    rhs       C41,44                          1
    rhs       C41,48                          1
    rhs       C41,49                          1
    rhs       C41,53                          1
    rhs       C41,57                          1
    rhs       C41,58                          1
    rhs       C41,59                          1
    rhs       C42,45                          1
    rhs       C42,51                          1
    rhs       C42,55                          1
    rhs       C42,57                          1
    rhs       C43,47                          1
    rhs       C43,49                          1
    rhs       C43,51                          1
    rhs       C43,53                          1
    rhs       C43,55                          1
    rhs       C43,57                          1
    rhs       C43,58                          1
    rhs       C44,45                          1
    rhs       C44,46                          1
    rhs       C44,49                          1
    rhs       C44,55                          1
    rhs       C44,58                          1
    rhs       C45,46                          1
    rhs       C45,48                          1
    rhs       C45,49                          1
    rhs       C45,51                          1
    rhs       C45,52                          1
    rhs       C45,53                          1
    rhs       C45,55                          1
    rhs       C45,57                          1
    rhs       C46,48                          1
    rhs       C46,52                          1
    rhs       C46,57                          1
    rhs       C47,54                          1
    rhs       C48,52                          1
    rhs       C49,51                          1
    rhs       C49,52                          1
    rhs       C49,54                          1
    rhs       C50,51                          1
    rhs       C50,53                          1
    rhs       C50,58                          1
    rhs       C51,54                          1
    rhs       C51,56                          1
    rhs       C51,57                          1
    rhs       C51,58                          1
    rhs       C52,55                          1
    rhs       C52,56                          1
    rhs       C52,57                          1
    rhs       C52,59                          1
    rhs       C53,54                          1
    rhs       C56,57                          1
    rhs       C56,59                          1
    rhs       C57,58                          1
    rhs       E0,1                            1
    rhs       E0,2                            1
    rhs       E0,4                            1
    rhs       E0,7                            1
    rhs       E0,8                            1
    rhs       E0,9                            1
    rhs       E0,10                           1
    rhs       E0,11                           1
    rhs       E0,12                           1
    rhs       E0,13                           1
    rhs       E0,14                           1
    rhs       E0,15                           1
    rhs       E0,16                           1
    rhs       E0,17                           1
    rhs       E0,18                           1
    rhs       E0,20                           1
    rhs       E0,21                           1
    rhs       E0,23                           1
    rhs       E0,25                           1
    rhs       E0,27                           1
    rhs       E0,28                           1
    rhs       E0,29                           1
    rhs       E0,30                           1
    rhs       E0,31                           1
    rhs       E0,32                           1
    rhs       E0,33                           1
    rhs       E0,34                           1
    rhs       E0,35                           1
    rhs       E0,39                           1
    rhs       E0,41                           1
    rhs       E0,42                           1
    rhs       E0,45                           1
    rhs       E0,46                           1
    rhs       E0,48                           1
    rhs       E0,49                           1
    rhs       E0,52                           1
    rhs       E0,53                           1
    rhs       E0,54                           1
    rhs       E0,55                           1
    rhs       E0,57                           1
    rhs       E0,59                           1
    rhs       E1,2                            1
    rhs       E1,3                            1
    rhs       E1,4                            1
    rhs       E1,5                            1
    rhs       E1,6                            1
    rhs       E1,7                            1
    rhs       E1,8                            1
    rhs       E1,10                           1
    rhs       E1,12                           1
    rhs       E1,13                           1
    rhs       E1,14                           1
    rhs       E1,15                           1
    rhs       E1,16                           1
    rhs       E1,17                           1
    rhs       E1,18                           1
    rhs       E1,19                           1
    rhs       E1,22                           1
    rhs       E1,23                           1
    rhs       E1,25                           1
    rhs       E1,26                           1
    rhs       E1,28                           1
    rhs       E1,29                           1
    rhs       E1,31                           1
    rhs       E1,32                           1
    rhs       E1,34                           1
    rhs       E1,36                           1
    rhs       E1,37                           1
    rhs       E1,39                           1
    rhs       E1,40                           1
    rhs       E1,42                           1
    rhs       E1,44                           1
    rhs       E1,48                           1
    rhs       E1,49                           1
    rhs       E1,51                           1
    rhs       E1,52                           1
    rhs       E1,53                           1
    rhs       E1,54                           1
    rhs       E1,55                           1
    rhs       E1,56                           1
    rhs       E1,58                           1
    rhs       E1,59                           1
    rhs       E2,3                            1
    rhs       E2,4                            1
    rhs       E2,6                            1
    rhs       E2,9                            1
    rhs       E2,11                           1
    rhs       E2,12                           1
    rhs       E2,14                           1
    rhs       E2,15                           1
    rhs       E2,16                           1
    rhs       E2,17                           1
    rhs       E2,18                           1
    rhs       E2,19                           1
    rhs       E2,21                           1
    rhs       E2,22                           1
    rhs       E2,23                           1
    rhs       E2,24                           1
    rhs       E2,25                           1
    rhs       E2,27                           1
    rhs       E2,28                           1
    rhs       E2,29                           1
    rhs       E2,30                           1
    rhs       E2,31                           1
    rhs       E2,33                           1
    rhs       E2,34                           1
    rhs       E2,35                           1
    rhs       E2,38                           1
    rhs       E2,39                           1
    rhs       E2,40                           1
    rhs       E2,41                           1
    rhs       E2,42                           1
    rhs       E2,48                           1
    rhs       E2,50                           1
    rhs       E2,51                           1
    rhs       E2,52                           1
    rhs       E2,53                           1
    rhs       E2,55                           1
    rhs       E2,56                           1
    rhs       E2,57                           1
    rhs       E2,58                           1
    rhs       E2,59                           1
    rhs       E3,5                            1
    rhs       E3,6                            1
    rhs       E3,8                            1
    rhs       E3,9                            1
    rhs       E3,10                           1
    rhs       E3,11                           1
    rhs       E3,12                           1
    rhs       E3,13                           1
    rhs       E3,15                           1
    rhs       E3,17                           1
    rhs       E3,18                           1
    rhs       E3,19                           1
    rhs       E3,20                           1
    rhs       E3,22                           1
    rhs       E3,25                           1
    rhs       E3,26                           1
    rhs       E3,27                           1
    rhs       E3,28                           1
    rhs       E3,29                           1
    rhs       E3,31                           1
    rhs       E3,32                           1
    rhs       E3,34                           1
    rhs       E3,35                           1
    rhs       E3,37                           1
    rhs       E3,39                           1
    rhs       E3,42                           1
    rhs       E3,43                           1
    rhs       E3,45                           1
    rhs       E3,47                           1
    rhs       E3,48                           1
    rhs       E3,49                           1
    rhs       E3,50                           1
    rhs       E3,51                           1
    rhs       E3,52                           1
    rhs       E3,53                           1
    rhs       E3,54                           1
    rhs       E3,55                           1
    rhs       E3,56                           1
    rhs       E3,57                           1
    rhs       E3,59                           1
    rhs       E4,5                            1
    rhs       E4,7                            1
    rhs       E4,8                            1
    rhs       E4,10                           1
    rhs       E4,13                           1
    rhs       E4,14                           1
    rhs       E4,15                           1
    rhs       E4,16                           1
    rhs       E4,19                           1
    rhs       E4,20                           1
    rhs       E4,22                           1
    rhs       E4,24                           1
    rhs       E4,25                           1
    rhs       E4,26                           1
    rhs       E4,27                           1
    rhs       E4,30                           1
    rhs       E4,33                           1
    rhs       E4,36                           1
    rhs       E4,37                           1
    rhs       E4,38                           1
    rhs       E4,40                           1
    rhs       E4,41                           1
    rhs       E4,43                           1
    rhs       E4,46                           1
    rhs       E4,47                           1
    rhs       E4,48                           1
    rhs       E4,49                           1
    rhs       E4,51                           1
    rhs       E4,53                           1
    rhs       E4,55                           1
    rhs       E4,56                           1
    rhs       E4,57                           1
    rhs       E4,58                           1
    rhs       E5,7                            1
    rhs       E5,8                            1
    rhs       E5,9                            1
    rhs       E5,10                           1
    rhs       E5,13                           1
    rhs       E5,14                           1
    rhs       E5,15                           1
    rhs       E5,18                           1
    rhs       E5,20                           1
    rhs       E5,22                           1
    rhs       E5,23                           1
    rhs       E5,24                           1
    rhs       E5,25                           1
    rhs       E5,26                           1
    rhs       E5,27                           1
    rhs       E5,28                           1
    rhs       E5,29                           1
    rhs       E5,30                           1
    rhs       E5,31                           1
    rhs       E5,32                           1
    rhs       E5,36                           1
    rhs       E5,37                           1
    rhs       E5,38                           1
    rhs       E5,40                           1
    rhs       E5,43                           1
    rhs       E5,46                           1
    rhs       E5,47                           1
    rhs       E5,48                           1
    rhs       E5,49                           1
    rhs       E5,50                           1
    rhs       E5,51                           1
    rhs       E5,52                           1
    rhs       E5,53                           1
    rhs       E5,54                           1
    rhs       E6,7                            1
    rhs       E6,8                            1
    rhs       E6,10                           1
    rhs       E6,15                           1
    rhs       E6,17                           1
    rhs       E6,19                           1
    rhs       E6,22                           1
    rhs       E6,23                           1
    rhs       E6,24                           1
    rhs       E6,27                           1
    rhs       E6,30                           1
    rhs       E6,34                           1
    rhs       E6,35                           1
    rhs       E6,36                           1
    rhs       E6,37                           1
    rhs       E6,38                           1
    rhs       E6,39                           1
    rhs       E6,41                           1
    rhs       E6,43                           1
    rhs       E6,44                           1
    rhs       E6,46                           1
    rhs       E6,48                           1
    rhs       E6,49                           1
    rhs       E6,50                           1
    rhs       E6,51                           1
    rhs       E6,53                           1
    rhs       E6,54                           1
    rhs       E6,56                           1
    rhs       E6,57                           1
    rhs       E6,58                           1
    rhs       E6,59                           1
    rhs       E7,8                            1
    rhs       E7,9                            1
    rhs       E7,12                           1
    rhs       E7,15                           1
    rhs       E7,16                           1
    rhs       E7,17                           1
    rhs       E7,18                           1
    rhs       E7,19                           1
    rhs       E7,20                           1
    rhs       E7,23                           1
    rhs       E7,24                           1
    rhs       E7,26                           1
    rhs       E7,27                           1
    rhs       E7,28                           1
    rhs       E7,30                           1
    rhs       E7,32                           1
    rhs       E7,33                           1
    rhs       E7,34                           1
    rhs       E7,35                           1
    rhs       E7,36                           1
    rhs       E7,38                           1
    rhs       E7,40                           1
    rhs       E7,41                           1
    rhs       E7,42                           1
    rhs       E7,43                           1
    rhs       E7,44                           1
    rhs       E7,45                           1
    rhs       E7,46                           1
    rhs       E7,47                           1
    rhs       E7,50                           1
    rhs       E7,51                           1
    rhs       E7,52                           1
    rhs       E7,53                           1
    rhs       E7,54                           1
    rhs       E7,56                           1
    rhs       E7,57                           1
    rhs       E7,58                           1
    rhs       E8,10                           1
    rhs       E8,12                           1
    rhs       E8,13                           1
    rhs       E8,14                           1
    rhs       E8,15                           1
    rhs       E8,16                           1
    rhs       E8,18                           1
    rhs       E8,19                           1
    rhs       E8,20                           1
    rhs       E8,21                           1
    rhs       E8,22                           1
    rhs       E8,23                           1
    rhs       E8,24                           1
    rhs       E8,25                           1
    rhs       E8,26                           1
    rhs       E8,27                           1
    rhs       E8,28                           1
    rhs       E8,30                           1
    rhs       E8,31                           1
    rhs       E8,32                           1
    rhs       E8,33                           1
    rhs       E8,34                           1
    rhs       E8,37                           1
    rhs       E8,39                           1
    rhs       E8,40                           1
    rhs       E8,41                           1
    rhs       E8,42                           1
    rhs       E8,43                           1
    rhs       E8,44                           1
    rhs       E8,45                           1
    rhs       E8,46                           1
    rhs       E8,49                           1
    rhs       E8,50                           1
    rhs       E8,51                           1
    rhs       E8,53                           1
    rhs       E8,54                           1
    rhs       E8,55                           1
    rhs       E8,56                           1
    rhs       E8,57                           1
    rhs       E8,58                           1
    rhs       E9,12                           1
    rhs       E9,15                           1
    rhs       E9,16                           1
    rhs       E9,19                           1
    rhs       E9,21                           1
    rhs       E9,22                           1
    rhs       E9,23                           1
    rhs       E9,25                           1
    rhs       E9,26                           1
    rhs       E9,28                           1
    rhs       E9,29                           1
    rhs       E9,30                           1
    rhs       E9,31                           1
    rhs       E9,32                           1
    rhs       E9,33                           1
    rhs       E9,34                           1
    rhs       E9,35                           1
    rhs       E9,36                           1
    rhs       E9,37                           1
    rhs       E9,38                           1
    rhs       E9,39                           1
    rhs       E9,40                           1
    rhs       E9,41                           1
    rhs       E9,42                           1
    rhs       E9,43                           1
    rhs       E9,44                           1
    rhs       E9,45                           1
    rhs       E9,46                           1
    rhs       E9,49                           1
    rhs       E9,50                           1
    rhs       E9,52                           1
    rhs       E9,54                           1
    rhs       E9,55                           1
    rhs       E9,58                           1
    rhs       E9,59                           1
    rhs       E10,11                          1
    rhs       E10,13                          1
    rhs       E10,15                          1
    rhs       E10,16                          1
    rhs       E10,18                          1
    rhs       E10,19                          1
    rhs       E10,21                          1
    rhs       E10,23                          1
    rhs       E10,25                          1
    rhs       E10,26                          1
    rhs       E10,27                          1
    rhs       E10,28                          1
    rhs       E10,29                          1
    rhs       E10,30                          1
    rhs       E10,31                          1
    rhs       E10,32                          1
    rhs       E10,34                          1
    rhs       E10,35                          1
    rhs       E10,36                          1
    rhs       E10,38                          1
    rhs       E10,39                          1
    rhs       E10,40                          1
    rhs       E10,41                          1
    rhs       E10,42                          1
    rhs       E10,44                          1
    rhs       E10,45                          1
    rhs       E10,46                          1
    rhs       E10,47                          1
    rhs       E10,48                          1
    rhs       E10,50                          1
    rhs       E10,51                          1
    rhs       E10,52                          1
    rhs       E10,53                          1
    rhs       E10,54                          1
    rhs       E10,56                          1
    rhs       E10,57                          1
    rhs       E10,59                          1
    rhs       E11,12                          1
    rhs       E11,14                          1
    rhs       E11,15                          1
    rhs       E11,17                          1
    rhs       E11,21                          1
    rhs       E11,23                          1
    rhs       E11,25                          1
    rhs       E11,26                          1
    rhs       E11,29                          1
    rhs       E11,30                          1
    rhs       E11,31                          1
    rhs       E11,32                          1
    rhs       E11,33                          1
    rhs       E11,34                          1
    rhs       E11,35                          1
    rhs       E11,36                          1
    rhs       E11,37                          1
    rhs       E11,38                          1
    rhs       E11,39                          1
    rhs       E11,40                          1
    rhs       E11,42                          1
    rhs       E11,45                          1
    rhs       E11,46                          1
    rhs       E11,47                          1
    rhs       E11,48                          1
    rhs       E11,49                          1
    rhs       E11,52                          1
    rhs       E11,53                          1
    rhs       E11,54                          1
    rhs       E11,56                          1
    rhs       E11,57                          1
    rhs       E11,58                          1
    rhs       E11,59                          1
    rhs       E12,14                          1
    rhs       E12,15                          1
    rhs       E12,16                          1
    rhs       E12,17                          1
    rhs       E12,19                          1
    rhs       E12,20                          1
    rhs       E12,22                          1
    rhs       E12,23                          1
    rhs       E12,25                          1
    rhs       E12,26                          1
    rhs       E12,27                          1
    rhs       E12,29                          1
    rhs       E12,30                          1
    rhs       E12,31                          1
    rhs       E12,32                          1
    rhs       E12,33                          1
    rhs       E12,34                          1
    rhs       E12,35                          1
    rhs       E12,36                          1
    rhs       E12,37                          1
    rhs       E12,38                          1
    rhs       E12,39                          1
    rhs       E12,40                          1
    rhs       E12,42                          1
    rhs       E12,43                          1
    rhs       E12,44                          1
    rhs       E12,45                          1
    rhs       E12,46                          1
    rhs       E12,47                          1
    rhs       E12,48                          1
    rhs       E12,49                          1
    rhs       E12,50                          1
    rhs       E12,52                          1
    rhs       E12,53                          1
    rhs       E12,54                          1
    rhs       E12,55                          1
    rhs       E12,56                          1
    rhs       E12,58                          1
    rhs       E12,59                          1
    rhs       E13,14                          1
    rhs       E13,16                          1
    rhs       E13,17                          1
    rhs       E13,19                          1
    rhs       E13,20                          1
    rhs       E13,21                          1
    rhs       E13,22                          1
    rhs       E13,23                          1
    rhs       E13,24                          1
    rhs       E13,27                          1
    rhs       E13,28                          1
    rhs       E13,32                          1
    rhs       E13,33                          1
    rhs       E13,34                          1
    rhs       E13,36                          1
    rhs       E13,38                          1
    rhs       E13,39                          1
    rhs       E13,40                          1
    rhs       E13,41                          1
    rhs       E13,42                          1
    rhs       E13,43                          1
    rhs       E13,46                          1
    rhs       E13,50                          1
    rhs       E13,51                          1
    rhs       E13,53                          1
    rhs       E13,55                          1
    rhs       E13,56                          1
    rhs       E13,57                          1
    rhs       E13,58                          1
    rhs       E13,59                          1
    rhs       E14,18                          1
    rhs       E14,19                          1
    rhs       E14,20                          1
    rhs       E14,21                          1
    rhs       E14,25                          1
    rhs       E14,27                          1
    rhs       E14,28                          1
    rhs       E14,29                          1
    rhs       E14,31                          1
    rhs       E14,33                          1
    rhs       E14,35                          1
    rhs       E14,36                          1
    rhs       E14,37                          1
    rhs       E14,38                          1
    rhs       E14,40                          1
    rhs       E14,43                          1
    rhs       E14,44                          1
    rhs       E14,45                          1
    rhs       E14,46                          1
    rhs       E14,47                          1
    rhs       E14,48                          1
    rhs       E14,49                          1
    rhs       E14,50                          1
    rhs       E14,51                          1
    rhs       E14,52                          1
    rhs       E14,53                          1
    rhs       E14,54                          1
    rhs       E14,56                          1
    rhs       E14,57                          1
    rhs       E14,58                          1
    rhs       E15,16                          1
    rhs       E15,17                          1
    rhs       E15,18                          1
    rhs       E15,20                          1
    rhs       E15,23                          1
    rhs       E15,25                          1
    rhs       E15,26                          1
    rhs       E15,28                          1
    rhs       E15,32                          1
    rhs       E15,33                          1
    rhs       E15,35                          1
    rhs       E15,36                          1
    rhs       E15,37                          1
    rhs       E15,39                          1
    rhs       E15,41                          1
    rhs       E15,45                          1
    rhs       E15,46                          1
    rhs       E15,47                          1
    rhs       E15,49                          1
    rhs       E15,50                          1
    rhs       E15,51                          1
    rhs       E15,54                          1
    rhs       E15,55                          1
    rhs       E15,57                          1
    rhs       E15,58                          1
    rhs       E15,59                          1
    rhs       E16,17                          1
    rhs       E16,18                          1
    rhs       E16,19                          1
    rhs       E16,20                          1
    rhs       E16,21                          1
    rhs       E16,25                          1
    rhs       E16,28                          1
    rhs       E16,29                          1
    rhs       E16,30                          1
    rhs       E16,31                          1
    rhs       E16,32                          1
    rhs       E16,33                          1
    rhs       E16,35                          1
    rhs       E16,36                          1
    rhs       E16,37                          1
    rhs       E16,38                          1
    rhs       E16,40                          1
    rhs       E16,41                          1
    rhs       E16,42                          1
    rhs       E16,43                          1
    rhs       E16,46                          1
    rhs       E16,47                          1
    rhs       E16,49                          1
    rhs       E16,51                          1
    rhs       E16,52                          1
    rhs       E16,53                          1
    rhs       E16,54                          1
    rhs       E16,57                          1
    rhs       E16,59                          1
    rhs       E17,18                          1
    rhs       E17,20                          1
    rhs       E17,21                          1
    rhs       E17,22                          1
    rhs       E17,23                          1
    rhs       E17,25                          1
    rhs       E17,26                          1
    rhs       E17,28                          1
    rhs       E17,29                          1
    rhs       E17,30                          1
    rhs       E17,32                          1
    rhs       E17,33                          1
    rhs       E17,35                          1
    rhs       E17,36                          1
    rhs       E17,37                          1
    rhs       E17,38                          1
    rhs       E17,41                          1
    rhs       E17,42                          1
    rhs       E17,44                          1
    rhs       E17,45                          1
    rhs       E17,46                          1
    rhs       E17,47                          1
    rhs       E17,48                          1
    rhs       E17,49                          1
    rhs       E17,51                          1
    rhs       E17,53                          1
    rhs       E17,54                          1
    rhs       E17,55                          1
    rhs       E17,58                          1
    rhs       E17,59                          1
    rhs       E18,19                          1
    rhs       E18,22                          1
    rhs       E18,23                          1
    rhs       E18,25                          1
    rhs       E18,26                          1
    rhs       E18,28                          1
    rhs       E18,29                          1
    rhs       E18,30                          1
    rhs       E18,31                          1
    rhs       E18,32                          1
    rhs       E18,33                          1
    rhs       E18,34                          1
    rhs       E18,35                          1
    rhs       E18,36                          1
    rhs       E18,37                          1
    rhs       E18,38                          1
    rhs       E18,39                          1
    rhs       E18,40                          1
    rhs       E18,41                          1
    rhs       E18,42                          1
    rhs       E18,43                          1
    rhs       E18,44                          1
    rhs       E18,45                          1
    rhs       E18,47                          1
    rhs       E18,48                          1
    rhs       E18,50                          1
    rhs       E18,51                          1
    rhs       E18,52                          1
    rhs       E18,53                          1
    rhs       E18,54                          1
    rhs       E18,55                          1
    rhs       E18,56                          1
    rhs       E18,57                          1
    rhs       E18,59                          1
    rhs       E19,20                          1
    rhs       E19,21                          1
    rhs       E19,22                          1
    rhs       E19,24                          1
    rhs       E19,28                          1
    rhs       E19,29                          1
    rhs       E19,30                          1
    rhs       E19,31                          1
    rhs       E19,32                          1
    rhs       E19,36                          1
    rhs       E19,37                          1
    rhs       E19,39                          1
    rhs       E19,40                          1
    rhs       E19,42                          1
    rhs       E19,43                          1
    rhs       E19,44                          1
    rhs       E19,45                          1
    rhs       E19,49                          1
    rhs       E19,50                          1
    rhs       E19,51                          1
    rhs       E19,52                          1
    rhs       E19,53                          1
    rhs       E19,54                          1
    rhs       E19,55                          1
    rhs       E19,58                          1
    rhs       E19,59                          1
    rhs       E20,21                          1
    rhs       E20,22                          1
    rhs       E20,23                          1
    rhs       E20,24                          1
    rhs       E20,26                          1
    rhs       E20,27                          1
    rhs       E20,28                          1
    rhs       E20,29                          1
    rhs       E20,30                          1
    rhs       E20,32                          1
    rhs       E20,34                          1
    rhs       E20,35                          1
    rhs       E20,36                          1
    rhs       E20,39                          1
    rhs       E20,41                          1
    rhs       E20,42                          1
    rhs       E20,43                          1
    rhs       E20,44                          1
    rhs       E20,45                          1
    rhs       E20,47                          1
    rhs       E20,48                          1
    rhs       E20,49                          1
    rhs       E20,50                          1
    rhs       E20,52                          1
    rhs       E20,53                          1
    rhs       E20,55                          1
    rhs       E20,56                          1
    rhs       E20,57                          1
    rhs       E21,24                          1
    rhs       E21,25                          1
    rhs       E21,26                          1
    rhs       E21,27                          1
    rhs       E21,30                          1
    rhs       E21,32                          1
    rhs       E21,34                          1
    rhs       E21,35                          1
    rhs       E21,36                          1
    rhs       E21,37                          1
    rhs       E21,38                          1
    rhs       E21,39                          1
    rhs       E21,41                          1
    rhs       E21,42                          1
    rhs       E21,44                          1
    rhs       E21,45                          1
    rhs       E21,47                          1
    rhs       E21,49                          1
    rhs       E21,50                          1
    rhs       E21,52                          1
    rhs       E21,53                          1
    rhs       E21,54                          1
    rhs       E21,55                          1
    rhs       E21,56                          1
    rhs       E21,57                          1
    rhs       E22,25                          1
    rhs       E22,26                          1
    rhs       E22,27                          1
    rhs       E22,28                          1
    rhs       E22,29                          1
    rhs       E22,30                          1
    rhs       E22,31                          1
    rhs       E22,32                          1
    rhs       E22,33                          1
    rhs       E22,37                          1
    rhs       E22,38                          1
    rhs       E22,39                          1
    rhs       E22,41                          1
    rhs       E22,42                          1
    rhs       E22,44                          1
    rhs       E22,45                          1
    rhs       E22,46                          1
    rhs       E22,47                          1
    rhs       E22,48                          1
    rhs       E22,49                          1
    rhs       E22,50                          1
    rhs       E22,51                          1
    rhs       E22,53                          1
    rhs       E22,56                          1
    rhs       E22,58                          1
    rhs       E22,59                          1
    rhs       E23,24                          1
    rhs       E23,25                          1
    rhs       E23,26                          1
    rhs       E23,28                          1
    rhs       E23,29                          1
    rhs       E23,30                          1
    rhs       E23,31                          1
    rhs       E23,32                          1
    rhs       E23,33                          1
    rhs       E23,34                          1
    rhs       E23,36                          1
    rhs       E23,37                          1
    rhs       E23,38                          1
    rhs       E23,39                          1
    rhs       E23,40                          1
    rhs       E23,41                          1
    rhs       E23,42                          1
    rhs       E23,43                          1
    rhs       E23,47                          1
    rhs       E23,49                          1
    rhs       E23,50                          1
    rhs       E23,51                          1
    rhs       E23,52                          1
    rhs       E23,54                          1
    rhs       E23,55                          1
    rhs       E23,56                          1
    rhs       E23,57                          1
    rhs       E23,58                          1
    rhs       E23,59                          1
    rhs       E24,25                          1
    rhs       E24,27                          1
    rhs       E24,28                          1
    rhs       E24,29                          1
    rhs       E24,30                          1
    rhs       E24,32                          1
    rhs       E24,33                          1
    rhs       E24,34                          1
    rhs       E24,35                          1
    rhs       E24,36                          1
    rhs       E24,37                          1
    rhs       E24,39                          1
    rhs       E24,41                          1
    rhs       E24,42                          1
    rhs       E24,43                          1
    rhs       E24,44                          1
    rhs       E24,45                          1
    rhs       E24,46                          1
    rhs       E24,47                          1
    rhs       E24,48                          1
    rhs       E24,49                          1
    rhs       E24,50                          1
    rhs       E24,51                          1
    rhs       E24,52                          1
    rhs       E24,53                          1
    rhs       E24,56                          1
    rhs       E24,57                          1
    rhs       E24,59                          1
    rhs       E25,26                          1
    rhs       E25,28                          1
    rhs       E25,31                          1
    rhs       E25,32                          1
    rhs       E25,33                          1
    rhs       E25,34                          1
    rhs       E25,35                          1
    rhs       E25,37                          1
    rhs       E25,38                          1
    rhs       E25,39                          1
    rhs       E25,40                          1
    rhs       E25,42                          1
    rhs       E25,44                          1
    rhs       E25,45                          1
    rhs       E25,47                          1
    rhs       E25,48                          1
    rhs       E25,49                          1
    rhs       E25,50                          1
    rhs       E25,51                          1
    rhs       E25,52                          1
    rhs       E25,53                          1
    rhs       E25,54                          1
    rhs       E25,55                          1
    rhs       E25,56                          1
    rhs       E25,57                          1
    rhs       E25,59                          1
    rhs       E26,29                          1
    rhs       E26,30                          1
    rhs       E26,31                          1
    rhs       E26,32                          1
    rhs       E26,34                          1
    rhs       E26,35                          1
    rhs       E26,36                          1
    rhs       E26,37                          1
    rhs       E26,38                          1
    rhs       E26,39                          1
    rhs       E26,40                          1
    rhs       E26,41                          1
    rhs       E26,42                          1
    rhs       E26,43                          1
    rhs       E26,45                          1
    rhs       E26,46                          1
    rhs       E26,48                          1
    rhs       E26,49                          1
    rhs       E26,50                          1
    rhs       E26,51                          1
    rhs       E26,55                          1
    rhs       E26,56                          1
    rhs       E26,57                          1
    rhs       E26,58                          1
    rhs       E26,59                          1
    rhs       E27,28                          1
    rhs       E27,31                          1
    rhs       E27,32                          1
    rhs       E27,33                          1
    rhs       E27,34                          1
    rhs       E27,35                          1
    rhs       E27,36                          1
    rhs       E27,39                          1
    rhs       E27,40                          1
    rhs       E27,41                          1
    rhs       E27,42                          1
    rhs       E27,43                          1
    rhs       E27,44                          1
    rhs       E27,46                          1
    rhs       E27,47                          1
    rhs       E27,49                          1
    rhs       E27,50                          1
    rhs       E27,51                          1
    rhs       E27,52                          1
    rhs       E27,53                          1
    rhs       E27,55                          1
    rhs       E27,56                          1
    rhs       E27,57                          1
    rhs       E27,59                          1
    rhs       E28,29                          1
    rhs       E28,30                          1
    rhs       E28,32                          1
    rhs       E28,33                          1
    rhs       E28,34                          1
    rhs       E28,35                          1
    rhs       E28,36                          1
    rhs       E28,38                          1
    rhs       E28,44                          1
    rhs       E28,47                          1
    rhs       E28,48                          1
    rhs       E28,49                          1
    rhs       E28,50                          1
    rhs       E28,51                          1
    rhs       E28,53                          1
    rhs       E28,54                          1
    rhs       E28,57                          1
    rhs       E28,58                          1
    rhs       E29,30                          1
    rhs       E29,33                          1
    rhs       E29,34                          1
    rhs       E29,38                          1
    rhs       E29,42                          1
    rhs       E29,44                          1
    rhs       E29,46                          1
    rhs       E29,49                          1
    rhs       E29,50                          1
    rhs       E29,51                          1
    rhs       E29,53                          1
    rhs       E29,54                          1
    rhs       E29,55                          1
    rhs       E29,56                          1
    rhs       E29,57                          1
    rhs       E29,58                          1
    rhs       E29,59                          1
    rhs       E30,31                          1
    rhs       E30,35                          1
    rhs       E30,38                          1
    rhs       E30,39                          1
    rhs       E30,40                          1
    rhs       E30,41                          1
    rhs       E30,42                          1
    rhs       E30,43                          1
    rhs       E30,44                          1
    rhs       E30,45                          1
    rhs       E30,46                          1
    rhs       E30,47                          1
    rhs       E30,48                          1
    rhs       E30,49                          1
    rhs       E30,50                          1
    rhs       E30,51                          1
    rhs       E30,52                          1
    rhs       E30,53                          1
    rhs       E30,56                          1
    rhs       E30,57                          1
    rhs       E30,58                          1
    rhs       E30,59                          1
    rhs       E31,32                          1
    rhs       E31,33                          1
    rhs       E31,35                          1
    rhs       E31,36                          1
    rhs       E31,37                          1
    rhs       E31,38                          1
    rhs       E31,39                          1
    rhs       E31,40                          1
    rhs       E31,42                          1
    rhs       E31,43                          1
    rhs       E31,44                          1
    rhs       E31,46                          1
    rhs       E31,47                          1
    rhs       E31,48                          1
    rhs       E31,49                          1
    rhs       E31,52                          1
    rhs       E31,53                          1
    rhs       E31,54                          1
    rhs       E31,56                          1
    rhs       E31,58                          1
    rhs       E32,34                          1
    rhs       E32,37                          1
    rhs       E32,38                          1
    rhs       E32,39                          1
    rhs       E32,40                          1
    rhs       E32,41                          1
    rhs       E32,46                          1
    rhs       E32,47                          1
    rhs       E32,48                          1
    rhs       E32,50                          1
    rhs       E32,51                          1
    rhs       E32,53                          1
    rhs       E32,54                          1
    rhs       E32,55                          1
    rhs       E32,57                          1
    rhs       E32,58                          1
    rhs       E33,34                          1
    rhs       E33,36                          1
    rhs       E33,38                          1
    rhs       E33,40                          1
    rhs       E33,41                          1
    rhs       E33,42                          1
    rhs       E33,44                          1
    rhs       E33,46                          1
    rhs       E33,48                          1
    rhs       E33,49                          1
    rhs       E33,50                          1
    rhs       E33,52                          1
    rhs       E33,53                          1
    rhs       E33,54                          1
    rhs       E33,55                          1
    rhs       E33,56                          1
    rhs       E33,58                          1
    rhs       E33,59                          1
    rhs       E34,35                          1
    rhs       E34,36                          1
    rhs       E34,38                          1
    rhs       E34,40                          1
    rhs       E34,41                          1
    rhs       E34,43                          1
    rhs       E34,44                          1
    rhs       E34,45                          1
    rhs       E34,46                          1
    rhs       E34,47                          1
    rhs       E34,48                          1
    rhs       E34,49                          1
    rhs       E34,50                          1
    rhs       E34,52                          1
    rhs       E34,54                          1
    rhs       E34,55                          1
    rhs       E34,57                          1
    rhs       E34,58                          1
    rhs       E34,59                          1
    rhs       E35,36                          1
    rhs       E35,39                          1
    rhs       E35,40                          1
    rhs       E35,41                          1
    rhs       E35,43                          1
    rhs       E35,44                          1
    rhs       E35,45                          1
    rhs       E35,46                          1
    rhs       E35,47                          1
    rhs       E35,48                          1
    rhs       E35,49                          1
    rhs       E35,51                          1
    rhs       E35,52                          1
    rhs       E35,53                          1
    rhs       E35,54                          1
    rhs       E35,55                          1
    rhs       E35,57                          1
    rhs       E35,58                          1
    rhs       E35,59                          1
    rhs       E36,37                          1
    rhs       E36,38                          1
    rhs       E36,40                          1
    rhs       E36,41                          1
    rhs       E36,42                          1
    rhs       E36,44                          1
    rhs       E36,45                          1
    rhs       E36,47                          1
    rhs       E36,48                          1
    rhs       E36,49                          1
    rhs       E36,50                          1
    rhs       E36,51                          1
    rhs       E36,52                          1
    rhs       E36,53                          1
    rhs       E36,54                          1
    rhs       E36,55                          1
    rhs       E36,57                          1
    rhs       E36,58                          1
    rhs       E36,59                          1
    rhs       E37,38                          1
    rhs       E37,39                          1
    rhs       E37,40                          1
    rhs       E37,41                          1
    rhs       E37,42                          1
    rhs       E37,43                          1
    rhs       E37,44                          1
    rhs       E37,45                          1
    rhs       E37,46                          1
    rhs       E37,48                          1
    rhs       E37,49                          1
    rhs       E37,50                          1
    rhs       E37,51                          1
    rhs       E37,52                          1
    rhs       E37,53                          1
    rhs       E37,56                          1
    rhs       E37,57                          1
    rhs       E37,58                          1
    rhs       E38,39                          1
    rhs       E38,40                          1
    rhs       E38,41                          1
    rhs       E38,42                          1
    rhs       E38,44                          1
    rhs       E38,45                          1
    rhs       E38,47                          1
    rhs       E38,48                          1
    rhs       E38,50                          1
    rhs       E38,51                          1
    rhs       E38,52                          1
    rhs       E38,55                          1
    rhs       E38,56                          1
    rhs       E38,59                          1
    rhs       E39,40                          1
    rhs       E39,41                          1
    rhs       E39,42                          1
    rhs       E39,45                          1
    rhs       E39,46                          1
    rhs       E39,47                          1
    rhs       E39,50                          1
    rhs       E39,51                          1
    rhs       E39,52                          1
    rhs       E39,53                          1
    rhs       E39,54                          1
    rhs       E39,58                          1
    rhs       E39,59                          1
    rhs       E40,42                          1
    rhs       E40,43                          1
    rhs       E40,45                          1
    rhs       E40,46                          1
    rhs       E40,47                          1
    rhs       E40,49                          1
    rhs       E40,50                          1
    rhs       E40,53                          1
    rhs       E40,54                          1
    rhs       E40,55                          1
    rhs       E40,56                          1
    rhs       E40,59                          1
    rhs       E41,42                          1
    rhs       E41,43                          1
    rhs       E41,45                          1
    rhs       E41,46                          1
    rhs       E41,47                          1
    rhs       E41,50                          1
    rhs       E41,51                          1
    rhs       E41,52                          1
    rhs       E41,54                          1
    rhs       E41,55                          1
    rhs       E41,56                          1
    rhs       E42,43                          1
    rhs       E42,44                          1
    rhs       E42,46                          1
    rhs       E42,47                          1
    rhs       E42,48                          1
    rhs       E42,49                          1
    rhs       E42,50                          1
    rhs       E42,52                          1
    rhs       E42,53                          1
    rhs       E42,54                          1
    rhs       E42,56                          1
    rhs       E42,58                          1
    rhs       E42,59                          1
    rhs       E43,44                          1
    rhs       E43,45                          1
    rhs       E43,46                          1
    rhs       E43,48                          1
    rhs       E43,50                          1
    rhs       E43,52                          1
    rhs       E43,54                          1
    rhs       E43,56                          1
    rhs       E43,59                          1
    rhs       E44,47                          1
    rhs       E44,48                          1
    rhs       E44,50                          1
    rhs       E44,51                          1
    rhs       E44,52                          1
    rhs       E44,53                          1
    rhs       E44,54                          1
    rhs       E44,56                          1
    rhs       E44,57                          1
    rhs       E44,59                          1
    rhs       E45,47                          1
    rhs       E45,50                          1
    rhs       E45,54                          1
    rhs       E45,56                          1
    rhs       E45,58                          1
    rhs       E45,59                          1
    rhs       E46,47                          1
    rhs       E46,49                          1
    rhs       E46,50                          1
    rhs       E46,51                          1
    rhs       E46,53                          1
    rhs       E46,54                          1
    rhs       E46,55                          1
    rhs       E46,56                          1
    rhs       E46,58                          1
    rhs       E46,59                          1
    rhs       E47,48                          1
    rhs       E47,49                          1
    rhs       E47,50                          1
    rhs       E47,51                          1
    rhs       E47,52                          1
    rhs       E47,53                          1
    rhs       E47,55                          1
    rhs       E47,56                          1
    rhs       E47,57                          1
    rhs       E47,58                          1
    rhs       E47,59                          1
    rhs       E48,49                          1
    rhs       E48,50                          1
    rhs       E48,51                          1
    rhs       E48,53                          1
    rhs       E48,54                          1
    rhs       E48,55                          1
    rhs       E48,56                          1
    rhs       E48,57                          1
    rhs       E48,58                          1
    rhs       E48,59                          1
    rhs       E49,50                          1
    rhs       E49,53                          1
    rhs       E49,55                          1
    rhs       E49,56                          1
    rhs       E49,57                          1
    rhs       E49,58                          1
    rhs       E49,59                          1
    rhs       E50,52                          1
    rhs       E50,54                          1
    rhs       E50,55                          1
    rhs       E50,56                          1
    rhs       E50,57                          1
    rhs       E50,59                          1
    rhs       E51,52                          1
    rhs       E51,53                          1
    rhs       E51,55                          1
    rhs       E51,59                          1
    rhs       E52,53                          1
    rhs       E52,54                          1
    rhs       E52,58                          1
    rhs       E53,55                          1
    rhs       E53,56                          1
    rhs       E53,57                          1
    rhs       E53,58                          1
    rhs       E53,59                          1
    rhs       E54,55                          1
    rhs       E54,56                          1
    rhs       E54,57                          1
    rhs       E54,58                          1
    rhs       E54,59                          1
    rhs       E55,56                          1
    rhs       E55,57                          1
    rhs       E55,58                          1
    rhs       E55,59                          1
    rhs       E56,58                          1
    rhs       E57,59                          1
    rhs       E58,59                          1
    rhs       I0,1                            1
    rhs       I0,2                            1
    rhs       I0,4                            1
    rhs       I0,7                            1
    rhs       I0,8                            1
    rhs       I0,9                            1
    rhs       I0,10                           1
    rhs       I0,11                           1
    rhs       I0,12                           1
    rhs       I0,13                           1
    rhs       I0,14                           1
    rhs       I0,15                           1
    rhs       I0,16                           1
    rhs       I0,17                           1
    rhs       I0,18                           1
    rhs       I0,20                           1
    rhs       I0,21                           1
    rhs       I0,23                           1
    rhs       I0,25                           1
    rhs       I0,27                           1
    rhs       I0,28                           1
    rhs       I0,29                           1
    rhs       I0,30                           1
    rhs       I0,31                           1
    rhs       I0,32                           1
    rhs       I0,33                           1
    rhs       I0,34                           1
    rhs       I0,35                           1
    rhs       I0,39                           1
    rhs       I0,41                           1
    rhs       I0,42                           1
    rhs       I0,45                           1
    rhs       I0,46                           1
    rhs       I0,48                           1
    rhs       I0,49                           1
    rhs       I0,52                           1
    rhs       I0,53                           1
    rhs       I0,54                           1
    rhs       I0,55                           1
    rhs       I0,57                           1
    rhs       I0,59                           1
    rhs       I1,2                            1
    rhs       I1,3                            1
    rhs       I1,4                            1
    rhs       I1,5                            1
    rhs       I1,6                            1
    rhs       I1,7                            1
    rhs       I1,8                            1
    rhs       I1,10                           1
    rhs       I1,12                           1
    rhs       I1,13                           1
    rhs       I1,14                           1
    rhs       I1,15                           1
    rhs       I1,16                           1
    rhs       I1,17                           1
    rhs       I1,18                           1
    rhs       I1,19                           1
    rhs       I1,22                           1
    rhs       I1,23                           1
    rhs       I1,25                           1
    rhs       I1,26                           1
    rhs       I1,28                           1
    rhs       I1,29                           1
    rhs       I1,31                           1
    rhs       I1,32                           1
    rhs       I1,34                           1
    rhs       I1,36                           1
    rhs       I1,37                           1
    rhs       I1,39                           1
    rhs       I1,40                           1
    rhs       I1,42                           1
    rhs       I1,44                           1
    rhs       I1,48                           1
    rhs       I1,49                           1
    rhs       I1,51                           1
    rhs       I1,52                           1
    rhs       I1,53                           1
    rhs       I1,54                           1
    rhs       I1,55                           1
    rhs       I1,56                           1
    rhs       I1,58                           1
    rhs       I1,59                           1
    rhs       I2,3                            1
    rhs       I2,4                            1
    rhs       I2,6                            1
    rhs       I2,9                            1
    rhs       I2,11                           1
    rhs       I2,12                           1
    rhs       I2,14                           1
    rhs       I2,15                           1
    rhs       I2,16                           1
    rhs       I2,17                           1
    rhs       I2,18                           1
    rhs       I2,19                           1
    rhs       I2,21                           1
    rhs       I2,22                           1
    rhs       I2,23                           1
    rhs       I2,24                           1
    rhs       I2,25                           1
    rhs       I2,27                           1
    rhs       I2,28                           1
    rhs       I2,29                           1
    rhs       I2,30                           1
    rhs       I2,31                           1
    rhs       I2,33                           1
    rhs       I2,34                           1
    rhs       I2,35                           1
    rhs       I2,38                           1
    rhs       I2,39                           1
    rhs       I2,40                           1
    rhs       I2,41                           1
    rhs       I2,42                           1
    rhs       I2,48                           1
    rhs       I2,50                           1
    rhs       I2,51                           1
    rhs       I2,52                           1
    rhs       I2,53                           1
    rhs       I2,55                           1
    rhs       I2,56                           1
    rhs       I2,57                           1
    rhs       I2,58                           1
    rhs       I2,59                           1
    rhs       I3,5                            1
    rhs       I3,6                            1
    rhs       I3,8                            1
    rhs       I3,9                            1
    rhs       I3,10                           1
    rhs       I3,11                           1
    rhs       I3,12                           1
    rhs       I3,13                           1
    rhs       I3,15                           1
    rhs       I3,17                           1
    rhs       I3,18                           1
    rhs       I3,19                           1
    rhs       I3,20                           1
    rhs       I3,22                           1
    rhs       I3,25                           1
    rhs       I3,26                           1
    rhs       I3,27                           1
    rhs       I3,28                           1
    rhs       I3,29                           1
    rhs       I3,31                           1
    rhs       I3,32                           1
    rhs       I3,34                           1
    rhs       I3,35                           1
    rhs       I3,37                           1
    rhs       I3,39                           1
    rhs       I3,42                           1
    rhs       I3,43                           1
    rhs       I3,45                           1
    rhs       I3,47                           1
    rhs       I3,48                           1
    rhs       I3,49                           1
    rhs       I3,50                           1
    rhs       I3,51                           1
    rhs       I3,52                           1
    rhs       I3,53                           1
    rhs       I3,54                           1
    rhs       I3,55                           1
    rhs       I3,56                           1
    rhs       I3,57                           1
    rhs       I3,59                           1
    rhs       I4,5                            1
    rhs       I4,7                            1
    rhs       I4,8                            1
    rhs       I4,10                           1
    rhs       I4,13                           1
    rhs       I4,14                           1
    rhs       I4,15                           1
    rhs       I4,16                           1
    rhs       I4,19                           1
    rhs       I4,20                           1
    rhs       I4,22                           1
    rhs       I4,24                           1
    rhs       I4,25                           1
    rhs       I4,26                           1
    rhs       I4,27                           1
    rhs       I4,30                           1
    rhs       I4,33                           1
    rhs       I4,36                           1
    rhs       I4,37                           1
    rhs       I4,38                           1
    rhs       I4,40                           1
    rhs       I4,41                           1
    rhs       I4,43                           1
    rhs       I4,46                           1
    rhs       I4,47                           1
    rhs       I4,48                           1
    rhs       I4,49                           1
    rhs       I4,51                           1
    rhs       I4,53                           1
    rhs       I4,55                           1
    rhs       I4,56                           1
    rhs       I4,57                           1
    rhs       I4,58                           1
    rhs       I5,7                            1
    rhs       I5,8                            1
    rhs       I5,9                            1
    rhs       I5,10                           1
    rhs       I5,13                           1
    rhs       I5,14                           1
    rhs       I5,15                           1
    rhs       I5,18                           1
    rhs       I5,20                           1
    rhs       I5,22                           1
    rhs       I5,23                           1
    rhs       I5,24                           1
    rhs       I5,25                           1
    rhs       I5,26                           1
    rhs       I5,27                           1
    rhs       I5,28                           1
    rhs       I5,29                           1
    rhs       I5,30                           1
    rhs       I5,31                           1
    rhs       I5,32                           1
    rhs       I5,36                           1
    rhs       I5,37                           1
    rhs       I5,38                           1
    rhs       I5,40                           1
    rhs       I5,43                           1
    rhs       I5,46                           1
    rhs       I5,47                           1
    rhs       I5,48                           1
    rhs       I5,49                           1
    rhs       I5,50                           1
    rhs       I5,51                           1
    rhs       I5,52                           1
    rhs       I5,53                           1
    rhs       I5,54                           1
    rhs       I6,7                            1
    rhs       I6,8                            1
    rhs       I6,10                           1
    rhs       I6,15                           1
    rhs       I6,17                           1
    rhs       I6,19                           1
    rhs       I6,22                           1
    rhs       I6,23                           1
    rhs       I6,24                           1
    rhs       I6,27                           1
    rhs       I6,30                           1
    rhs       I6,34                           1
    rhs       I6,35                           1
    rhs       I6,36                           1
    rhs       I6,37                           1
    rhs       I6,38                           1
    rhs       I6,39                           1
    rhs       I6,41                           1
    rhs       I6,43                           1
    rhs       I6,44                           1
    rhs       I6,46                           1
    rhs       I6,48                           1
    rhs       I6,49                           1
    rhs       I6,50                           1
    rhs       I6,51                           1
    rhs       I6,53                           1
    rhs       I6,54                           1
    rhs       I6,56                           1
    rhs       I6,57                           1
    rhs       I6,58                           1
    rhs       I6,59                           1
    rhs       I7,8                            1
    rhs       I7,9                            1
    rhs       I7,12                           1
    rhs       I7,15                           1
    rhs       I7,16                           1
    rhs       I7,17                           1
    rhs       I7,18                           1
    rhs       I7,19                           1
    rhs       I7,20                           1
    rhs       I7,23                           1
    rhs       I7,24                           1
    rhs       I7,26                           1
    rhs       I7,27                           1
    rhs       I7,28                           1
    rhs       I7,30                           1
    rhs       I7,32                           1
    rhs       I7,33                           1
    rhs       I7,34                           1
    rhs       I7,35                           1
    rhs       I7,36                           1
    rhs       I7,38                           1
    rhs       I7,40                           1
    rhs       I7,41                           1
    rhs       I7,42                           1
    rhs       I7,43                           1
    rhs       I7,44                           1
    rhs       I7,45                           1
    rhs       I7,46                           1
    rhs       I7,47                           1
    rhs       I7,50                           1
    rhs       I7,51                           1
    rhs       I7,52                           1
    rhs       I7,53                           1
    rhs       I7,54                           1
    rhs       I7,56                           1
    rhs       I7,57                           1
    rhs       I7,58                           1
    rhs       I8,10                           1
    rhs       I8,12                           1
    rhs       I8,13                           1
    rhs       I8,14                           1
    rhs       I8,15                           1
    rhs       I8,16                           1
    rhs       I8,18                           1
    rhs       I8,19                           1
    rhs       I8,20                           1
    rhs       I8,21                           1
    rhs       I8,22                           1
    rhs       I8,23                           1
    rhs       I8,24                           1
    rhs       I8,25                           1
    rhs       I8,26                           1
    rhs       I8,27                           1
    rhs       I8,28                           1
    rhs       I8,30                           1
    rhs       I8,31                           1
    rhs       I8,32                           1
    rhs       I8,33                           1
    rhs       I8,34                           1
    rhs       I8,37                           1
    rhs       I8,39                           1
    rhs       I8,40                           1
    rhs       I8,41                           1
    rhs       I8,42                           1
    rhs       I8,43                           1
    rhs       I8,44                           1
    rhs       I8,45                           1
    rhs       I8,46                           1
    rhs       I8,49                           1
    rhs       I8,50                           1
    rhs       I8,51                           1
    rhs       I8,53                           1
    rhs       I8,54                           1
    rhs       I8,55                           1
    rhs       I8,56                           1
    rhs       I8,57                           1
    rhs       I8,58                           1
    rhs       I9,12                           1
    rhs       I9,15                           1
    rhs       I9,16                           1
    rhs       I9,19                           1
    rhs       I9,21                           1
    rhs       I9,22                           1
    rhs       I9,23                           1
    rhs       I9,25                           1
    rhs       I9,26                           1
    rhs       I9,28                           1
    rhs       I9,29                           1
    rhs       I9,30                           1
    rhs       I9,31                           1
    rhs       I9,32                           1
    rhs       I9,33                           1
    rhs       I9,34                           1
    rhs       I9,35                           1
    rhs       I9,36                           1
    rhs       I9,37                           1
    rhs       I9,38                           1
    rhs       I9,39                           1
    rhs       I9,40                           1
    rhs       I9,41                           1
    rhs       I9,42                           1
    rhs       I9,43                           1
    rhs       I9,44                           1
    rhs       I9,45                           1
    rhs       I9,46                           1
    rhs       I9,49                           1
    rhs       I9,50                           1
    rhs       I9,52                           1
    rhs       I9,54                           1
    rhs       I9,55                           1
    rhs       I9,58                           1
    rhs       I9,59                           1
    rhs       I10,11                          1
    rhs       I10,13                          1
    rhs       I10,15                          1
    rhs       I10,16                          1
    rhs       I10,18                          1
    rhs       I10,19                          1
    rhs       I10,21                          1
    rhs       I10,23                          1
    rhs       I10,25                          1
    rhs       I10,26                          1
    rhs       I10,27                          1
    rhs       I10,28                          1
    rhs       I10,29                          1
    rhs       I10,30                          1
    rhs       I10,31                          1
    rhs       I10,32                          1
    rhs       I10,34                          1
    rhs       I10,35                          1
    rhs       I10,36                          1
    rhs       I10,38                          1
    rhs       I10,39                          1
    rhs       I10,40                          1
    rhs       I10,41                          1
    rhs       I10,42                          1
    rhs       I10,44                          1
    rhs       I10,45                          1
    rhs       I10,46                          1
    rhs       I10,47                          1
    rhs       I10,48                          1
    rhs       I10,50                          1
    rhs       I10,51                          1
    rhs       I10,52                          1
    rhs       I10,53                          1
    rhs       I10,54                          1
    rhs       I10,56                          1
    rhs       I10,57                          1
    rhs       I10,59                          1
    rhs       I11,12                          1
    rhs       I11,14                          1
    rhs       I11,15                          1
    rhs       I11,17                          1
    rhs       I11,21                          1
    rhs       I11,23                          1
    rhs       I11,25                          1
    rhs       I11,26                          1
    rhs       I11,29                          1
    rhs       I11,30                          1
    rhs       I11,31                          1
    rhs       I11,32                          1
    rhs       I11,33                          1
    rhs       I11,34                          1
    rhs       I11,35                          1
    rhs       I11,36                          1
    rhs       I11,37                          1
    rhs       I11,38                          1
    rhs       I11,39                          1
    rhs       I11,40                          1
    rhs       I11,42                          1
    rhs       I11,45                          1
    rhs       I11,46                          1
    rhs       I11,47                          1
    rhs       I11,48                          1
    rhs       I11,49                          1
    rhs       I11,52                          1
    rhs       I11,53                          1
    rhs       I11,54                          1
    rhs       I11,56                          1
    rhs       I11,57                          1
    rhs       I11,58                          1
    rhs       I11,59                          1
    rhs       I12,14                          1
    rhs       I12,15                          1
    rhs       I12,16                          1
    rhs       I12,17                          1
    rhs       I12,19                          1
    rhs       I12,20                          1
    rhs       I12,22                          1
    rhs       I12,23                          1
    rhs       I12,25                          1
    rhs       I12,26                          1
    rhs       I12,27                          1
    rhs       I12,29                          1
    rhs       I12,30                          1
    rhs       I12,31                          1
    rhs       I12,32                          1
    rhs       I12,33                          1
    rhs       I12,34                          1
    rhs       I12,35                          1
    rhs       I12,36                          1
    rhs       I12,37                          1
    rhs       I12,38                          1
    rhs       I12,39                          1
    rhs       I12,40                          1
    rhs       I12,42                          1
    rhs       I12,43                          1
    rhs       I12,44                          1
    rhs       I12,45                          1
    rhs       I12,46                          1
    rhs       I12,47                          1
    rhs       I12,48                          1
    rhs       I12,49                          1
    rhs       I12,50                          1
    rhs       I12,52                          1
    rhs       I12,53                          1
    rhs       I12,54                          1
    rhs       I12,55                          1
    rhs       I12,56                          1
    rhs       I12,58                          1
    rhs       I12,59                          1
    rhs       I13,14                          1
    rhs       I13,16                          1
    rhs       I13,17                          1
    rhs       I13,19                          1
    rhs       I13,20                          1
    rhs       I13,21                          1
    rhs       I13,22                          1
    rhs       I13,23                          1
    rhs       I13,24                          1
    rhs       I13,27                          1
    rhs       I13,28                          1
    rhs       I13,32                          1
    rhs       I13,33                          1
    rhs       I13,34                          1
    rhs       I13,36                          1
    rhs       I13,38                          1
    rhs       I13,39                          1
    rhs       I13,40                          1
    rhs       I13,41                          1
    rhs       I13,42                          1
    rhs       I13,43                          1
    rhs       I13,46                          1
    rhs       I13,50                          1
    rhs       I13,51                          1
    rhs       I13,53                          1
    rhs       I13,55                          1
    rhs       I13,56                          1
    rhs       I13,57                          1
    rhs       I13,58                          1
    rhs       I13,59                          1
    rhs       I14,18                          1
    rhs       I14,19                          1
    rhs       I14,20                          1
    rhs       I14,21                          1
    rhs       I14,25                          1
    rhs       I14,27                          1
    rhs       I14,28                          1
    rhs       I14,29                          1
    rhs       I14,31                          1
    rhs       I14,33                          1
    rhs       I14,35                          1
    rhs       I14,36                          1
    rhs       I14,37                          1
    rhs       I14,38                          1
    rhs       I14,40                          1
    rhs       I14,43                          1
    rhs       I14,44                          1
    rhs       I14,45                          1
    rhs       I14,46                          1
    rhs       I14,47                          1
    rhs       I14,48                          1
    rhs       I14,49                          1
    rhs       I14,50                          1
    rhs       I14,51                          1
    rhs       I14,52                          1
    rhs       I14,53                          1
    rhs       I14,54                          1
    rhs       I14,56                          1
    rhs       I14,57                          1
    rhs       I14,58                          1
    rhs       I15,16                          1
    rhs       I15,17                          1
    rhs       I15,18                          1
    rhs       I15,20                          1
    rhs       I15,23                          1
    rhs       I15,25                          1
    rhs       I15,26                          1
    rhs       I15,28                          1
    rhs       I15,32                          1
    rhs       I15,33                          1
    rhs       I15,35                          1
    rhs       I15,36                          1
    rhs       I15,37                          1
    rhs       I15,39                          1
    rhs       I15,41                          1
    rhs       I15,45                          1
    rhs       I15,46                          1
    rhs       I15,47                          1
    rhs       I15,49                          1
    rhs       I15,50                          1
    rhs       I15,51                          1
    rhs       I15,54                          1
    rhs       I15,55                          1
    rhs       I15,57                          1
    rhs       I15,58                          1
    rhs       I15,59                          1
    rhs       I16,17                          1
    rhs       I16,18                          1
    rhs       I16,19                          1
    rhs       I16,20                          1
    rhs       I16,21                          1
    rhs       I16,25                          1
    rhs       I16,28                          1
    rhs       I16,29                          1
    rhs       I16,30                          1
    rhs       I16,31                          1
    rhs       I16,32                          1
    rhs       I16,33                          1
    rhs       I16,35                          1
    rhs       I16,36                          1
    rhs       I16,37                          1
    rhs       I16,38                          1
    rhs       I16,40                          1
    rhs       I16,41                          1
    rhs       I16,42                          1
    rhs       I16,43                          1
    rhs       I16,46                          1
    rhs       I16,47                          1
    rhs       I16,49                          1
    rhs       I16,51                          1
    rhs       I16,52                          1
    rhs       I16,53                          1
    rhs       I16,54                          1
    rhs       I16,57                          1
    rhs       I16,59                          1
    rhs       I17,18                          1
    rhs       I17,20                          1
    rhs       I17,21                          1
    rhs       I17,22                          1
    rhs       I17,23                          1
    rhs       I17,25                          1
    rhs       I17,26                          1
    rhs       I17,28                          1
    rhs       I17,29                          1
    rhs       I17,30                          1
    rhs       I17,32                          1
    rhs       I17,33                          1
    rhs       I17,35                          1
    rhs       I17,36                          1
    rhs       I17,37                          1
    rhs       I17,38                          1
    rhs       I17,41                          1
    rhs       I17,42                          1
    rhs       I17,44                          1
    rhs       I17,45                          1
    rhs       I17,46                          1
    rhs       I17,47                          1
    rhs       I17,48                          1
    rhs       I17,49                          1
    rhs       I17,51                          1
    rhs       I17,53                          1
    rhs       I17,54                          1
    rhs       I17,55                          1
    rhs       I17,58                          1
    rhs       I17,59                          1
    rhs       I18,19                          1
    rhs       I18,22                          1
    rhs       I18,23                          1
    rhs       I18,25                          1
    rhs       I18,26                          1
    rhs       I18,28                          1
    rhs       I18,29                          1
    rhs       I18,30                          1
    rhs       I18,31                          1
    rhs       I18,32                          1
    rhs       I18,33                          1
    rhs       I18,34                          1
    rhs       I18,35                          1
    rhs       I18,36                          1
    rhs       I18,37                          1
    rhs       I18,38                          1
    rhs       I18,39                          1
    rhs       I18,40                          1
    rhs       I18,41                          1
    rhs       I18,42                          1
    rhs       I18,43                          1
    rhs       I18,44                          1
    rhs       I18,45                          1
    rhs       I18,47                          1
    rhs       I18,48                          1
    rhs       I18,50                          1
    rhs       I18,51                          1
    rhs       I18,52                          1
    rhs       I18,53                          1
    rhs       I18,54                          1
    rhs       I18,55                          1
    rhs       I18,56                          1
    rhs       I18,57                          1
    rhs       I18,59                          1
    rhs       I19,20                          1
    rhs       I19,21                          1
    rhs       I19,22                          1
    rhs       I19,24                          1
    rhs       I19,28                          1
    rhs       I19,29                          1
    rhs       I19,30                          1
    rhs       I19,31                          1
    rhs       I19,32                          1
    rhs       I19,36                          1
    rhs       I19,37                          1
    rhs       I19,39                          1
    rhs       I19,40                          1
    rhs       I19,42                          1
    rhs       I19,43                          1
    rhs       I19,44                          1
    rhs       I19,45                          1
    rhs       I19,49                          1
    rhs       I19,50                          1
    rhs       I19,51                          1
    rhs       I19,52                          1
    rhs       I19,53                          1
    rhs       I19,54                          1
    rhs       I19,55                          1
    rhs       I19,58                          1
    rhs       I19,59                          1
    rhs       I20,21                          1
    rhs       I20,22                          1
    rhs       I20,23                          1
    rhs       I20,24                          1
    rhs       I20,26                          1
    rhs       I20,27                          1
    rhs       I20,28                          1
    rhs       I20,29                          1
    rhs       I20,30                          1
    rhs       I20,32                          1
    rhs       I20,34                          1
    rhs       I20,35                          1
    rhs       I20,36                          1
    rhs       I20,39                          1
    rhs       I20,41                          1
    rhs       I20,42                          1
    rhs       I20,43                          1
    rhs       I20,44                          1
    rhs       I20,45                          1
    rhs       I20,47                          1
    rhs       I20,48                          1
    rhs       I20,49                          1
    rhs       I20,50                          1
    rhs       I20,52                          1
    rhs       I20,53                          1
    rhs       I20,55                          1
    rhs       I20,56                          1
    rhs       I20,57                          1
    rhs       I21,24                          1
    rhs       I21,25                          1
    rhs       I21,26                          1
    rhs       I21,27                          1
    rhs       I21,30                          1
    rhs       I21,32                          1
    rhs       I21,34                          1
    rhs       I21,35                          1
    rhs       I21,36                          1
    rhs       I21,37                          1
    rhs       I21,38                          1
    rhs       I21,39                          1
    rhs       I21,41                          1
    rhs       I21,42                          1
    rhs       I21,44                          1
    rhs       I21,45                          1
    rhs       I21,47                          1
    rhs       I21,49                          1
    rhs       I21,50                          1
    rhs       I21,52                          1
    rhs       I21,53                          1
    rhs       I21,54                          1
    rhs       I21,55                          1
    rhs       I21,56                          1
    rhs       I21,57                          1
    rhs       I22,25                          1
    rhs       I22,26                          1
    rhs       I22,27                          1
    rhs       I22,28                          1
    rhs       I22,29                          1
    rhs       I22,30                          1
    rhs       I22,31                          1
    rhs       I22,32                          1
    rhs       I22,33                          1
    rhs       I22,37                          1
    rhs       I22,38                          1
    rhs       I22,39                          1
    rhs       I22,41                          1
    rhs       I22,42                          1
    rhs       I22,44                          1
    rhs       I22,45                          1
    rhs       I22,46                          1
    rhs       I22,47                          1
    rhs       I22,48                          1
    rhs       I22,49                          1
    rhs       I22,50                          1
    rhs       I22,51                          1
    rhs       I22,53                          1
    rhs       I22,56                          1
    rhs       I22,58                          1
    rhs       I22,59                          1
    rhs       I23,24                          1
    rhs       I23,25                          1
    rhs       I23,26                          1
    rhs       I23,28                          1
    rhs       I23,29                          1
    rhs       I23,30                          1
    rhs       I23,31                          1
    rhs       I23,32                          1
    rhs       I23,33                          1
    rhs       I23,34                          1
    rhs       I23,36                          1
    rhs       I23,37                          1
    rhs       I23,38                          1
    rhs       I23,39                          1
    rhs       I23,40                          1
    rhs       I23,41                          1
    rhs       I23,42                          1
    rhs       I23,43                          1
    rhs       I23,47                          1
    rhs       I23,49                          1
    rhs       I23,50                          1
    rhs       I23,51                          1
    rhs       I23,52                          1
    rhs       I23,54                          1
    rhs       I23,55                          1
    rhs       I23,56                          1
    rhs       I23,57                          1
    rhs       I23,58                          1
    rhs       I23,59                          1
    rhs       I24,25                          1
    rhs       I24,27                          1
    rhs       I24,28                          1
    rhs       I24,29                          1
    rhs       I24,30                          1
    rhs       I24,32                          1
    rhs       I24,33                          1
    rhs       I24,34                          1
    rhs       I24,35                          1
    rhs       I24,36                          1
    rhs       I24,37                          1
    rhs       I24,39                          1
    rhs       I24,41                          1
    rhs       I24,42                          1
    rhs       I24,43                          1
    rhs       I24,44                          1
    rhs       I24,45                          1
    rhs       I24,46                          1
    rhs       I24,47                          1
    rhs       I24,48                          1
    rhs       I24,49                          1
    rhs       I24,50                          1
    rhs       I24,51                          1
    rhs       I24,52                          1
    rhs       I24,53                          1
    rhs       I24,56                          1
    rhs       I24,57                          1
    rhs       I24,59                          1
    rhs       I25,26                          1
    rhs       I25,28                          1
    rhs       I25,31                          1
    rhs       I25,32                          1
    rhs       I25,33                          1
    rhs       I25,34                          1
    rhs       I25,35                          1
    rhs       I25,37                          1
    rhs       I25,38                          1
    rhs       I25,39                          1
    rhs       I25,40                          1
    rhs       I25,42                          1
    rhs       I25,44                          1
    rhs       I25,45                          1
    rhs       I25,47                          1
    rhs       I25,48                          1
    rhs       I25,49                          1
    rhs       I25,50                          1
    rhs       I25,51                          1
    rhs       I25,52                          1
    rhs       I25,53                          1
    rhs       I25,54                          1
    rhs       I25,55                          1
    rhs       I25,56                          1
    rhs       I25,57                          1
    rhs       I25,59                          1
    rhs       I26,29                          1
    rhs       I26,30                          1
    rhs       I26,31                          1
    rhs       I26,32                          1
    rhs       I26,34                          1
    rhs       I26,35                          1
    rhs       I26,36                          1
    rhs       I26,37                          1
    rhs       I26,38                          1
    rhs       I26,39                          1
    rhs       I26,40                          1
    rhs       I26,41                          1
    rhs       I26,42                          1
    rhs       I26,43                          1
    rhs       I26,45                          1
    rhs       I26,46                          1
    rhs       I26,48                          1
    rhs       I26,49                          1
    rhs       I26,50                          1
    rhs       I26,51                          1
    rhs       I26,55                          1
    rhs       I26,56                          1
    rhs       I26,57                          1
    rhs       I26,58                          1
    rhs       I26,59                          1
    rhs       I27,28                          1
    rhs       I27,31                          1
    rhs       I27,32                          1
    rhs       I27,33                          1
    rhs       I27,34                          1
    rhs       I27,35                          1
    rhs       I27,36                          1
    rhs       I27,39                          1
    rhs       I27,40                          1
    rhs       I27,41                          1
    rhs       I27,42                          1
    rhs       I27,43                          1
    rhs       I27,44                          1
    rhs       I27,46                          1
    rhs       I27,47                          1
    rhs       I27,49                          1
    rhs       I27,50                          1
    rhs       I27,51                          1
    rhs       I27,52                          1
    rhs       I27,53                          1
    rhs       I27,55                          1
    rhs       I27,56                          1
    rhs       I27,57                          1
    rhs       I27,59                          1
    rhs       I28,29                          1
    rhs       I28,30                          1
    rhs       I28,32                          1
    rhs       I28,33                          1
    rhs       I28,34                          1
    rhs       I28,35                          1
    rhs       I28,36                          1
    rhs       I28,38                          1
    rhs       I28,44                          1
    rhs       I28,47                          1
    rhs       I28,48                          1
    rhs       I28,49                          1
    rhs       I28,50                          1
    rhs       I28,51                          1
    rhs       I28,53                          1
    rhs       I28,54                          1
    rhs       I28,57                          1
    rhs       I28,58                          1
    rhs       I29,30                          1
    rhs       I29,33                          1
    rhs       I29,34                          1
    rhs       I29,38                          1
    rhs       I29,42                          1
    rhs       I29,44                          1
    rhs       I29,46                          1
    rhs       I29,49                          1
    rhs       I29,50                          1
    rhs       I29,51                          1
    rhs       I29,53                          1
    rhs       I29,54                          1
    rhs       I29,55                          1
    rhs       I29,56                          1
    rhs       I29,57                          1
    rhs       I29,58                          1
    rhs       I29,59                          1
    rhs       I30,31                          1
    rhs       I30,35                          1
    rhs       I30,38                          1
    rhs       I30,39                          1
    rhs       I30,40                          1
    rhs       I30,41                          1
    rhs       I30,42                          1
    rhs       I30,43                          1
    rhs       I30,44                          1
    rhs       I30,45                          1
    rhs       I30,46                          1
    rhs       I30,47                          1
    rhs       I30,48                          1
    rhs       I30,49                          1
    rhs       I30,50                          1
    rhs       I30,51                          1
    rhs       I30,52                          1
    rhs       I30,53                          1
    rhs       I30,56                          1
    rhs       I30,57                          1
    rhs       I30,58                          1
    rhs       I30,59                          1
    rhs       I31,32                          1
    rhs       I31,33                          1
    rhs       I31,35                          1
    rhs       I31,36                          1
    rhs       I31,37                          1
    rhs       I31,38                          1
    rhs       I31,39                          1
    rhs       I31,40                          1
    rhs       I31,42                          1
    rhs       I31,43                          1
    rhs       I31,44                          1
    rhs       I31,46                          1
    rhs       I31,47                          1
    rhs       I31,48                          1
    rhs       I31,49                          1
    rhs       I31,52                          1
    rhs       I31,53                          1
    rhs       I31,54                          1
    rhs       I31,56                          1
    rhs       I31,58                          1
    rhs       I32,34                          1
    rhs       I32,37                          1
    rhs       I32,38                          1
    rhs       I32,39                          1
    rhs       I32,40                          1
    rhs       I32,41                          1
    rhs       I32,46                          1
    rhs       I32,47                          1
    rhs       I32,48                          1
    rhs       I32,50                          1
    rhs       I32,51                          1
    rhs       I32,53                          1
    rhs       I32,54                          1
    rhs       I32,55                          1
    rhs       I32,57                          1
    rhs       I32,58                          1
    rhs       I33,34                          1
    rhs       I33,36                          1
    rhs       I33,38                          1
    rhs       I33,40                          1
    rhs       I33,41                          1
    rhs       I33,42                          1
    rhs       I33,44                          1
    rhs       I33,46                          1
    rhs       I33,48                          1
    rhs       I33,49                          1
    rhs       I33,50                          1
    rhs       I33,52                          1
    rhs       I33,53                          1
    rhs       I33,54                          1
    rhs       I33,55                          1
    rhs       I33,56                          1
    rhs       I33,58                          1
    rhs       I33,59                          1
    rhs       I34,35                          1
    rhs       I34,36                          1
    rhs       I34,38                          1
    rhs       I34,40                          1
    rhs       I34,41                          1
    rhs       I34,43                          1
    rhs       I34,44                          1
    rhs       I34,45                          1
    rhs       I34,46                          1
    rhs       I34,47                          1
    rhs       I34,48                          1
    rhs       I34,49                          1
    rhs       I34,50                          1
    rhs       I34,52                          1
    rhs       I34,54                          1
    rhs       I34,55                          1
    rhs       I34,57                          1
    rhs       I34,58                          1
    rhs       I34,59                          1
    rhs       I35,36                          1
    rhs       I35,39                          1
    rhs       I35,40                          1
    rhs       I35,41                          1
    rhs       I35,43                          1
    rhs       I35,44                          1
    rhs       I35,45                          1
    rhs       I35,46                          1
    rhs       I35,47                          1
    rhs       I35,48                          1
    rhs       I35,49                          1
    rhs       I35,51                          1
    rhs       I35,52                          1
    rhs       I35,53                          1
    rhs       I35,54                          1
    rhs       I35,55                          1
    rhs       I35,57                          1
    rhs       I35,58                          1
    rhs       I35,59                          1
    rhs       I36,37                          1
    rhs       I36,38                          1
    rhs       I36,40                          1
    rhs       I36,41                          1
    rhs       I36,42                          1
    rhs       I36,44                          1
    rhs       I36,45                          1
    rhs       I36,47                          1
    rhs       I36,48                          1
    rhs       I36,49                          1
    rhs       I36,50                          1
    rhs       I36,51                          1
    rhs       I36,52                          1
    rhs       I36,53                          1
    rhs       I36,54                          1
    rhs       I36,55                          1
    rhs       I36,57                          1
    rhs       I36,58                          1
    rhs       I36,59                          1
    rhs       I37,38                          1
    rhs       I37,39                          1
    rhs       I37,40                          1
    rhs       I37,41                          1
    rhs       I37,42                          1
    rhs       I37,43                          1
    rhs       I37,44                          1
    rhs       I37,45                          1
    rhs       I37,46                          1
    rhs       I37,48                          1
    rhs       I37,49                          1
    rhs       I37,50                          1
    rhs       I37,51                          1
    rhs       I37,52                          1
    rhs       I37,53                          1
    rhs       I37,56                          1
    rhs       I37,57                          1
    rhs       I37,58                          1
    rhs       I38,39                          1
    rhs       I38,40                          1
    rhs       I38,41                          1
    rhs       I38,42                          1
    rhs       I38,44                          1
    rhs       I38,45                          1
    rhs       I38,47                          1
    rhs       I38,48                          1
    rhs       I38,50                          1
    rhs       I38,51                          1
    rhs       I38,52                          1
    rhs       I38,55                          1
    rhs       I38,56                          1
    rhs       I38,59                          1
    rhs       I39,40                          1
    rhs       I39,41                          1
    rhs       I39,42                          1
    rhs       I39,45                          1
    rhs       I39,46                          1
    rhs       I39,47                          1
    rhs       I39,50                          1
    rhs       I39,51                          1
    rhs       I39,52                          1
    rhs       I39,53                          1
    rhs       I39,54                          1
    rhs       I39,58                          1
    rhs       I39,59                          1
    rhs       I40,42                          1
    rhs       I40,43                          1
    rhs       I40,45                          1
    rhs       I40,46                          1
    rhs       I40,47                          1
    rhs       I40,49                          1
    rhs       I40,50                          1
    rhs       I40,53                          1
    rhs       I40,54                          1
    rhs       I40,55                          1
    rhs       I40,56                          1
    rhs       I40,59                          1
    rhs       I41,42                          1
    rhs       I41,43                          1
    rhs       I41,45                          1
    rhs       I41,46                          1
    rhs       I41,47                          1
    rhs       I41,50                          1
    rhs       I41,51                          1
    rhs       I41,52                          1
    rhs       I41,54                          1
    rhs       I41,55                          1
    rhs       I41,56                          1
    rhs       I42,43                          1
    rhs       I42,44                          1
    rhs       I42,46                          1
    rhs       I42,47                          1
    rhs       I42,48                          1
    rhs       I42,49                          1
    rhs       I42,50                          1
    rhs       I42,52                          1
    rhs       I42,53                          1
    rhs       I42,54                          1
    rhs       I42,56                          1
    rhs       I42,58                          1
    rhs       I42,59                          1
    rhs       I43,44                          1
    rhs       I43,45                          1
    rhs       I43,46                          1
    rhs       I43,48                          1
    rhs       I43,50                          1
    rhs       I43,52                          1
    rhs       I43,54                          1
    rhs       I43,56                          1
    rhs       I43,59                          1
    rhs       I44,47                          1
    rhs       I44,48                          1
    rhs       I44,50                          1
    rhs       I44,51                          1
    rhs       I44,52                          1
    rhs       I44,53                          1
    rhs       I44,54                          1
    rhs       I44,56                          1
    rhs       I44,57                          1
    rhs       I44,59                          1
    rhs       I45,47                          1
    rhs       I45,50                          1
    rhs       I45,54                          1
    rhs       I45,56                          1
    rhs       I45,58                          1
    rhs       I45,59                          1
    rhs       I46,47                          1
    rhs       I46,49                          1
    rhs       I46,50                          1
    rhs       I46,51                          1
    rhs       I46,53                          1
    rhs       I46,54                          1
    rhs       I46,55                          1
    rhs       I46,56                          1
    rhs       I46,58                          1
    rhs       I46,59                          1
    rhs       I47,48                          1
    rhs       I47,49                          1
    rhs       I47,50                          1
    rhs       I47,51                          1
    rhs       I47,52                          1
    rhs       I47,53                          1
    rhs       I47,55                          1
    rhs       I47,56                          1
    rhs       I47,57                          1
    rhs       I47,58                          1
    rhs       I47,59                          1
    rhs       I48,49                          1
    rhs       I48,50                          1
    rhs       I48,51                          1
    rhs       I48,53                          1
    rhs       I48,54                          1
    rhs       I48,55                          1
    rhs       I48,56                          1
    rhs       I48,57                          1
    rhs       I48,58                          1
    rhs       I48,59                          1
    rhs       I49,50                          1
    rhs       I49,53                          1
    rhs       I49,55                          1
    rhs       I49,56                          1
    rhs       I49,57                          1
    rhs       I49,58                          1
    rhs       I49,59                          1
    rhs       I50,52                          1
    rhs       I50,54                          1
    rhs       I50,55                          1
    rhs       I50,56                          1
    rhs       I50,57                          1
    rhs       I50,59                          1
    rhs       I51,52                          1
    rhs       I51,53                          1
    rhs       I51,55                          1
    rhs       I51,59                          1
    rhs       I52,53                          1
    rhs       I52,54                          1
    rhs       I52,58                          1
    rhs       I53,55                          1
    rhs       I53,56                          1
    rhs       I53,57                          1
    rhs       I53,58                          1
    rhs       I53,59                          1
    rhs       I54,55                          1
    rhs       I54,56                          1
    rhs       I54,57                          1
    rhs       I54,58                          1
    rhs       I54,59                          1
    rhs       I55,56                          1
    rhs       I55,57                          1
    rhs       I55,58                          1
    rhs       I55,59                          1
    rhs       I56,58                          1
    rhs       I57,59                          1
    rhs       I58,59                          1
BOUNDS
 BV bnd       w0,1    
 BV bnd       w0,2    
 BV bnd       w0,4    
 BV bnd       w0,7    
 BV bnd       w0,8    
 BV bnd       w0,9    
 BV bnd       w0,10   
 BV bnd       w0,11   
 BV bnd       w0,12   
 BV bnd       w0,13   
 BV bnd       w0,14   
 BV bnd       w0,15   
 BV bnd       w0,16   
 BV bnd       w0,17   
 BV bnd       w0,18   
 BV bnd       w0,20   
 BV bnd       w0,21   
 BV bnd       w0,23   
 BV bnd       w0,25   
 BV bnd       w0,27   
 BV bnd       w0,28   
 BV bnd       w0,29   
 BV bnd       w0,30   
 BV bnd       w0,31   
 BV bnd       w0,32   
 BV bnd       w0,33   
 BV bnd       w0,34   
 BV bnd       w0,35   
 BV bnd       w0,39   
 BV bnd       w0,41   
 BV bnd       w0,42   
 BV bnd       w0,45   
 BV bnd       w0,46   
 BV bnd       w0,48   
 BV bnd       w0,49   
 BV bnd       w0,52   
 BV bnd       w0,53   
 BV bnd       w0,54   
 BV bnd       w0,55   
 BV bnd       w0,57   
 BV bnd       w0,59   
 BV bnd       w1,2    
 BV bnd       w1,3    
 BV bnd       w1,4    
 BV bnd       w1,5    
 BV bnd       w1,6    
 BV bnd       w1,7    
 BV bnd       w1,8    
 BV bnd       w1,10   
 BV bnd       w1,12   
 BV bnd       w1,13   
 BV bnd       w1,14   
 BV bnd       w1,15   
 BV bnd       w1,16   
 BV bnd       w1,17   
 BV bnd       w1,18   
 BV bnd       w1,19   
 BV bnd       w1,22   
 BV bnd       w1,23   
 BV bnd       w1,25   
 BV bnd       w1,26   
 BV bnd       w1,28   
 BV bnd       w1,29   
 BV bnd       w1,31   
 BV bnd       w1,32   
 BV bnd       w1,34   
 BV bnd       w1,36   
 BV bnd       w1,37   
 BV bnd       w1,39   
 BV bnd       w1,40   
 BV bnd       w1,42   
 BV bnd       w1,44   
 BV bnd       w1,48   
 BV bnd       w1,49   
 BV bnd       w1,51   
 BV bnd       w1,52   
 BV bnd       w1,53   
 BV bnd       w1,54   
 BV bnd       w1,55   
 BV bnd       w1,56   
 BV bnd       w1,58   
 BV bnd       w1,59   
 BV bnd       w2,3    
 BV bnd       w2,4    
 BV bnd       w2,6    
 BV bnd       w2,9    
 BV bnd       w2,11   
 BV bnd       w2,12   
 BV bnd       w2,14   
 BV bnd       w2,15   
 BV bnd       w2,16   
 BV bnd       w2,17   
 BV bnd       w2,18   
 BV bnd       w2,19   
 BV bnd       w2,21   
 BV bnd       w2,22   
 BV bnd       w2,23   
 BV bnd       w2,24   
 BV bnd       w2,25   
 BV bnd       w2,27   
 BV bnd       w2,28   
 BV bnd       w2,29   
 BV bnd       w2,30   
 BV bnd       w2,31   
 BV bnd       w2,33   
 BV bnd       w2,34   
 BV bnd       w2,35   
 BV bnd       w2,38   
 BV bnd       w2,39   
 BV bnd       w2,40   
 BV bnd       w2,41   
 BV bnd       w2,42   
 BV bnd       w2,48   
 BV bnd       w2,50   
 BV bnd       w2,51   
 BV bnd       w2,52   
 BV bnd       w2,53   
 BV bnd       w2,55   
 BV bnd       w2,56   
 BV bnd       w2,57   
 BV bnd       w2,58   
 BV bnd       w2,59   
 BV bnd       w3,5    
 BV bnd       w3,6    
 BV bnd       w3,8    
 BV bnd       w3,9    
 BV bnd       w3,10   
 BV bnd       w3,11   
 BV bnd       w3,12   
 BV bnd       w3,13   
 BV bnd       w3,15   
 BV bnd       w3,17   
 BV bnd       w3,18   
 BV bnd       w3,19   
 BV bnd       w3,20   
 BV bnd       w3,22   
 BV bnd       w3,25   
 BV bnd       w3,26   
 BV bnd       w3,27   
 BV bnd       w3,28   
 BV bnd       w3,29   
 BV bnd       w3,31   
 BV bnd       w3,32   
 BV bnd       w3,34   
 BV bnd       w3,35   
 BV bnd       w3,37   
 BV bnd       w3,39   
 BV bnd       w3,42   
 BV bnd       w3,43   
 BV bnd       w3,45   
 BV bnd       w3,47   
 BV bnd       w3,48   
 BV bnd       w3,49   
 BV bnd       w3,50   
 BV bnd       w3,51   
 BV bnd       w3,52   
 BV bnd       w3,53   
 BV bnd       w3,54   
 BV bnd       w3,55   
 BV bnd       w3,56   
 BV bnd       w3,57   
 BV bnd       w3,59   
 BV bnd       w4,5    
 BV bnd       w4,7    
 BV bnd       w4,8    
 BV bnd       w4,10   
 BV bnd       w4,13   
 BV bnd       w4,14   
 BV bnd       w4,15   
 BV bnd       w4,16   
 BV bnd       w4,19   
 BV bnd       w4,20   
 BV bnd       w4,22   
 BV bnd       w4,24   
 BV bnd       w4,25   
 BV bnd       w4,26   
 BV bnd       w4,27   
 BV bnd       w4,30   
 BV bnd       w4,33   
 BV bnd       w4,36   
 BV bnd       w4,37   
 BV bnd       w4,38   
 BV bnd       w4,40   
 BV bnd       w4,41   
 BV bnd       w4,43   
 BV bnd       w4,46   
 BV bnd       w4,47   
 BV bnd       w4,48   
 BV bnd       w4,49   
 BV bnd       w4,51   
 BV bnd       w4,53   
 BV bnd       w4,55   
 BV bnd       w4,56   
 BV bnd       w4,57   
 BV bnd       w4,58   
 BV bnd       w5,7    
 BV bnd       w5,8    
 BV bnd       w5,9    
 BV bnd       w5,10   
 BV bnd       w5,13   
 BV bnd       w5,14   
 BV bnd       w5,15   
 BV bnd       w5,18   
 BV bnd       w5,20   
 BV bnd       w5,22   
 BV bnd       w5,23   
 BV bnd       w5,24   
 BV bnd       w5,25   
 BV bnd       w5,26   
 BV bnd       w5,27   
 BV bnd       w5,28   
 BV bnd       w5,29   
 BV bnd       w5,30   
 BV bnd       w5,31   
 BV bnd       w5,32   
 BV bnd       w5,36   
 BV bnd       w5,37   
 BV bnd       w5,38   
 BV bnd       w5,40   
 BV bnd       w5,43   
 BV bnd       w5,46   
 BV bnd       w5,47   
 BV bnd       w5,48   
 BV bnd       w5,49   
 BV bnd       w5,50   
 BV bnd       w5,51   
 BV bnd       w5,52   
 BV bnd       w5,53   
 BV bnd       w5,54   
 BV bnd       w6,7    
 BV bnd       w6,8    
 BV bnd       w6,10   
 BV bnd       w6,15   
 BV bnd       w6,17   
 BV bnd       w6,19   
 BV bnd       w6,22   
 BV bnd       w6,23   
 BV bnd       w6,24   
 BV bnd       w6,27   
 BV bnd       w6,30   
 BV bnd       w6,34   
 BV bnd       w6,35   
 BV bnd       w6,36   
 BV bnd       w6,37   
 BV bnd       w6,38   
 BV bnd       w6,39   
 BV bnd       w6,41   
 BV bnd       w6,43   
 BV bnd       w6,44   
 BV bnd       w6,46   
 BV bnd       w6,48   
 BV bnd       w6,49   
 BV bnd       w6,50   
 BV bnd       w6,51   
 BV bnd       w6,53   
 BV bnd       w6,54   
 BV bnd       w6,56   
 BV bnd       w6,57   
 BV bnd       w6,58   
 BV bnd       w6,59   
 BV bnd       w7,8    
 BV bnd       w7,9    
 BV bnd       w7,12   
 BV bnd       w7,15   
 BV bnd       w7,16   
 BV bnd       w7,17   
 BV bnd       w7,18   
 BV bnd       w7,19   
 BV bnd       w7,20   
 BV bnd       w7,23   
 BV bnd       w7,24   
 BV bnd       w7,26   
 BV bnd       w7,27   
 BV bnd       w7,28   
 BV bnd       w7,30   
 BV bnd       w7,32   
 BV bnd       w7,33   
 BV bnd       w7,34   
 BV bnd       w7,35   
 BV bnd       w7,36   
 BV bnd       w7,38   
 BV bnd       w7,40   
 BV bnd       w7,41   
 BV bnd       w7,42   
 BV bnd       w7,43   
 BV bnd       w7,44   
 BV bnd       w7,45   
 BV bnd       w7,46   
 BV bnd       w7,47   
 BV bnd       w7,50   
 BV bnd       w7,51   
 BV bnd       w7,52   
 BV bnd       w7,53   
 BV bnd       w7,54   
 BV bnd       w7,56   
 BV bnd       w7,57   
 BV bnd       w7,58   
 BV bnd       w8,10   
 BV bnd       w8,12   
 BV bnd       w8,13   
 BV bnd       w8,14   
 BV bnd       w8,15   
 BV bnd       w8,16   
 BV bnd       w8,18   
 BV bnd       w8,19   
 BV bnd       w8,20   
 BV bnd       w8,21   
 BV bnd       w8,22   
 BV bnd       w8,23   
 BV bnd       w8,24   
 BV bnd       w8,25   
 BV bnd       w8,26   
 BV bnd       w8,27   
 BV bnd       w8,28   
 BV bnd       w8,30   
 BV bnd       w8,31   
 BV bnd       w8,32   
 BV bnd       w8,33   
 BV bnd       w8,34   
 BV bnd       w8,37   
 BV bnd       w8,39   
 BV bnd       w8,40   
 BV bnd       w8,41   
 BV bnd       w8,42   
 BV bnd       w8,43   
 BV bnd       w8,44   
 BV bnd       w8,45   
 BV bnd       w8,46   
 BV bnd       w8,49   
 BV bnd       w8,50   
 BV bnd       w8,51   
 BV bnd       w8,53   
 BV bnd       w8,54   
 BV bnd       w8,55   
 BV bnd       w8,56   
 BV bnd       w8,57   
 BV bnd       w8,58   
 BV bnd       w9,12   
 BV bnd       w9,15   
 BV bnd       w9,16   
 BV bnd       w9,19   
 BV bnd       w9,21   
 BV bnd       w9,22   
 BV bnd       w9,23   
 BV bnd       w9,25   
 BV bnd       w9,26   
 BV bnd       w9,28   
 BV bnd       w9,29   
 BV bnd       w9,30   
 BV bnd       w9,31   
 BV bnd       w9,32   
 BV bnd       w9,33   
 BV bnd       w9,34   
 BV bnd       w9,35   
 BV bnd       w9,36   
 BV bnd       w9,37   
 BV bnd       w9,38   
 BV bnd       w9,39   
 BV bnd       w9,40   
 BV bnd       w9,41   
 BV bnd       w9,42   
 BV bnd       w9,43   
 BV bnd       w9,44   
 BV bnd       w9,45   
 BV bnd       w9,46   
 BV bnd       w9,49   
 BV bnd       w9,50   
 BV bnd       w9,52   
 BV bnd       w9,54   
 BV bnd       w9,55   
 BV bnd       w9,58   
 BV bnd       w9,59   
 BV bnd       w10,11  
 BV bnd       w10,13  
 BV bnd       w10,15  
 BV bnd       w10,16  
 BV bnd       w10,18  
 BV bnd       w10,19  
 BV bnd       w10,21  
 BV bnd       w10,23  
 BV bnd       w10,25  
 BV bnd       w10,26  
 BV bnd       w10,27  
 BV bnd       w10,28  
 BV bnd       w10,29  
 BV bnd       w10,30  
 BV bnd       w10,31  
 BV bnd       w10,32  
 BV bnd       w10,34  
 BV bnd       w10,35  
 BV bnd       w10,36  
 BV bnd       w10,38  
 BV bnd       w10,39  
 BV bnd       w10,40  
 BV bnd       w10,41  
 BV bnd       w10,42  
 BV bnd       w10,44  
 BV bnd       w10,45  
 BV bnd       w10,46  
 BV bnd       w10,47  
 BV bnd       w10,48  
 BV bnd       w10,50  
 BV bnd       w10,51  
 BV bnd       w10,52  
 BV bnd       w10,53  
 BV bnd       w10,54  
 BV bnd       w10,56  
 BV bnd       w10,57  
 BV bnd       w10,59  
 BV bnd       w11,12  
 BV bnd       w11,14  
 BV bnd       w11,15  
 BV bnd       w11,17  
 BV bnd       w11,21  
 BV bnd       w11,23  
 BV bnd       w11,25  
 BV bnd       w11,26  
 BV bnd       w11,29  
 BV bnd       w11,30  
 BV bnd       w11,31  
 BV bnd       w11,32  
 BV bnd       w11,33  
 BV bnd       w11,34  
 BV bnd       w11,35  
 BV bnd       w11,36  
 BV bnd       w11,37  
 BV bnd       w11,38  
 BV bnd       w11,39  
 BV bnd       w11,40  
 BV bnd       w11,42  
 BV bnd       w11,45  
 BV bnd       w11,46  
 BV bnd       w11,47  
 BV bnd       w11,48  
 BV bnd       w11,49  
 BV bnd       w11,52  
 BV bnd       w11,53  
 BV bnd       w11,54  
 BV bnd       w11,56  
 BV bnd       w11,57  
 BV bnd       w11,58  
 BV bnd       w11,59  
 BV bnd       w12,14  
 BV bnd       w12,15  
 BV bnd       w12,16  
 BV bnd       w12,17  
 BV bnd       w12,19  
 BV bnd       w12,20  
 BV bnd       w12,22  
 BV bnd       w12,23  
 BV bnd       w12,25  
 BV bnd       w12,26  
 BV bnd       w12,27  
 BV bnd       w12,29  
 BV bnd       w12,30  
 BV bnd       w12,31  
 BV bnd       w12,32  
 BV bnd       w12,33  
 BV bnd       w12,34  
 BV bnd       w12,35  
 BV bnd       w12,36  
 BV bnd       w12,37  
 BV bnd       w12,38  
 BV bnd       w12,39  
 BV bnd       w12,40  
 BV bnd       w12,42  
 BV bnd       w12,43  
 BV bnd       w12,44  
 BV bnd       w12,45  
 BV bnd       w12,46  
 BV bnd       w12,47  
 BV bnd       w12,48  
 BV bnd       w12,49  
 BV bnd       w12,50  
 BV bnd       w12,52  
 BV bnd       w12,53  
 BV bnd       w12,54  
 BV bnd       w12,55  
 BV bnd       w12,56  
 BV bnd       w12,58  
 BV bnd       w12,59  
 BV bnd       w13,14  
 BV bnd       w13,16  
 BV bnd       w13,17  
 BV bnd       w13,19  
 BV bnd       w13,20  
 BV bnd       w13,21  
 BV bnd       w13,22  
 BV bnd       w13,23  
 BV bnd       w13,24  
 BV bnd       w13,27  
 BV bnd       w13,28  
 BV bnd       w13,32  
 BV bnd       w13,33  
 BV bnd       w13,34  
 BV bnd       w13,36  
 BV bnd       w13,38  
 BV bnd       w13,39  
 BV bnd       w13,40  
 BV bnd       w13,41  
 BV bnd       w13,42  
 BV bnd       w13,43  
 BV bnd       w13,46  
 BV bnd       w13,50  
 BV bnd       w13,51  
 BV bnd       w13,53  
 BV bnd       w13,55  
 BV bnd       w13,56  
 BV bnd       w13,57  
 BV bnd       w13,58  
 BV bnd       w13,59  
 BV bnd       w14,18  
 BV bnd       w14,19  
 BV bnd       w14,20  
 BV bnd       w14,21  
 BV bnd       w14,25  
 BV bnd       w14,27  
 BV bnd       w14,28  
 BV bnd       w14,29  
 BV bnd       w14,31  
 BV bnd       w14,33  
 BV bnd       w14,35  
 BV bnd       w14,36  
 BV bnd       w14,37  
 BV bnd       w14,38  
 BV bnd       w14,40  
 BV bnd       w14,43  
 BV bnd       w14,44  
 BV bnd       w14,45  
 BV bnd       w14,46  
 BV bnd       w14,47  
 BV bnd       w14,48  
 BV bnd       w14,49  
 BV bnd       w14,50  
 BV bnd       w14,51  
 BV bnd       w14,52  
 BV bnd       w14,53  
 BV bnd       w14,54  
 BV bnd       w14,56  
 BV bnd       w14,57  
 BV bnd       w14,58  
 BV bnd       w15,16  
 BV bnd       w15,17  
 BV bnd       w15,18  
 BV bnd       w15,20  
 BV bnd       w15,23  
 BV bnd       w15,25  
 BV bnd       w15,26  
 BV bnd       w15,28  
 BV bnd       w15,32  
 BV bnd       w15,33  
 BV bnd       w15,35  
 BV bnd       w15,36  
 BV bnd       w15,37  
 BV bnd       w15,39  
 BV bnd       w15,41  
 BV bnd       w15,45  
 BV bnd       w15,46  
 BV bnd       w15,47  
 BV bnd       w15,49  
 BV bnd       w15,50  
 BV bnd       w15,51  
 BV bnd       w15,54  
 BV bnd       w15,55  
 BV bnd       w15,57  
 BV bnd       w15,58  
 BV bnd       w15,59  
 BV bnd       w16,17  
 BV bnd       w16,18  
 BV bnd       w16,19  
 BV bnd       w16,20  
 BV bnd       w16,21  
 BV bnd       w16,25  
 BV bnd       w16,28  
 BV bnd       w16,29  
 BV bnd       w16,30  
 BV bnd       w16,31  
 BV bnd       w16,32  
 BV bnd       w16,33  
 BV bnd       w16,35  
 BV bnd       w16,36  
 BV bnd       w16,37  
 BV bnd       w16,38  
 BV bnd       w16,40  
 BV bnd       w16,41  
 BV bnd       w16,42  
 BV bnd       w16,43  
 BV bnd       w16,46  
 BV bnd       w16,47  
 BV bnd       w16,49  
 BV bnd       w16,51  
 BV bnd       w16,52  
 BV bnd       w16,53  
 BV bnd       w16,54  
 BV bnd       w16,57  
 BV bnd       w16,59  
 BV bnd       w17,18  
 BV bnd       w17,20  
 BV bnd       w17,21  
 BV bnd       w17,22  
 BV bnd       w17,23  
 BV bnd       w17,25  
 BV bnd       w17,26  
 BV bnd       w17,28  
 BV bnd       w17,29  
 BV bnd       w17,30  
 BV bnd       w17,32  
 BV bnd       w17,33  
 BV bnd       w17,35  
 BV bnd       w17,36  
 BV bnd       w17,37  
 BV bnd       w17,38  
 BV bnd       w17,41  
 BV bnd       w17,42  
 BV bnd       w17,44  
 BV bnd       w17,45  
 BV bnd       w17,46  
 BV bnd       w17,47  
 BV bnd       w17,48  
 BV bnd       w17,49  
 BV bnd       w17,51  
 BV bnd       w17,53  
 BV bnd       w17,54  
 BV bnd       w17,55  
 BV bnd       w17,58  
 BV bnd       w17,59  
 BV bnd       w18,19  
 BV bnd       w18,22  
 BV bnd       w18,23  
 BV bnd       w18,25  
 BV bnd       w18,26  
 BV bnd       w18,28  
 BV bnd       w18,29  
 BV bnd       w18,30  
 BV bnd       w18,31  
 BV bnd       w18,32  
 BV bnd       w18,33  
 BV bnd       w18,34  
 BV bnd       w18,35  
 BV bnd       w18,36  
 BV bnd       w18,37  
 BV bnd       w18,38  
 BV bnd       w18,39  
 BV bnd       w18,40  
 BV bnd       w18,41  
 BV bnd       w18,42  
 BV bnd       w18,43  
 BV bnd       w18,44  
 BV bnd       w18,45  
 BV bnd       w18,47  
 BV bnd       w18,48  
 BV bnd       w18,50  
 BV bnd       w18,51  
 BV bnd       w18,52  
 BV bnd       w18,53  
 BV bnd       w18,54  
 BV bnd       w18,55  
 BV bnd       w18,56  
 BV bnd       w18,57  
 BV bnd       w18,59  
 BV bnd       w19,20  
 BV bnd       w19,21  
 BV bnd       w19,22  
 BV bnd       w19,24  
 BV bnd       w19,28  
 BV bnd       w19,29  
 BV bnd       w19,30  
 BV bnd       w19,31  
 BV bnd       w19,32  
 BV bnd       w19,36  
 BV bnd       w19,37  
 BV bnd       w19,39  
 BV bnd       w19,40  
 BV bnd       w19,42  
 BV bnd       w19,43  
 BV bnd       w19,44  
 BV bnd       w19,45  
 BV bnd       w19,49  
 BV bnd       w19,50  
 BV bnd       w19,51  
 BV bnd       w19,52  
 BV bnd       w19,53  
 BV bnd       w19,54  
 BV bnd       w19,55  
 BV bnd       w19,58  
 BV bnd       w19,59  
 BV bnd       w20,21  
 BV bnd       w20,22  
 BV bnd       w20,23  
 BV bnd       w20,24  
 BV bnd       w20,26  
 BV bnd       w20,27  
 BV bnd       w20,28  
 BV bnd       w20,29  
 BV bnd       w20,30  
 BV bnd       w20,32  
 BV bnd       w20,34  
 BV bnd       w20,35  
 BV bnd       w20,36  
 BV bnd       w20,39  
 BV bnd       w20,41  
 BV bnd       w20,42  
 BV bnd       w20,43  
 BV bnd       w20,44  
 BV bnd       w20,45  
 BV bnd       w20,47  
 BV bnd       w20,48  
 BV bnd       w20,49  
 BV bnd       w20,50  
 BV bnd       w20,52  
 BV bnd       w20,53  
 BV bnd       w20,55  
 BV bnd       w20,56  
 BV bnd       w20,57  
 BV bnd       w21,24  
 BV bnd       w21,25  
 BV bnd       w21,26  
 BV bnd       w21,27  
 BV bnd       w21,30  
 BV bnd       w21,32  
 BV bnd       w21,34  
 BV bnd       w21,35  
 BV bnd       w21,36  
 BV bnd       w21,37  
 BV bnd       w21,38  
 BV bnd       w21,39  
 BV bnd       w21,41  
 BV bnd       w21,42  
 BV bnd       w21,44  
 BV bnd       w21,45  
 BV bnd       w21,47  
 BV bnd       w21,49  
 BV bnd       w21,50  
 BV bnd       w21,52  
 BV bnd       w21,53  
 BV bnd       w21,54  
 BV bnd       w21,55  
 BV bnd       w21,56  
 BV bnd       w21,57  
 BV bnd       w22,25  
 BV bnd       w22,26  
 BV bnd       w22,27  
 BV bnd       w22,28  
 BV bnd       w22,29  
 BV bnd       w22,30  
 BV bnd       w22,31  
 BV bnd       w22,32  
 BV bnd       w22,33  
 BV bnd       w22,37  
 BV bnd       w22,38  
 BV bnd       w22,39  
 BV bnd       w22,41  
 BV bnd       w22,42  
 BV bnd       w22,44  
 BV bnd       w22,45  
 BV bnd       w22,46  
 BV bnd       w22,47  
 BV bnd       w22,48  
 BV bnd       w22,49  
 BV bnd       w22,50  
 BV bnd       w22,51  
 BV bnd       w22,53  
 BV bnd       w22,56  
 BV bnd       w22,58  
 BV bnd       w22,59  
 BV bnd       w23,24  
 BV bnd       w23,25  
 BV bnd       w23,26  
 BV bnd       w23,28  
 BV bnd       w23,29  
 BV bnd       w23,30  
 BV bnd       w23,31  
 BV bnd       w23,32  
 BV bnd       w23,33  
 BV bnd       w23,34  
 BV bnd       w23,36  
 BV bnd       w23,37  
 BV bnd       w23,38  
 BV bnd       w23,39  
 BV bnd       w23,40  
 BV bnd       w23,41  
 BV bnd       w23,42  
 BV bnd       w23,43  
 BV bnd       w23,47  
 BV bnd       w23,49  
 BV bnd       w23,50  
 BV bnd       w23,51  
 BV bnd       w23,52  
 BV bnd       w23,54  
 BV bnd       w23,55  
 BV bnd       w23,56  
 BV bnd       w23,57  
 BV bnd       w23,58  
 BV bnd       w23,59  
 BV bnd       w24,25  
 BV bnd       w24,27  
 BV bnd       w24,28  
 BV bnd       w24,29  
 BV bnd       w24,30  
 BV bnd       w24,32  
 BV bnd       w24,33  
 BV bnd       w24,34  
 BV bnd       w24,35  
 BV bnd       w24,36  
 BV bnd       w24,37  
 BV bnd       w24,39  
 BV bnd       w24,41  
 BV bnd       w24,42  
 BV bnd       w24,43  
 BV bnd       w24,44  
 BV bnd       w24,45  
 BV bnd       w24,46  
 BV bnd       w24,47  
 BV bnd       w24,48  
 BV bnd       w24,49  
 BV bnd       w24,50  
 BV bnd       w24,51  
 BV bnd       w24,52  
 BV bnd       w24,53  
 BV bnd       w24,56  
 BV bnd       w24,57  
 BV bnd       w24,59  
 BV bnd       w25,26  
 BV bnd       w25,28  
 BV bnd       w25,31  
 BV bnd       w25,32  
 BV bnd       w25,33  
 BV bnd       w25,34  
 BV bnd       w25,35  
 BV bnd       w25,37  
 BV bnd       w25,38  
 BV bnd       w25,39  
 BV bnd       w25,40  
 BV bnd       w25,42  
 BV bnd       w25,44  
 BV bnd       w25,45  
 BV bnd       w25,47  
 BV bnd       w25,48  
 BV bnd       w25,49  
 BV bnd       w25,50  
 BV bnd       w25,51  
 BV bnd       w25,52  
 BV bnd       w25,53  
 BV bnd       w25,54  
 BV bnd       w25,55  
 BV bnd       w25,56  
 BV bnd       w25,57  
 BV bnd       w25,59  
 BV bnd       w26,29  
 BV bnd       w26,30  
 BV bnd       w26,31  
 BV bnd       w26,32  
 BV bnd       w26,34  
 BV bnd       w26,35  
 BV bnd       w26,36  
 BV bnd       w26,37  
 BV bnd       w26,38  
 BV bnd       w26,39  
 BV bnd       w26,40  
 BV bnd       w26,41  
 BV bnd       w26,42  
 BV bnd       w26,43  
 BV bnd       w26,45  
 BV bnd       w26,46  
 BV bnd       w26,48  
 BV bnd       w26,49  
 BV bnd       w26,50  
 BV bnd       w26,51  
 BV bnd       w26,55  
 BV bnd       w26,56  
 BV bnd       w26,57  
 BV bnd       w26,58  
 BV bnd       w26,59  
 BV bnd       w27,28  
 BV bnd       w27,31  
 BV bnd       w27,32  
 BV bnd       w27,33  
 BV bnd       w27,34  
 BV bnd       w27,35  
 BV bnd       w27,36  
 BV bnd       w27,39  
 BV bnd       w27,40  
 BV bnd       w27,41  
 BV bnd       w27,42  
 BV bnd       w27,43  
 BV bnd       w27,44  
 BV bnd       w27,46  
 BV bnd       w27,47  
 BV bnd       w27,49  
 BV bnd       w27,50  
 BV bnd       w27,51  
 BV bnd       w27,52  
 BV bnd       w27,53  
 BV bnd       w27,55  
 BV bnd       w27,56  
 BV bnd       w27,57  
 BV bnd       w27,59  
 BV bnd       w28,29  
 BV bnd       w28,30  
 BV bnd       w28,32  
 BV bnd       w28,33  
 BV bnd       w28,34  
 BV bnd       w28,35  
 BV bnd       w28,36  
 BV bnd       w28,38  
 BV bnd       w28,44  
 BV bnd       w28,47  
 BV bnd       w28,48  
 BV bnd       w28,49  
 BV bnd       w28,50  
 BV bnd       w28,51  
 BV bnd       w28,53  
 BV bnd       w28,54  
 BV bnd       w28,57  
 BV bnd       w28,58  
 BV bnd       w29,30  
 BV bnd       w29,33  
 BV bnd       w29,34  
 BV bnd       w29,38  
 BV bnd       w29,42  
 BV bnd       w29,44  
 BV bnd       w29,46  
 BV bnd       w29,49  
 BV bnd       w29,50  
 BV bnd       w29,51  
 BV bnd       w29,53  
 BV bnd       w29,54  
 BV bnd       w29,55  
 BV bnd       w29,56  
 BV bnd       w29,57  
 BV bnd       w29,58  
 BV bnd       w29,59  
 BV bnd       w30,31  
 BV bnd       w30,35  
 BV bnd       w30,38  
 BV bnd       w30,39  
 BV bnd       w30,40  
 BV bnd       w30,41  
 BV bnd       w30,42  
 BV bnd       w30,43  
 BV bnd       w30,44  
 BV bnd       w30,45  
 BV bnd       w30,46  
 BV bnd       w30,47  
 BV bnd       w30,48  
 BV bnd       w30,49  
 BV bnd       w30,50  
 BV bnd       w30,51  
 BV bnd       w30,52  
 BV bnd       w30,53  
 BV bnd       w30,56  
 BV bnd       w30,57  
 BV bnd       w30,58  
 BV bnd       w30,59  
 BV bnd       w31,32  
 BV bnd       w31,33  
 BV bnd       w31,35  
 BV bnd       w31,36  
 BV bnd       w31,37  
 BV bnd       w31,38  
 BV bnd       w31,39  
 BV bnd       w31,40  
 BV bnd       w31,42  
 BV bnd       w31,43  
 BV bnd       w31,44  
 BV bnd       w31,46  
 BV bnd       w31,47  
 BV bnd       w31,48  
 BV bnd       w31,49  
 BV bnd       w31,52  
 BV bnd       w31,53  
 BV bnd       w31,54  
 BV bnd       w31,56  
 BV bnd       w31,58  
 BV bnd       w32,34  
 BV bnd       w32,37  
 BV bnd       w32,38  
 BV bnd       w32,39  
 BV bnd       w32,40  
 BV bnd       w32,41  
 BV bnd       w32,46  
 BV bnd       w32,47  
 BV bnd       w32,48  
 BV bnd       w32,50  
 BV bnd       w32,51  
 BV bnd       w32,53  
 BV bnd       w32,54  
 BV bnd       w32,55  
 BV bnd       w32,57  
 BV bnd       w32,58  
 BV bnd       w33,34  
 BV bnd       w33,36  
 BV bnd       w33,38  
 BV bnd       w33,40  
 BV bnd       w33,41  
 BV bnd       w33,42  
 BV bnd       w33,44  
 BV bnd       w33,46  
 BV bnd       w33,48  
 BV bnd       w33,49  
 BV bnd       w33,50  
 BV bnd       w33,52  
 BV bnd       w33,53  
 BV bnd       w33,54  
 BV bnd       w33,55  
 BV bnd       w33,56  
 BV bnd       w33,58  
 BV bnd       w33,59  
 BV bnd       w34,35  
 BV bnd       w34,36  
 BV bnd       w34,38  
 BV bnd       w34,40  
 BV bnd       w34,41  
 BV bnd       w34,43  
 BV bnd       w34,44  
 BV bnd       w34,45  
 BV bnd       w34,46  
 BV bnd       w34,47  
 BV bnd       w34,48  
 BV bnd       w34,49  
 BV bnd       w34,50  
 BV bnd       w34,52  
 BV bnd       w34,54  
 BV bnd       w34,55  
 BV bnd       w34,57  
 BV bnd       w34,58  
 BV bnd       w34,59  
 BV bnd       w35,36  
 BV bnd       w35,39  
 BV bnd       w35,40  
 BV bnd       w35,41  
 BV bnd       w35,43  
 BV bnd       w35,44  
 BV bnd       w35,45  
 BV bnd       w35,46  
 BV bnd       w35,47  
 BV bnd       w35,48  
 BV bnd       w35,49  
 BV bnd       w35,51  
 BV bnd       w35,52  
 BV bnd       w35,53  
 BV bnd       w35,54  
 BV bnd       w35,55  
 BV bnd       w35,57  
 BV bnd       w35,58  
 BV bnd       w35,59  
 BV bnd       w36,37  
 BV bnd       w36,38  
 BV bnd       w36,40  
 BV bnd       w36,41  
 BV bnd       w36,42  
 BV bnd       w36,44  
 BV bnd       w36,45  
 BV bnd       w36,47  
 BV bnd       w36,48  
 BV bnd       w36,49  
 BV bnd       w36,50  
 BV bnd       w36,51  
 BV bnd       w36,52  
 BV bnd       w36,53  
 BV bnd       w36,54  
 BV bnd       w36,55  
 BV bnd       w36,57  
 BV bnd       w36,58  
 BV bnd       w36,59  
 BV bnd       w37,38  
 BV bnd       w37,39  
 BV bnd       w37,40  
 BV bnd       w37,41  
 BV bnd       w37,42  
 BV bnd       w37,43  
 BV bnd       w37,44  
 BV bnd       w37,45  
 BV bnd       w37,46  
 BV bnd       w37,48  
 BV bnd       w37,49  
 BV bnd       w37,50  
 BV bnd       w37,51  
 BV bnd       w37,52  
 BV bnd       w37,53  
 BV bnd       w37,56  
 BV bnd       w37,57  
 BV bnd       w37,58  
 BV bnd       w38,39  
 BV bnd       w38,40  
 BV bnd       w38,41  
 BV bnd       w38,42  
 BV bnd       w38,44  
 BV bnd       w38,45  
 BV bnd       w38,47  
 BV bnd       w38,48  
 BV bnd       w38,50  
 BV bnd       w38,51  
 BV bnd       w38,52  
 BV bnd       w38,55  
 BV bnd       w38,56  
 BV bnd       w38,59  
 BV bnd       w39,40  
 BV bnd       w39,41  
 BV bnd       w39,42  
 BV bnd       w39,45  
 BV bnd       w39,46  
 BV bnd       w39,47  
 BV bnd       w39,50  
 BV bnd       w39,51  
 BV bnd       w39,52  
 BV bnd       w39,53  
 BV bnd       w39,54  
 BV bnd       w39,58  
 BV bnd       w39,59  
 BV bnd       w40,42  
 BV bnd       w40,43  
 BV bnd       w40,45  
 BV bnd       w40,46  
 BV bnd       w40,47  
 BV bnd       w40,49  
 BV bnd       w40,50  
 BV bnd       w40,53  
 BV bnd       w40,54  
 BV bnd       w40,55  
 BV bnd       w40,56  
 BV bnd       w40,59  
 BV bnd       w41,42  
 BV bnd       w41,43  
 BV bnd       w41,45  
 BV bnd       w41,46  
 BV bnd       w41,47  
 BV bnd       w41,50  
 BV bnd       w41,51  
 BV bnd       w41,52  
 BV bnd       w41,54  
 BV bnd       w41,55  
 BV bnd       w41,56  
 BV bnd       w42,43  
 BV bnd       w42,44  
 BV bnd       w42,46  
 BV bnd       w42,47  
 BV bnd       w42,48  
 BV bnd       w42,49  
 BV bnd       w42,50  
 BV bnd       w42,52  
 BV bnd       w42,53  
 BV bnd       w42,54  
 BV bnd       w42,56  
 BV bnd       w42,58  
 BV bnd       w42,59  
 BV bnd       w43,44  
 BV bnd       w43,45  
 BV bnd       w43,46  
 BV bnd       w43,48  
 BV bnd       w43,50  
 BV bnd       w43,52  
 BV bnd       w43,54  
 BV bnd       w43,56  
 BV bnd       w43,59  
 BV bnd       w44,47  
 BV bnd       w44,48  
 BV bnd       w44,50  
 BV bnd       w44,51  
 BV bnd       w44,52  
 BV bnd       w44,53  
 BV bnd       w44,54  
 BV bnd       w44,56  
 BV bnd       w44,57  
 BV bnd       w44,59  
 BV bnd       w45,47  
 BV bnd       w45,50  
 BV bnd       w45,54  
 BV bnd       w45,56  
 BV bnd       w45,58  
 BV bnd       w45,59  
 BV bnd       w46,47  
 BV bnd       w46,49  
 BV bnd       w46,50  
 BV bnd       w46,51  
 BV bnd       w46,53  
 BV bnd       w46,54  
 BV bnd       w46,55  
 BV bnd       w46,56  
 BV bnd       w46,58  
 BV bnd       w46,59  
 BV bnd       w47,48  
 BV bnd       w47,49  
 BV bnd       w47,50  
 BV bnd       w47,51  
 BV bnd       w47,52  
 BV bnd       w47,53  
 BV bnd       w47,55  
 BV bnd       w47,56  
 BV bnd       w47,57  
 BV bnd       w47,58  
 BV bnd       w47,59  
 BV bnd       w48,49  
 BV bnd       w48,50  
 BV bnd       w48,51  
 BV bnd       w48,53  
 BV bnd       w48,54  
 BV bnd       w48,55  
 BV bnd       w48,56  
 BV bnd       w48,57  
 BV bnd       w48,58  
 BV bnd       w48,59  
 BV bnd       w49,50  
 BV bnd       w49,53  
 BV bnd       w49,55  
 BV bnd       w49,56  
 BV bnd       w49,57  
 BV bnd       w49,58  
 BV bnd       w49,59  
 BV bnd       w50,52  
 BV bnd       w50,54  
 BV bnd       w50,55  
 BV bnd       w50,56  
 BV bnd       w50,57  
 BV bnd       w50,59  
 BV bnd       w51,52  
 BV bnd       w51,53  
 BV bnd       w51,55  
 BV bnd       w51,59  
 BV bnd       w52,53  
 BV bnd       w52,54  
 BV bnd       w52,58  
 BV bnd       w53,55  
 BV bnd       w53,56  
 BV bnd       w53,57  
 BV bnd       w53,58  
 BV bnd       w53,59  
 BV bnd       w54,55  
 BV bnd       w54,56  
 BV bnd       w54,57  
 BV bnd       w54,58  
 BV bnd       w54,59  
 BV bnd       w55,56  
 BV bnd       w55,57  
 BV bnd       w55,58  
 BV bnd       w55,59  
 BV bnd       w56,58  
 BV bnd       w57,59  
 BV bnd       w58,59  
 BV bnd       y0,1    
 BV bnd       y0,2    
 BV bnd       y0,4    
 BV bnd       y0,7    
 BV bnd       y0,8    
 BV bnd       y0,9    
 BV bnd       y0,10   
 BV bnd       y0,11   
 BV bnd       y0,12   
 BV bnd       y0,13   
 BV bnd       y0,14   
 BV bnd       y0,15   
 BV bnd       y0,16   
 BV bnd       y0,17   
 BV bnd       y0,18   
 BV bnd       y0,20   
 BV bnd       y0,21   
 BV bnd       y0,23   
 BV bnd       y0,25   
 BV bnd       y0,27   
 BV bnd       y0,28   
 BV bnd       y0,29   
 BV bnd       y0,30   
 BV bnd       y0,31   
 BV bnd       y0,32   
 BV bnd       y0,33   
 BV bnd       y0,34   
 BV bnd       y0,35   
 BV bnd       y0,39   
 BV bnd       y0,41   
 BV bnd       y0,42   
 BV bnd       y0,45   
 BV bnd       y0,46   
 BV bnd       y0,48   
 BV bnd       y0,49   
 BV bnd       y0,52   
 BV bnd       y0,53   
 BV bnd       y0,54   
 BV bnd       y0,55   
 BV bnd       y0,57   
 BV bnd       y0,59   
 BV bnd       y1,2    
 BV bnd       y1,3    
 BV bnd       y1,4    
 BV bnd       y1,5    
 BV bnd       y1,6    
 BV bnd       y1,7    
 BV bnd       y1,8    
 BV bnd       y1,10   
 BV bnd       y1,12   
 BV bnd       y1,13   
 BV bnd       y1,14   
 BV bnd       y1,15   
 BV bnd       y1,16   
 BV bnd       y1,17   
 BV bnd       y1,18   
 BV bnd       y1,19   
 BV bnd       y1,22   
 BV bnd       y1,23   
 BV bnd       y1,25   
 BV bnd       y1,26   
 BV bnd       y1,28   
 BV bnd       y1,29   
 BV bnd       y1,31   
 BV bnd       y1,32   
 BV bnd       y1,34   
 BV bnd       y1,36   
 BV bnd       y1,37   
 BV bnd       y1,39   
 BV bnd       y1,40   
 BV bnd       y1,42   
 BV bnd       y1,44   
 BV bnd       y1,48   
 BV bnd       y1,49   
 BV bnd       y1,51   
 BV bnd       y1,52   
 BV bnd       y1,53   
 BV bnd       y1,54   
 BV bnd       y1,55   
 BV bnd       y1,56   
 BV bnd       y1,58   
 BV bnd       y1,59   
 BV bnd       y2,3    
 BV bnd       y2,4    
 BV bnd       y2,6    
 BV bnd       y2,9    
 BV bnd       y2,11   
 BV bnd       y2,12   
 BV bnd       y2,14   
 BV bnd       y2,15   
 BV bnd       y2,16   
 BV bnd       y2,17   
 BV bnd       y2,18   
 BV bnd       y2,19   
 BV bnd       y2,21   
 BV bnd       y2,22   
 BV bnd       y2,23   
 BV bnd       y2,24   
 BV bnd       y2,25   
 BV bnd       y2,27   
 BV bnd       y2,28   
 BV bnd       y2,29   
 BV bnd       y2,30   
 BV bnd       y2,31   
 BV bnd       y2,33   
 BV bnd       y2,34   
 BV bnd       y2,35   
 BV bnd       y2,38   
 BV bnd       y2,39   
 BV bnd       y2,40   
 BV bnd       y2,41   
 BV bnd       y2,42   
 BV bnd       y2,48   
 BV bnd       y2,50   
 BV bnd       y2,51   
 BV bnd       y2,52   
 BV bnd       y2,53   
 BV bnd       y2,55   
 BV bnd       y2,56   
 BV bnd       y2,57   
 BV bnd       y2,58   
 BV bnd       y2,59   
 BV bnd       y3,5    
 BV bnd       y3,6    
 BV bnd       y3,8    
 BV bnd       y3,9    
 BV bnd       y3,10   
 BV bnd       y3,11   
 BV bnd       y3,12   
 BV bnd       y3,13   
 BV bnd       y3,15   
 BV bnd       y3,17   
 BV bnd       y3,18   
 BV bnd       y3,19   
 BV bnd       y3,20   
 BV bnd       y3,22   
 BV bnd       y3,25   
 BV bnd       y3,26   
 BV bnd       y3,27   
 BV bnd       y3,28   
 BV bnd       y3,29   
 BV bnd       y3,31   
 BV bnd       y3,32   
 BV bnd       y3,34   
 BV bnd       y3,35   
 BV bnd       y3,37   
 BV bnd       y3,39   
 BV bnd       y3,42   
 BV bnd       y3,43   
 BV bnd       y3,45   
 BV bnd       y3,47   
 BV bnd       y3,48   
 BV bnd       y3,49   
 BV bnd       y3,50   
 BV bnd       y3,51   
 BV bnd       y3,52   
 BV bnd       y3,53   
 BV bnd       y3,54   
 BV bnd       y3,55   
 BV bnd       y3,56   
 BV bnd       y3,57   
 BV bnd       y3,59   
 BV bnd       y4,5    
 BV bnd       y4,7    
 BV bnd       y4,8    
 BV bnd       y4,10   
 BV bnd       y4,13   
 BV bnd       y4,14   
 BV bnd       y4,15   
 BV bnd       y4,16   
 BV bnd       y4,19   
 BV bnd       y4,20   
 BV bnd       y4,22   
 BV bnd       y4,24   
 BV bnd       y4,25   
 BV bnd       y4,26   
 BV bnd       y4,27   
 BV bnd       y4,30   
 BV bnd       y4,33   
 BV bnd       y4,36   
 BV bnd       y4,37   
 BV bnd       y4,38   
 BV bnd       y4,40   
 BV bnd       y4,41   
 BV bnd       y4,43   
 BV bnd       y4,46   
 BV bnd       y4,47   
 BV bnd       y4,48   
 BV bnd       y4,49   
 BV bnd       y4,51   
 BV bnd       y4,53   
 BV bnd       y4,55   
 BV bnd       y4,56   
 BV bnd       y4,57   
 BV bnd       y4,58   
 BV bnd       y5,7    
 BV bnd       y5,8    
 BV bnd       y5,9    
 BV bnd       y5,10   
 BV bnd       y5,13   
 BV bnd       y5,14   
 BV bnd       y5,15   
 BV bnd       y5,18   
 BV bnd       y5,20   
 BV bnd       y5,22   
 BV bnd       y5,23   
 BV bnd       y5,24   
 BV bnd       y5,25   
 BV bnd       y5,26   
 BV bnd       y5,27   
 BV bnd       y5,28   
 BV bnd       y5,29   
 BV bnd       y5,30   
 BV bnd       y5,31   
 BV bnd       y5,32   
 BV bnd       y5,36   
 BV bnd       y5,37   
 BV bnd       y5,38   
 BV bnd       y5,40   
 BV bnd       y5,43   
 BV bnd       y5,46   
 BV bnd       y5,47   
 BV bnd       y5,48   
 BV bnd       y5,49   
 BV bnd       y5,50   
 BV bnd       y5,51   
 BV bnd       y5,52   
 BV bnd       y5,53   
 BV bnd       y5,54   
 BV bnd       y6,7    
 BV bnd       y6,8    
 BV bnd       y6,10   
 BV bnd       y6,15   
 BV bnd       y6,17   
 BV bnd       y6,19   
 BV bnd       y6,22   
 BV bnd       y6,23   
 BV bnd       y6,24   
 BV bnd       y6,27   
 BV bnd       y6,30   
 BV bnd       y6,34   
 BV bnd       y6,35   
 BV bnd       y6,36   
 BV bnd       y6,37   
 BV bnd       y6,38   
 BV bnd       y6,39   
 BV bnd       y6,41   
 BV bnd       y6,43   
 BV bnd       y6,44   
 BV bnd       y6,46   
 BV bnd       y6,48   
 BV bnd       y6,49   
 BV bnd       y6,50   
 BV bnd       y6,51   
 BV bnd       y6,53   
 BV bnd       y6,54   
 BV bnd       y6,56   
 BV bnd       y6,57   
 BV bnd       y6,58   
 BV bnd       y6,59   
 BV bnd       y7,8    
 BV bnd       y7,9    
 BV bnd       y7,12   
 BV bnd       y7,15   
 BV bnd       y7,16   
 BV bnd       y7,17   
 BV bnd       y7,18   
 BV bnd       y7,19   
 BV bnd       y7,20   
 BV bnd       y7,23   
 BV bnd       y7,24   
 BV bnd       y7,26   
 BV bnd       y7,27   
 BV bnd       y7,28   
 BV bnd       y7,30   
 BV bnd       y7,32   
 BV bnd       y7,33   
 BV bnd       y7,34   
 BV bnd       y7,35   
 BV bnd       y7,36   
 BV bnd       y7,38   
 BV bnd       y7,40   
 BV bnd       y7,41   
 BV bnd       y7,42   
 BV bnd       y7,43   
 BV bnd       y7,44   
 BV bnd       y7,45   
 BV bnd       y7,46   
 BV bnd       y7,47   
 BV bnd       y7,50   
 BV bnd       y7,51   
 BV bnd       y7,52   
 BV bnd       y7,53   
 BV bnd       y7,54   
 BV bnd       y7,56   
 BV bnd       y7,57   
 BV bnd       y7,58   
 BV bnd       y8,10   
 BV bnd       y8,12   
 BV bnd       y8,13   
 BV bnd       y8,14   
 BV bnd       y8,15   
 BV bnd       y8,16   
 BV bnd       y8,18   
 BV bnd       y8,19   
 BV bnd       y8,20   
 BV bnd       y8,21   
 BV bnd       y8,22   
 BV bnd       y8,23   
 BV bnd       y8,24   
 BV bnd       y8,25   
 BV bnd       y8,26   
 BV bnd       y8,27   
 BV bnd       y8,28   
 BV bnd       y8,30   
 BV bnd       y8,31   
 BV bnd       y8,32   
 BV bnd       y8,33   
 BV bnd       y8,34   
 BV bnd       y8,37   
 BV bnd       y8,39   
 BV bnd       y8,40   
 BV bnd       y8,41   
 BV bnd       y8,42   
 BV bnd       y8,43   
 BV bnd       y8,44   
 BV bnd       y8,45   
 BV bnd       y8,46   
 BV bnd       y8,49   
 BV bnd       y8,50   
 BV bnd       y8,51   
 BV bnd       y8,53   
 BV bnd       y8,54   
 BV bnd       y8,55   
 BV bnd       y8,56   
 BV bnd       y8,57   
 BV bnd       y8,58   
 BV bnd       y9,12   
 BV bnd       y9,15   
 BV bnd       y9,16   
 BV bnd       y9,19   
 BV bnd       y9,21   
 BV bnd       y9,22   
 BV bnd       y9,23   
 BV bnd       y9,25   
 BV bnd       y9,26   
 BV bnd       y9,28   
 BV bnd       y9,29   
 BV bnd       y9,30   
 BV bnd       y9,31   
 BV bnd       y9,32   
 BV bnd       y9,33   
 BV bnd       y9,34   
 BV bnd       y9,35   
 BV bnd       y9,36   
 BV bnd       y9,37   
 BV bnd       y9,38   
 BV bnd       y9,39   
 BV bnd       y9,40   
 BV bnd       y9,41   
 BV bnd       y9,42   
 BV bnd       y9,43   
 BV bnd       y9,44   
 BV bnd       y9,45   
 BV bnd       y9,46   
 BV bnd       y9,49   
 BV bnd       y9,50   
 BV bnd       y9,52   
 BV bnd       y9,54   
 BV bnd       y9,55   
 BV bnd       y9,58   
 BV bnd       y9,59   
 BV bnd       y10,11  
 BV bnd       y10,13  
 BV bnd       y10,15  
 BV bnd       y10,16  
 BV bnd       y10,18  
 BV bnd       y10,19  
 BV bnd       y10,21  
 BV bnd       y10,23  
 BV bnd       y10,25  
 BV bnd       y10,26  
 BV bnd       y10,27  
 BV bnd       y10,28  
 BV bnd       y10,29  
 BV bnd       y10,30  
 BV bnd       y10,31  
 BV bnd       y10,32  
 BV bnd       y10,34  
 BV bnd       y10,35  
 BV bnd       y10,36  
 BV bnd       y10,38  
 BV bnd       y10,39  
 BV bnd       y10,40  
 BV bnd       y10,41  
 BV bnd       y10,42  
 BV bnd       y10,44  
 BV bnd       y10,45  
 BV bnd       y10,46  
 BV bnd       y10,47  
 BV bnd       y10,48  
 BV bnd       y10,50  
 BV bnd       y10,51  
 BV bnd       y10,52  
 BV bnd       y10,53  
 BV bnd       y10,54  
 BV bnd       y10,56  
 BV bnd       y10,57  
 BV bnd       y10,59  
 BV bnd       y11,12  
 BV bnd       y11,14  
 BV bnd       y11,15  
 BV bnd       y11,17  
 BV bnd       y11,21  
 BV bnd       y11,23  
 BV bnd       y11,25  
 BV bnd       y11,26  
 BV bnd       y11,29  
 BV bnd       y11,30  
 BV bnd       y11,31  
 BV bnd       y11,32  
 BV bnd       y11,33  
 BV bnd       y11,34  
 BV bnd       y11,35  
 BV bnd       y11,36  
 BV bnd       y11,37  
 BV bnd       y11,38  
 BV bnd       y11,39  
 BV bnd       y11,40  
 BV bnd       y11,42  
 BV bnd       y11,45  
 BV bnd       y11,46  
 BV bnd       y11,47  
 BV bnd       y11,48  
 BV bnd       y11,49  
 BV bnd       y11,52  
 BV bnd       y11,53  
 BV bnd       y11,54  
 BV bnd       y11,56  
 BV bnd       y11,57  
 BV bnd       y11,58  
 BV bnd       y11,59  
 BV bnd       y12,14  
 BV bnd       y12,15  
 BV bnd       y12,16  
 BV bnd       y12,17  
 BV bnd       y12,19  
 BV bnd       y12,20  
 BV bnd       y12,22  
 BV bnd       y12,23  
 BV bnd       y12,25  
 BV bnd       y12,26  
 BV bnd       y12,27  
 BV bnd       y12,29  
 BV bnd       y12,30  
 BV bnd       y12,31  
 BV bnd       y12,32  
 BV bnd       y12,33  
 BV bnd       y12,34  
 BV bnd       y12,35  
 BV bnd       y12,36  
 BV bnd       y12,37  
 BV bnd       y12,38  
 BV bnd       y12,39  
 BV bnd       y12,40  
 BV bnd       y12,42  
 BV bnd       y12,43  
 BV bnd       y12,44  
 BV bnd       y12,45  
 BV bnd       y12,46  
 BV bnd       y12,47  
 BV bnd       y12,48  
 BV bnd       y12,49  
 BV bnd       y12,50  
 BV bnd       y12,52  
 BV bnd       y12,53  
 BV bnd       y12,54  
 BV bnd       y12,55  
 BV bnd       y12,56  
 BV bnd       y12,58  
 BV bnd       y12,59  
 BV bnd       y13,14  
 BV bnd       y13,16  
 BV bnd       y13,17  
 BV bnd       y13,19  
 BV bnd       y13,20  
 BV bnd       y13,21  
 BV bnd       y13,22  
 BV bnd       y13,23  
 BV bnd       y13,24  
 BV bnd       y13,27  
 BV bnd       y13,28  
 BV bnd       y13,32  
 BV bnd       y13,33  
 BV bnd       y13,34  
 BV bnd       y13,36  
 BV bnd       y13,38  
 BV bnd       y13,39  
 BV bnd       y13,40  
 BV bnd       y13,41  
 BV bnd       y13,42  
 BV bnd       y13,43  
 BV bnd       y13,46  
 BV bnd       y13,50  
 BV bnd       y13,51  
 BV bnd       y13,53  
 BV bnd       y13,55  
 BV bnd       y13,56  
 BV bnd       y13,57  
 BV bnd       y13,58  
 BV bnd       y13,59  
 BV bnd       y14,18  
 BV bnd       y14,19  
 BV bnd       y14,20  
 BV bnd       y14,21  
 BV bnd       y14,25  
 BV bnd       y14,27  
 BV bnd       y14,28  
 BV bnd       y14,29  
 BV bnd       y14,31  
 BV bnd       y14,33  
 BV bnd       y14,35  
 BV bnd       y14,36  
 BV bnd       y14,37  
 BV bnd       y14,38  
 BV bnd       y14,40  
 BV bnd       y14,43  
 BV bnd       y14,44  
 BV bnd       y14,45  
 BV bnd       y14,46  
 BV bnd       y14,47  
 BV bnd       y14,48  
 BV bnd       y14,49  
 BV bnd       y14,50  
 BV bnd       y14,51  
 BV bnd       y14,52  
 BV bnd       y14,53  
 BV bnd       y14,54  
 BV bnd       y14,56  
 BV bnd       y14,57  
 BV bnd       y14,58  
 BV bnd       y15,16  
 BV bnd       y15,17  
 BV bnd       y15,18  
 BV bnd       y15,20  
 BV bnd       y15,23  
 BV bnd       y15,25  
 BV bnd       y15,26  
 BV bnd       y15,28  
 BV bnd       y15,32  
 BV bnd       y15,33  
 BV bnd       y15,35  
 BV bnd       y15,36  
 BV bnd       y15,37  
 BV bnd       y15,39  
 BV bnd       y15,41  
 BV bnd       y15,45  
 BV bnd       y15,46  
 BV bnd       y15,47  
 BV bnd       y15,49  
 BV bnd       y15,50  
 BV bnd       y15,51  
 BV bnd       y15,54  
 BV bnd       y15,55  
 BV bnd       y15,57  
 BV bnd       y15,58  
 BV bnd       y15,59  
 BV bnd       y16,17  
 BV bnd       y16,18  
 BV bnd       y16,19  
 BV bnd       y16,20  
 BV bnd       y16,21  
 BV bnd       y16,25  
 BV bnd       y16,28  
 BV bnd       y16,29  
 BV bnd       y16,30  
 BV bnd       y16,31  
 BV bnd       y16,32  
 BV bnd       y16,33  
 BV bnd       y16,35  
 BV bnd       y16,36  
 BV bnd       y16,37  
 BV bnd       y16,38  
 BV bnd       y16,40  
 BV bnd       y16,41  
 BV bnd       y16,42  
 BV bnd       y16,43  
 BV bnd       y16,46  
 BV bnd       y16,47  
 BV bnd       y16,49  
 BV bnd       y16,51  
 BV bnd       y16,52  
 BV bnd       y16,53  
 BV bnd       y16,54  
 BV bnd       y16,57  
 BV bnd       y16,59  
 BV bnd       y17,18  
 BV bnd       y17,20  
 BV bnd       y17,21  
 BV bnd       y17,22  
 BV bnd       y17,23  
 BV bnd       y17,25  
 BV bnd       y17,26  
 BV bnd       y17,28  
 BV bnd       y17,29  
 BV bnd       y17,30  
 BV bnd       y17,32  
 BV bnd       y17,33  
 BV bnd       y17,35  
 BV bnd       y17,36  
 BV bnd       y17,37  
 BV bnd       y17,38  
 BV bnd       y17,41  
 BV bnd       y17,42  
 BV bnd       y17,44  
 BV bnd       y17,45  
 BV bnd       y17,46  
 BV bnd       y17,47  
 BV bnd       y17,48  
 BV bnd       y17,49  
 BV bnd       y17,51  
 BV bnd       y17,53  
 BV bnd       y17,54  
 BV bnd       y17,55  
 BV bnd       y17,58  
 BV bnd       y17,59  
 BV bnd       y18,19  
 BV bnd       y18,22  
 BV bnd       y18,23  
 BV bnd       y18,25  
 BV bnd       y18,26  
 BV bnd       y18,28  
 BV bnd       y18,29  
 BV bnd       y18,30  
 BV bnd       y18,31  
 BV bnd       y18,32  
 BV bnd       y18,33  
 BV bnd       y18,34  
 BV bnd       y18,35  
 BV bnd       y18,36  
 BV bnd       y18,37  
 BV bnd       y18,38  
 BV bnd       y18,39  
 BV bnd       y18,40  
 BV bnd       y18,41  
 BV bnd       y18,42  
 BV bnd       y18,43  
 BV bnd       y18,44  
 BV bnd       y18,45  
 BV bnd       y18,47  
 BV bnd       y18,48  
 BV bnd       y18,50  
 BV bnd       y18,51  
 BV bnd       y18,52  
 BV bnd       y18,53  
 BV bnd       y18,54  
 BV bnd       y18,55  
 BV bnd       y18,56  
 BV bnd       y18,57  
 BV bnd       y18,59  
 BV bnd       y19,20  
 BV bnd       y19,21  
 BV bnd       y19,22  
 BV bnd       y19,24  
 BV bnd       y19,28  
 BV bnd       y19,29  
 BV bnd       y19,30  
 BV bnd       y19,31  
 BV bnd       y19,32  
 BV bnd       y19,36  
 BV bnd       y19,37  
 BV bnd       y19,39  
 BV bnd       y19,40  
 BV bnd       y19,42  
 BV bnd       y19,43  
 BV bnd       y19,44  
 BV bnd       y19,45  
 BV bnd       y19,49  
 BV bnd       y19,50  
 BV bnd       y19,51  
 BV bnd       y19,52  
 BV bnd       y19,53  
 BV bnd       y19,54  
 BV bnd       y19,55  
 BV bnd       y19,58  
 BV bnd       y19,59  
 BV bnd       y20,21  
 BV bnd       y20,22  
 BV bnd       y20,23  
 BV bnd       y20,24  
 BV bnd       y20,26  
 BV bnd       y20,27  
 BV bnd       y20,28  
 BV bnd       y20,29  
 BV bnd       y20,30  
 BV bnd       y20,32  
 BV bnd       y20,34  
 BV bnd       y20,35  
 BV bnd       y20,36  
 BV bnd       y20,39  
 BV bnd       y20,41  
 BV bnd       y20,42  
 BV bnd       y20,43  
 BV bnd       y20,44  
 BV bnd       y20,45  
 BV bnd       y20,47  
 BV bnd       y20,48  
 BV bnd       y20,49  
 BV bnd       y20,50  
 BV bnd       y20,52  
 BV bnd       y20,53  
 BV bnd       y20,55  
 BV bnd       y20,56  
 BV bnd       y20,57  
 BV bnd       y21,24  
 BV bnd       y21,25  
 BV bnd       y21,26  
 BV bnd       y21,27  
 BV bnd       y21,30  
 BV bnd       y21,32  
 BV bnd       y21,34  
 BV bnd       y21,35  
 BV bnd       y21,36  
 BV bnd       y21,37  
 BV bnd       y21,38  
 BV bnd       y21,39  
 BV bnd       y21,41  
 BV bnd       y21,42  
 BV bnd       y21,44  
 BV bnd       y21,45  
 BV bnd       y21,47  
 BV bnd       y21,49  
 BV bnd       y21,50  
 BV bnd       y21,52  
 BV bnd       y21,53  
 BV bnd       y21,54  
 BV bnd       y21,55  
 BV bnd       y21,56  
 BV bnd       y21,57  
 BV bnd       y22,25  
 BV bnd       y22,26  
 BV bnd       y22,27  
 BV bnd       y22,28  
 BV bnd       y22,29  
 BV bnd       y22,30  
 BV bnd       y22,31  
 BV bnd       y22,32  
 BV bnd       y22,33  
 BV bnd       y22,37  
 BV bnd       y22,38  
 BV bnd       y22,39  
 BV bnd       y22,41  
 BV bnd       y22,42  
 BV bnd       y22,44  
 BV bnd       y22,45  
 BV bnd       y22,46  
 BV bnd       y22,47  
 BV bnd       y22,48  
 BV bnd       y22,49  
 BV bnd       y22,50  
 BV bnd       y22,51  
 BV bnd       y22,53  
 BV bnd       y22,56  
 BV bnd       y22,58  
 BV bnd       y22,59  
 BV bnd       y23,24  
 BV bnd       y23,25  
 BV bnd       y23,26  
 BV bnd       y23,28  
 BV bnd       y23,29  
 BV bnd       y23,30  
 BV bnd       y23,31  
 BV bnd       y23,32  
 BV bnd       y23,33  
 BV bnd       y23,34  
 BV bnd       y23,36  
 BV bnd       y23,37  
 BV bnd       y23,38  
 BV bnd       y23,39  
 BV bnd       y23,40  
 BV bnd       y23,41  
 BV bnd       y23,42  
 BV bnd       y23,43  
 BV bnd       y23,47  
 BV bnd       y23,49  
 BV bnd       y23,50  
 BV bnd       y23,51  
 BV bnd       y23,52  
 BV bnd       y23,54  
 BV bnd       y23,55  
 BV bnd       y23,56  
 BV bnd       y23,57  
 BV bnd       y23,58  
 BV bnd       y23,59  
 BV bnd       y24,25  
 BV bnd       y24,27  
 BV bnd       y24,28  
 BV bnd       y24,29  
 BV bnd       y24,30  
 BV bnd       y24,32  
 BV bnd       y24,33  
 BV bnd       y24,34  
 BV bnd       y24,35  
 BV bnd       y24,36  
 BV bnd       y24,37  
 BV bnd       y24,39  
 BV bnd       y24,41  
 BV bnd       y24,42  
 BV bnd       y24,43  
 BV bnd       y24,44  
 BV bnd       y24,45  
 BV bnd       y24,46  
 BV bnd       y24,47  
 BV bnd       y24,48  
 BV bnd       y24,49  
 BV bnd       y24,50  
 BV bnd       y24,51  
 BV bnd       y24,52  
 BV bnd       y24,53  
 BV bnd       y24,56  
 BV bnd       y24,57  
 BV bnd       y24,59  
 BV bnd       y25,26  
 BV bnd       y25,28  
 BV bnd       y25,31  
 BV bnd       y25,32  
 BV bnd       y25,33  
 BV bnd       y25,34  
 BV bnd       y25,35  
 BV bnd       y25,37  
 BV bnd       y25,38  
 BV bnd       y25,39  
 BV bnd       y25,40  
 BV bnd       y25,42  
 BV bnd       y25,44  
 BV bnd       y25,45  
 BV bnd       y25,47  
 BV bnd       y25,48  
 BV bnd       y25,49  
 BV bnd       y25,50  
 BV bnd       y25,51  
 BV bnd       y25,52  
 BV bnd       y25,53  
 BV bnd       y25,54  
 BV bnd       y25,55  
 BV bnd       y25,56  
 BV bnd       y25,57  
 BV bnd       y25,59  
 BV bnd       y26,29  
 BV bnd       y26,30  
 BV bnd       y26,31  
 BV bnd       y26,32  
 BV bnd       y26,34  
 BV bnd       y26,35  
 BV bnd       y26,36  
 BV bnd       y26,37  
 BV bnd       y26,38  
 BV bnd       y26,39  
 BV bnd       y26,40  
 BV bnd       y26,41  
 BV bnd       y26,42  
 BV bnd       y26,43  
 BV bnd       y26,45  
 BV bnd       y26,46  
 BV bnd       y26,48  
 BV bnd       y26,49  
 BV bnd       y26,50  
 BV bnd       y26,51  
 BV bnd       y26,55  
 BV bnd       y26,56  
 BV bnd       y26,57  
 BV bnd       y26,58  
 BV bnd       y26,59  
 BV bnd       y27,28  
 BV bnd       y27,31  
 BV bnd       y27,32  
 BV bnd       y27,33  
 BV bnd       y27,34  
 BV bnd       y27,35  
 BV bnd       y27,36  
 BV bnd       y27,39  
 BV bnd       y27,40  
 BV bnd       y27,41  
 BV bnd       y27,42  
 BV bnd       y27,43  
 BV bnd       y27,44  
 BV bnd       y27,46  
 BV bnd       y27,47  
 BV bnd       y27,49  
 BV bnd       y27,50  
 BV bnd       y27,51  
 BV bnd       y27,52  
 BV bnd       y27,53  
 BV bnd       y27,55  
 BV bnd       y27,56  
 BV bnd       y27,57  
 BV bnd       y27,59  
 BV bnd       y28,29  
 BV bnd       y28,30  
 BV bnd       y28,32  
 BV bnd       y28,33  
 BV bnd       y28,34  
 BV bnd       y28,35  
 BV bnd       y28,36  
 BV bnd       y28,38  
 BV bnd       y28,44  
 BV bnd       y28,47  
 BV bnd       y28,48  
 BV bnd       y28,49  
 BV bnd       y28,50  
 BV bnd       y28,51  
 BV bnd       y28,53  
 BV bnd       y28,54  
 BV bnd       y28,57  
 BV bnd       y28,58  
 BV bnd       y29,30  
 BV bnd       y29,33  
 BV bnd       y29,34  
 BV bnd       y29,38  
 BV bnd       y29,42  
 BV bnd       y29,44  
 BV bnd       y29,46  
 BV bnd       y29,49  
 BV bnd       y29,50  
 BV bnd       y29,51  
 BV bnd       y29,53  
 BV bnd       y29,54  
 BV bnd       y29,55  
 BV bnd       y29,56  
 BV bnd       y29,57  
 BV bnd       y29,58  
 BV bnd       y29,59  
 BV bnd       y30,31  
 BV bnd       y30,35  
 BV bnd       y30,38  
 BV bnd       y30,39  
 BV bnd       y30,40  
 BV bnd       y30,41  
 BV bnd       y30,42  
 BV bnd       y30,43  
 BV bnd       y30,44  
 BV bnd       y30,45  
 BV bnd       y30,46  
 BV bnd       y30,47  
 BV bnd       y30,48  
 BV bnd       y30,49  
 BV bnd       y30,50  
 BV bnd       y30,51  
 BV bnd       y30,52  
 BV bnd       y30,53  
 BV bnd       y30,56  
 BV bnd       y30,57  
 BV bnd       y30,58  
 BV bnd       y30,59  
 BV bnd       y31,32  
 BV bnd       y31,33  
 BV bnd       y31,35  
 BV bnd       y31,36  
 BV bnd       y31,37  
 BV bnd       y31,38  
 BV bnd       y31,39  
 BV bnd       y31,40  
 BV bnd       y31,42  
 BV bnd       y31,43  
 BV bnd       y31,44  
 BV bnd       y31,46  
 BV bnd       y31,47  
 BV bnd       y31,48  
 BV bnd       y31,49  
 BV bnd       y31,52  
 BV bnd       y31,53  
 BV bnd       y31,54  
 BV bnd       y31,56  
 BV bnd       y31,58  
 BV bnd       y32,34  
 BV bnd       y32,37  
 BV bnd       y32,38  
 BV bnd       y32,39  
 BV bnd       y32,40  
 BV bnd       y32,41  
 BV bnd       y32,46  
 BV bnd       y32,47  
 BV bnd       y32,48  
 BV bnd       y32,50  
 BV bnd       y32,51  
 BV bnd       y32,53  
 BV bnd       y32,54  
 BV bnd       y32,55  
 BV bnd       y32,57  
 BV bnd       y32,58  
 BV bnd       y33,34  
 BV bnd       y33,36  
 BV bnd       y33,38  
 BV bnd       y33,40  
 BV bnd       y33,41  
 BV bnd       y33,42  
 BV bnd       y33,44  
 BV bnd       y33,46  
 BV bnd       y33,48  
 BV bnd       y33,49  
 BV bnd       y33,50  
 BV bnd       y33,52  
 BV bnd       y33,53  
 BV bnd       y33,54  
 BV bnd       y33,55  
 BV bnd       y33,56  
 BV bnd       y33,58  
 BV bnd       y33,59  
 BV bnd       y34,35  
 BV bnd       y34,36  
 BV bnd       y34,38  
 BV bnd       y34,40  
 BV bnd       y34,41  
 BV bnd       y34,43  
 BV bnd       y34,44  
 BV bnd       y34,45  
 BV bnd       y34,46  
 BV bnd       y34,47  
 BV bnd       y34,48  
 BV bnd       y34,49  
 BV bnd       y34,50  
 BV bnd       y34,52  
 BV bnd       y34,54  
 BV bnd       y34,55  
 BV bnd       y34,57  
 BV bnd       y34,58  
 BV bnd       y34,59  
 BV bnd       y35,36  
 BV bnd       y35,39  
 BV bnd       y35,40  
 BV bnd       y35,41  
 BV bnd       y35,43  
 BV bnd       y35,44  
 BV bnd       y35,45  
 BV bnd       y35,46  
 BV bnd       y35,47  
 BV bnd       y35,48  
 BV bnd       y35,49  
 BV bnd       y35,51  
 BV bnd       y35,52  
 BV bnd       y35,53  
 BV bnd       y35,54  
 BV bnd       y35,55  
 BV bnd       y35,57  
 BV bnd       y35,58  
 BV bnd       y35,59  
 BV bnd       y36,37  
 BV bnd       y36,38  
 BV bnd       y36,40  
 BV bnd       y36,41  
 BV bnd       y36,42  
 BV bnd       y36,44  
 BV bnd       y36,45  
 BV bnd       y36,47  
 BV bnd       y36,48  
 BV bnd       y36,49  
 BV bnd       y36,50  
 BV bnd       y36,51  
 BV bnd       y36,52  
 BV bnd       y36,53  
 BV bnd       y36,54  
 BV bnd       y36,55  
 BV bnd       y36,57  
 BV bnd       y36,58  
 BV bnd       y36,59  
 BV bnd       y37,38  
 BV bnd       y37,39  
 BV bnd       y37,40  
 BV bnd       y37,41  
 BV bnd       y37,42  
 BV bnd       y37,43  
 BV bnd       y37,44  
 BV bnd       y37,45  
 BV bnd       y37,46  
 BV bnd       y37,48  
 BV bnd       y37,49  
 BV bnd       y37,50  
 BV bnd       y37,51  
 BV bnd       y37,52  
 BV bnd       y37,53  
 BV bnd       y37,56  
 BV bnd       y37,57  
 BV bnd       y37,58  
 BV bnd       y38,39  
 BV bnd       y38,40  
 BV bnd       y38,41  
 BV bnd       y38,42  
 BV bnd       y38,44  
 BV bnd       y38,45  
 BV bnd       y38,47  
 BV bnd       y38,48  
 BV bnd       y38,50  
 BV bnd       y38,51  
 BV bnd       y38,52  
 BV bnd       y38,55  
 BV bnd       y38,56  
 BV bnd       y38,59  
 BV bnd       y39,40  
 BV bnd       y39,41  
 BV bnd       y39,42  
 BV bnd       y39,45  
 BV bnd       y39,46  
 BV bnd       y39,47  
 BV bnd       y39,50  
 BV bnd       y39,51  
 BV bnd       y39,52  
 BV bnd       y39,53  
 BV bnd       y39,54  
 BV bnd       y39,58  
 BV bnd       y39,59  
 BV bnd       y40,42  
 BV bnd       y40,43  
 BV bnd       y40,45  
 BV bnd       y40,46  
 BV bnd       y40,47  
 BV bnd       y40,49  
 BV bnd       y40,50  
 BV bnd       y40,53  
 BV bnd       y40,54  
 BV bnd       y40,55  
 BV bnd       y40,56  
 BV bnd       y40,59  
 BV bnd       y41,42  
 BV bnd       y41,43  
 BV bnd       y41,45  
 BV bnd       y41,46  
 BV bnd       y41,47  
 BV bnd       y41,50  
 BV bnd       y41,51  
 BV bnd       y41,52  
 BV bnd       y41,54  
 BV bnd       y41,55  
 BV bnd       y41,56  
 BV bnd       y42,43  
 BV bnd       y42,44  
 BV bnd       y42,46  
 BV bnd       y42,47  
 BV bnd       y42,48  
 BV bnd       y42,49  
 BV bnd       y42,50  
 BV bnd       y42,52  
 BV bnd       y42,53  
 BV bnd       y42,54  
 BV bnd       y42,56  
 BV bnd       y42,58  
 BV bnd       y42,59  
 BV bnd       y43,44  
 BV bnd       y43,45  
 BV bnd       y43,46  
 BV bnd       y43,48  
 BV bnd       y43,50  
 BV bnd       y43,52  
 BV bnd       y43,54  
 BV bnd       y43,56  
 BV bnd       y43,59  
 BV bnd       y44,47  
 BV bnd       y44,48  
 BV bnd       y44,50  
 BV bnd       y44,51  
 BV bnd       y44,52  
 BV bnd       y44,53  
 BV bnd       y44,54  
 BV bnd       y44,56  
 BV bnd       y44,57  
 BV bnd       y44,59  
 BV bnd       y45,47  
 BV bnd       y45,50  
 BV bnd       y45,54  
 BV bnd       y45,56  
 BV bnd       y45,58  
 BV bnd       y45,59  
 BV bnd       y46,47  
 BV bnd       y46,49  
 BV bnd       y46,50  
 BV bnd       y46,51  
 BV bnd       y46,53  
 BV bnd       y46,54  
 BV bnd       y46,55  
 BV bnd       y46,56  
 BV bnd       y46,58  
 BV bnd       y46,59  
 BV bnd       y47,48  
 BV bnd       y47,49  
 BV bnd       y47,50  
 BV bnd       y47,51  
 BV bnd       y47,52  
 BV bnd       y47,53  
 BV bnd       y47,55  
 BV bnd       y47,56  
 BV bnd       y47,57  
 BV bnd       y47,58  
 BV bnd       y47,59  
 BV bnd       y48,49  
 BV bnd       y48,50  
 BV bnd       y48,51  
 BV bnd       y48,53  
 BV bnd       y48,54  
 BV bnd       y48,55  
 BV bnd       y48,56  
 BV bnd       y48,57  
 BV bnd       y48,58  
 BV bnd       y48,59  
 BV bnd       y49,50  
 BV bnd       y49,53  
 BV bnd       y49,55  
 BV bnd       y49,56  
 BV bnd       y49,57  
 BV bnd       y49,58  
 BV bnd       y49,59  
 BV bnd       y50,52  
 BV bnd       y50,54  
 BV bnd       y50,55  
 BV bnd       y50,56  
 BV bnd       y50,57  
 BV bnd       y50,59  
 BV bnd       y51,52  
 BV bnd       y51,53  
 BV bnd       y51,55  
 BV bnd       y51,59  
 BV bnd       y52,53  
 BV bnd       y52,54  
 BV bnd       y52,58  
 BV bnd       y53,55  
 BV bnd       y53,56  
 BV bnd       y53,57  
 BV bnd       y53,58  
 BV bnd       y53,59  
 BV bnd       y54,55  
 BV bnd       y54,56  
 BV bnd       y54,57  
 BV bnd       y54,58  
 BV bnd       y54,59  
 BV bnd       y55,56  
 BV bnd       y55,57  
 BV bnd       y55,58  
 BV bnd       y55,59  
 BV bnd       y56,58  
 BV bnd       y57,59  
 BV bnd       y58,59  
 BV bnd       x0      
 BV bnd       x1      
 BV bnd       x2      
 BV bnd       x3      
 BV bnd       x4      
 BV bnd       x5      
 BV bnd       x6      
 BV bnd       x7      
 BV bnd       x8      
 BV bnd       x9      
 BV bnd       x10     
 BV bnd       x11     
 BV bnd       x12     
 BV bnd       x13     
 BV bnd       x14     
 BV bnd       x15     
 BV bnd       x16     
 BV bnd       x17     
 BV bnd       x18     
 BV bnd       x19     
 BV bnd       x20     
 BV bnd       x21     
 BV bnd       x22     
 BV bnd       x23     
 BV bnd       x24     
 BV bnd       x25     
 BV bnd       x26     
 BV bnd       x27     
 BV bnd       x28     
 BV bnd       x29     
 BV bnd       x30     
 BV bnd       x31     
 BV bnd       x32     
 BV bnd       x33     
 BV bnd       x34     
 BV bnd       x35     
 BV bnd       x36     
 BV bnd       x37     
 BV bnd       x38     
 BV bnd       x39     
 BV bnd       x40     
 BV bnd       x41     
 BV bnd       x42     
 BV bnd       x43     
 BV bnd       x44     
 BV bnd       x45     
 BV bnd       x46     
 BV bnd       x47     
 BV bnd       x48     
 BV bnd       x49     
 BV bnd       x50     
 BV bnd       x51     
 BV bnd       x52     
 BV bnd       x53     
 BV bnd       x54     
 BV bnd       x55     
 BV bnd       x56     
 BV bnd       x57     
 BV bnd       x58     
 BV bnd       x59     
ENDATA
